/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.rd.pageindicatorview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int alpha = 2130968632;
        public static final int font = 2130969071;
        public static final int fontProviderAuthority = 2130969073;
        public static final int fontProviderCerts = 2130969074;
        public static final int fontProviderFetchStrategy = 2130969075;
        public static final int fontProviderFetchTimeout = 2130969076;
        public static final int fontProviderPackage = 2130969077;
        public static final int fontProviderQuery = 2130969078;
        public static final int fontStyle = 2130969080;
        public static final int fontVariationSettings = 2130969081;
        public static final int fontWeight = 2130969082;
        public static final int piv_animationDuration = 2130969466;
        public static final int piv_animationType = 2130969467;
        public static final int piv_autoVisibility = 2130969468;
        public static final int piv_count = 2130969469;
        public static final int piv_dynamicCount = 2130969470;
        public static final int piv_fadeOnIdle = 2130969471;
        public static final int piv_idleDuration = 2130969472;
        public static final int piv_interactiveAnimation = 2130969473;
        public static final int piv_orientation = 2130969474;
        public static final int piv_padding = 2130969475;
        public static final int piv_radius = 2130969476;
        public static final int piv_rtl_mode = 2130969477;
        public static final int piv_scaleFactor = 2130969478;
        public static final int piv_select = 2130969479;
        public static final int piv_selectedColor = 2130969480;
        public static final int piv_strokeWidth = 2130969481;
        public static final int piv_unselectedColor = 2130969482;
        public static final int piv_viewPager = 2130969483;
        public static final int ttcIndex = 2130969830;

        private attr() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 2131100444;
        public static final int notification_icon_bg_color = 2131100445;
        public static final int ripple_material_light = 2131100526;
        public static final int secondary_text_default_material_light = 2131100528;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131165280;
        public static final int compat_button_inset_vertical_material = 2131165281;
        public static final int compat_button_padding_horizontal_material = 2131165282;
        public static final int compat_button_padding_vertical_material = 2131165283;
        public static final int compat_control_corner_material = 2131165284;
        public static final int compat_notification_large_icon_max_height = 2131165285;
        public static final int compat_notification_large_icon_max_width = 2131165286;
        public static final int notification_action_icon_size = 2131165763;
        public static final int notification_action_text_size = 2131165764;
        public static final int notification_big_circle_margin = 2131165765;
        public static final int notification_content_margin_start = 2131165768;
        public static final int notification_large_icon_height = 2131165769;
        public static final int notification_large_icon_width = 2131165770;
        public static final int notification_main_column_padding_top = 2131165772;
        public static final int notification_media_narrow_margin = 2131165773;
        public static final int notification_right_icon_size = 2131165774;
        public static final int notification_right_side_padding_top = 2131165775;
        public static final int notification_small_icon_background_padding = 2131165776;
        public static final int notification_small_icon_size_as_large = 2131165777;
        public static final int notification_subtext_size = 2131165779;
        public static final int notification_top_pad = 2131165780;
        public static final int notification_top_pad_large_text = 2131165781;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 2131231008;
        public static final int notification_bg = 2131231009;
        public static final int notification_bg_low = 2131231011;
        public static final int notification_bg_low_normal = 2131231012;
        public static final int notification_bg_low_pressed = 2131231013;
        public static final int notification_bg_normal = 2131231014;
        public static final int notification_bg_normal_pressed = 2131231015;
        public static final int notification_icon_background = 2131231017;
        public static final int notification_template_icon_bg = 2131231018;
        public static final int notification_template_icon_low_bg = 2131231019;
        public static final int notification_tile_bg = 2131231020;
        public static final int notify_panel_notification_icon_bg = 2131231021;

        private drawable() {
        }
    }

    public static final class id {
        public static final int action_container = 2131361854;
        public static final int action_divider = 2131361856;
        public static final int action_image = 2131361857;
        public static final int action_text = 2131361864;
        public static final int actions = 2131361865;
        public static final int async = 2131361902;
        public static final int auto = 2131361903;
        public static final int blocking = 2131361917;
        public static final int chronometer = 2131361960;
        public static final int color = 2131361970;
        public static final int drop = 2131362035;
        public static final int fill = 2131362066;
        public static final int forever = 2131362081;
        public static final int horizontal = 2131362110;
        public static final int icon = 2131362112;
        public static final int icon_group = 2131362114;
        public static final int info = 2131362130;
        public static final int italic = 2131362140;
        public static final int line1 = 2131362166;
        public static final int line3 = 2131362167;
        public static final int none = 2131362269;
        public static final int normal = 2131362270;
        public static final int notification_background = 2131362274;
        public static final int notification_main_column = 2131362275;
        public static final int notification_main_column_container = 2131362276;
        public static final int off = 2131362281;
        public static final int on = 2131362283;
        public static final int right_icon = 2131362341;
        public static final int right_side = 2131362342;
        public static final int scale = 2131362355;
        public static final int scale_down = 2131362356;
        public static final int slide = 2131362393;
        public static final int swap = 2131362435;
        public static final int tag_transition_group = 2131362447;
        public static final int tag_unhandled_key_event_manager = 2131362448;
        public static final int tag_unhandled_key_listeners = 2131362449;
        public static final int text = 2131362455;
        public static final int text2 = 2131362456;
        public static final int thinWorm = 2131362478;
        public static final int time = 2131362481;
        public static final int title = 2131362482;
        public static final int vertical = 2131362537;
        public static final int worm = 2131362554;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131427383;

        private integer() {
        }
    }

    public static final class layout {
        public static final int notification_action = 2131558524;
        public static final int notification_action_tombstone = 2131558526;
        public static final int notification_template_custom_big = 2131558538;
        public static final int notification_template_icon_group = 2131558539;
        public static final int notification_template_part_chronometer = 2131558543;
        public static final int notification_template_part_time = 2131558544;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131886405;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131952115;
        public static final int TextAppearance_Compat_Notification_Info = 2131952116;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131952118;
        public static final int TextAppearance_Compat_Notification_Time = 2131952121;
        public static final int TextAppearance_Compat_Notification_Title = 2131952123;
        public static final int Widget_Compat_NotificationActionContainer = 2131952469;
        public static final int Widget_Compat_NotificationActionText = 2131952470;

        private style() {
        }
    }

    public static final class styleable {
        public static final int[] ColorStateListItem = new int[]{16843173, 16843551, 16844359, 2130968632, 2130969184};
        public static final int ColorStateListItem_alpha = 3;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_lStar = 2;
        public static final int ColorStateListItem_lStar = 4;
        public static final int[] FontFamily = new int[]{2130969073, 2130969074, 2130969075, 2130969076, 2130969077, 2130969078, 2130969079};
        public static final int[] FontFamilyFont = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130969071, 2130969080, 2130969081, 2130969082, 2130969830};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = new int[]{16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
        public static final int[] PageIndicatorView = new int[]{2130969466, 2130969467, 2130969468, 2130969469, 2130969470, 2130969471, 2130969472, 2130969473, 2130969474, 2130969475, 2130969476, 2130969477, 2130969478, 2130969479, 2130969480, 2130969481, 2130969482, 2130969483};
        public static final int PageIndicatorView_piv_animationDuration = 0;
        public static final int PageIndicatorView_piv_animationType = 1;
        public static final int PageIndicatorView_piv_autoVisibility = 2;
        public static final int PageIndicatorView_piv_count = 3;
        public static final int PageIndicatorView_piv_dynamicCount = 4;
        public static final int PageIndicatorView_piv_fadeOnIdle = 5;
        public static final int PageIndicatorView_piv_idleDuration = 6;
        public static final int PageIndicatorView_piv_interactiveAnimation = 7;
        public static final int PageIndicatorView_piv_orientation = 8;
        public static final int PageIndicatorView_piv_padding = 9;
        public static final int PageIndicatorView_piv_radius = 10;
        public static final int PageIndicatorView_piv_rtl_mode = 11;
        public static final int PageIndicatorView_piv_scaleFactor = 12;
        public static final int PageIndicatorView_piv_select = 13;
        public static final int PageIndicatorView_piv_selectedColor = 14;
        public static final int PageIndicatorView_piv_strokeWidth = 15;
        public static final int PageIndicatorView_piv_unselectedColor = 16;
        public static final int PageIndicatorView_piv_viewPager = 17;

        private styleable() {
        }
    }

}

