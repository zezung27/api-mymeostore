/*
 * Decompiled with CFR 0.0.
 */
package com.rd.animation.data.type;

import com.rd.animation.data.Value;
import com.rd.animation.data.type.ColorAnimationValue;

public class ScaleAnimationValue
extends ColorAnimationValue
implements Value {
    private int radius;
    private int radiusReverse;

    public int getRadius() {
        return this.radius;
    }

    public int getRadiusReverse() {
        return this.radiusReverse;
    }

    public void setRadius(int n) {
        this.radius = n;
    }

    public void setRadiusReverse(int n) {
        this.radiusReverse = n;
    }
}

