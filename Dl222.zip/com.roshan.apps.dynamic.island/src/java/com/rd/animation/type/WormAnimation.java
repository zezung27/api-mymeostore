/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.AnimatorSet
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.rd.animation.type;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import com.rd.animation.controller.ValueController;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.WormAnimationValue;
import com.rd.animation.type.BaseAnimation;
import java.util.ArrayList;
import java.util.Iterator;

public class WormAnimation
extends BaseAnimation<AnimatorSet> {
    int coordinateEnd;
    int coordinateStart;
    boolean isRightSide;
    int radius;
    int rectLeftEdge;
    int rectRightEdge;
    private WormAnimationValue value = new WormAnimationValue();

    public WormAnimation(ValueController.UpdateListener updateListener) {
        super(updateListener);
    }

    private void onAnimateUpdated(WormAnimationValue wormAnimationValue, ValueAnimator valueAnimator, boolean bl) {
        int n = (Integer)valueAnimator.getAnimatedValue();
        if (this.isRightSide) {
            if (!bl) {
                wormAnimationValue.setRectEnd(n);
            } else {
                wormAnimationValue.setRectStart(n);
            }
        } else if (!bl) {
            wormAnimationValue.setRectStart(n);
        } else {
            wormAnimationValue.setRectEnd(n);
        }
        if (this.listener != null) {
            this.listener.onValueUpdated(wormAnimationValue);
        }
    }

    @Override
    public AnimatorSet createAnimator() {
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
        return animatorSet;
    }

    RectValues createRectValues(boolean bl) {
        int n;
        int n2;
        int n3;
        int n4;
        if (bl) {
            int n5 = this.coordinateStart;
            int n6 = this.radius;
            n3 = n5 + n6;
            int n7 = this.coordinateEnd;
            n2 = n7 + n6;
            n4 = n5 - n6;
            n = n7 - n6;
        } else {
            int n8 = this.coordinateStart;
            int n9 = this.radius;
            n3 = n8 - n9;
            int n10 = this.coordinateEnd;
            n2 = n10 - n9;
            n4 = n8 + n9;
            n = n10 + n9;
        }
        int n11 = n4;
        int n12 = n3;
        int n13 = n;
        int n14 = n2;
        RectValues rectValues = new RectValues(n12, n14, n11, n13);
        return rectValues;
    }

    ValueAnimator createWormAnimator(int n, int n2, long l, final boolean bl, final WormAnimationValue wormAnimationValue) {
        ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])new int[]{n, n2});
        valueAnimator.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
        valueAnimator.setDuration(l);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                WormAnimation.this.onAnimateUpdated(wormAnimationValue, valueAnimator, bl);
            }
        });
        return valueAnimator;
    }

    @Override
    public WormAnimation duration(long l) {
        super.duration(l);
        return this;
    }

    boolean hasChanges(int n, int n2, int n3, boolean bl) {
        if (this.coordinateStart != n) {
            return true;
        }
        if (this.coordinateEnd != n2) {
            return true;
        }
        if (this.radius != n3) {
            return true;
        }
        return this.isRightSide != bl;
    }

    @Override
    public WormAnimation progress(float f) {
        if (this.animator == null) {
            return this;
        }
        long l = (long)(f * (float)this.animationDuration);
        Iterator iterator = ((AnimatorSet)this.animator).getChildAnimations().iterator();
        while (iterator.hasNext()) {
            ValueAnimator valueAnimator = (ValueAnimator)((Animator)iterator.next());
            long l2 = valueAnimator.getDuration();
            if (l <= l2) {
                l2 = l;
            }
            valueAnimator.setCurrentPlayTime(l2);
            l -= l2;
        }
        return this;
    }

    public WormAnimation with(int n, int n2, int n3, boolean bl) {
        if (this.hasChanges(n, n2, n3, bl)) {
            int n4;
            this.animator = this.createAnimator();
            this.coordinateStart = n;
            this.coordinateEnd = n2;
            this.radius = n3;
            this.isRightSide = bl;
            this.rectLeftEdge = n4 = n - n3;
            this.rectRightEdge = n + n3;
            this.value.setRectStart(n4);
            this.value.setRectEnd(this.rectRightEdge);
            RectValues rectValues = this.createRectValues(bl);
            long l = this.animationDuration / 2L;
            ValueAnimator valueAnimator = this.createWormAnimator(rectValues.fromX, rectValues.toX, l, false, this.value);
            ValueAnimator valueAnimator2 = this.createWormAnimator(rectValues.reverseFromX, rectValues.reverseToX, l, true, this.value);
            ((AnimatorSet)this.animator).playSequentially(new Animator[]{valueAnimator, valueAnimator2});
        }
        return this;
    }

    class RectValues {
        final int fromX;
        final int reverseFromX;
        final int reverseToX;
        final int toX;

        RectValues(int n, int n2, int n3, int n4) {
            this.fromX = n;
            this.toX = n2;
            this.reverseFromX = n3;
            this.reverseToX = n4;
        }
    }

}

