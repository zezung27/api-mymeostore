/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.SlideAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.drawer.type.BaseDrawer;

public class SlideDrawer
extends BaseDrawer {
    public SlideDrawer(Paint paint, Indicator indicator) {
        super(paint, indicator);
    }

    public void draw(Canvas canvas, Value value, int n, int n2) {
        if (!(value instanceof SlideAnimationValue)) {
            return;
        }
        int n3 = ((SlideAnimationValue)value).getCoordinate();
        int n4 = this.indicator.getUnselectedColor();
        int n5 = this.indicator.getSelectedColor();
        int n6 = this.indicator.getRadius();
        this.paint.setColor(n4);
        float f = n;
        float f2 = n2;
        float f3 = n6;
        canvas.drawCircle(f, f2, f3, this.paint);
        this.paint.setColor(n5);
        if (this.indicator.getOrientation() == Orientation.HORIZONTAL) {
            canvas.drawCircle((float)n3, f2, f3, this.paint);
            return;
        }
        canvas.drawCircle(f, (float)n3, f3, this.paint);
    }
}

