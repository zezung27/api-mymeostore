/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Indicator;
import com.rd.draw.drawer.type.BaseDrawer;

public class BasicDrawer
extends BaseDrawer {
    private Paint strokePaint;

    public BasicDrawer(Paint paint, Indicator indicator) {
        Paint paint2;
        super(paint, indicator);
        this.strokePaint = paint2 = new Paint();
        paint2.setStyle(Paint.Style.STROKE);
        this.strokePaint.setAntiAlias(true);
        this.strokePaint.setStrokeWidth((float)indicator.getStroke());
    }

    /*
     * Enabled aggressive block sorting
     */
    public void draw(Canvas canvas, int n, boolean bl, int n2, int n3) {
        Paint paint;
        float f = this.indicator.getRadius();
        int n4 = this.indicator.getStroke();
        float f2 = this.indicator.getScaleFactor();
        int n5 = this.indicator.getSelectedColor();
        int n6 = this.indicator.getUnselectedColor();
        int n7 = this.indicator.getSelectedPosition();
        AnimationType animationType = this.indicator.getAnimationType();
        if (animationType == AnimationType.SCALE && !bl || animationType == AnimationType.SCALE_DOWN && bl) {
            f *= f2;
        }
        if (n != n7) {
            n5 = n6;
        }
        if (animationType == AnimationType.FILL && n != n7) {
            paint = this.strokePaint;
            paint.setStrokeWidth((float)n4);
        } else {
            paint = this.paint;
        }
        paint.setColor(n5);
        canvas.drawCircle((float)n2, (float)n3, f, paint);
    }
}

