/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.SwapAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.drawer.type.BaseDrawer;

public class SwapDrawer
extends BaseDrawer {
    public SwapDrawer(Paint paint, Indicator indicator) {
        super(paint, indicator);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void draw(Canvas var1_1, Value var2_2, int var3_3, int var4_4, int var5_5) {
        block8 : {
            block6 : {
                block7 : {
                    if (!(var2_2 instanceof SwapAnimationValue)) {
                        return;
                    }
                    var6_6 = (SwapAnimationValue)var2_2;
                    var7_7 = this.indicator.getSelectedColor();
                    var8_8 = this.indicator.getUnselectedColor();
                    var9_9 = this.indicator.getRadius();
                    var10_10 = this.indicator.getSelectedPosition();
                    var11_11 = this.indicator.getSelectingPosition();
                    var12_12 = this.indicator.getLastSelectedPosition();
                    var13_13 = var6_6.getCoordinate();
                    if (!this.indicator.isInteractiveAnimation()) break block6;
                    if (var3_3 != var11_11) break block7;
                    var13_13 = var6_6.getCoordinate();
                    break block8;
                }
                if (var3_3 == var10_10) {
                    var13_13 = var6_6.getCoordinateReverse();
                }
                ** GOTO lbl25
            }
            if (var3_3 == var12_12) {
                var13_13 = var6_6.getCoordinate();
            } else {
                if (var3_3 == var10_10) {
                    var13_13 = var6_6.getCoordinateReverse();
                }
lbl25: // 4 sources:
                var7_7 = var8_8;
            }
        }
        this.paint.setColor(var7_7);
        if (this.indicator.getOrientation() == Orientation.HORIZONTAL) {
            var1_1.drawCircle((float)var13_13, (float)var5_5, (float)var9_9, this.paint);
            return;
        }
        var1_1.drawCircle((float)var4_4, (float)var13_13, (float)var9_9, this.paint);
    }
}

