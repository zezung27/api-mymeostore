/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  com.rd.animation.data.type.FillAnimationValue
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.FillAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.drawer.type.BaseDrawer;

public class FillDrawer
extends BaseDrawer {
    private Paint strokePaint;

    public FillDrawer(Paint paint, Indicator indicator) {
        Paint paint2;
        super(paint, indicator);
        this.strokePaint = paint2 = new Paint();
        paint2.setStyle(Paint.Style.STROKE);
        this.strokePaint.setAntiAlias(true);
    }

    public void draw(Canvas canvas, Value value, int n, int n2, int n3) {
        if (!(value instanceof FillAnimationValue)) {
            return;
        }
        FillAnimationValue fillAnimationValue = (FillAnimationValue)value;
        int n4 = this.indicator.getUnselectedColor();
        float f = this.indicator.getRadius();
        int n5 = this.indicator.getStroke();
        int n6 = this.indicator.getSelectedPosition();
        int n7 = this.indicator.getSelectingPosition();
        int n8 = this.indicator.getLastSelectedPosition();
        if (this.indicator.isInteractiveAnimation()) {
            if (n == n7) {
                n4 = fillAnimationValue.getColor();
                f = fillAnimationValue.getRadius();
                n5 = fillAnimationValue.getStroke();
            } else if (n == n6) {
                n4 = fillAnimationValue.getColorReverse();
                f = fillAnimationValue.getRadiusReverse();
                n5 = fillAnimationValue.getStrokeReverse();
            }
        } else if (n == n6) {
            n4 = fillAnimationValue.getColor();
            f = fillAnimationValue.getRadius();
            n5 = fillAnimationValue.getStroke();
        } else if (n == n8) {
            n4 = fillAnimationValue.getColorReverse();
            f = fillAnimationValue.getRadiusReverse();
            n5 = fillAnimationValue.getStrokeReverse();
        }
        this.strokePaint.setColor(n4);
        this.strokePaint.setStrokeWidth((float)this.indicator.getStroke());
        float f2 = n2;
        float f3 = n3;
        canvas.drawCircle(f2, f3, (float)this.indicator.getRadius(), this.strokePaint);
        this.strokePaint.setStrokeWidth((float)n5);
        canvas.drawCircle(f2, f3, f, this.strokePaint);
    }
}

