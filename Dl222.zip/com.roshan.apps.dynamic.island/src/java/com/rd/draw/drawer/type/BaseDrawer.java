/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  java.lang.Object
 */
package com.rd.draw.drawer.type;

import android.graphics.Paint;
import com.rd.draw.data.Indicator;

class BaseDrawer {
    Indicator indicator;
    Paint paint;

    BaseDrawer(Paint paint, Indicator indicator) {
        this.paint = paint;
        this.indicator = indicator;
    }
}

