/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.rd.draw.data;

public final class RtlMode
extends Enum<RtlMode> {
    private static final /* synthetic */ RtlMode[] $VALUES;
    public static final /* enum */ RtlMode Auto;
    public static final /* enum */ RtlMode Off;
    public static final /* enum */ RtlMode On;

    static {
        RtlMode rtlMode;
        RtlMode rtlMode2;
        RtlMode rtlMode3;
        On = rtlMode2 = new RtlMode();
        Off = rtlMode = new RtlMode();
        Auto = rtlMode3 = new RtlMode();
        $VALUES = new RtlMode[]{rtlMode2, rtlMode, rtlMode3};
    }

    public static RtlMode valueOf(String string2) {
        return (RtlMode)Enum.valueOf(RtlMode.class, (String)string2);
    }

    public static RtlMode[] values() {
        return (RtlMode[])$VALUES.clone();
    }
}

