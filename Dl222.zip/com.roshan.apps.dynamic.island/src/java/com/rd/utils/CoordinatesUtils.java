/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 */
package com.rd.utils;

import android.util.Pair;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;

public class CoordinatesUtils {
    public static int getCoordinate(Indicator indicator, int n) {
        if (indicator == null) {
            return 0;
        }
        if (indicator.getOrientation() == Orientation.HORIZONTAL) {
            return CoordinatesUtils.getXCoordinate(indicator, n);
        }
        return CoordinatesUtils.getYCoordinate(indicator, n);
    }

    private static int getFitPosition(Indicator indicator, float f, float f2) {
        int n = indicator.getCount();
        int n2 = indicator.getRadius();
        int n3 = indicator.getStroke();
        int n4 = indicator.getPadding();
        int n5 = indicator.getOrientation() == Orientation.HORIZONTAL ? indicator.getHeight() : indicator.getWidth();
        int n6 = 0;
        for (int i = 0; i < n; ++i) {
            int n7 = i > 0 ? n4 : n4 / 2;
            int n8 = n6 + (n7 + (n2 * 2 + n3 / 2));
            float f3 = f FCMPL (float)n6;
            boolean bl = true;
            boolean bl2 = f3 >= 0 && f <= (float)n8 ? bl : false;
            if (!(f2 >= 0.0f) || !(f2 <= (float)n5)) {
                bl = false;
            }
            if (bl2 && bl) {
                return i;
            }
            n6 = n8;
        }
        return -1;
    }

    private static int getHorizontalCoordinate(Indicator indicator, int n) {
        int n2 = indicator.getCount();
        int n3 = indicator.getRadius();
        int n4 = indicator.getStroke();
        int n5 = indicator.getPadding();
        int n6 = 0;
        for (int i = 0; i < n2; ++i) {
            int n7 = n4 / 2;
            int n8 = n6 + (n3 + n7);
            if (n == i) {
                return n8;
            }
            n6 = n8 + (n7 + (n3 + n5));
        }
        if (indicator.getAnimationType() == AnimationType.DROP) {
            n6 += n3 * 2;
        }
        return n6;
    }

    public static int getPosition(Indicator indicator, float f, float f2) {
        if (indicator == null) {
            return -1;
        }
        if (indicator.getOrientation() != Orientation.HORIZONTAL) {
            float f3 = f2;
            f2 = f;
            f = f3;
        }
        return CoordinatesUtils.getFitPosition(indicator, f, f2);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Pair<Integer, Float> getProgress(Indicator indicator, int n, float f, boolean bl) {
        float f2;
        int n2 = indicator.getCount();
        int n3 = indicator.getSelectedPosition();
        if (bl) {
            n = n2 - 1 - n;
        }
        if (n < 0) {
            n = 0;
        } else {
            int n4 = n2 - 1;
            if (n > n4) {
                n = n4;
            }
        }
        boolean bl2 = n > n3;
        boolean bl3 = bl ? n - 1 < n3 : n + 1 < n3;
        if (bl2 || bl3) {
            indicator.setSelectedPosition(n);
            n3 = n;
        }
        boolean bl4 = false;
        if (n3 == n) {
            float f3 = f FCMPL 0.0f;
            bl4 = false;
            if (f3 != false) {
                bl4 = true;
            }
        }
        if (bl4) {
            n = bl ? --n : ++n;
        } else {
            f = 1.0f - f;
        }
        if (f > 1.0f) {
            f2 = 1.0f;
            return new Pair((Object)n, (Object)Float.valueOf((float)f2));
        }
        if (f < 0.0f) {
            f2 = 0.0f;
            return new Pair((Object)n, (Object)Float.valueOf((float)f2));
        }
        f2 = f;
        return new Pair((Object)n, (Object)Float.valueOf((float)f2));
    }

    private static int getVerticalCoordinate(Indicator indicator) {
        int n = indicator.getRadius();
        if (indicator.getAnimationType() == AnimationType.DROP) {
            n *= 3;
        }
        return n;
    }

    public static int getXCoordinate(Indicator indicator, int n) {
        if (indicator == null) {
            return 0;
        }
        int n2 = indicator.getOrientation() == Orientation.HORIZONTAL ? CoordinatesUtils.getHorizontalCoordinate(indicator, n) : CoordinatesUtils.getVerticalCoordinate(indicator);
        return n2 + indicator.getPaddingLeft();
    }

    public static int getYCoordinate(Indicator indicator, int n) {
        if (indicator == null) {
            return 0;
        }
        int n2 = indicator.getOrientation() == Orientation.HORIZONTAL ? CoordinatesUtils.getVerticalCoordinate(indicator) : CoordinatesUtils.getHorizontalCoordinate(indicator, n);
        return n2 + indicator.getPaddingTop();
    }
}

