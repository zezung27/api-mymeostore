/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.animation.Interpolator
 *  android.widget.Adapter
 *  android.widget.ListAdapter
 *  android.widget.ListView
 *  java.lang.Math
 *  java.lang.Object
 */
package com.baoyz.swipemenulistview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import android.widget.Adapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuAdapter;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuLayout;
import com.baoyz.swipemenulistview.SwipeMenuView;

public class SwipeMenuListView
extends ListView {
    public static final int DIRECTION_LEFT = 1;
    public static final int DIRECTION_RIGHT = -1;
    private static final int TOUCH_STATE_NONE = 0;
    private static final int TOUCH_STATE_X = 1;
    private static final int TOUCH_STATE_Y = 2;
    private int MAX_X = 3;
    private int MAX_Y = 5;
    private Interpolator mCloseInterpolator;
    private int mDirection = 1;
    private float mDownX;
    private float mDownY;
    private SwipeMenuCreator mMenuCreator;
    private OnMenuItemClickListener mOnMenuItemClickListener;
    private OnMenuStateChangeListener mOnMenuStateChangeListener;
    private OnSwipeListener mOnSwipeListener;
    private Interpolator mOpenInterpolator;
    private int mTouchPosition;
    private int mTouchState;
    private SwipeMenuLayout mTouchView;

    public SwipeMenuListView(Context context) {
        super(context);
        this.init();
    }

    public SwipeMenuListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init();
    }

    public SwipeMenuListView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init();
    }

    private int dp2px(int n) {
        return (int)TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getContext().getResources().getDisplayMetrics());
    }

    private void init() {
        this.MAX_X = this.dp2px(this.MAX_X);
        this.MAX_Y = this.dp2px(this.MAX_Y);
        this.mTouchState = 0;
    }

    public Interpolator getCloseInterpolator() {
        return this.mCloseInterpolator;
    }

    public Interpolator getOpenInterpolator() {
        return this.mOpenInterpolator;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return super.onInterceptTouchEvent(motionEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 && this.mTouchView == null) {
            return super.onTouchEvent(motionEvent);
        }
        int n = motionEvent.getAction();
        if (n != 0) {
            if (n != 1) {
                if (n == 2) {
                    float f = Math.abs((float)(motionEvent.getY() - this.mDownY));
                    float f2 = Math.abs((float)(motionEvent.getX() - this.mDownX));
                    int n2 = this.mTouchState;
                    if (n2 == 1) {
                        SwipeMenuLayout swipeMenuLayout = this.mTouchView;
                        if (swipeMenuLayout != null) {
                            swipeMenuLayout.onSwipe(motionEvent);
                        }
                        this.getSelector().setState(new int[]{0});
                        motionEvent.setAction(3);
                        super.onTouchEvent(motionEvent);
                        return true;
                    }
                    if (n2 == 0) {
                        if (Math.abs((float)f) > (float)this.MAX_Y) {
                            this.mTouchState = 2;
                        } else if (f2 > (float)this.MAX_X) {
                            this.mTouchState = 1;
                            OnSwipeListener onSwipeListener = this.mOnSwipeListener;
                            if (onSwipeListener != null) {
                                onSwipeListener.onSwipeStart(this.mTouchPosition);
                            }
                        }
                    }
                }
            } else if (this.mTouchState == 1) {
                OnSwipeListener onSwipeListener;
                SwipeMenuLayout swipeMenuLayout = this.mTouchView;
                if (swipeMenuLayout != null) {
                    OnMenuStateChangeListener onMenuStateChangeListener;
                    boolean bl = swipeMenuLayout.isOpen();
                    this.mTouchView.onSwipe(motionEvent);
                    boolean bl2 = this.mTouchView.isOpen();
                    if (bl != bl2 && (onMenuStateChangeListener = this.mOnMenuStateChangeListener) != null) {
                        if (bl2) {
                            onMenuStateChangeListener.onMenuOpen(this.mTouchPosition);
                        } else {
                            onMenuStateChangeListener.onMenuClose(this.mTouchPosition);
                        }
                    }
                    if (!bl2) {
                        this.mTouchPosition = -1;
                        this.mTouchView = null;
                    }
                }
                if ((onSwipeListener = this.mOnSwipeListener) != null) {
                    onSwipeListener.onSwipeEnd(this.mTouchPosition);
                }
                motionEvent.setAction(3);
                super.onTouchEvent(motionEvent);
                return true;
            }
        } else {
            SwipeMenuLayout swipeMenuLayout;
            int n3;
            SwipeMenuLayout swipeMenuLayout2;
            int n4 = this.mTouchPosition;
            this.mDownX = motionEvent.getX();
            this.mDownY = motionEvent.getY();
            this.mTouchState = 0;
            this.mTouchPosition = n3 = this.pointToPosition((int)motionEvent.getX(), (int)motionEvent.getY());
            if (n3 == n4 && (swipeMenuLayout2 = this.mTouchView) != null && swipeMenuLayout2.isOpen()) {
                this.mTouchState = 1;
                this.mTouchView.onSwipe(motionEvent);
                return true;
            }
            View view = this.getChildAt(this.mTouchPosition - this.getFirstVisiblePosition());
            SwipeMenuLayout swipeMenuLayout3 = this.mTouchView;
            if (swipeMenuLayout3 != null && swipeMenuLayout3.isOpen()) {
                this.mTouchView.smoothCloseMenu();
                this.mTouchView = null;
                MotionEvent motionEvent2 = MotionEvent.obtain((MotionEvent)motionEvent);
                motionEvent2.setAction(3);
                this.onTouchEvent(motionEvent2);
                OnMenuStateChangeListener onMenuStateChangeListener = this.mOnMenuStateChangeListener;
                if (onMenuStateChangeListener != null) {
                    onMenuStateChangeListener.onMenuClose(n4);
                }
                return true;
            }
            if (view instanceof SwipeMenuLayout) {
                SwipeMenuLayout swipeMenuLayout4;
                this.mTouchView = swipeMenuLayout4 = (SwipeMenuLayout)view;
                swipeMenuLayout4.setSwipeDirection(this.mDirection);
            }
            if ((swipeMenuLayout = this.mTouchView) != null) {
                swipeMenuLayout.onSwipe(motionEvent);
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setAdapter(ListAdapter listAdapter) {
        super.setAdapter((ListAdapter)new SwipeMenuAdapter(this.getContext(), listAdapter){

            @Override
            public void createMenu(SwipeMenu swipeMenu) {
                if (SwipeMenuListView.this.mMenuCreator != null) {
                    SwipeMenuListView.this.mMenuCreator.create(swipeMenu);
                }
            }

            @Override
            public void onItemClick(SwipeMenuView swipeMenuView, SwipeMenu swipeMenu, int n) {
                boolean bl = SwipeMenuListView.this.mOnMenuItemClickListener != null ? SwipeMenuListView.this.mOnMenuItemClickListener.onMenuItemClick(swipeMenuView.getPosition(), swipeMenu, n) : false;
                if (SwipeMenuListView.this.mTouchView != null && !bl) {
                    SwipeMenuListView.this.mTouchView.smoothCloseMenu();
                }
            }
        });
    }

    public void setCloseInterpolator(Interpolator interpolator2) {
        this.mCloseInterpolator = interpolator2;
    }

    public void setMenuCreator(SwipeMenuCreator swipeMenuCreator) {
        this.mMenuCreator = swipeMenuCreator;
    }

    public void setOnMenuItemClickListener(OnMenuItemClickListener onMenuItemClickListener) {
        this.mOnMenuItemClickListener = onMenuItemClickListener;
    }

    public void setOnMenuStateChangeListener(OnMenuStateChangeListener onMenuStateChangeListener) {
        this.mOnMenuStateChangeListener = onMenuStateChangeListener;
    }

    public void setOnSwipeListener(OnSwipeListener onSwipeListener) {
        this.mOnSwipeListener = onSwipeListener;
    }

    public void setOpenInterpolator(Interpolator interpolator2) {
        this.mOpenInterpolator = interpolator2;
    }

    public void setSwipeDirection(int n) {
        this.mDirection = n;
    }

    public void smoothCloseMenu() {
        SwipeMenuLayout swipeMenuLayout = this.mTouchView;
        if (swipeMenuLayout != null && swipeMenuLayout.isOpen()) {
            this.mTouchView.smoothCloseMenu();
        }
    }

    public void smoothOpenMenu(int n) {
        View view;
        if (n >= this.getFirstVisiblePosition() && n <= this.getLastVisiblePosition() && (view = this.getChildAt(n - this.getFirstVisiblePosition())) instanceof SwipeMenuLayout) {
            SwipeMenuLayout swipeMenuLayout;
            this.mTouchPosition = n;
            SwipeMenuLayout swipeMenuLayout2 = this.mTouchView;
            if (swipeMenuLayout2 != null && swipeMenuLayout2.isOpen()) {
                this.mTouchView.smoothCloseMenu();
            }
            this.mTouchView = swipeMenuLayout = (SwipeMenuLayout)view;
            swipeMenuLayout.setSwipeDirection(this.mDirection);
            this.mTouchView.smoothOpenMenu();
        }
    }

    public static interface OnMenuItemClickListener {
        public boolean onMenuItemClick(int var1, SwipeMenu var2, int var3);
    }

    public static interface OnMenuStateChangeListener {
        public void onMenuClose(int var1);

        public void onMenuOpen(int var1);
    }

    public static interface OnSwipeListener {
        public void onSwipeEnd(int var1);

        public void onSwipeStart(int var1);
    }

}

