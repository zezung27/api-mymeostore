/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.baoyz.swipemenulistview;

import com.baoyz.swipemenulistview.SwipeMenu;

public interface SwipeMenuCreator {
    public void create(SwipeMenu var1);
}

