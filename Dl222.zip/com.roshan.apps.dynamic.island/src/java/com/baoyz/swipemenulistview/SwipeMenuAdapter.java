/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.database.DataSetObserver
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.animation.Interpolator
 *  android.widget.ListAdapter
 *  android.widget.WrapperListAdapter
 *  java.lang.Object
 *  java.lang.String
 */
package com.baoyz.swipemenulistview;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.widget.ListAdapter;
import android.widget.WrapperListAdapter;
import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuLayout;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.baoyz.swipemenulistview.SwipeMenuView;

public class SwipeMenuAdapter
implements WrapperListAdapter,
SwipeMenuView.OnSwipeItemClickListener {
    private ListAdapter mAdapter;
    private Context mContext;
    private SwipeMenuListView.OnMenuItemClickListener onMenuItemClickListener;

    public SwipeMenuAdapter(Context context, ListAdapter listAdapter) {
        this.mAdapter = listAdapter;
        this.mContext = context;
    }

    public boolean areAllItemsEnabled() {
        return this.mAdapter.areAllItemsEnabled();
    }

    public void createMenu(SwipeMenu swipeMenu) {
        SwipeMenuItem swipeMenuItem = new SwipeMenuItem(this.mContext);
        swipeMenuItem.setTitle("Item 1");
        swipeMenuItem.setBackground((Drawable)new ColorDrawable(-7829368));
        swipeMenuItem.setWidth(300);
        swipeMenu.addMenuItem(swipeMenuItem);
        SwipeMenuItem swipeMenuItem2 = new SwipeMenuItem(this.mContext);
        swipeMenuItem2.setTitle("Item 2");
        swipeMenuItem2.setBackground((Drawable)new ColorDrawable(-65536));
        swipeMenuItem2.setWidth(300);
        swipeMenu.addMenuItem(swipeMenuItem2);
    }

    public int getCount() {
        return this.mAdapter.getCount();
    }

    public Object getItem(int n) {
        return this.mAdapter.getItem(n);
    }

    public long getItemId(int n) {
        return this.mAdapter.getItemId(n);
    }

    public int getItemViewType(int n) {
        return this.mAdapter.getItemViewType(n);
    }

    public View getView(int n, View view, ViewGroup viewGroup) {
        if (view == null) {
            View view2 = this.mAdapter.getView(n, view, viewGroup);
            SwipeMenu swipeMenu = new SwipeMenu(this.mContext);
            swipeMenu.setViewType(this.mAdapter.getItemViewType(n));
            this.createMenu(swipeMenu);
            SwipeMenuListView swipeMenuListView = (SwipeMenuListView)viewGroup;
            SwipeMenuView swipeMenuView = new SwipeMenuView(swipeMenu, swipeMenuListView);
            swipeMenuView.setOnSwipeItemClickListener(this);
            SwipeMenuLayout swipeMenuLayout = new SwipeMenuLayout(view2, swipeMenuView, swipeMenuListView.getCloseInterpolator(), swipeMenuListView.getOpenInterpolator());
            swipeMenuLayout.setPosition(n);
            return swipeMenuLayout;
        }
        SwipeMenuLayout swipeMenuLayout = (SwipeMenuLayout)view;
        swipeMenuLayout.closeMenu();
        swipeMenuLayout.setPosition(n);
        this.mAdapter.getView(n, swipeMenuLayout.getContentView(), viewGroup);
        return swipeMenuLayout;
    }

    public int getViewTypeCount() {
        return this.mAdapter.getViewTypeCount();
    }

    public ListAdapter getWrappedAdapter() {
        return this.mAdapter;
    }

    public boolean hasStableIds() {
        return this.mAdapter.hasStableIds();
    }

    public boolean isEmpty() {
        return this.mAdapter.isEmpty();
    }

    public boolean isEnabled(int n) {
        return this.mAdapter.isEnabled(n);
    }

    @Override
    public void onItemClick(SwipeMenuView swipeMenuView, SwipeMenu swipeMenu, int n) {
        SwipeMenuListView.OnMenuItemClickListener onMenuItemClickListener = this.onMenuItemClickListener;
        if (onMenuItemClickListener != null) {
            onMenuItemClickListener.onMenuItemClick(swipeMenuView.getPosition(), swipeMenu, n);
        }
    }

    public void registerDataSetObserver(DataSetObserver dataSetObserver) {
        this.mAdapter.registerDataSetObserver(dataSetObserver);
    }

    public void setOnMenuItemClickListener(SwipeMenuListView.OnMenuItemClickListener onMenuItemClickListener) {
        this.onMenuItemClickListener = onMenuItemClickListener;
    }

    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
        this.mAdapter.unregisterDataSetObserver(dataSetObserver);
    }
}

