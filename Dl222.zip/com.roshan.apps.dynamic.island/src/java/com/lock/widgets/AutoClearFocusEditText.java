/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.KeyEvent
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  com.google.android.material.textfield.TextInputEditText
 *  java.lang.Object
 */
package com.lock.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputEditText;

public class AutoClearFocusEditText
extends TextInputEditText {
    public AutoClearFocusEditText(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.setOnEditorActionListener(new TextView.OnEditorActionListener(){

            public boolean onEditorAction(TextView textView, int n, KeyEvent keyEvent) {
                if (n != 6) {
                    return false;
                }
                AutoClearFocusEditText.this.clearFocus();
                return false;
            }
        });
    }

    public boolean onKeyDown(int n, KeyEvent keyEvent) {
        if (n == 4) {
            return true;
        }
        return super.onKeyDown(n, keyEvent);
    }

    public boolean onKeyPreIme(int n, KeyEvent keyEvent) {
        if (n == 4 && keyEvent.getAction() == 1) {
            this.clearFocus();
        }
        return super.onKeyPreIme(n, keyEvent);
    }

    public boolean onKeyUp(int n, KeyEvent keyEvent) {
        if (n != 4) {
            return super.onKeyUp(n, keyEvent);
        }
        this.clearFocus();
        return true;
    }

}

