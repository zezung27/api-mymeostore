/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.webkit.WebSettings
 *  android.webkit.WebView
 *  androidx.appcompat.app.AppCompatActivity
 *  java.lang.String
 */
package com.lock.activites;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import com.lock.activites.PrivacyPolicyActivity;

public class PrivacyPolicyActivity
extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558434);
        WebView webView = (WebView)this.findViewById(2131362549);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webView.loadUrl("file:///android_asset/File/Privacy.html");
        this.findViewById(2131362282).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ PrivacyPolicyActivity this$0;
            {
                this.this$0 = privacyPolicyActivity;
            }

            public void onClick(View view) {
                this.this$0.finish();
            }
        });
    }
}

