/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.lock.views;

public interface ScrollEndListener {
    public void onScrollEnd();
}

