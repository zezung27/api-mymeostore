/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 */
package com.lock.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class CustomRecyclerView
extends RecyclerView {
    int firstCompleteElementPosition = 0;
    int lastCompleteElementPosition = 0;
    public int overScrollDirection;
    int preDirections = 0;

    public CustomRecyclerView(Context context) {
        super(context);
    }

    public CustomRecyclerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public CustomRecyclerView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return super.onInterceptTouchEvent(motionEvent);
    }

    protected void onScrollChanged(int n, int n2, int n3, int n4) {
        super.onScrollChanged(n, n2, n3, n4);
        this.preDirections = 0;
    }

    public void onScrolled(int n, int n2) {
        super.onScrolled(n, n2);
        LinearLayoutManager linearLayoutManager = (LinearLayoutManager)this.getLayoutManager();
        if (linearLayoutManager != null) {
            this.firstCompleteElementPosition = linearLayoutManager.findFirstCompletelyVisibleItemPosition();
            this.lastCompleteElementPosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
        }
        this.preDirections = 0;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 1) {
            return super.onTouchEvent(motionEvent);
        }
        this.preDirections = this.preDirections != this.overScrollDirection && (this.lastCompleteElementPosition != this.getChildCount() - 1 || this.firstCompleteElementPosition != 0) ? this.overScrollDirection : 0;
        return super.onTouchEvent(motionEvent);
    }
}

