/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Bundle
 *  android.util.Base64
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.ProgressBar
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.android.volley.AuthFailureError
 *  com.android.volley.DefaultRetryPolicy
 *  com.android.volley.Request
 *  com.android.volley.RequestQueue
 *  com.android.volley.Response
 *  com.android.volley.Response$ErrorListener
 *  com.android.volley.Response$Listener
 *  com.android.volley.RetryPolicy
 *  com.android.volley.toolbox.JsonObjectRequest
 *  com.android.volley.toolbox.Volley
 *  com.google.gson.Gson
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Map
 *  org.json.JSONObject
 */
package com.lock.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.lock.adaptar.ThemeListAdaptr;
import com.lock.entity.Theme;
import com.lock.entity.ThemeData;
import com.lock.fragment.ThemeFragment;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class ThemeFragment
extends Fragment {
    int index;
    Context mConxt;
    private ProgressBar pbLoader;
    public ArrayList<ThemeData> themeData = new ArrayList();
    ThemeListAdaptr themeListAdaptr;
    RecyclerView thmee;
    String url;

    static /* synthetic */ ProgressBar access$000(ThemeFragment themeFragment) {
        return themeFragment.pbLoader;
    }

    public static ThemeFragment newInstance(String string, int n) {
        ThemeFragment themeFragment = new ThemeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("index", n);
        bundle.putString("url", string);
        themeFragment.setArguments(bundle);
        return themeFragment;
    }

    public void getAlltheme(JSONObject jSONObject) {
        Theme theme = (Theme)new Gson().fromJson(jSONObject.toString(), Theme.class);
        this.themeData.clear();
        this.themeData.addAll(theme.getAppThems());
        int n = 0;
        do {
            block6 : {
                try {
                    if (n < this.themeData.size()) {
                        if (((ThemeData)this.themeData.get(n)).getPkg().equals((Object)this.getActivity().getPackageName())) {
                            this.themeData.remove(n);
                        }
                        break block6;
                    }
                    this.themeListAdaptr.notifyDataSetChanged();
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
            ++n;
        } while (true);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.index = this.getArguments().getInt("index");
        this.url = this.getArguments().getString("url");
        return layoutInflater.inflate(2131558467, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        ThemeListAdaptr themeListAdaptr;
        super.onViewCreated(view, bundle);
        this.mConxt = this.getActivity();
        this.thmee = (RecyclerView)view.findViewById(2131362477);
        this.pbLoader = (ProgressBar)view.findViewById(2131362299);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.mConxt);
        this.thmee.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.themeListAdaptr = themeListAdaptr = new ThemeListAdaptr((Activity)this.getActivity(), this.themeData, this.index);
        this.thmee.setAdapter((RecyclerView.Adapter)themeListAdaptr);
        try {
            RequestQueue requestQueue = Volley.newRequestQueue((Context)this.getContext());
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, this.url, null, (Response.Listener)new Response.Listener<JSONObject>(this){
                final /* synthetic */ ThemeFragment this$0;
                {
                    this.this$0 = themeFragment;
                }

                public void onResponse(JSONObject jSONObject) {
                    android.util.Log.d((String)"LOCKSCREEN", (String)jSONObject.toString());
                    ThemeFragment.access$000(this.this$0).setVisibility(8);
                    this.this$0.getAlltheme(jSONObject);
                }
            }, new Response.ErrorListener(this){
                final /* synthetic */ ThemeFragment this$0;
                {
                    this.this$0 = themeFragment;
                }

                public void onErrorResponse(com.android.volley.VolleyError volleyError) {
                    ThemeFragment.access$000(this.this$0).setVisibility(8);
                }
            }){

                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap hashMap = new HashMap();
                    String string = "Basic " + Base64.encodeToString((byte[])"ali:uraan1234".getBytes(), (int)2);
                    hashMap.put((Object)"Content-Type", (Object)"application/json");
                    hashMap.put((Object)"Authorization", (Object)string);
                    return hashMap;
                }

                protected Map<String, String> getParams() throws AuthFailureError {
                    return new HashMap();
                }
            };
            jsonObjectRequest.setRetryPolicy((RetryPolicy)new DefaultRetryPolicy(10000, 2, 1.0f));
            jsonObjectRequest.setShouldCache(false);
            requestQueue.add((Request)jsonObjectRequest);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

}

