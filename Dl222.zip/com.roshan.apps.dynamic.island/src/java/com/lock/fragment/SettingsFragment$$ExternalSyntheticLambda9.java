/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.lock.fragment.SettingsFragment
 *  java.lang.Object
 */
package com.lock.fragment;

import android.view.View;
import com.lock.fragment.SettingsFragment;

public final class SettingsFragment$$ExternalSyntheticLambda9
implements View.OnClickListener {
    public final /* synthetic */ SettingsFragment f$0;
    public final /* synthetic */ View f$1;

    public /* synthetic */ SettingsFragment$$ExternalSyntheticLambda9(SettingsFragment settingsFragment, View view) {
        this.f$0 = settingsFragment;
        this.f$1 = view;
    }

    public final void onClick(View view) {
        this.f$0.lambda$onViewCreated$11$com-lock-fragment-SettingsFragment(this.f$1, view);
    }
}

