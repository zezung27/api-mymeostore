/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.background;

import com.google.gson.annotations.SerializedName;
import com.lock.background.ImageList;
import java.io.Serializable;
import java.util.ArrayList;

public class Wallpaper
implements Serializable {
    @SerializedName(value="album_images")
    ArrayList<ImageList> album_images;
    @SerializedName(value="status")
    String status;

    public ArrayList<ImageList> getAlbum_images() {
        return this.album_images;
    }

    public String getStatus() {
        return this.status;
    }

    public void setAlbum_images(ArrayList<ImageList> arrayList) {
        this.album_images = arrayList;
    }

    public void setStatus(String string2) {
        this.status = string2;
    }
}

