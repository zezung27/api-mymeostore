/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.background;

public class WallpaperCategoryList {
    public String album;
    public String icon;
    public String id;

    public String getAlbum() {
        return this.album;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getId() {
        return this.id;
    }

    public void setAlbum(String string2) {
        this.album = string2;
    }

    public void setIcon(String string2) {
        this.icon = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }
}

