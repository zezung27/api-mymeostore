/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 *  java.io.Serializable
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.lock.background;

import com.google.gson.annotations.SerializedName;
import com.lock.background.WallpaperCategoryList;
import java.io.Serializable;
import java.util.ArrayList;

public class WallpaperCategory
implements Serializable {
    @SerializedName(value="category")
    ArrayList<WallpaperCategoryList> category;

    public ArrayList<WallpaperCategoryList> getCategory() {
        return this.category;
    }

    public void setCategory(ArrayList<WallpaperCategoryList> arrayList) {
        this.category = arrayList;
    }
}

