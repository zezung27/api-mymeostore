/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.Window
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.GridView
 *  android.widget.ListAdapter
 *  android.widget.ProgressBar
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  com.android.volley.DefaultRetryPolicy
 *  com.android.volley.Request
 *  com.android.volley.Response
 *  com.android.volley.Response$ErrorListener
 *  com.android.volley.Response$Listener
 *  com.android.volley.RetryPolicy
 *  com.android.volley.toolbox.JsonObjectRequest
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.FullScreenContentCallback
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.interstitial.InterstitialAd
 *  com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
 *  com.google.gson.Gson
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONObject
 */
package com.lock.background;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.lock.application.LauncherApp;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.background.WallpaperCategory;
import com.lock.background.WallpaperCategoryAdapter;
import com.lock.background.WallpaperCategoryList;
import com.lock.background.WallpapersCategoryActivity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

public class WallpapersCategoryActivity
extends AppCompatActivity {
    AdRequest adRequest;
    private WallpaperCategoryAdapter adapter;
    private int columnWidth;
    private GridView gridView;
    AdView mAdView;
    Context mContext;
    private InterstitialAd mInterstitialAd;
    private ProgressBar pbLoader;
    private ArrayList<WallpaperCategoryList> photosList = new ArrayList();
    private PrefManager pref;
    private Utils utils;
    private String wallpaperPosition;

    private void InitilizeGridLayout() {
        float f = TypedValue.applyDimension((int)1, (float)4.0f, (DisplayMetrics)this.getResources().getDisplayMetrics());
        this.columnWidth = (int)(((float)this.utils.getScreenWidth() - f * (float)(1 + this.pref.getNoOfGridColumnsCategory())) / (float)this.pref.getNoOfGridColumnsCategory());
        this.gridView.setNumColumns(this.pref.getNoOfGridColumnsCategory());
        this.gridView.setColumnWidth(this.columnWidth);
        this.gridView.setStretchMode(0);
        GridView gridView = this.gridView;
        int n = (int)f;
        gridView.setPadding(n, n, n, n);
        this.gridView.setHorizontalSpacing(n);
        this.gridView.setVerticalSpacing(n);
    }

    static /* synthetic */ ProgressBar access$000(WallpapersCategoryActivity wallpapersCategoryActivity) {
        return wallpapersCategoryActivity.pbLoader;
    }

    static /* synthetic */ String access$100(WallpapersCategoryActivity wallpapersCategoryActivity) {
        return wallpapersCategoryActivity.wallpaperPosition;
    }

    static /* synthetic */ String access$102(WallpapersCategoryActivity wallpapersCategoryActivity, String string) {
        wallpapersCategoryActivity.wallpaperPosition = string;
        return string;
    }

    static /* synthetic */ ArrayList access$200(WallpapersCategoryActivity wallpapersCategoryActivity) {
        return wallpapersCategoryActivity.photosList;
    }

    private void loadInterstitial() {
        InterstitialAd.load((Context)this, (String)this.getString(2131886082), (AdRequest)this.adRequest, (InterstitialAdLoadCallback)new InterstitialAdLoadCallback(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                WallpapersCategoryActivity.this.mInterstitialAd = null;
            }

            public void onAdLoaded(InterstitialAd interstitialAd) {
                WallpapersCategoryActivity.this.mInterstitialAd = interstitialAd;
                WallpapersCategoryActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(this){
                    final /* synthetic */ 4 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onAdDismissedFullScreenContent() {
                        android.content.Intent intent = new android.content.Intent(this.this$1.WallpapersCategoryActivity.this.mContext, com.lock.background.WallpapersActivity.class);
                        intent.putExtra("image_name", WallpapersCategoryActivity.access$100(this.this$1.WallpapersCategoryActivity.this));
                        this.this$1.WallpapersCategoryActivity.this.startActivity(intent);
                    }

                    public void onAdShowedFullScreenContent() {
                        WallpapersCategoryActivity.access$302(this.this$1.WallpapersCategoryActivity.this, null);
                    }
                });
            }
        });
    }

    public void getAllImages(JSONObject jSONObject) {
        try {
            WallpaperCategoryAdapter wallpaperCategoryAdapter;
            WallpaperCategory wallpaperCategory = (WallpaperCategory)new Gson().fromJson(jSONObject.toString(), WallpaperCategory.class);
            this.photosList.clear();
            this.pbLoader.setVisibility(8);
            this.gridView.setVisibility(0);
            this.photosList.addAll(wallpaperCategory.getCategory());
            this.adapter = wallpaperCategoryAdapter = new WallpaperCategoryAdapter(this.mContext, (List<WallpaperCategoryList>)this.photosList, this.columnWidth);
            this.gridView.setAdapter((ListAdapter)wallpaperCategoryAdapter);
            this.adapter.notifyDataSetChanged();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    protected void onCreate(Bundle bundle) {
        ProgressBar progressBar;
        GridView gridView;
        super.onCreate(bundle);
        this.setContentView(2131558591);
        this.mContext = this;
        Toolbar toolbar = (Toolbar)this.findViewById(2131362494);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131100533));
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
        Drawable drawable = toolbar.getNavigationIcon();
        if (drawable != null) {
            drawable.setTint(this.getResources().getColor(2131100533));
        }
        this.utils = new Utils(this.mContext);
        this.pref = new PrefManager(this.mContext);
        this.photosList = new ArrayList();
        this.gridView = gridView = (GridView)this.findViewById(2131362093);
        gridView.setVisibility(8);
        this.InitilizeGridLayout();
        this.pbLoader = progressBar = (ProgressBar)this.findViewById(2131362299);
        progressBar.setVisibility(0);
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, "http://45.55.46.214/wallpaper_ahmed/getCatagory.php", null, (Response.Listener)new Response.Listener<JSONObject>(this){
                final /* synthetic */ WallpapersCategoryActivity this$0;
                {
                    this.this$0 = wallpapersCategoryActivity;
                }

                public void onResponse(JSONObject jSONObject) {
                    this.this$0.getAllImages(jSONObject);
                }
            }, new Response.ErrorListener(this){
                final /* synthetic */ WallpapersCategoryActivity this$0;
                {
                    this.this$0 = wallpapersCategoryActivity;
                }

                public void onErrorResponse(com.android.volley.VolleyError volleyError) {
                    WallpapersCategoryActivity.access$000(this.this$0).setVisibility(8);
                    android.widget.Toast.makeText((Context)this.this$0.mContext, (java.lang.CharSequence)"Try Again in Few minutes", (int)1).show();
                }
            });
            jsonObjectRequest.setRetryPolicy((RetryPolicy)new DefaultRetryPolicy(10000, 2, 1.0f));
            jsonObjectRequest.setShouldCache(false);
            LauncherApp.getInstance().addToRequestQueue(jsonObjectRequest);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.mAdView = (AdView)this.findViewById(2131361910);
        if (!Utils.isAdsRemoved((Context)this)) {
            this.adRequest = new AdRequest.Builder().build();
            this.loadInterstitial();
            this.mAdView.loadAd(this.adRequest);
        } else {
            this.mAdView.setVisibility(8);
        }
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener(this){
            final /* synthetic */ WallpapersCategoryActivity this$0;
            {
                this.this$0 = wallpapersCategoryActivity;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                WallpapersCategoryActivity wallpapersCategoryActivity = this.this$0;
                WallpapersCategoryActivity.access$102(wallpapersCategoryActivity, ((WallpaperCategoryList)WallpapersCategoryActivity.access$200(wallpapersCategoryActivity).get(n)).getId().trim());
                if (!Utils.isAdsRemoved(this.this$0.mContext) && WallpapersCategoryActivity.access$300(this.this$0) != null) {
                    WallpapersCategoryActivity.access$300(this.this$0).show((android.app.Activity)this.this$0);
                    return;
                }
                android.content.Intent intent = new android.content.Intent(this.this$0.mContext, com.lock.background.WallpapersActivity.class);
                intent.putExtra("album_id", ((WallpaperCategoryList)WallpapersCategoryActivity.access$200(this.this$0).get(n)).getId().trim());
                this.this$0.startActivity(intent);
            }
        });
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

