/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.BaseAdapter
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package com.lock.background;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.background.WallpaperCategoryList;
import java.util.ArrayList;
import java.util.List;

public class WallpaperCategoryAdapter
extends BaseAdapter {
    private Context _activity;
    private int imageWidth;
    private LayoutInflater inflater;
    private List<WallpaperCategoryList> wallpapersList;

    public WallpaperCategoryAdapter(Context context, List<WallpaperCategoryList> list, int n) {
        new ArrayList();
        this._activity = context;
        this.wallpapersList = list;
        this.inflater = LayoutInflater.from((Context)context);
        this.imageWidth = n;
    }

    public int getCount() {
        return this.wallpapersList.size();
    }

    public Object getItem(int n) {
        return this.wallpapersList.get(n);
    }

    public long getItemId(int n) {
        return n;
    }

    public View getView(int n, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = this.inflater.inflate(2131558468, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.progressBar = (ProgressBar)view.findViewById(2131362315);
            viewHolder.image = (ImageView)view.findViewById(2131362480);
            viewHolder.albumName_tv = (TextView)view.findViewById(2131361882);
            view.setTag((Object)viewHolder);
        } else {
            viewHolder = (ViewHolder)view.getTag();
        }
        viewHolder.albumName_tv.setVisibility(0);
        viewHolder.albumName_tv.setText((CharSequence)((WallpaperCategoryList)this.wallpapersList.get(n)).getAlbum());
        viewHolder.image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ImageView imageView = viewHolder.image;
        int n2 = this.imageWidth;
        imageView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(n2, n2));
        String string2 = ((WallpaperCategoryList)this.wallpapersList.get(n)).getIcon().trim();
        Context context = this._activity;
        if (context != null) {
            Glide.with((Context)context).load("http://45.55.46.214/wallpaper_ahmed/images/" + string2).listener((RequestListener)new RequestListener<Drawable>(){

                public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                    viewHolder.progressBar.setVisibility(8);
                    return false;
                }

                public boolean onResourceReady(Drawable drawable2, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                    viewHolder.progressBar.setVisibility(8);
                    return false;
                }
            }).into(viewHolder.image);
        }
        return view;
    }

    static class ViewHolder {
        TextView albumName_tv;
        ImageView image;
        ProgressBar progressBar;

        ViewHolder() {
        }
    }

}

