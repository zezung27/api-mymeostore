/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.background;

public class ImageList {
    public String image;
    public String thumb_image;

    public String getImage() {
        return this.image;
    }

    public String getThumb_image() {
        return this.thumb_image;
    }

    public void setImage(String string2) {
        this.image = string2;
    }

    public void setThumb_image(String string2) {
        this.thumb_image = string2;
    }
}

