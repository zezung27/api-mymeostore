/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.res.Resources
 *  android.os.Build
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.provider.Settings$System
 *  android.widget.TextView
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.provider.Settings;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;
import com.lock.utils.Utils;

public class NightModeController
extends ButtonState {
    private Context context;
    private Intent intent;
    private String name;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public NightModeController(Context context) {
        String string2;
        int n;
        block9 : {
            int n2;
            Intent intent;
            super(context);
            this.context = context;
            this.intent = intent = new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.Settings$BlueLightFilterSettingsActivity"));
            if (!Utils.checkIfActivityFound(context, intent)) {
                this.intent = new Intent("android.settings.NIGHT_DISPLAY_SETTINGS");
            }
            try {
                string2 = Build.MANUFACTURER;
                boolean bl = string2.equalsIgnoreCase("vivo");
                n = 0;
                if (!bl) break block9;
                Resources resources = this.context.getPackageManager().getResourcesForApplication("com.vivo.upslide");
                n2 = resources.getIdentifier("com.vivo.upslide:string/vivo_switcher_eye_protection", null, null);
                if (n2 != 0) {
                    this.name = resources.getString(n2);
                    return;
                }
            }
            catch (Exception exception) {
                this.name = this.context.getString(2131886359);
                return;
            }
            n = n2;
        }
        if (string2.equalsIgnoreCase("huawei")) {
            n = context.getResources().getIdentifier("com.android.systemui:string/eye_comfort_widget_name", null, null);
        }
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/quick_settings_bluelightfilter_label", null, null);
        }
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/quick_settings_night_mode", null, null);
        }
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/quick_settings_papermode_label", null, null);
        }
        Resources resources = context.getResources();
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/quick_settings_night_display_label", null, null);
        }
        this.name = resources.getString(n);
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public boolean getState() {
        return Build.BRAND.toLowerCase().equals((Object)"samsung") ? Settings.System.getInt((ContentResolver)this.context.getContentResolver(), (String)"blue_light_filter", (int)0) == 1 : Settings.Secure.getInt((ContentResolver)this.context.getContentResolver(), (String)"night_display_activated", (int)0) == 1;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231023);
            return;
        }
        lottieAnimationView.setImageResource(2131231022);
    }
}

