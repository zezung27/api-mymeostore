/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.media.AudioManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.widget.ImageView
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.widget.ImageView;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class AudioSettingController
extends ButtonState {
    private final Context context;
    private final Intent intent;
    private String name;
    public final AudioManager w;

    public AudioSettingController(Context context) {
        super(context);
        this.context = context;
        this.w = (AudioManager)context.getSystemService("audio");
        if (Build.VERSION.SDK_INT >= 29) {
            this.intent = new Intent("android.settings.panel.action.VOLUME");
            return;
        }
        this.intent = new Intent("android.settings.SOUND_SETTINGS");
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    public int getMode() {
        return this.w.getRingerMode();
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    public void setMode(ImageView imageView, TextView textView, TextView textView2) {
        int n = this.w.getRingerMode();
        if (n == 0) {
            this.w.setRingerMode(2);
            imageView.setImageResource(2131231023);
            textView.setText((CharSequence)"Volume");
            textView2.setText((CharSequence)"Normal");
            return;
        }
        if (n == 1) {
            this.w.setRingerMode(0);
            imageView.setImageResource(2131231022);
            textView.setText((CharSequence)"Volume");
            textView2.setText((CharSequence)"Mute");
            return;
        }
        if (n == 2) {
            this.w.setRingerMode(1);
            imageView.setImageResource(2131231022);
            textView.setText((CharSequence)"Volume");
            textView2.setText((CharSequence)"Vibrate");
        }
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        this.w.getRingerMode();
    }
}

