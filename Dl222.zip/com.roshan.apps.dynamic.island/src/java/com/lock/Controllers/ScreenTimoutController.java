/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.provider.Settings
 *  android.provider.Settings$SettingNotFoundException
 *  android.provider.Settings$System
 *  android.widget.TextView
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class ScreenTimoutController
extends ButtonState {
    private final Context context;
    public int currentScreenTimeout = 0;

    public ScreenTimoutController(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.settings.DISPLAY_SETTINGS");
    }

    @Override
    public String getName() {
        return "Screen Timeout";
    }

    @Override
    public boolean getState() {
        return false;
    }

    public String getTimeoutString() {
        int n;
        try {
            n = Settings.System.getInt((ContentResolver)this.context.getContentResolver(), (String)"screen_off_timeout");
        }
        catch (Settings.SettingNotFoundException settingNotFoundException) {
            settingNotFoundException.printStackTrace();
            n = 0;
        }
        if (n >= 0 && n <= 15000) {
            return "15s";
        }
        if (n >= 16000 && n <= 30000) {
            return "30s";
        }
        if (n >= 31000 && n <= 60000) {
            return "01m";
        }
        if (n >= 61000 && n <= 120000) {
            return "02m";
        }
        if (n >= 120000 && n <= 300000) {
            return "05m";
        }
        return "01m";
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }

    public String setTimeout() {
        String string2;
        int n;
        try {
            n = Settings.System.getInt((ContentResolver)this.context.getContentResolver(), (String)"screen_off_timeout");
        }
        catch (Settings.SettingNotFoundException settingNotFoundException) {
            settingNotFoundException.printStackTrace();
            n = 0;
        }
        if (n >= 0 && n <= 15000) {
            string2 = "15s,30s";
            n = 30000;
        } else if (n >= 16000 && n <= 30000) {
            string2 = "30s,01m";
            n = 60000;
        } else if (n >= 31000 && n <= 60000) {
            string2 = "01m,02m";
            n = 120000;
        } else if (n >= 61000 && n <= 120000) {
            string2 = "02m,05m";
            n = 300000;
        } else if (n >= 120000 && n <= 300000) {
            string2 = "0,15s";
            n = 15000;
        } else {
            string2 = "01m";
        }
        Settings.System.putInt((ContentResolver)this.context.getContentResolver(), (String)"screen_off_timeout", (int)n);
        return string2;
    }
}

