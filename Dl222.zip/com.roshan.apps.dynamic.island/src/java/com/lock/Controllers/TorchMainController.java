/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.res.Resources
 *  android.hardware.camera2.CameraManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.Controllers.CameraFlashController;
import com.lock.Controllers.TorchWithCameraController;
import com.lock.entity.ButtonState;

public class TorchMainController
extends ButtonState {
    CameraFlashController cameraFlashController;
    public final CameraManager cameraManager;
    private final Context context;
    public String stateName;
    TorchWithCameraController torchWithCameraController;

    public TorchMainController(Context context) {
        super(context);
        this.context = context;
        this.cameraManager = (CameraManager)context.getSystemService("camera");
        if (Build.VERSION.SDK_INT >= 23) {
            this.cameraFlashController = new CameraFlashController(context);
            return;
        }
        this.torchWithCameraController = new TorchWithCameraController(context);
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.media.action.STILL_IMAGE_CAMERA");
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131886354);
    }

    @Override
    public boolean getState() {
        CameraFlashController cameraFlashController = this.cameraFlashController;
        if (cameraFlashController != null) {
            return cameraFlashController.isEnabled();
        }
        return this.torchWithCameraController.isEnabled();
    }

    @Override
    public boolean hasSystemFeature() {
        return this.context.getPackageManager().hasSystemFeature("android.hardware.camera.flash");
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231023);
            textView2.setText((CharSequence)this.context.getResources().getString(2131886440));
            CameraFlashController cameraFlashController = this.cameraFlashController;
            if (cameraFlashController != null) {
                cameraFlashController.setTorchMode(true);
            } else {
                this.torchWithCameraController.setTorchMode(true);
            }
        } else {
            lottieAnimationView.setImageResource(2131231022);
            textView2.setText((CharSequence)this.context.getResources().getString(2131886439));
            CameraFlashController cameraFlashController = this.cameraFlashController;
            if (cameraFlashController != null) {
                cameraFlashController.setTorchMode(false);
            } else {
                this.torchWithCameraController.setTorchMode(false);
            }
        }
        textView.setText((CharSequence)this.context.getResources().getString(2131886354));
    }
}

