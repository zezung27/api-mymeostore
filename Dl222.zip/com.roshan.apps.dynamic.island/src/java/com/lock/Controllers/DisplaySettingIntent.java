/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  android.widget.TextView
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class DisplaySettingIntent
extends ButtonState {
    private Context context;

    public DisplaySettingIntent(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.settings.DISPLAY_SETTINGS");
    }

    @Override
    public String getName() {
        return this.context.getString(2131886360);
    }

    @Override
    public boolean getState() {
        int n = Settings.System.getInt((ContentResolver)this.context.getContentResolver(), (String)"accelerometer_rotation", (int)0);
        boolean bl = false;
        if (n == 0) {
            bl = true;
        }
        return bl;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231023);
            Settings.System.putInt((ContentResolver)this.context.getContentResolver(), (String)"accelerometer_rotation", (int)1);
            return;
        }
        lottieAnimationView.setImageResource(2131231022);
        Settings.System.putInt((ContentResolver)this.context.getContentResolver(), (String)"accelerometer_rotation", (int)0);
    }
}

