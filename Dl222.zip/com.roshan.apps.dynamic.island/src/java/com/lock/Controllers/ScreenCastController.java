/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.String
 */
package com.lock.Controllers;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.widget.TextView;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class ScreenCastController
extends ButtonState {
    private Context context;

    public ScreenCastController(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.settings.CAST_SETTINGS");
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131886391);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231023);
            return;
        }
        lottieAnimationView.setImageResource(2131231022);
    }

    public boolean startScreenCast() {
        try {
            Intent intent = new Intent("android.settings.CAST_SETTINGS");
            intent.addFlags(335544320);
            PendingIntent.getActivity((Context)this.context, (int)0, (Intent)intent, (int)0).send();
            return true;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)"No Activity found to handle this feature", (int)0).show();
            return false;
        }
    }
}

