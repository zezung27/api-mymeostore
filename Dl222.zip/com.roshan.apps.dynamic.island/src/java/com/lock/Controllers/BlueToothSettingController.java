/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.bluetooth.BluetoothAdapter
 *  android.content.Context
 *  android.content.Intent
 *  android.os.UserManager
 *  android.widget.TextView
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.UserManager;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class BlueToothSettingController
extends ButtonState {
    private final BluetoothAdapter bluetoothAdapter;
    private final Context context;
    private final Intent intent;
    private String name;
    private final UserManager userManager;

    public BlueToothSettingController(Context context) {
        UserManager userManager;
        super(context);
        this.context = context;
        this.intent = new Intent("android.settings.BLUETOOTH_SETTINGS");
        this.bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.userManager = userManager = (UserManager)context.getSystemService("user");
        this.name = userManager.getUserName();
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    public boolean isAllowed() {
        return !this.userManager.hasUserRestriction("no_config_bluetooth") && !this.userManager.hasUserRestriction("no_bluetooth");
        {
        }
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        BluetoothAdapter bluetoothAdapter = this.bluetoothAdapter;
        if (bluetoothAdapter != null) {
            if (bl) {
                bluetoothAdapter.enable();
                lottieAnimationView.setImageResource(2131231023);
                return;
            }
            bluetoothAdapter.disable();
            lottieAnimationView.setImageResource(2131231022);
        }
    }
}

