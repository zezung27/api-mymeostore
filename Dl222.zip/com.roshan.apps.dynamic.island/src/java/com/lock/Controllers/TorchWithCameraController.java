/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.SurfaceTexture
 *  android.hardware.Camera
 *  android.hardware.Camera$Parameters
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import java.io.IOException;

public class TorchWithCameraController {
    public Camera camera = null;
    private Context context;
    public boolean isEnabled = false;

    public TorchWithCameraController(Context context) {
        this.context = context;
    }

    public boolean isEnabled() {
        return this.isEnabled;
    }

    public void setTorchMode(boolean bl) {
        this.isEnabled = bl;
        if (bl) {
            Camera camera;
            this.camera = camera = Camera.open();
            Camera.Parameters parameters = camera.getParameters();
            parameters.setFlashMode("torch");
            this.camera.setParameters(parameters);
            try {
                this.camera.setPreviewTexture(new SurfaceTexture(0));
            }
            catch (IOException iOException) {}
            this.camera.startPreview();
            return;
        }
        Camera camera = this.camera;
        if (camera != null) {
            try {
                Camera.Parameters parameters = camera.getParameters();
                parameters.setFlashMode("off");
                this.camera.setParameters(parameters);
            }
            catch (Exception exception) {}
            this.camera.stopPreview();
            this.camera.release();
            this.camera = null;
        }
    }
}

