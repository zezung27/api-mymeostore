/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.graphics.Bitmap
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 */
package com.lock.entity;

import android.app.PendingIntent;
import android.graphics.Bitmap;
import com.lock.services.ActionParsable;
import java.util.ArrayList;
import java.util.HashMap;

public class Notification {
    public ArrayList<ActionParsable> actions;
    public String app_name;
    public CharSequence bigText;
    public String category;
    public int color;
    public int count;
    public long duration;
    public String groupKey;
    public Bitmap icon;
    public String id;
    public CharSequence info_text;
    public boolean isAppGroup;
    public boolean isClearable;
    public boolean isGroup;
    public boolean isGroupConversation;
    public boolean isOngoing;
    public String key;
    public HashMap<String, Notification> keyMap = new HashMap();
    public String pack;
    public PendingIntent pendingIntent;
    public Bitmap picture;
    public long position;
    public long postTime;
    public int progress;
    public boolean progressIndeterminate;
    public int progressMax;
    public Bitmap senderIcon;
    public boolean showChronometer;
    public CharSequence subText;
    public CharSequence substName;
    public CharSequence summaryText;
    public String tag;
    public String template;
    public CharSequence titleBig;
    public CharSequence tv_text;
    public CharSequence tv_title;
    public int uId;

    public Notification(String string2, Bitmap bitmap, Bitmap bitmap2, CharSequence charSequence, CharSequence charSequence2, int n, String string3, long l, PendingIntent pendingIntent, ArrayList<ActionParsable> arrayList, CharSequence charSequence3, String string4, boolean bl, int n2, Bitmap bitmap3, String string5, String string6, boolean bl2, boolean bl3, boolean bl4, boolean bl5, String string7, int n3, String string8, CharSequence charSequence4, CharSequence charSequence5, CharSequence charSequence6, CharSequence charSequence7, int n4, int n5, boolean bl6, CharSequence charSequence8, boolean bl7, String string9) {
        this.id = string2;
        this.icon = bitmap;
        this.senderIcon = bitmap2;
        this.tv_title = charSequence;
        this.tv_text = charSequence2;
        this.count = n;
        this.pack = string3;
        this.postTime = l;
        this.pendingIntent = pendingIntent;
        this.actions = arrayList;
        this.bigText = charSequence3;
        this.app_name = string4;
        this.isClearable = bl;
        this.color = n2;
        this.picture = bitmap3;
        this.groupKey = string5;
        this.key = string6;
        this.isGroupConversation = bl2;
        this.isAppGroup = bl3;
        this.isGroup = bl4;
        this.isOngoing = bl5;
        this.tag = string7;
        this.uId = n3;
        this.template = string8;
        this.substName = charSequence4;
        this.subText = charSequence5;
        this.titleBig = charSequence6;
        this.info_text = charSequence7;
        this.progressMax = n4;
        this.progress = n5;
        this.progressIndeterminate = bl6;
        this.summaryText = charSequence8;
        this.showChronometer = bl7;
        this.category = string9;
    }
}

