/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.media.projection.MediaProjection
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.utils;

import android.media.projection.MediaProjection;
import com.lock.activites.ScreenshotCaptureActivity;

public class screenShotRunable
implements Runnable {
    public void run() {
        MediaProjection mediaProjection = ScreenshotCaptureActivity.mediaProjection;
        if (mediaProjection != null) {
            mediaProjection.stop();
        }
    }
}

