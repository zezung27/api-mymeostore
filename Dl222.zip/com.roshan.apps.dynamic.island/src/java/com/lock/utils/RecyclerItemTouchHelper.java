/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.TextView
 *  androidx.recyclerview.widget.ItemTouchHelper
 *  androidx.recyclerview.widget.ItemTouchHelper$SimpleCallback
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.Boolean
 *  java.lang.Object
 */
package com.lock.utils;

import android.widget.TextView;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.CustomNotificationAdapter;

public class RecyclerItemTouchHelper
extends ItemTouchHelper.SimpleCallback {
    private final RecyclerItemTouchHelperListener listener;

    public RecyclerItemTouchHelper(int n, int n2, RecyclerItemTouchHelperListener recyclerItemTouchHelperListener) {
        super(n, n2);
        this.listener = recyclerItemTouchHelperListener;
    }

    public int convertToAbsoluteDirection(int n, int n2) {
        return super.convertToAbsoluteDirection(n, n2);
    }

    public int getSwipeDirs(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
        if (!((Boolean)((CustomNotificationAdapter.ViewHolder)viewHolder).tv_title.getTag()).booleanValue()) {
            return 0;
        }
        return super.getSwipeDirs(recyclerView, viewHolder);
    }

    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder viewHolder2) {
        return true;
    }

    public void onSwiped(RecyclerView.ViewHolder viewHolder, int n) {
        this.listener.onSwiped(viewHolder, n, viewHolder.getAbsoluteAdapterPosition());
    }

}

