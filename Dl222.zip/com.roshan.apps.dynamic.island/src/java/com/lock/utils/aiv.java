/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.lock.utils;

import android.graphics.Bitmap;

public final class aiv {
    private static String f572a = "ImageBlurCPU";

    public static Bitmap m436a(Bitmap bitmap) {
        try {
            new Object[2];
            Integer.valueOf((int)Math.round((float)(0.15f * (float)bitmap.getWidth())));
            Integer.valueOf((int)Math.round((float)(0.15f * (float)bitmap.getHeight())));
            Bitmap bitmap2 = Bitmap.createScaledBitmap((Bitmap)bitmap, (int)Math.round((float)(0.15f * (float)bitmap.getWidth())), (int)Math.round((float)(0.15f * (float)bitmap.getHeight())), (boolean)true);
            return bitmap2;
        }
        catch (Throwable throwable) {
            throwable.getMessage();
            return bitmap;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static Bitmap m438a(Bitmap bitmap, int n) {
        try {
            Integer.valueOf((int)n).intValue();
            if (n > 96) {
                n = 96;
            }
            int n2 = bitmap.getWidth() > n ? n : bitmap.getWidth();
            if (bitmap.getHeight() > n) return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n2, (int)n, (boolean)true);
            n = bitmap.getHeight();
            return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n2, (int)n, (boolean)true);
        }
        catch (Throwable throwable) {
            throwable.getMessage();
            return bitmap;
        }
    }
}

