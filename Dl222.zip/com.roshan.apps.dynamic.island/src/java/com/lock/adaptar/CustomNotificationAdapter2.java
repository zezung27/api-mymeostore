/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.app.PendingIntent$CanceledException
 *  android.app.RemoteInput
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.text.Editable
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.widget.Chronometer
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  java.util.Set
 */
package com.lock.adaptar;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.CustomNotificationAdapter2$$ExternalSyntheticLambda0;
import com.lock.adaptar.CustomNotificationAdapter2$$ExternalSyntheticLambda1;
import com.lock.adaptar.CustomNotificationAdapter2$$ExternalSyntheticLambda2;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import de.hdodenhof.circleimageview.CircleImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CustomNotificationAdapter2
extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int DAY_MILLIS = 86400000;
    private static final int HOUR_MILLIS = 3600000;
    private static final int MINUTE_MILLIS = 60000;
    private static final int SECOND_MILLIS = 1000;
    private static final int VIEW_TYPE_CALL = 2;
    private static final int VIEW_TYPE_NORMAL = 1;
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    private Utils utils;
    ViewGroup viewGroup;

    public CustomNotificationAdapter2(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
        this.utils = ((MAccessibilityService)context).utils;
    }

    private void addSubItemsToGroupContainer(final Notification notification, LinearLayout linearLayout) {
        CustomNotificationAdapter2 customNotificationAdapter2 = this;
        for (final String string2 : notification.keyMap.keySet()) {
            if (notification.keyMap.get((Object)string2) != null) {
                View view = LayoutInflater.from((Context)customNotificationAdapter2.mContext).inflate(2131558530, null);
                TextView textView = (TextView)view.findViewById(2131362509);
                TextView textView2 = (TextView)view.findViewById(2131362524);
                final TextView textView3 = (TextView)view.findViewById(2131362431);
                CircleImageView circleImageView = (CircleImageView)view.findViewById(2131361962);
                final LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362272);
                final RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362277);
                final ImageView imageView = (ImageView)view.findViewById(2131361900);
                ImageView imageView2 = (ImageView)view.findViewById(2131362278);
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon != null) {
                    circleImageView.setVisibility(0);
                    circleImageView.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon);
                } else {
                    circleImageView.setImageResource(0);
                    circleImageView.setVisibility(8);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    imageView2.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    imageView2.setImageBitmap(null);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    ((ImageView)view.findViewById(2131362278)).setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    ((ImageView)view.findViewById(2131362278)).setImageBitmap(null);
                }
                textView.setText((CharSequence)((MAccessibilityService)customNotificationAdapter2.mContext).utils.getFormatedDate(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).postTime));
                textView2.setText(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_title);
                textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions == null && ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                    imageView.setVisibility(8);
                } else {
                    imageView.setVisibility(0);
                }
                View.OnClickListener onClickListener = new View.OnClickListener(){

                    public void onClick(View view) {
                        if (linearLayout2.getVisibility() == 0) {
                            imageView.setImageResource(2131230828);
                            linearLayout2.setVisibility(8);
                            relativeLayout.setVisibility(8);
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                            return;
                        }
                        if (!((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString());
                        }
                        imageView.setImageResource(2131230829);
                        linearLayout2.setVisibility(0);
                        linearLayout2.removeAllViews();
                        if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions != null) {
                            new Handler().post(new Runnable(){

                                public void run() {
                                    linearLayout2.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter2.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter2.this.mContext));
                                    CustomNotificationAdapter2.this.addViewToActionContainer((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2))), linearLayout2);
                                }
                            });
                            return;
                        }
                        linearLayout2.setPadding(0, 0, 0, 0);
                    }

                };
                imageView.setOnClickListener(onClickListener);
                view.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter2$$ExternalSyntheticLambda2(notification, string2, linearLayout, view));
                linearLayout.addView(view);
            }
            customNotificationAdapter2 = this;
        }
    }

    private void addTitleAndTextSubItems(Notification notification, LinearLayout linearLayout) {
        for (String string2 : notification.keyMap.keySet()) {
            Notification notification2 = (Notification)notification.keyMap.get((Object)string2);
            if (notification.keyMap.size() == 1) {
                if (notification.tv_text.equals((Object)notification2.tv_text)) continue;
                linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
                continue;
            }
            linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
        }
    }

    private void addViewToActionContainer(final Notification notification, final LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        for (int i = 0; i < notification.actions.size(); ++i) {
            TextView textView = (TextView)LayoutInflater.from((Context)this.mContext).inflate(2131558525, null);
            Drawable drawable2 = ResourcesCompat.getDrawable((Resources)this.mContext.getResources(), (int)2131230923, null);
            try {
                drawable2 = ContextCompat.getDrawable((Context)this.mContext.createPackageContext(notification.pack, 0), (int)((ActionParsable)notification.actions.get((int)i)).actionIcon);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            textView.setText(((ActionParsable)notification.actions.get((int)i)).charSequence);
            textView.setTextColor(notification.color);
            if (notification.template.equals((Object)"MediaStyle")) {
                drawable2.setTint(notification.color);
                textView.setCompoundDrawablesWithIntrinsicBounds(drawable2, null, null, null);
                textView.setText((CharSequence)"");
            }
            if (i > 0) {
                textView.setPadding(50, 5, 5, 5);
            }
            linearLayout.addView((View)textView);
            textView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    new Handler().post(new Runnable(){

                        public void run() {
                            if (((ActionParsable)notification.actions.get((int)i)).remoteInputs != null) {
                                CustomNotificationAdapter2.this.showReplyBox((View)linearLayout, (ArrayList<ActionParsable>)notification.actions, i);
                                return;
                            }
                            try {
                                if (((ActionParsable)notification.actions.get((int)i)).pendingIntent != null) {
                                    ((ActionParsable)notification.actions.get((int)i)).pendingIntent.send();
                                }
                                if (!notification.template.equals((Object)"MediaStyle")) {
                                    ((ImageView)((RelativeLayout)linearLayout.getParent().getParent()).findViewById(2131361900)).setImageResource(2131230828);
                                    linearLayout.setVisibility(8);
                                    return;
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                }

            });
        }
    }

    private void addViewToCallActionContainer(Notification notification, LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        linearLayout.findViewById(2131361853).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter2$$ExternalSyntheticLambda0(this, notification));
        linearLayout.findViewById(2131361845).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter2$$ExternalSyntheticLambda1(this, notification));
    }

    private View getTitleAndTextViewForSubItems(CharSequence charSequence, CharSequence charSequence2) {
        LinearLayout linearLayout = (LinearLayout)LayoutInflater.from((Context)this.mContext).inflate(2131558533, null);
        int n = (int)Constants.convertDpToPixel(5.0f, this.mContext);
        if (charSequence.toString().isEmpty()) {
            linearLayout.findViewById(2131362141).setVisibility(8);
            linearLayout.findViewById(2131362142).setPadding(0, n, n, n);
        } else {
            ((TextView)linearLayout.findViewById(2131362141)).setText((CharSequence)charSequence.toString());
        }
        if (charSequence2.toString().isEmpty()) {
            linearLayout.findViewById(2131362142).setVisibility(8);
            return linearLayout;
        }
        ((TextView)linearLayout.findViewById(2131362142)).setText((CharSequence)charSequence2.toString());
        return linearLayout;
    }

    static /* synthetic */ void lambda$addSubItemsToGroupContainer$0(Notification notification, String string2, LinearLayout linearLayout, View view, View view2) {
        try {
            if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent != null) {
                ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent.send();
                linearLayout.removeView(view);
                notification.keyMap.remove((Object)string2);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void sendRemoteInput(PendingIntent pendingIntent, RemoteInput[] arrremoteInput, RemoteInput remoteInput, String string2) {
        Bundle bundle = new Bundle();
        bundle.putString(remoteInput.getResultKey(), string2);
        Intent intent = new Intent().addFlags(268435456);
        RemoteInput.addResultsToIntent((RemoteInput[])arrremoteInput, (Intent)intent, (Bundle)bundle);
        if (Build.VERSION.SDK_INT >= 28) {
            if (remoteInput.getAllowFreeFormInput()) {
                RemoteInput.setResultsSource((Intent)intent, (int)0);
            } else {
                RemoteInput.setResultsSource((Intent)intent, (int)1);
            }
        }
        try {
            pendingIntent.send(this.mContext, 0, intent);
            return;
        }
        catch (PendingIntent.CanceledException canceledException) {
            canceledException.printStackTrace();
            return;
        }
    }

    private void showReplyBox(final View view, final ArrayList<ActionParsable> arrayList, final int n) {
        final View view2 = ((LinearLayout)view.getParent()).getChildAt(0);
        if (view2 != null) {
            view2.setVisibility(0);
            view2.findViewById(2131362151).setVisibility(0);
            view2.findViewById(2131362151).setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    CustomNotificationAdapter2.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362043)).getText().toString());
                    ((EditText)view2.findViewById(2131362043)).setText((CharSequence)"");
                    view2.setVisibility(8);
                    view.setVisibility(8);
                }
            });
            EditText editText = (EditText)view2.findViewById(2131362043);
            TextView.OnEditorActionListener onEditorActionListener = new TextView.OnEditorActionListener(){

                public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                    boolean bl = false;
                    if (n2 == 4) {
                        CustomNotificationAdapter2.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362043)).getText().toString());
                        ((EditText)view2.findViewById(2131362043)).setText((CharSequence)"");
                        view2.setVisibility(8);
                        view.setVisibility(8);
                        bl = true;
                    }
                    return bl;
                }
            };
            editText.setOnEditorActionListener(onEditorActionListener);
        }
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public int getItemViewType(int n) {
        if (((Notification)this.notifications.get((int)n)).category.equalsIgnoreCase("call") && ((Notification)this.notifications.get((int)n)).isOngoing) {
            return 2;
        }
        return super.getItemViewType(n);
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$1$com-lock-adaptar-CustomNotificationAdapter2(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)0)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)0)).pendingIntent.send();
            }
            catch (PendingIntent.CanceledException canceledException) {
                canceledException.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$2$com-lock-adaptar-CustomNotificationAdapter2(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)1)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)1)).pendingIntent.send();
            }
            catch (PendingIntent.CanceledException canceledException) {
                canceledException.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int n) {
        if (((Notification)this.notifications.get((int)n)).category.equalsIgnoreCase("call")) {
            ((ViewHolderCall)viewHolder).bind(this.notifications);
            return;
        }
        ((ViewHolder)viewHolder).bind(this.notifications);
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        if (n == 2) {
            return new ViewHolderCall(layoutInflater.inflate(2131558527, viewGroup, false));
        }
        return new ViewHolder(layoutInflater.inflate(2131558529, viewGroup, false));
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView arrow_iv;
        private final Chronometer chronometer;
        private final View divider;
        private final LinearLayout group_message_parent;
        private final ImageView iv_app_icon;
        ImageView iv_senderIcon2;
        CircleImageView iv_sender_icon;
        private final View mRootLayout;
        private final LinearLayout notification_action_container;
        private final RelativeLayout notification_material_reply_container;
        private final ImageView picture_iv;
        private final ProgressBar progressBar;
        private final TextView sub_text;
        private final TextView tv_text;
        public final TextView tv_title;
        private ViewHolder viewHolder;

        public ViewHolder(View view) {
            super(view);
            this.viewHolder = this;
            this.mRootLayout = view;
            this.progressBar = (ProgressBar)view.findViewById(2131362430);
            this.chronometer = (Chronometer)view.findViewById(2131361960);
            this.iv_app_icon = (ImageView)view.findViewById(2131362144);
            this.tv_title = (TextView)view.findViewById(2131362509);
            this.tv_text = (TextView)view.findViewById(2131362524);
            this.divider = view.findViewById(2131362023);
            this.iv_sender_icon = (CircleImageView)view.findViewById(2131361962);
            this.notification_action_container = (LinearLayout)view.findViewById(2131362272);
            this.notification_material_reply_container = (RelativeLayout)view.findViewById(2131362277);
            this.arrow_iv = (ImageView)view.findViewById(2131361900);
            this.sub_text = (TextView)view.findViewById(2131362431);
            this.picture_iv = (ImageView)view.findViewById(2131362278);
            this.group_message_parent = (LinearLayout)view.findViewById(2131362095);
            this.iv_senderIcon2 = (ImageView)view.findViewById(2131361963);
        }

        public void bind(final ArrayList<Notification> arrayList) {
            this.viewHolder.itemView.setOnLongClickListener(null);
            this.viewHolder.itemView.setLongClickable(false);
            final Notification notification = (Notification)arrayList.get(this.viewHolder.getAbsoluteAdapterPosition());
            if (notification.picture != null && notification.keyMap.size() == 0) {
                this.viewHolder.picture_iv.setImageBitmap(notification.picture);
            } else {
                this.viewHolder.picture_iv.setImageBitmap(null);
            }
            this.viewHolder.tv_title.setText((CharSequence)notification.app_name);
            this.viewHolder.tv_title.setTag((Object)notification.isClearable);
            this.viewHolder.tv_text.setText(notification.tv_title);
            this.viewHolder.sub_text.setText((CharSequence)notification.tv_text.toString());
            this.viewHolder.group_message_parent.removeAllViews();
            CustomNotificationAdapter2.this.addTitleAndTextSubItems(notification, this.viewHolder.group_message_parent);
            this.viewHolder.notification_action_container.setVisibility(8);
            this.viewHolder.notification_material_reply_container.setVisibility(8);
            if (notification.icon != null) {
                this.viewHolder.iv_app_icon.setVisibility(0);
                this.viewHolder.iv_app_icon.setImageBitmap(notification.icon);
            }
            if (notification.senderIcon != null) {
                this.viewHolder.iv_senderIcon2.setVisibility(4);
                this.viewHolder.iv_sender_icon.setVisibility(0);
                this.viewHolder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.viewHolder.iv_sender_icon.setColorFilter(null);
            } else {
                this.viewHolder.iv_senderIcon2.setImageBitmap(notification.icon);
                this.viewHolder.iv_senderIcon2.setColorFilter(-1);
                this.viewHolder.iv_senderIcon2.setVisibility(0);
                this.viewHolder.iv_sender_icon.setVisibility(4);
                this.viewHolder.iv_app_icon.setVisibility(4);
            }
            if (notification.progressMax > 0) {
                if (notification.showChronometer) {
                    this.viewHolder.chronometer.setVisibility(0);
                    this.viewHolder.chronometer.start();
                } else {
                    this.viewHolder.chronometer.setVisibility(8);
                    this.viewHolder.chronometer.setBase(SystemClock.elapsedRealtime());
                    this.viewHolder.chronometer.stop();
                }
                this.viewHolder.progressBar.setVisibility(0);
                this.viewHolder.progressBar.setMax(notification.progressMax);
                this.viewHolder.progressBar.setProgress(notification.progress);
                this.viewHolder.progressBar.setIndeterminate(notification.progressIndeterminate);
            } else {
                this.viewHolder.progressBar.setVisibility(8);
                this.viewHolder.chronometer.setVisibility(8);
                this.viewHolder.chronometer.setBase(SystemClock.elapsedRealtime());
                this.viewHolder.chronometer.stop();
            }
            this.viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    try {
                        if (((Notification)arrayList.get((int)ViewHolder.access$800((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)arrayList.get((int)ViewHolder.access$800((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter2.this.notificationListener.onItemClicked((Notification)arrayList.get(ViewHolder.this.viewHolder.getAbsoluteAdapterPosition()));
                        }
                        if (((Notification)arrayList.get((int)ViewHolder.access$800((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).isClearable) {
                            arrayList.remove(ViewHolder.this.viewHolder.getAbsoluteAdapterPosition());
                            CustomNotificationAdapter2.this.notifyDataSetChanged();
                        }
                        ((MAccessibilityService)CustomNotificationAdapter2.this.mContext).closeFullNotificationIsland();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    ViewHolder.this.viewHolder.arrow_iv.setImageResource(2131230828);
                    ViewHolder.this.viewHolder.notification_action_container.setVisibility(8);
                }
            });
            if (notification.keyMap.size() <= 0 && (notification.bigText.toString().isEmpty() || notification.bigText.toString().equals((Object)notification.tv_text.toString())) && notification.actions == null) {
                this.viewHolder.arrow_iv.setVisibility(4);
            } else {
                this.viewHolder.arrow_iv.setVisibility(0);
                this.viewHolder.arrow_iv.setImageResource(2131230828);
            }
            if (((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                this.viewHolder.arrow_iv.setVisibility(4);
                this.viewHolder.notification_action_container.setVisibility(0);
                this.viewHolder.notification_action_container.removeAllViews();
                CustomNotificationAdapter2.this.addViewToActionContainer(notification, this.viewHolder.notification_action_container);
            }
            this.viewHolder.arrow_iv.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    int n = ViewHolder.this.viewHolder.getAbsoluteAdapterPosition();
                    if (n >= 0 && n < arrayList.size()) {
                        if (ViewHolder.this.viewHolder.notification_action_container.getVisibility() == 0) {
                            ViewHolder.this.viewHolder.arrow_iv.setImageResource(2131230828);
                            ViewHolder.this.viewHolder.notification_action_container.setVisibility(8);
                            ViewHolder.this.viewHolder.notification_material_reply_container.setVisibility(8);
                            ViewHolder.this.viewHolder.sub_text.setText((CharSequence)((Notification)arrayList.get((int)ViewHolder.access$800((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).tv_text.toString());
                            ViewHolder.this.viewHolder.group_message_parent.removeAllViews();
                            CustomNotificationAdapter2.this.addTitleAndTextSubItems(notification, ViewHolder.this.viewHolder.group_message_parent);
                            return;
                        }
                        if (!notification.bigText.toString().isEmpty()) {
                            ViewHolder.this.viewHolder.sub_text.setText((CharSequence)((Notification)arrayList.get((int)ViewHolder.access$800((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).bigText.toString());
                        }
                        ViewHolder.this.viewHolder.arrow_iv.setImageResource(2131230829);
                        ViewHolder.this.viewHolder.notification_action_container.setVisibility(0);
                        ViewHolder.this.viewHolder.notification_action_container.removeAllViews();
                        ViewHolder.this.viewHolder.group_message_parent.removeAllViews();
                        if (notification.actions != null) {
                            CustomNotificationAdapter2.this.addViewToActionContainer(notification, ViewHolder.this.viewHolder.notification_action_container);
                            ViewHolder.this.viewHolder.notification_action_container.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter2.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter2.this.mContext));
                            return;
                        }
                        CustomNotificationAdapter2.this.addSubItemsToGroupContainer(notification, ViewHolder.this.viewHolder.group_message_parent);
                        ViewHolder.this.viewHolder.notification_action_container.setPadding(0, 0, 0, 0);
                    }
                }
            });
            this.viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener(){

                public boolean onLongClick(View view) {
                    return false;
                }
            });
        }

    }

    public class ViewHolderCall
    extends RecyclerView.ViewHolder {
        CircleImageView iv_sender_icon;
        private final View mRootLayout;
        private final LinearLayout notification_action_container;
        private final TextView tv_text;
        public final TextView tv_title;
        private ViewHolderCall viewHolder;

        public ViewHolderCall(View view) {
            super(view);
            this.viewHolder = this;
            this.mRootLayout = view;
            this.tv_title = (TextView)view.findViewById(2131362509);
            this.tv_text = (TextView)view.findViewById(2131362524);
            this.iv_sender_icon = (CircleImageView)view.findViewById(2131361962);
            this.notification_action_container = (LinearLayout)view.findViewById(2131362273);
        }

        public void bind(final ArrayList<Notification> arrayList) {
            this.viewHolder.itemView.setOnLongClickListener(null);
            this.viewHolder.itemView.setLongClickable(false);
            Notification notification = (Notification)arrayList.get(this.viewHolder.getAbsoluteAdapterPosition());
            this.viewHolder.tv_title.setText((CharSequence)notification.app_name);
            this.viewHolder.tv_title.setTag((Object)notification.isClearable);
            this.viewHolder.tv_text.setText(notification.tv_title);
            if (notification.senderIcon != null) {
                this.viewHolder.iv_sender_icon.setVisibility(0);
                this.viewHolder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.viewHolder.iv_sender_icon.setColorFilter(null);
            } else {
                this.viewHolder.iv_sender_icon.setVisibility(4);
            }
            this.viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    try {
                        if (((Notification)arrayList.get((int)ViewHolderCall.access$400((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)arrayList.get((int)ViewHolderCall.access$400((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter2.this.notificationListener.onItemClicked((Notification)arrayList.get(ViewHolderCall.this.viewHolder.getAbsoluteAdapterPosition()));
                        }
                        if (((Notification)arrayList.get((int)ViewHolderCall.access$400((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).isClearable) {
                            arrayList.remove(ViewHolderCall.this.viewHolder.getAbsoluteAdapterPosition());
                            CustomNotificationAdapter2.this.notifyDataSetChanged();
                        }
                        ((MAccessibilityService)CustomNotificationAdapter2.this.mContext).closeFullNotificationIsland();
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        return;
                    }
                }
            });
            if (((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                CustomNotificationAdapter2.this.addViewToCallActionContainer(notification, this.viewHolder.notification_action_container);
            }
        }

    }

}

