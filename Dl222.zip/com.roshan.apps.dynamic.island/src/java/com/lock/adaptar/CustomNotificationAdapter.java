/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.app.PendingIntent$CanceledException
 *  android.app.RemoteInput
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.text.Editable
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.widget.Chronometer
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.android.material.imageview.ShapeableImageView
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.text.DecimalFormat
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  java.util.Set
 */
package com.lock.adaptar;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.imageview.ShapeableImageView;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda0;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda1;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda2;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda3;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda4;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda5;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.services.NotificationService;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import de.hdodenhof.circleimageview.CircleImageView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CustomNotificationAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private static final int DAY_MILLIS = 86400000;
    private static final int HOUR_MILLIS = 3600000;
    private static final int MINUTE_MILLIS = 60000;
    private static final int SECOND_MILLIS = 1000;
    private static final DecimalFormat df = new DecimalFormat("00");
    private final Context mContext;
    ViewHolder mediaViewHolder;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    private Utils utils;
    ViewGroup viewGroup;

    public CustomNotificationAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
        this.utils = ((MAccessibilityService)context).utils;
    }

    private void addSubItemsToGroupContainer(final Notification notification, LinearLayout linearLayout) {
        CustomNotificationAdapter customNotificationAdapter = this;
        for (final String string2 : notification.keyMap.keySet()) {
            if (notification.keyMap.get((Object)string2) != null) {
                View view = LayoutInflater.from((Context)customNotificationAdapter.mContext).inflate(2131558530, null);
                TextView textView = (TextView)view.findViewById(2131362509);
                TextView textView2 = (TextView)view.findViewById(2131362524);
                final TextView textView3 = (TextView)view.findViewById(2131362431);
                CircleImageView circleImageView = (CircleImageView)view.findViewById(2131361962);
                final LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362272);
                final RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362277);
                final ImageView imageView = (ImageView)view.findViewById(2131361900);
                ImageView imageView2 = (ImageView)view.findViewById(2131362278);
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon != null) {
                    circleImageView.setVisibility(0);
                    circleImageView.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon);
                } else {
                    circleImageView.setImageResource(0);
                    circleImageView.setVisibility(8);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    imageView2.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    imageView2.setImageBitmap(null);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    ((ImageView)view.findViewById(2131362278)).setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    ((ImageView)view.findViewById(2131362278)).setImageBitmap(null);
                }
                textView.setText((CharSequence)((MAccessibilityService)customNotificationAdapter.mContext).utils.getFormatedDate(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).postTime));
                textView2.setText(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_title);
                textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions == null && ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                    imageView.setVisibility(8);
                } else {
                    imageView.setVisibility(0);
                }
                View.OnClickListener onClickListener = new View.OnClickListener(){

                    public void onClick(View view) {
                        if (linearLayout2.getVisibility() == 0) {
                            imageView.setImageResource(2131230828);
                            linearLayout2.setVisibility(8);
                            relativeLayout.setVisibility(8);
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                            return;
                        }
                        if (!((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString());
                        }
                        imageView.setImageResource(2131230829);
                        linearLayout2.setVisibility(0);
                        linearLayout2.removeAllViews();
                        if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions != null) {
                            new Handler().post(new Runnable(){

                                public void run() {
                                    linearLayout2.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.this.mContext));
                                    CustomNotificationAdapter.this.addViewToActionContainer((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2))), linearLayout2);
                                }
                            });
                            return;
                        }
                        linearLayout2.setPadding(0, 0, 0, 0);
                    }

                };
                imageView.setOnClickListener(onClickListener);
                view.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda0(notification, string2, linearLayout, view));
                linearLayout.addView(view);
            }
            customNotificationAdapter = this;
        }
    }

    private void addTitleAndTextSubItems(Notification notification, LinearLayout linearLayout) {
        for (String string2 : notification.keyMap.keySet()) {
            Notification notification2 = (Notification)notification.keyMap.get((Object)string2);
            if (notification.keyMap.size() == 1) {
                if (notification.tv_text.equals((Object)notification2.tv_text)) continue;
                linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
                continue;
            }
            linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
        }
    }

    private void addViewToActionContainer(Notification notification, LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        for (int i = 0; i < notification.actions.size(); ++i) {
            TextView textView = (TextView)LayoutInflater.from((Context)this.mContext).inflate(2131558525, null);
            Drawable drawable2 = ResourcesCompat.getDrawable((Resources)this.mContext.getResources(), (int)2131230923, null);
            try {
                drawable2 = ContextCompat.getDrawable((Context)this.mContext.createPackageContext(notification.pack, 0), (int)((ActionParsable)notification.actions.get((int)i)).actionIcon);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            textView.setText(((ActionParsable)notification.actions.get((int)i)).charSequence);
            textView.setTextColor(notification.color);
            if (notification.template.equals((Object)"MediaStyle")) {
                drawable2.setTint(notification.color);
                textView.setCompoundDrawablesWithIntrinsicBounds(drawable2, null, null, null);
                textView.setText((CharSequence)"");
            }
            if (i > 0) {
                textView.setPadding(50, 5, 5, 5);
            }
            linearLayout.addView((View)textView);
            textView.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda2(this, notification, i, linearLayout));
        }
        if (notification.isClearable) {
            ImageView imageView = new ImageView(this.mContext);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMarginStart((int)this.utils.convertPixelsToDp(80.0f, this.mContext));
            imageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            imageView.setImageResource(2131230928);
            imageView.setColorFilter(notification.color);
            imageView.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda3(this, notification));
            linearLayout.addView((View)imageView);
        }
    }

    private void addViewToCallActionContainer(Notification notification, LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        linearLayout.findViewById(2131361853).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda4(this, notification));
        linearLayout.findViewById(2131361845).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda5(this, notification));
    }

    private String getFormattedTime(long l) {
        long l2 = l / 1000L;
        long l3 = l2 / 60L;
        long l4 = l2 % 60L;
        DecimalFormat decimalFormat = df;
        String string2 = decimalFormat.format(l3);
        String string3 = decimalFormat.format(l4);
        return string2 + ":" + string3;
    }

    private View getTitleAndTextViewForSubItems(CharSequence charSequence, CharSequence charSequence2) {
        LinearLayout linearLayout = (LinearLayout)LayoutInflater.from((Context)this.mContext).inflate(2131558533, null);
        int n = (int)Constants.convertDpToPixel(5.0f, this.mContext);
        if (charSequence.toString().isEmpty()) {
            linearLayout.findViewById(2131362141).setVisibility(8);
            linearLayout.findViewById(2131362142).setPadding(0, n, n, n);
        } else {
            ((TextView)linearLayout.findViewById(2131362141)).setText((CharSequence)charSequence.toString());
        }
        if (charSequence2.toString().isEmpty()) {
            linearLayout.findViewById(2131362142).setVisibility(8);
            return linearLayout;
        }
        ((TextView)linearLayout.findViewById(2131362142)).setText((CharSequence)charSequence2.toString());
        return linearLayout;
    }

    static /* synthetic */ void lambda$addSubItemsToGroupContainer$0(Notification notification, String string2, LinearLayout linearLayout, View view, View view2) {
        try {
            if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent != null) {
                ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent.send();
                linearLayout.removeView(view);
                notification.keyMap.remove((Object)string2);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void sendRemoteInput(PendingIntent pendingIntent, RemoteInput[] arrremoteInput, RemoteInput remoteInput, String string2) {
        Bundle bundle = new Bundle();
        bundle.putString(remoteInput.getResultKey(), string2);
        Intent intent = new Intent().addFlags(268435456);
        RemoteInput.addResultsToIntent((RemoteInput[])arrremoteInput, (Intent)intent, (Bundle)bundle);
        if (Build.VERSION.SDK_INT >= 28) {
            if (remoteInput.getAllowFreeFormInput()) {
                RemoteInput.setResultsSource((Intent)intent, (int)0);
            } else {
                RemoteInput.setResultsSource((Intent)intent, (int)1);
            }
        }
        try {
            pendingIntent.send(this.mContext, 0, intent);
            return;
        }
        catch (PendingIntent.CanceledException canceledException) {
            canceledException.printStackTrace();
            return;
        }
    }

    private void showReplyBox(final View view, final ArrayList<ActionParsable> arrayList, final int n) {
        final View view2 = ((LinearLayout)view.getParent()).getChildAt(0);
        if (view2 != null) {
            view2.setVisibility(0);
            view2.findViewById(2131362151).setVisibility(0);
            view2.findViewById(2131362151).setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    CustomNotificationAdapter.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362043)).getText().toString());
                    ((EditText)view2.findViewById(2131362043)).setText((CharSequence)"");
                    view2.setVisibility(8);
                    view.setVisibility(8);
                }
            });
            EditText editText = (EditText)view2.findViewById(2131362043);
            TextView.OnEditorActionListener onEditorActionListener = new TextView.OnEditorActionListener(){

                public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                    boolean bl = false;
                    if (n2 == 4) {
                        CustomNotificationAdapter.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362043)).getText().toString());
                        ((EditText)view2.findViewById(2131362043)).setText((CharSequence)"");
                        view2.setVisibility(8);
                        view.setVisibility(8);
                        bl = true;
                    }
                    return bl;
                }
            };
            editText.setOnEditorActionListener(onEditorActionListener);
        }
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    /* synthetic */ void lambda$addViewToActionContainer$1$com-lock-adaptar-CustomNotificationAdapter(Notification notification, int n, LinearLayout linearLayout) {
        if (((ActionParsable)notification.actions.get((int)n)).remoteInputs != null) {
            this.showReplyBox((View)linearLayout, notification.actions, n);
            return;
        }
        try {
            if (((ActionParsable)notification.actions.get((int)n)).pendingIntent != null) {
                ((ActionParsable)notification.actions.get((int)n)).pendingIntent.send();
            }
            if (!notification.template.equals((Object)"MediaStyle")) {
                ((ImageView)((RelativeLayout)linearLayout.getParent().getParent()).findViewById(2131361900)).setImageResource(2131230828);
                linearLayout.setVisibility(8);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (notification.category.equalsIgnoreCase("call")) {
            ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
        }
    }

    /* synthetic */ void lambda$addViewToActionContainer$2$com-lock-adaptar-CustomNotificationAdapter(Notification notification, int n, LinearLayout linearLayout, View view) {
        new Handler().post((Runnable)new CustomNotificationAdapter$$ExternalSyntheticLambda1(this, notification, n, linearLayout));
    }

    /* synthetic */ void lambda$addViewToActionContainer$3$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
        NotificationService.getInstance().cancelNotificationById(notification.key);
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$4$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)0)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)0)).pendingIntent.send();
            }
            catch (PendingIntent.CanceledException canceledException) {
                canceledException.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$5$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)1)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)1)).pendingIntent.send();
            }
            catch (PendingIntent.CanceledException canceledException) {
                canceledException.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    public void onBindViewHolder(ViewHolder viewHolder, int n) {
        viewHolder.bind(this.notifications);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        return new ViewHolder(layoutInflater.inflate(2131558529, viewGroup, false));
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        viewHolder.clearAnimation();
        super.onViewDetachedFromWindow((RecyclerView.ViewHolder)viewHolder);
    }

    public void updateMediaProgress() {
        int n = this.mediaViewHolder.getAbsoluteAdapterPosition();
        if (this.mediaViewHolder != null && n >= 0) {
            String string2 = this.getFormattedTime(((Notification)this.notifications.get((int)n)).duration);
            String string3 = this.getFormattedTime(((Notification)this.notifications.get((int)n)).position);
            this.mediaViewHolder.tv_duration.setText((CharSequence)string2);
            this.mediaViewHolder.tv_position.setText((CharSequence)string3);
            this.mediaViewHolder.progressBar.setProgress(((Notification)this.notifications.get((int)n)).progress);
            this.mediaViewHolder.progressBar.setVisibility(0);
            this.mediaViewHolder.progressBar.setMax(((Notification)this.notifications.get((int)n)).progressMax);
        }
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView arrow_iv;
        private final Chronometer chronometer;
        private final View divider;
        private final LinearLayout group_message_parent;
        private ViewHolder holder;
        private final ImageView iv_app_icon;
        ImageView iv_senderIcon2;
        ShapeableImageView iv_sender_icon;
        private final View mRootLayout;
        private final LinearLayout notification_action_container;
        private final RelativeLayout notification_material_reply_container;
        private final ImageView picture_iv;
        private final ProgressBar progressBar;
        private final TextView sub_text;
        private final TextView tv_duration;
        private final TextView tv_position;
        private final TextView tv_text;
        public final TextView tv_title;

        public ViewHolder(View view) {
            super(view);
            this.holder = this;
            CustomNotificationAdapter.this.mediaViewHolder = this;
            this.mRootLayout = view;
            this.tv_position = (TextView)view.findViewById(2131362208);
            this.tv_duration = (TextView)view.findViewById(2131362207);
            this.progressBar = (ProgressBar)view.findViewById(2131362430);
            this.chronometer = (Chronometer)view.findViewById(2131361960);
            this.iv_app_icon = (ImageView)view.findViewById(2131362144);
            this.tv_title = (TextView)view.findViewById(2131362509);
            this.tv_text = (TextView)view.findViewById(2131362524);
            this.divider = view.findViewById(2131362023);
            this.iv_sender_icon = (ShapeableImageView)view.findViewById(2131361962);
            this.notification_action_container = (LinearLayout)view.findViewById(2131362272);
            this.notification_material_reply_container = (RelativeLayout)view.findViewById(2131362277);
            this.arrow_iv = (ImageView)view.findViewById(2131361900);
            this.sub_text = (TextView)view.findViewById(2131362431);
            this.picture_iv = (ImageView)view.findViewById(2131362278);
            this.group_message_parent = (LinearLayout)view.findViewById(2131362095);
            this.iv_senderIcon2 = (ImageView)view.findViewById(2131361963);
        }

        public void bind(final ArrayList<Notification> arrayList) {
            this.holder.itemView.setOnLongClickListener(null);
            this.holder.itemView.setLongClickable(false);
            final Notification notification = (Notification)arrayList.get(this.holder.getAbsoluteAdapterPosition());
            if (notification.picture != null && notification.keyMap.size() == 0) {
                this.holder.picture_iv.setImageBitmap(notification.picture);
            } else {
                this.holder.picture_iv.setImageBitmap(null);
            }
            this.holder.tv_title.setText((CharSequence)notification.app_name);
            this.holder.tv_title.setTag((Object)notification.isClearable);
            this.holder.tv_text.setText(notification.tv_title);
            this.holder.sub_text.setText((CharSequence)notification.tv_text.toString());
            this.holder.group_message_parent.removeAllViews();
            CustomNotificationAdapter.this.addTitleAndTextSubItems(notification, this.holder.group_message_parent);
            this.holder.notification_action_container.setVisibility(8);
            this.holder.notification_material_reply_container.setVisibility(8);
            if (notification.icon != null) {
                this.holder.iv_app_icon.setVisibility(0);
                this.holder.iv_app_icon.setImageBitmap(notification.icon);
            }
            if (notification.senderIcon != null) {
                this.holder.iv_senderIcon2.setVisibility(4);
                this.holder.iv_sender_icon.setVisibility(0);
                this.holder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.holder.iv_sender_icon.setColorFilter(null);
            } else {
                this.holder.iv_senderIcon2.setImageBitmap(notification.icon);
                this.holder.iv_senderIcon2.setColorFilter(-1);
                this.holder.iv_senderIcon2.setVisibility(0);
                this.holder.iv_sender_icon.setVisibility(4);
                this.holder.iv_app_icon.setVisibility(4);
            }
            if (notification.progressMax > 0) {
                if (notification.showChronometer) {
                    this.holder.chronometer.setVisibility(0);
                    this.holder.chronometer.start();
                } else {
                    this.holder.chronometer.setVisibility(8);
                    this.holder.chronometer.setBase(SystemClock.elapsedRealtime());
                    this.holder.chronometer.stop();
                }
                this.holder.progressBar.setVisibility(0);
                this.holder.progressBar.setMax(notification.progressMax);
                this.holder.progressBar.setProgress(notification.progress);
                this.holder.progressBar.setIndeterminate(notification.progressIndeterminate);
            } else {
                this.holder.progressBar.setVisibility(8);
                this.holder.chronometer.setVisibility(8);
                this.holder.chronometer.setBase(SystemClock.elapsedRealtime());
                this.holder.chronometer.stop();
            }
            this.holder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    try {
                        if (((Notification)arrayList.get((int)ViewHolder.access$700((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)arrayList.get((int)ViewHolder.access$700((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter.this.notificationListener.onItemClicked((Notification)arrayList.get(ViewHolder.this.holder.getAbsoluteAdapterPosition()));
                        }
                        if (((Notification)arrayList.get((int)ViewHolder.access$700((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).isClearable) {
                            arrayList.remove(ViewHolder.this.holder.getAbsoluteAdapterPosition());
                            CustomNotificationAdapter.this.notifyDataSetChanged();
                        }
                        ((MAccessibilityService)CustomNotificationAdapter.this.mContext).closeFullNotificationIsland();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    ViewHolder.this.holder.arrow_iv.setImageResource(2131230828);
                    ViewHolder.this.holder.notification_action_container.setVisibility(8);
                }
            });
            if (notification.keyMap.size() <= 0 && (notification.bigText.toString().isEmpty() || notification.bigText.toString().equals((Object)notification.tv_text.toString())) && notification.actions == null) {
                this.holder.arrow_iv.setVisibility(4);
            } else {
                this.holder.arrow_iv.setVisibility(0);
                this.holder.arrow_iv.setImageResource(2131230828);
            }
            if (((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                this.holder.arrow_iv.setVisibility(4);
                this.holder.notification_action_container.setVisibility(0);
                this.holder.notification_action_container.removeAllViews();
                CustomNotificationAdapter.this.addViewToActionContainer(notification, this.holder.notification_action_container);
                if (notification.template.equals((Object)"MediaStyle")) {
                    this.holder.tv_duration.setVisibility(0);
                    this.holder.tv_position.setVisibility(0);
                    String string2 = CustomNotificationAdapter.this.getFormattedTime(((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).duration);
                    String string3 = CustomNotificationAdapter.this.getFormattedTime(((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).position);
                    this.holder.tv_duration.setText((CharSequence)string2);
                    this.holder.tv_position.setText((CharSequence)string3);
                } else {
                    this.holder.tv_duration.setVisibility(8);
                    this.holder.tv_position.setVisibility(8);
                }
            } else {
                this.holder.tv_duration.setVisibility(8);
                this.holder.tv_position.setVisibility(8);
            }
            this.holder.arrow_iv.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    int n = ViewHolder.this.holder.getAbsoluteAdapterPosition();
                    if (n >= 0 && n < arrayList.size()) {
                        if (ViewHolder.this.holder.notification_action_container.getVisibility() == 0) {
                            ViewHolder.this.holder.arrow_iv.setImageResource(2131230828);
                            ViewHolder.this.holder.notification_action_container.setVisibility(8);
                            ViewHolder.this.holder.notification_material_reply_container.setVisibility(8);
                            ViewHolder.this.holder.sub_text.setText((CharSequence)((Notification)arrayList.get((int)ViewHolder.access$700((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).tv_text.toString());
                            ViewHolder.this.holder.group_message_parent.removeAllViews();
                            CustomNotificationAdapter.this.addTitleAndTextSubItems(notification, ViewHolder.this.holder.group_message_parent);
                            return;
                        }
                        if (!notification.bigText.toString().isEmpty()) {
                            ViewHolder.this.holder.sub_text.setText((CharSequence)((Notification)arrayList.get((int)ViewHolder.access$700((ViewHolder)ViewHolder.this).getAbsoluteAdapterPosition())).bigText.toString());
                        }
                        ViewHolder.this.holder.arrow_iv.setImageResource(2131230829);
                        ViewHolder.this.holder.notification_action_container.setVisibility(0);
                        ViewHolder.this.holder.notification_action_container.removeAllViews();
                        ViewHolder.this.holder.group_message_parent.removeAllViews();
                        if (notification.actions != null) {
                            CustomNotificationAdapter.this.addViewToActionContainer(notification, ViewHolder.this.holder.notification_action_container);
                            ViewHolder.this.holder.notification_action_container.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.this.mContext));
                            return;
                        }
                        CustomNotificationAdapter.this.addSubItemsToGroupContainer(notification, ViewHolder.this.holder.group_message_parent);
                        ViewHolder.this.holder.notification_action_container.setPadding(0, 0, 0, 0);
                    }
                }
            });
            this.holder.itemView.setOnLongClickListener(new View.OnLongClickListener(){

                public boolean onLongClick(View view) {
                    return false;
                }
            });
        }

        public void clearAnimation() {
            this.mRootLayout.clearAnimation();
        }

    }

    public class ViewHolderCall
    extends RecyclerView.ViewHolder {
        CircleImageView iv_sender_icon;
        private final View mRootLayout;
        private final LinearLayout notification_action_container;
        private final TextView tv_text;
        public final TextView tv_title;
        private ViewHolderCall viewHolder;

        public ViewHolderCall(View view) {
            super(view);
            this.viewHolder = this;
            this.mRootLayout = view;
            this.tv_title = (TextView)view.findViewById(2131362509);
            this.tv_text = (TextView)view.findViewById(2131362524);
            this.iv_sender_icon = (CircleImageView)view.findViewById(2131361962);
            this.notification_action_container = (LinearLayout)view.findViewById(2131362273);
        }

        public void bind(final ArrayList<Notification> arrayList) {
            this.viewHolder.itemView.setOnLongClickListener(null);
            this.viewHolder.itemView.setLongClickable(false);
            Notification notification = (Notification)arrayList.get(this.viewHolder.getAbsoluteAdapterPosition());
            this.viewHolder.tv_title.setText((CharSequence)notification.app_name);
            this.viewHolder.tv_title.setTag((Object)notification.isClearable);
            this.viewHolder.tv_text.setText(notification.tv_title);
            if (notification.senderIcon != null) {
                this.viewHolder.iv_sender_icon.setVisibility(0);
                this.viewHolder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.viewHolder.iv_sender_icon.setColorFilter(null);
            } else {
                this.viewHolder.iv_sender_icon.setVisibility(4);
            }
            this.viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    try {
                        if (((Notification)arrayList.get((int)ViewHolderCall.access$1600((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)arrayList.get((int)ViewHolderCall.access$1600((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter.this.notificationListener.onItemClicked((Notification)arrayList.get(ViewHolderCall.this.viewHolder.getAbsoluteAdapterPosition()));
                        }
                        if (((Notification)arrayList.get((int)ViewHolderCall.access$1600((ViewHolderCall)ViewHolderCall.this).getAbsoluteAdapterPosition())).isClearable) {
                            arrayList.remove(ViewHolderCall.this.viewHolder.getAbsoluteAdapterPosition());
                            CustomNotificationAdapter.this.notifyDataSetChanged();
                        }
                        ((MAccessibilityService)CustomNotificationAdapter.this.mContext).closeFullNotificationIsland();
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        return;
                    }
                }
            });
            if (((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                CustomNotificationAdapter.this.addViewToCallActionContainer(notification, this.viewHolder.notification_action_container);
            }
        }

    }

}

