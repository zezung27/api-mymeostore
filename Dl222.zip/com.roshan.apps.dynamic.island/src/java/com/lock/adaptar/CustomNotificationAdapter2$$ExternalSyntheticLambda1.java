/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.lock.adaptar;

import android.view.View;
import com.lock.adaptar.CustomNotificationAdapter2;
import com.lock.entity.Notification;

public final class CustomNotificationAdapter2$$ExternalSyntheticLambda1
implements View.OnClickListener {
    public final /* synthetic */ CustomNotificationAdapter2 f$0;
    public final /* synthetic */ Notification f$1;

    public /* synthetic */ CustomNotificationAdapter2$$ExternalSyntheticLambda1(CustomNotificationAdapter2 customNotificationAdapter2, Notification notification) {
        this.f$0 = customNotificationAdapter2;
        this.f$1 = notification;
    }

    public final void onClick(View view) {
        this.f$0.lambda$addViewToCallActionContainer$2$com-lock-adaptar-CustomNotificationAdapter2(this.f$1, view);
    }
}

