/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.view.ContextThemeWrapper
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.entity.LockData;
import com.lock.utils.Constants;
import java.util.ArrayList;

public class LockListAdaptr
extends RecyclerView.Adapter<MyViewHolder> {
    private LayoutInflater inflater = null;
    private Context mContext;
    public ArrayList<LockData> themeData;

    public LockListAdaptr(Context context, ArrayList<LockData> arrayList) {
        this.mContext = context;
        this.themeData = arrayList;
    }

    public int getItemCount() {
        return this.themeData.size();
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, int n) {
        final LockData lockData = (LockData)this.themeData.get(n);
        Glide.with((Context)this.mContext).load(lockData.getImage()).listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                myViewHolder.progressBar.setVisibility(8);
                return false;
            }

            public boolean onResourceReady(Drawable drawable2, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                myViewHolder.progressBar.setVisibility(8);
                return false;
            }
        }).into(myViewHolder.image);
        myViewHolder.name.setText((CharSequence)(lockData.getName() + " Lock"));
        myViewHolder.image.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (Constants.isAppInstalled(LockListAdaptr.this.mContext, lockData.getPkg())) {
                    Intent intent = LockListAdaptr.this.mContext.getPackageManager().getLaunchIntentForPackage(lockData.getPkg());
                    LockListAdaptr.this.mContext.startActivity(intent);
                    return;
                }
                new AlertDialog.Builder((Context)new ContextThemeWrapper(LockListAdaptr.this.mContext, 2131951618)).setIcon(2131230824).setTitle((CharSequence)(lockData.getName() + " Lock")).setMessage((CharSequence)"Do You Want To Install It From PlayStore.....!!!").setPositiveButton((CharSequence)"Yes", new DialogInterface.OnClickListener(){

                    public void onClick(DialogInterface dialogInterface, int n) {
                        LockListAdaptr.this.mContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/details?id=" + lockData.getPkg()))));
                    }
                }).setNegativeButton((CharSequence)"No", null).show();
            }

        });
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new MyViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558469, viewGroup, false));
    }

    public class MyViewHolder
    extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name;
        ProgressBar progressBar;

        public MyViewHolder(View view) {
            super(view);
            this.progressBar = (ProgressBar)view.findViewById(2131362314);
            this.image = (ImageView)view.findViewById(2131361896);
            this.name = (TextView)view.findViewById(2131361897);
        }
    }

}

