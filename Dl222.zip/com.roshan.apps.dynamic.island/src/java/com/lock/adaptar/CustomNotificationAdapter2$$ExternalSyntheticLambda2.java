/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.adaptar;

import android.view.View;
import android.widget.LinearLayout;
import com.lock.adaptar.CustomNotificationAdapter2;
import com.lock.entity.Notification;

public final class CustomNotificationAdapter2$$ExternalSyntheticLambda2
implements View.OnClickListener {
    public final /* synthetic */ Notification f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ LinearLayout f$2;
    public final /* synthetic */ View f$3;

    public /* synthetic */ CustomNotificationAdapter2$$ExternalSyntheticLambda2(Notification notification, String string2, LinearLayout linearLayout, View view) {
        this.f$0 = notification;
        this.f$1 = string2;
        this.f$2 = linearLayout;
        this.f$3 = view;
    }

    public final void onClick(View view) {
        CustomNotificationAdapter2.lambda$addSubItemsToGroupContainer$0(this.f$0, this.f$1, this.f$2, this.f$3, view);
    }
}

