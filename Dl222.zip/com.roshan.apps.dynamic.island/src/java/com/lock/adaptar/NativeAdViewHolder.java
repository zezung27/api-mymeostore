/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.android.gms.ads.nativead.MediaView
 *  com.google.android.gms.ads.nativead.NativeAdView
 */
package com.lock.adaptar;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAdView;

public class NativeAdViewHolder
extends RecyclerView.ViewHolder {
    private NativeAdView adView;

    public NativeAdViewHolder(View view) {
        NativeAdView nativeAdView;
        super(view);
        this.adView = nativeAdView = (NativeAdView)view.findViewById(2131361876);
        nativeAdView.setMediaView((MediaView)nativeAdView.findViewById(2131361872));
        NativeAdView nativeAdView2 = this.adView;
        nativeAdView2.setHeadlineView(nativeAdView2.findViewById(2131361871));
        NativeAdView nativeAdView3 = this.adView;
        nativeAdView3.setBodyView(nativeAdView3.findViewById(2131361869));
        NativeAdView nativeAdView4 = this.adView;
        nativeAdView4.setCallToActionView(nativeAdView4.findViewById(2131361870));
        NativeAdView nativeAdView5 = this.adView;
        nativeAdView5.setIconView(nativeAdView5.findViewById(2131361868));
        NativeAdView nativeAdView6 = this.adView;
        nativeAdView6.setPriceView(nativeAdView6.findViewById(2131361873));
        NativeAdView nativeAdView7 = this.adView;
        nativeAdView7.setStarRatingView(nativeAdView7.findViewById(2131361874));
        NativeAdView nativeAdView8 = this.adView;
        nativeAdView8.setStoreView(nativeAdView8.findViewById(2131361875));
        NativeAdView nativeAdView9 = this.adView;
        nativeAdView9.setAdvertiserView(nativeAdView9.findViewById(2131361867));
    }

    public NativeAdView getAdView() {
        return this.adView;
    }
}

