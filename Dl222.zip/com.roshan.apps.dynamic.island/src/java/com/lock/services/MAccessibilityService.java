/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.accessibilityservice.AccessibilityService$GestureResultCallback
 *  android.accessibilityservice.GestureDescription
 *  android.accessibilityservice.GestureDescription$Builder
 *  android.accessibilityservice.GestureDescription$StrokeDescription
 *  android.app.KeyguardManager
 *  android.app.PendingIntent
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.database.ContentObserver
 *  android.graphics.Bitmap
 *  android.graphics.Color
 *  android.graphics.Path
 *  android.media.MediaMetadata
 *  android.media.session.MediaController
 *  android.media.session.MediaSessionManager
 *  android.media.session.PlaybackState
 *  android.net.Uri
 *  android.os.Handler
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnSystemUiVisibilityChangeListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.accessibility.AccessibilityEvent
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  androidx.core.graphics.ColorUtils
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ItemDecoration
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.lock.views.CustomRecyclerView
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.List
 */
package com.lock.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import androidx.core.graphics.ColorUtils;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.adaptar.CustomNotificationIconAdapter;
import com.lock.background.PrefManager;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda0;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda1;
import com.lock.services.MAccessibilityService$9$$ExternalSyntheticLambda0;
import com.lock.services.NotificationListener;
import com.lock.services.NotificationService;
import com.lock.utils.Constants;
import com.lock.utils.ItemOffsetDecoration2;
import com.lock.utils.Utils;
import com.lock.views.CustomRecyclerView;
import com.lock.views.StatusBarParentView;
import java.util.ArrayList;
import java.util.List;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class MAccessibilityService
extends AccessibilityService {
    public static final Uri ENABLED_ACCESSIBILITY_SERVICES = Settings.Secure.getUriFor((String)"enabled_accessibility_services");
    private static MContentObserver mContentObserver;
    private CustomNotificationAdapter adapter_island_big;
    private CustomNotificationIconAdapter adapter_island_small;
    int currentIndex = 0;
    int flagKeyBoard = 8913696;
    int flagNormal = 8913704;
    private final Handler handler;
    boolean isControlEnabled = true;
    private boolean isInFullScreen;
    private boolean isPhoneLocked;
    boolean isShowingFullIsland = false;
    private LinearLayout island_parent_layout;
    private LinearLayout island_top_layout;
    private final ArrayList<Notification> list_big_island = new ArrayList();
    private final ArrayList<Notification> list_small_island = new ArrayList();
    SharedPreferences.OnSharedPreferenceChangeListener listener;
    WindowManager.LayoutParams localLayoutParams;
    Context mContext;
    Handler mHandle;
    private BroadcastReceiver mInfoReceiver = new BroadcastReceiver(){

        public void onReceive(Context context, Intent intent) {
            KeyguardManager keyguardManager = (KeyguardManager)MAccessibilityService.this.mContext.getSystemService("keyguard");
            if (intent.getAction().equals((Object)"android.intent.action.USER_PRESENT") || intent.getAction().equals((Object)"android.intent.action.SCREEN_OFF") || intent.getAction().equals((Object)"android.intent.action.SCREEN_ON")) {
                if (keyguardManager.inKeyguardRestrictedInputMode()) {
                    MAccessibilityService.this.isPhoneLocked = true;
                    if (!Constants.getShowOnLock(MAccessibilityService.this.mContext)) {
                        MAccessibilityService.this.hideSmallIslandNotification();
                        MAccessibilityService.this.closeFullNotificationIsland();
                        return;
                    }
                } else {
                    MAccessibilityService.this.isPhoneLocked = false;
                }
            }
        }
    };
    Runnable mRunnable = new MAccessibilityService$$ExternalSyntheticLambda1(this);
    WindowManager manager;
    int margin = 25;
    private final int maxIslandHeight = 170;
    private final int maxIslandHeight2 = 110;
    private final int maxIslandWidth = 350;
    Handler mediaHandler = new Handler();
    Runnable mediaUpdateRunnable = new Runnable(){

        public void run() {
            MAccessibilityService.this.notification.duration = MAccessibilityService.this.getMediaDuration();
            MAccessibilityService.this.notification.position = MAccessibilityService.this.getMediaPosition();
            if (MAccessibilityService.this.notification.duration > 0L) {
                int n = (int)(100.0f * ((float)MAccessibilityService.this.notification.position / (float)MAccessibilityService.this.notification.duration));
                MAccessibilityService.this.notification.progressMax = 100;
                MAccessibilityService.this.notification.progress = n;
                MAccessibilityService.this.notification.progressIndeterminate = false;
                MAccessibilityService.this.adapter_island_big.updateMediaProgress();
            }
            MAccessibilityService.this.mediaHandler.postDelayed(MAccessibilityService.this.mediaUpdateRunnable, 1000L);
        }
    };
    public int minCameIslandWidth = 150;
    private int minIslandHeight = 30;
    public int minOneCameIslandWidth = 150;
    public int minThreeCameIslandWidth = 200;
    public int minTwoCameIslandWidth = 180;
    BroadcastReceiver notiReceiver = new BroadcastReceiver(){

        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction().matches("from_notification_service" + context.getPackageName()) && intent.getAction().equals((Object)("from_notification_service" + context.getPackageName()))) {
                MAccessibilityService.this.updateNotificationList(intent);
            }
        }
    };
    Notification notification;
    int pos = 1;
    PrefManager prefManager;
    SharedPreferences preferences;
    private CustomRecyclerView rv_island_big;
    RecyclerView rv_island_small;
    View statusBarParentView;
    public StatusBarParentView statusBarView;
    int tempMargin;
    public Utils utils;
    public int zeroHeight = 0;

    public MAccessibilityService() {
        Handler handler;
        this.handler = handler = new Handler();
        mContentObserver = new MContentObserver(handler);
    }

    private void enableControls(boolean bl) {
        this.isControlEnabled = bl;
        if (!bl) {
            this.hideSmallIslandNotification();
            return;
        }
        this.showTempBar();
    }

    private int getIconColor(int n) {
        if (ColorUtils.calculateLuminance((int)n) < 0.15) {
            n = Color.rgb((int)240, (int)240, (int)240);
        }
        return n;
    }

    private void initNotifications() {
        CustomNotificationIconAdapter customNotificationIconAdapter;
        this.rv_island_big = (CustomRecyclerView)this.statusBarView.findViewById(2131362350);
        this.rv_island_small = (RecyclerView)this.statusBarView.findViewById(2131362351);
        this.adapter_island_small = customNotificationIconAdapter = new CustomNotificationIconAdapter((Context)this, this.list_small_island, new NotificationListener(){

            @Override
            public void onItemClicked(Notification notification) {
            }

            @Override
            public void onItemClicked(Notification notification, int n) {
                MAccessibilityService.this.showFullIslandNotification(notification);
                MAccessibilityService.this.currentIndex = n;
            }
        });
        this.rv_island_small.setAdapter((RecyclerView.Adapter)customNotificationIconAdapter);
        this.rv_island_small.setHasFixedSize(true);
        this.rv_island_small.addItemDecoration((RecyclerView.ItemDecoration)new ItemOffsetDecoration2((Context)this, 2131165801));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager((Context)this);
        linearLayoutManager.setOrientation(0);
        this.rv_island_small.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager);
        this.adapter_island_big = new CustomNotificationAdapter((Context)this, this.list_big_island, new NotificationListener(){

            @Override
            public void onItemClicked(Notification notification) {
            }

            @Override
            public void onItemClicked(Notification notification, int n) {
            }
        });
        LinearLayoutManager linearLayoutManager2 = new LinearLayoutManager((Context)this);
        linearLayoutManager2.setOrientation(1);
        this.rv_island_big.setAdapter((RecyclerView.Adapter)this.adapter_island_big);
        this.rv_island_big.setHasFixedSize(true);
        this.rv_island_big.addItemDecoration((RecyclerView.ItemDecoration)new ItemOffsetDecoration2((Context)this, 2131165801));
        this.rv_island_big.setLayoutManager((RecyclerView.LayoutManager)linearLayoutManager2);
    }

    private boolean isSameItem(Notification notification) {
        if (notification.pack.equals((Object)"com.whatsapp") && notification.template.equals((Object)"")) {
            return true;
        }
        return notification.pack.equals((Object)"com.google.android.gm") && notification.id.equals((Object)"0");
    }

    private void setCenterCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 49;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarParentView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setFullIslandMargin(boolean bl) {
        if (bl) {
            this.tempMargin = this.margin;
            this.margin = (int)(25.0f * this.getResources().getDisplayMetrics().scaledDensity);
        } else {
            this.margin = this.tempMargin;
        }
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)this.island_top_layout.getLayoutParams();
        if (this.pos == 1) {
            layoutParams.leftMargin = this.margin;
            layoutParams.rightMargin = 0;
        }
        if (this.pos == 2) {
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
        }
        if (this.pos == 3) {
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = this.margin;
        }
        this.island_top_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    }

    private void setIslandPosition() {
        this.pos = this.prefManager.getCameraPos();
        int n = this.prefManager.getCameraCount();
        this.margin = (int)(25.0f * this.getResources().getDisplayMetrics().scaledDensity);
        if (n == 1) {
            this.localLayoutParams.width = (int)((float)this.minOneCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
        }
        if (n == 2) {
            this.margin = (int)(50.0f * this.getResources().getDisplayMetrics().scaledDensity);
            this.localLayoutParams.width = (int)((float)this.minTwoCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
        }
        if (n == 3) {
            this.localLayoutParams.width = (int)((float)this.minThreeCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
            this.margin = (int)(75.0f * this.getResources().getDisplayMetrics().scaledDensity);
        }
        this.minCameIslandWidth = this.localLayoutParams.width;
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)this.island_top_layout.getLayoutParams();
        int n2 = this.pos;
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 == 3) {
                    this.setRightCamera();
                    layoutParams.leftMargin = 0;
                    layoutParams.rightMargin = this.margin;
                }
            } else {
                this.setCenterCamera();
                layoutParams.leftMargin = 0;
                layoutParams.rightMargin = 0;
            }
        } else {
            this.setLeftCamera();
            layoutParams.leftMargin = this.margin;
            layoutParams.rightMargin = 0;
        }
        this.island_top_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.island_parent_layout.requestLayout();
    }

    private void setLeftCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 8388659;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarParentView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setMediaUpdateHandler() {
        this.mediaHandler.postDelayed(this.mediaUpdateRunnable, 1000L);
    }

    private void setRightCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 8388661;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarParentView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setYPosIsland() {
        this.localLayoutParams.y = (int)((float)this.prefManager.getYPosOfIsland() * this.getResources().getDisplayMetrics().scaledDensity);
        this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
    }

    private void showFullIslandNotification(Notification notification) {
        this.notification = notification;
        if (notification.template.equals((Object)"MediaStyle")) {
            this.setMediaUpdateHandler();
        }
        this.setFullIslandMargin(true);
        this.setKeyboardFlag(true);
        if (this.isShowingFullIsland) {
            return;
        }
        this.isShowingFullIsland = true;
        this.rv_island_small.setVisibility(8);
        this.localLayoutParams.height = -1;
        this.localLayoutParams.width = (int)(350.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.island_parent_layout.getLayoutParams();
        layoutParams.width = -1;
        layoutParams.height = notification.actions != null && notification.actions.size() > 0 ? (int)(170.0f * this.getResources().getDisplayMetrics().scaledDensity) : (int)(110.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.rv_island_big.setVisibility(0);
        this.list_big_island.clear();
        this.adapter_island_big.notifyItemChanged(0);
        this.list_big_island.add((Object)notification);
        this.adapter_island_big.notifyItemChanged(0);
    }

    private void updateNotificationItem(Notification notification, int n) {
        ((Notification)this.list_small_island.get((int)n)).senderIcon = notification.senderIcon;
        ((Notification)this.list_small_island.get((int)n)).icon = notification.icon;
        ((Notification)this.list_small_island.get((int)n)).actions = notification.actions;
        ((Notification)this.list_small_island.get((int)n)).pendingIntent = notification.pendingIntent;
        ((Notification)this.list_small_island.get((int)n)).tv_title = notification.tv_title;
        ((Notification)this.list_small_island.get((int)n)).tv_text = notification.tv_text;
        ((Notification)this.list_small_island.get((int)n)).pack = notification.pack;
        ((Notification)this.list_small_island.get((int)n)).postTime = notification.postTime;
        ((Notification)this.list_small_island.get((int)n)).count = notification.count;
        ((Notification)this.list_small_island.get((int)n)).bigText = notification.bigText;
        ((Notification)this.list_small_island.get((int)n)).app_name = notification.app_name;
        ((Notification)this.list_small_island.get((int)n)).isClearable = notification.isClearable;
        ((Notification)this.list_small_island.get((int)n)).color = notification.color;
        ((Notification)this.list_small_island.get((int)n)).picture = notification.picture;
        ((Notification)this.list_small_island.get((int)n)).id = notification.id;
        ((Notification)this.list_small_island.get((int)n)).template = notification.template;
        ((Notification)this.list_small_island.get((int)n)).key = notification.key;
        ((Notification)this.list_small_island.get((int)n)).groupKey = notification.groupKey;
        ((Notification)this.list_small_island.get((int)n)).isAppGroup = notification.isAppGroup;
        ((Notification)this.list_small_island.get((int)n)).isGroup = notification.isGroup;
        ((Notification)this.list_small_island.get((int)n)).isOngoing = notification.isOngoing;
        ((Notification)this.list_small_island.get((int)n)).isGroupConversation = notification.isGroupConversation;
        ((Notification)this.list_small_island.get((int)n)).showChronometer = notification.showChronometer;
        ((Notification)this.list_small_island.get((int)n)).progress = notification.progress;
        ((Notification)this.list_small_island.get((int)n)).progressMax = notification.progressMax;
        ((Notification)this.list_small_island.get((int)n)).progressIndeterminate = notification.progressIndeterminate;
    }

    public final void cleanUp() {
        this.handler.removeCallbacksAndMessages(null);
        try {
            this.getContentResolver().unregisterContentObserver((ContentObserver)mContentObserver);
        }
        catch (Throwable throwable) {}
    }

    public void closeFullNotificationIsland() {
        this.mediaHandler.removeCallbacks(this.mediaUpdateRunnable);
        this.setFullIslandMargin(false);
        this.setKeyboardFlag(false);
        this.localLayoutParams.height = (int)(170.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.island_parent_layout.getLayoutParams();
        layoutParams.width = (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity);
        layoutParams.height = (int)((float)this.minIslandHeight * this.getResources().getDisplayMetrics().scaledDensity);
        this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.rv_island_small.setVisibility(0);
        this.rv_island_big.setVisibility(8);
        new Handler().postDelayed(new Runnable(){

            /* synthetic */ void lambda$run$0$com-lock-services-MAccessibilityService$9() {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)MAccessibilityService.this.island_parent_layout.getLayoutParams();
                layoutParams.width = -1;
                layoutParams.height = -1;
                MAccessibilityService.this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                if (MAccessibilityService.this.adapter_island_small.getItemCount() > MAccessibilityService.this.currentIndex) {
                    MAccessibilityService.this.rv_island_small.scrollToPosition(MAccessibilityService.this.currentIndex);
                }
            }

            public void run() {
                MAccessibilityService.this.isShowingFullIsland = false;
                if (MAccessibilityService.this.list_small_island.size() == 0) {
                    MAccessibilityService.this.hideSmallIslandNotification();
                    return;
                }
                MAccessibilityService.this.localLayoutParams.height = (int)((float)MAccessibilityService.this.minIslandHeight * MAccessibilityService.this.getResources().getDisplayMetrics().scaledDensity);
                MAccessibilityService.this.localLayoutParams.width = MAccessibilityService.this.minCameIslandWidth;
                MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarParentView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                new Handler().postDelayed((Runnable)new MAccessibilityService$9$$ExternalSyntheticLambda0(this), 100L);
            }
        }, 500L);
    }

    public void closeSystemNotification() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                DisplayMetrics displayMetrics = MAccessibilityService.this.getResources().getDisplayMetrics();
                GestureDescription.Builder builder = new GestureDescription.Builder();
                Path path = new Path();
                double d = displayMetrics.heightPixels;
                double d2 = 0.01 * d;
                double d3 = d * 0.05;
                float f = displayMetrics.widthPixels / 2 + displayMetrics.widthPixels / 4;
                path.moveTo(f, (float)d3);
                path.lineTo(f, (float)d2);
                GestureDescription.StrokeDescription strokeDescription = new GestureDescription.StrokeDescription(path, 100L, 50L);
                builder.addStroke(strokeDescription);
                MAccessibilityService.this.dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback(){

                    public void onCompleted(GestureDescription gestureDescription) {
                        super.onCompleted(gestureDescription);
                    }
                }, null);
            }

        }, 500L);
    }

    public long getMediaDuration() {
        try {
            long l = ((MediaController)((MediaSessionManager)this.getSystemService("media_session")).getActiveSessions(new ComponentName(this.getApplicationContext(), NotificationService.class)).get(0)).getMetadata().getLong("android.media.metadata.DURATION");
            return l;
        }
        catch (Exception exception) {
            return 1L;
        }
    }

    public long getMediaPosition() {
        try {
            long l = ((MediaController)((MediaSessionManager)this.getSystemService("media_session")).getActiveSessions(new ComponentName(this.getApplicationContext(), NotificationService.class)).get(0)).getPlaybackState().getPosition();
            return l;
        }
        catch (Exception exception) {
            return 0L;
        }
    }

    public void hideSmallIslandNotification() {
        this.setKeyboardFlag(false);
        this.localLayoutParams.height = (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.localLayoutParams.width = (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
        this.statusBarParentView.setVisibility(8);
        this.isShowingFullIsland = false;
    }

    /* synthetic */ void lambda$new$1$com-lock-services-MAccessibilityService() {
        if (this.list_small_island.size() == 0) {
            this.hideSmallIslandNotification();
        }
    }

    /* synthetic */ void lambda$onServiceConnected$0$com-lock-services-MAccessibilityService(SharedPreferences sharedPreferences, String string2) {
        if (string2.equals((Object)"default_color")) {
            this.utils.setTileColor(this.prefManager.getDefaultColor());
            this.adapter_island_small.notifyDataSetChanged();
        }
        if (string2.equals((Object)"SHOW_IN_FULL_SCREEN")) {
            this.showTempBar();
        }
        if (string2.equals((Object)"CONTROL_GESTURE")) {
            this.enableControls(Constants.getControlEnabled(this.mContext));
        }
        if (string2.equals((Object)"SHOW_IN_LOCK")) {
            this.showTempBar();
        }
        if (string2.equals((Object)"CAM_COUNT") || string2.equals((Object)"CAM_POS")) {
            this.setIslandPosition();
            this.showTempBar();
        }
        if (string2.equals((Object)"Y_POS")) {
            this.setYPosIsland();
            this.showTempBar();
        }
        if (string2.equals((Object)"Y_HEIGHT")) {
            int n;
            this.minIslandHeight = n = this.prefManager.getHeightOfIsland();
            this.localLayoutParams.height = (int)((float)n * this.getResources().getDisplayMetrics().scaledDensity);
            this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
            this.island_parent_layout.requestLayout();
            this.showTempBar();
        }
    }

    /* synthetic */ void lambda$showSmallIslandNotification$2$com-lock-services-MAccessibilityService() {
        if (this.list_small_island.size() == 0) {
            this.hideSmallIslandNotification();
        }
    }

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        try {
            if (accessibilityEvent.getPackageName() != null) {
                accessibilityEvent.getEventType();
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.updateFontSize(configuration);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onDestroy() {
        try {
            SharedPreferences sharedPreferences;
            Context context;
            SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener;
            BroadcastReceiver broadcastReceiver;
            Context context2;
            View view;
            WindowManager windowManager = this.manager;
            if (windowManager != null && (view = this.statusBarParentView) != null) {
                windowManager.removeView(view);
            }
            if ((sharedPreferences = this.preferences) != null && (onSharedPreferenceChangeListener = this.listener) != null) {
                sharedPreferences.unregisterOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
            }
            if (this.notiReceiver != null && (context = this.mContext) != null) {
                LocalBroadcastManager.getInstance((Context)context).unregisterReceiver(this.notiReceiver);
            }
            if ((broadcastReceiver = this.mInfoReceiver) != null && (context2 = this.mContext) != null) {
                context2.unregisterReceiver(broadcastReceiver);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        super.onDestroy();
    }

    public void onInterrupt() {
    }

    /*
     * Exception decompiling
     */
    protected void onServiceConnected() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl164 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public int onStartCommand(Intent var1, int var2, int var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void setKeyboardFlag(final boolean bl) {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                MAccessibilityService.this.localLayoutParams.flags = bl ? MAccessibilityService.this.flagKeyBoard : MAccessibilityService.this.flagNormal;
                try {
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarParentView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 300L);
    }

    public void showSmallIslandNotification() {
        this.statusBarParentView.setVisibility(0);
        if (this.list_small_island.size() == 0) {
            this.closeFullNotificationIsland();
            this.hideSmallIslandNotification();
        }
        if (this.isControlEnabled && (!this.isPhoneLocked || Constants.getShowOnLock(this.mContext)) && !this.isShowingFullIsland) {
            if (this.isInFullScreen && !Constants.getShowInFullScreen(this.mContext)) {
                return;
            }
            if (this.list_small_island.size() == 0) {
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.island_parent_layout.getLayoutParams();
                layoutParams.width = (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity);
                this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            } else {
                this.localLayoutParams.height = (int)((float)this.prefManager.getHeightOfIsland() * this.getResources().getDisplayMetrics().scaledDensity);
                this.localLayoutParams.width = this.minCameIslandWidth;
                this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.island_parent_layout.getLayoutParams();
                layoutParams.width = -1;
                layoutParams.height = -1;
                this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                if (this.adapter_island_small.getItemCount() >= 1) {
                    this.rv_island_small.scrollToPosition(this.adapter_island_small.getItemCount() - 1);
                }
            }
            new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda0(this), 1000L);
        }
    }

    public void showTempBar() {
        this.statusBarParentView.setVisibility(0);
        this.localLayoutParams.height = (int)((float)this.prefManager.getHeightOfIsland() * this.getResources().getDisplayMetrics().scaledDensity);
        this.localLayoutParams.width = this.minCameIslandWidth;
        this.manager.updateViewLayout(this.statusBarParentView, (ViewGroup.LayoutParams)this.localLayoutParams);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.island_parent_layout.getLayoutParams();
        layoutParams.width = -1;
        layoutParams.height = -1;
        this.island_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.mHandle.removeCallbacks(this.mRunnable);
        this.mHandle.postDelayed(this.mRunnable, 3000L);
    }

    public final void updateFontSize(Configuration configuration) {
        if (configuration.fontScale > 1.3f) {
            configuration.fontScale = 1.3f;
            DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
            ((WindowManager)this.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
            displayMetrics.scaledDensity = configuration.fontScale * displayMetrics.density;
            this.getResources().updateConfiguration(configuration, displayMetrics);
        }
    }

    /*
     * Exception decompiling
     */
    public void updateNotificationList(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl222 : ILOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public class MContentObserver
    extends ContentObserver {
        public MContentObserver(Handler handler) {
            super(handler);
        }

        public void onChange(boolean bl, Uri uri) {
            if (MAccessibilityService.ENABLED_ACCESSIBILITY_SERVICES.equals((Object)uri) && !Constants.checkAccessibilityEnabled((Context)MAccessibilityService.this)) {
                MAccessibilityService.this.cleanUp();
            }
        }
    }

}

