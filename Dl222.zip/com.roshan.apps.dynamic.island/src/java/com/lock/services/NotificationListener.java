/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.lock.services;

import com.lock.entity.Notification;

public interface NotificationListener {
    public void onItemClicked(Notification var1);

    public void onItemClicked(Notification var1, int var2);
}

