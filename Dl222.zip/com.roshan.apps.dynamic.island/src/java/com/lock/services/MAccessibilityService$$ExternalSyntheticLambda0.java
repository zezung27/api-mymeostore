/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.services;

import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda0(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void run() {
        this.f$0.lambda$showSmallIslandNotification$2$com-lock-services-MAccessibilityService();
    }
}

