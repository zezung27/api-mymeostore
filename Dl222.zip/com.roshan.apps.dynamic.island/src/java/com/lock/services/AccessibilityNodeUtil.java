/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.accessibility.AccessibilityNodeInfo
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.lock.services;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.os.Build;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class AccessibilityNodeUtil {
    public static final boolean a;
    public AccessibilityNodeInfo accessibilityNodeInfo;
    public final ArrayList<AccessibilityNodeInfo> accessibilityNodeInfoArrayList = new ArrayList();
    public Context context;
    public String f10353d;
    public double f10355f;
    public final Rect rect = new Rect();
    public SharedPreferences sharedPreferences;
    public final int statusBarHeight;

    static {
        boolean bl = AccessibilityNodeUtil.J() || Build.VERSION.SDK_INT < 28 && Build.MANUFACTURER.equalsIgnoreCase("samsung");
        a = bl;
    }

    public AccessibilityNodeUtil(Context context, int n) {
        SharedPreferences sharedPreferences;
        this.context = context;
        this.statusBarHeight = n;
        this.sharedPreferences = sharedPreferences = context.getSharedPreferences("QS_TILES", 0);
        AccessibilityNodeUtil.N(sharedPreferences);
    }

    /*
     * Exception decompiling
     */
    public static boolean J() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void N(SharedPreferences sharedPreferences) {
        Iterator iterator = sharedPreferences.getAll().entrySet().iterator();
        SharedPreferences.Editor editor = null;
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            if (!(entry.getValue() instanceof Integer)) continue;
            if (editor == null) {
                editor = sharedPreferences.edit();
            }
            editor.remove((String)entry.getKey());
            StringBuilder stringBuilder = AccessibilityNodeUtil.w("/");
            stringBuilder.append(-1 + (Integer)entry.getValue());
            editor.putString((String)entry.getKey(), stringBuilder.toString());
        }
        if (editor != null) {
            editor.apply();
        }
    }

    public static void f(Collection<AccessibilityNodeInfo> collection) {
        if (collection != null) {
            for (AccessibilityNodeInfo accessibilityNodeInfo : collection) {
                if (accessibilityNodeInfo == null) continue;
                accessibilityNodeInfo.recycle();
            }
            collection.clear();
        }
    }

    public static String h(CharSequence charSequence) {
        return charSequence.toString().toLowerCase().replaceAll("\n", " ").replaceAll(",", " ").replaceAll("\\s{2,}", " ");
    }

    public static boolean performButtonClick(AccessibilityNodeInfo accessibilityNodeInfo) {
        if (accessibilityNodeInfo == null) {
            return false;
        }
        boolean bl = accessibilityNodeInfo.performAction(16);
        accessibilityNodeInfo.recycle();
        return bl;
    }

    public static StringBuilder w(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        return stringBuilder;
    }

    /*
     * Exception decompiling
     */
    public final String d() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl11 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public final boolean e(AccessibilityNodeInfo accessibilityNodeInfo, double d) {
        try {
            this.accessibilityNodeInfo.recycle();
        }
        catch (Throwable throwable) {}
        this.accessibilityNodeInfo = AccessibilityNodeInfo.obtain((AccessibilityNodeInfo)accessibilityNodeInfo);
        this.f10355f = d;
        return d == 1.0;
    }

    public final boolean findButtonAndClick(AccessibilityNodeInfo accessibilityNodeInfo, performActionListener<AccessibilityNodeInfo> performActionListener2, String string2) {
        if (accessibilityNodeInfo != null) {
            int n = accessibilityNodeInfo.getChildCount();
            do {
                if (--n < 0) {
                    block1 : while (!this.accessibilityNodeInfoArrayList.isEmpty()) {
                        ArrayList<AccessibilityNodeInfo> arrayList = this.accessibilityNodeInfoArrayList;
                        AccessibilityNodeInfo accessibilityNodeInfo2 = (AccessibilityNodeInfo)arrayList.remove(arrayList.size() - 1);
                        if (accessibilityNodeInfo2 == null) continue;
                        if (performActionListener2.performActionOnButton(accessibilityNodeInfo2, string2)) {
                            AccessibilityNodeUtil.f(this.accessibilityNodeInfoArrayList);
                            return true;
                        }
                        int n2 = accessibilityNodeInfo2.getChildCount();
                        do {
                            if (--n2 < 0) {
                                accessibilityNodeInfo2.recycle();
                                continue block1;
                            }
                            this.accessibilityNodeInfoArrayList.add((Object)accessibilityNodeInfo2.getChild(n2));
                        } while (true);
                    }
                    return false;
                }
                this.accessibilityNodeInfoArrayList.add((Object)accessibilityNodeInfo.getChild(n));
            } while (true);
        }
        return false;
    }

    public static interface performActionListener<T> {
        public boolean performActionOnButton(T var1, String var2);
    }

}

