/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.services;

import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$9$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ MAccessibilityService.9 f$0;

    public /* synthetic */ MAccessibilityService$9$$ExternalSyntheticLambda0(MAccessibilityService.9 var1_1) {
        this.f$0 = var1_1;
    }

    public final void run() {
        this.f$0.lambda$run$0$com-lock-services-MAccessibilityService$9();
    }
}

