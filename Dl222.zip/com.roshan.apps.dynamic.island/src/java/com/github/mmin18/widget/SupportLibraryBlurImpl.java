/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.graphics.Bitmap
 *  android.renderscript.RSRuntimeException
 *  androidx.renderscript.Allocation
 *  androidx.renderscript.Allocation$MipmapControl
 *  androidx.renderscript.Element
 *  androidx.renderscript.RenderScript
 *  androidx.renderscript.ScriptIntrinsicBlur
 *  androidx.renderscript.Type
 *  java.lang.Boolean
 *  java.lang.Object
 */
package com.github.mmin18.widget;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.renderscript.RSRuntimeException;
import androidx.renderscript.Allocation;
import androidx.renderscript.Element;
import androidx.renderscript.RenderScript;
import androidx.renderscript.ScriptIntrinsicBlur;
import androidx.renderscript.Type;
import com.github.mmin18.widget.BlurImpl;

public class SupportLibraryBlurImpl
implements BlurImpl {
    static Boolean DEBUG;
    private Allocation mBlurInput;
    private Allocation mBlurOutput;
    private ScriptIntrinsicBlur mBlurScript;
    private RenderScript mRenderScript;

    static boolean isDebug(Context context) {
        if (DEBUG == null && context != null) {
            boolean bl = (2 & context.getApplicationInfo().flags) != 0;
            DEBUG = bl;
        }
        return DEBUG == Boolean.TRUE;
    }

    @Override
    public void blur(Bitmap bitmap, Bitmap bitmap2) {
        this.mBlurInput.copyFrom(bitmap);
        this.mBlurScript.setInput(this.mBlurInput);
        this.mBlurScript.forEach(this.mBlurOutput);
        this.mBlurOutput.copyTo(bitmap2);
    }

    @Override
    public boolean prepare(Context context, Bitmap bitmap, float f) {
        Allocation allocation;
        if (this.mRenderScript == null) {
            try {
                RenderScript renderScript;
                this.mRenderScript = renderScript = RenderScript.create((Context)context);
                this.mBlurScript = ScriptIntrinsicBlur.create((RenderScript)renderScript, (Element)Element.U8_4((RenderScript)renderScript));
            }
            catch (RSRuntimeException rSRuntimeException) {
                if (!SupportLibraryBlurImpl.isDebug(context)) {
                    this.release();
                    return false;
                }
                throw rSRuntimeException;
            }
        }
        this.mBlurScript.setRadius(f);
        this.mBlurInput = allocation = Allocation.createFromBitmap((RenderScript)this.mRenderScript, (Bitmap)bitmap, (Allocation.MipmapControl)Allocation.MipmapControl.MIPMAP_NONE, (int)1);
        this.mBlurOutput = Allocation.createTyped((RenderScript)this.mRenderScript, (Type)allocation.getType());
        return true;
    }

    @Override
    public void release() {
        RenderScript renderScript;
        ScriptIntrinsicBlur scriptIntrinsicBlur;
        Allocation allocation;
        Allocation allocation2 = this.mBlurInput;
        if (allocation2 != null) {
            allocation2.destroy();
            this.mBlurInput = null;
        }
        if ((allocation = this.mBlurOutput) != null) {
            allocation.destroy();
            this.mBlurOutput = null;
        }
        if ((scriptIntrinsicBlur = this.mBlurScript) != null) {
            scriptIntrinsicBlur.destroy();
            this.mBlurScript = null;
        }
        if ((renderScript = this.mRenderScript) != null) {
            renderScript.destroy();
            this.mRenderScript = null;
        }
    }
}

