/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  java.lang.Object
 */
package com.github.mmin18.widget;

import android.content.Context;
import android.graphics.Bitmap;
import com.github.mmin18.widget.BlurImpl;

public class EmptyBlurImpl
implements BlurImpl {
    @Override
    public void blur(Bitmap bitmap, Bitmap bitmap2) {
    }

    @Override
    public boolean prepare(Context context, Bitmap bitmap, float f) {
        return false;
    }

    @Override
    public void release() {
    }
}

