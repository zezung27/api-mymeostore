/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RadialGradient
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.SweepGradient
 *  android.util.AttributeSet
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 */
package com.github.dhaval2404.colorpicker.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.view.View;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

@Metadata(d1={"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B/\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\tJ\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0014J(\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010\u001a\u001a\u00020\u00072\u0006\u0010\u001b\u001a\u00020\u0007H\u0014R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001c"}, d2={"Lcom/github/dhaval2404/colorpicker/widget/ColorPalette;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyle", "", "defStyleRes", "(Landroid/content/Context;Landroid/util/AttributeSet;II)V", "centerX", "", "centerY", "hueColors", "", "huePaint", "Landroid/graphics/Paint;", "radius", "saturationPaint", "onDraw", "", "canvas", "Landroid/graphics/Canvas;", "onSizeChanged", "w", "h", "oldw", "oldh", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorPalette
extends View {
    private float centerX;
    private float centerY;
    private int[] hueColors;
    private Paint huePaint;
    private float radius;
    private Paint saturationPaint;

    public ColorPalette(Context context) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, null, 0, 0, 14, null);
    }

    public ColorPalette(Context context, AttributeSet attributeSet) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, attributeSet, 0, 0, 12, null);
    }

    public ColorPalette(Context context, AttributeSet attributeSet, int n) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, attributeSet, n, 0, 8, null);
    }

    public ColorPalette(Context context, AttributeSet attributeSet, int n, int n2) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        super(context, attributeSet, n, n2);
        this.huePaint = new Paint(1);
        this.saturationPaint = new Paint(1);
        this.hueColors = new int[]{-65536, -65281, -16776961, -16711681, -16711936, -256, -65536};
    }

    public /* synthetic */ ColorPalette(Context context, AttributeSet attributeSet, int n, int n2, int n3, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n3 & 2) != 0) {
            attributeSet = null;
        }
        if ((n3 & 4) != 0) {
            n = 0;
        }
        if ((n3 & 8) != 0) {
            n2 = 0;
        }
        this(context, attributeSet, n, n2);
    }

    public void _$_clearFindViewByIdCache() {
    }

    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter((Object)canvas, (String)"canvas");
        canvas.drawCircle(this.centerX, this.centerY, this.radius, this.huePaint);
        canvas.drawCircle(this.centerX, this.centerY, this.radius, this.saturationPaint);
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        float f;
        this.radius = f = 0.5f * (float)RangesKt.coerceAtMost((int)(n - this.getPaddingLeft() - this.getPaddingRight()), (int)(n2 - this.getPaddingTop() - this.getPaddingBottom()));
        if (f < 0.0f) {
            return;
        }
        this.centerX = 0.5f * (float)n;
        this.centerY = 0.5f * (float)n2;
        this.huePaint.setShader((Shader)new SweepGradient(this.centerX, this.centerY, this.hueColors, null));
        Paint paint = this.saturationPaint;
        RadialGradient radialGradient = new RadialGradient(this.centerX, this.centerY, this.radius, -1, 16777215, Shader.TileMode.CLAMP);
        paint.setShader((Shader)radialGradient);
    }
}

