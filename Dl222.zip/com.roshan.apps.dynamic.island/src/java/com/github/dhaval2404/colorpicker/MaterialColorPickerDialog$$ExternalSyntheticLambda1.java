/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnDismissListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.content.DialogInterface;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog;
import com.github.dhaval2404.colorpicker.listener.DismissListener;

public final class MaterialColorPickerDialog$$ExternalSyntheticLambda1
implements DialogInterface.OnDismissListener {
    public final /* synthetic */ DismissListener f$0;

    public /* synthetic */ MaterialColorPickerDialog$$ExternalSyntheticLambda1(DismissListener dismissListener) {
        this.f$0 = dismissListener;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        MaterialColorPickerDialog.$r8$lambda$rWipqyar85LPbYvyXQat6lSFBnc(this.f$0, dialogInterface);
    }
}

