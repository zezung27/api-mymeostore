/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.util;

import android.view.View;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\u001a\u0012\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0004\u00a8\u0006\u0005"}, d2={"setVisibility", "", "Landroid/view/View;", "visible", "", "colorpicker_release"}, k=2, mv={1, 5, 1}, xi=48)
public final class ViewExtKt {
    public static final void setVisibility(View view, boolean bl) {
        Intrinsics.checkNotNullParameter((Object)view, (String)"<this>");
        int n = bl ? 0 : 8;
        view.setVisibility(n);
    }
}

