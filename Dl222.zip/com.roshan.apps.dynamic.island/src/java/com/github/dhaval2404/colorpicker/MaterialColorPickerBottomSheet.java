/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  androidx.appcompat.widget.AppCompatButton
 *  androidx.appcompat.widget.AppCompatTextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.google.android.flexbox.FlexboxLayoutManager
 *  com.google.android.material.bottomsheet.BottomSheetDialogFragment
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.colorpicker;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.RecyclerView;
import com.github.dhaval2404.colorpicker.MaterialColorPickerBottomSheet$$ExternalSyntheticLambda0;
import com.github.dhaval2404.colorpicker.MaterialColorPickerBottomSheet$$ExternalSyntheticLambda1;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog;
import com.github.dhaval2404.colorpicker.R;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.listener.DismissListener;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.github.dhaval2404.colorpicker.model.ColorSwatch;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import dalvik.annotation.SourceDebugExtension;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@SourceDebugExtension(value="SMAP\nMaterialColorPickerBottomSheet.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MaterialColorPickerBottomSheet.kt\ncom/github/dhaval2404/colorpicker/MaterialColorPickerBottomSheet\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,144:1\n1#2:145\n*E\n")
@Metadata(d1={"\u0000`\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 &2\u00020\u0001:\u0001&B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0014\u001a\u00020\u0015H\u0016J\u0010\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0018H\u0016J&\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0006\u0010\u001b\u001a\u00020\u001c2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0016J\u001a\u0010!\u001a\u00020\u00152\u0006\u0010\"\u001a\u00020\u001a2\b\u0010\u001f\u001a\u0004\u0018\u00010 H\u0016J\u0010\u0010#\u001a\u00020\u00002\b\u0010$\u001a\u0004\u0018\u00010\u0004J\u0010\u0010%\u001a\u00020\u00002\b\u0010$\u001a\u0004\u0018\u00010\u000eR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u000b\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006'"}, d2={"Lcom/github/dhaval2404/colorpicker/MaterialColorPickerBottomSheet;", "Lcom/google/android/material/bottomsheet/BottomSheetDialogFragment;", "()V", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "colorSwatch", "Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;", "colors", "", "", "defaultColor", "dismissListener", "Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "isTickColorPerCard", "", "negativeButton", "positiveButton", "title", "dismiss", "", "onCancel", "dialog", "Landroid/content/DialogInterface;", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onViewCreated", "view", "setColorListener", "listener", "setDismissListener", "Companion", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class MaterialColorPickerBottomSheet
extends BottomSheetDialogFragment {
    public static final Companion Companion = new Companion(null);
    private static final String EXTRA_COLORS = "extra.colors";
    private static final String EXTRA_COLOR_SHAPE = "extra.color_shape";
    private static final String EXTRA_COLOR_SWATCH = "extra.color_swatch";
    private static final String EXTRA_DEFAULT_COLOR = "extra.default_color";
    private static final String EXTRA_IS_TICK_COLOR_PER_CARD = "extra.is_tick_color_per_card";
    private static final String EXTRA_NEGATIVE_BUTTON = "extra.negative_button";
    private static final String EXTRA_POSITIVE_BUTTON = "extra.positive_Button";
    private static final String EXTRA_TITLE = "extra.title";
    private ColorListener colorListener;
    private ColorShape colorShape = ColorShape.CIRCLE;
    private ColorSwatch colorSwatch = ColorSwatch._300;
    private List<String> colors;
    private String defaultColor;
    private DismissListener dismissListener;
    private boolean isTickColorPerCard;
    private String negativeButton;
    private String positiveButton;
    private String title;

    public static /* synthetic */ void $r8$lambda$Cc3tMDHWz-rSz7OD73s8S64i1ig(MaterialColorPickerBottomSheet materialColorPickerBottomSheet, View view) {
        MaterialColorPickerBottomSheet.onViewCreated$lambda-5(materialColorPickerBottomSheet, view);
    }

    public static /* synthetic */ void $r8$lambda$aoqYvJUQZuzN5X2gy5UnCHUyviQ(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerBottomSheet materialColorPickerBottomSheet, View view) {
        MaterialColorPickerBottomSheet.onViewCreated$lambda-4(materialColorPickerAdapter, materialColorPickerBottomSheet, view);
    }

    private static final void onViewCreated$lambda-4(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerBottomSheet materialColorPickerBottomSheet, View view) {
        ColorListener colorListener;
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorPickerAdapter), (String)"$adapter");
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorPickerBottomSheet), (String)"this$0");
        String string2 = materialColorPickerAdapter.getSelectedColor();
        if (true ^ StringsKt.isBlank((CharSequence)string2) && (colorListener = materialColorPickerBottomSheet.colorListener) != null) {
            colorListener.onColorSelected(ColorUtil.parseColor(string2), string2);
        }
        materialColorPickerBottomSheet.dismiss();
    }

    private static final void onViewCreated$lambda-5(MaterialColorPickerBottomSheet materialColorPickerBottomSheet, View view) {
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorPickerBottomSheet), (String)"this$0");
        materialColorPickerBottomSheet.dismiss();
    }

    public void _$_clearFindViewByIdCache() {
    }

    public void dismiss() {
        super.dismiss();
        DismissListener dismissListener = this.dismissListener;
        if (dismissListener == null) {
            return;
        }
        dismissListener.onDismiss();
    }

    public void onCancel(DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter((Object)dialogInterface, (String)"dialog");
        super.onCancel(dialogInterface);
        DismissListener dismissListener = this.dismissListener;
        if (dismissListener == null) {
            return;
        }
        dismissListener.onDismiss();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkNotNullParameter((Object)layoutInflater, (String)"inflater");
        return layoutInflater.inflate(R.layout.dialog_bottomsheet_material_color_picker, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        List<String> list;
        String string2;
        String string3;
        View view2;
        Intrinsics.checkNotNullParameter((Object)view, (String)"view");
        super.onViewCreated(view, bundle);
        Bundle bundle2 = this.getArguments();
        if (bundle2 != null) {
            this.title = bundle2.getString(EXTRA_TITLE);
            this.positiveButton = bundle2.getString(EXTRA_POSITIVE_BUTTON);
            this.negativeButton = bundle2.getString(EXTRA_NEGATIVE_BUTTON);
            this.defaultColor = bundle2.getString(EXTRA_DEFAULT_COLOR);
            ColorSwatch colorSwatch = (ColorSwatch)bundle2.getParcelable(EXTRA_COLOR_SWATCH);
            Intrinsics.checkNotNull((Object)((Object)colorSwatch));
            this.colorSwatch = colorSwatch;
            ColorShape colorShape = (ColorShape)bundle2.getParcelable(EXTRA_COLOR_SHAPE);
            Intrinsics.checkNotNull((Object)((Object)colorShape));
            this.colorShape = colorShape;
            this.colors = (List)bundle2.getStringArrayList(EXTRA_COLORS);
            this.isTickColorPerCard = bundle2.getBoolean(EXTRA_IS_TICK_COLOR_PER_CARD);
        }
        String string4 = this.title;
        if (string4 != null) {
            View view3 = this.getView();
            View view4 = view3 == null ? null : view3.findViewById(R.id.titleTxt);
            ((AppCompatTextView)view4).setText((CharSequence)string4);
        }
        if ((string2 = this.positiveButton) != null) {
            View view5 = this.getView();
            View view6 = view5 == null ? null : view5.findViewById(R.id.positiveBtn);
            ((AppCompatButton)view6).setText((CharSequence)string2);
        }
        if ((string3 = this.negativeButton) != null) {
            View view7 = this.getView();
            View view8 = view7 == null ? null : view7.findViewById(R.id.negativeBtn);
            ((AppCompatButton)view8).setText((CharSequence)string3);
        }
        if ((list = this.colors) == null) {
            ColorUtil colorUtil = ColorUtil.INSTANCE;
            Context context = this.requireContext();
            Intrinsics.checkNotNullExpressionValue((Object)context, (String)"requireContext()");
            list = colorUtil.getColors(context, this.colorSwatch.getValue());
        }
        MaterialColorPickerAdapter materialColorPickerAdapter = new MaterialColorPickerAdapter(list);
        materialColorPickerAdapter.setColorShape(this.colorShape);
        materialColorPickerAdapter.setTickColorPerCard(this.isTickColorPerCard);
        CharSequence charSequence = this.defaultColor;
        boolean bl = charSequence == null || StringsKt.isBlank((CharSequence)charSequence);
        if (!bl) {
            String string5 = this.defaultColor;
            Intrinsics.checkNotNull((Object)string5);
            materialColorPickerAdapter.setDefaultColor(string5);
        }
        View view9 = (view2 = this.getView()) == null ? null : view2.findViewById(R.id.materialColorRV);
        ((RecyclerView)view9).setHasFixedSize(true);
        View view10 = this.getView();
        View view11 = view10 == null ? null : view10.findViewById(R.id.materialColorRV);
        ((RecyclerView)view11).setLayoutManager((RecyclerView.LayoutManager)new FlexboxLayoutManager(this.getContext()));
        View view12 = this.getView();
        View view13 = view12 == null ? null : view12.findViewById(R.id.materialColorRV);
        ((RecyclerView)view13).setAdapter((RecyclerView.Adapter)materialColorPickerAdapter);
        View view14 = this.getView();
        View view15 = view14 == null ? null : view14.findViewById(R.id.positiveBtn);
        ((AppCompatButton)view15).setOnClickListener((View.OnClickListener)new MaterialColorPickerBottomSheet$$ExternalSyntheticLambda0(materialColorPickerAdapter, this));
        View view16 = this.getView();
        View view17 = view16 == null ? null : view16.findViewById(R.id.negativeBtn);
        ((AppCompatButton)view17).setOnClickListener((View.OnClickListener)new MaterialColorPickerBottomSheet$$ExternalSyntheticLambda1(this));
    }

    public final MaterialColorPickerBottomSheet setColorListener(ColorListener colorListener) {
        this.colorListener = colorListener;
        return this;
    }

    public final MaterialColorPickerBottomSheet setDismissListener(DismissListener dismissListener) {
        this.dismissListener = dismissListener;
        return this;
    }

    @Metadata(d1={"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000fR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2={"Lcom/github/dhaval2404/colorpicker/MaterialColorPickerBottomSheet$Companion;", "", "()V", "EXTRA_COLORS", "", "EXTRA_COLOR_SHAPE", "EXTRA_COLOR_SWATCH", "EXTRA_DEFAULT_COLOR", "EXTRA_IS_TICK_COLOR_PER_CARD", "EXTRA_NEGATIVE_BUTTON", "EXTRA_POSITIVE_BUTTON", "EXTRA_TITLE", "getInstance", "Lcom/github/dhaval2404/colorpicker/MaterialColorPickerBottomSheet;", "dialog", "Lcom/github/dhaval2404/colorpicker/MaterialColorPickerDialog;", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final MaterialColorPickerBottomSheet getInstance(MaterialColorPickerDialog materialColorPickerDialog) {
            Intrinsics.checkNotNullParameter((Object)materialColorPickerDialog, (String)"dialog");
            Bundle bundle = new Bundle();
            bundle.putString(MaterialColorPickerBottomSheet.EXTRA_TITLE, materialColorPickerDialog.getTitle());
            bundle.putString(MaterialColorPickerBottomSheet.EXTRA_POSITIVE_BUTTON, materialColorPickerDialog.getPositiveButton());
            bundle.putString(MaterialColorPickerBottomSheet.EXTRA_NEGATIVE_BUTTON, materialColorPickerDialog.getNegativeButton());
            bundle.putString(MaterialColorPickerBottomSheet.EXTRA_DEFAULT_COLOR, materialColorPickerDialog.getDefaultColor());
            bundle.putParcelable(MaterialColorPickerBottomSheet.EXTRA_COLOR_SWATCH, (Parcelable)materialColorPickerDialog.getColorSwatch());
            bundle.putParcelable(MaterialColorPickerBottomSheet.EXTRA_COLOR_SHAPE, (Parcelable)materialColorPickerDialog.getColorShape());
            bundle.putBoolean(MaterialColorPickerBottomSheet.EXTRA_IS_TICK_COLOR_PER_CARD, materialColorPickerDialog.isTickColorPerCard());
            ArrayList arrayList = materialColorPickerDialog.getColors() != null ? new ArrayList((Collection)materialColorPickerDialog.getColors()) : null;
            bundle.putStringArrayList(MaterialColorPickerBottomSheet.EXTRA_COLORS, arrayList);
            MaterialColorPickerBottomSheet materialColorPickerBottomSheet = new MaterialColorPickerBottomSheet();
            materialColorPickerBottomSheet.setArguments(bundle);
            return materialColorPickerBottomSheet;
        }
    }

}

