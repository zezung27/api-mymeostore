/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.graphics.Color
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.core.content.ContextCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.github.dhaval2404.colorpicker.ColorPickerDialog$Builder$setColorListener
 *  com.github.dhaval2404.colorpicker.ColorPickerDialog$Builder$setDismissListener
 *  com.github.dhaval2404.colorpicker.ColorPickerDialog$show
 *  com.google.android.flexbox.FlexboxLayoutManager
 *  com.google.android.material.card.MaterialCardView
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.colorpicker;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.ColorPickerDialog$$ExternalSyntheticLambda0;
import com.github.dhaval2404.colorpicker.ColorPickerDialog$$ExternalSyntheticLambda1;
import com.github.dhaval2404.colorpicker.ColorPickerView;
import com.github.dhaval2404.colorpicker.R;
import com.github.dhaval2404.colorpicker.adapter.RecentColorAdapter;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.listener.DismissListener;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import com.github.dhaval2404.colorpicker.util.DialogExtKt;
import com.github.dhaval2404.colorpicker.util.SharedPref;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.material.card.MaterialCardView;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Metadata(d1={"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001!BM\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\r\u001a\u00020\u000e\u00a2\u0006\u0002\u0010\u000fJ\u0006\u0010\u001f\u001a\u00020 R\u0013\u0010\b\u001a\u0004\u0018\u00010\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u001a\u0010\r\u001a\u00020\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0012\u0010\u0013\"\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0013\u0010\n\u001a\u0004\u0018\u00010\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\u0007\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0019R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019\u00a8\u0006\""}, d2={"Lcom/github/dhaval2404/colorpicker/ColorPickerDialog;", "", "context", "Landroid/content/Context;", "title", "", "positiveButton", "negativeButton", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "dismissListener", "Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "defaultColor", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/github/dhaval2404/colorpicker/listener/ColorListener;Lcom/github/dhaval2404/colorpicker/listener/DismissListener;Ljava/lang/String;Lcom/github/dhaval2404/colorpicker/model/ColorShape;)V", "getColorListener", "()Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "getColorShape", "()Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "setColorShape", "(Lcom/github/dhaval2404/colorpicker/model/ColorShape;)V", "getContext", "()Landroid/content/Context;", "getDefaultColor", "()Ljava/lang/String;", "getDismissListener", "()Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "getNegativeButton", "getPositiveButton", "getTitle", "show", "", "Builder", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorPickerDialog {
    private final ColorListener colorListener;
    private ColorShape colorShape;
    private final Context context;
    private final String defaultColor;
    private final DismissListener dismissListener;
    private final String negativeButton;
    private final String positiveButton;
    private final String title;

    public static /* synthetic */ void $r8$lambda$gJ_vSXgZSUtxaazXKIfuGqWoOQw(ColorPickerView colorPickerView, ColorPickerDialog colorPickerDialog, SharedPref sharedPref, DialogInterface dialogInterface, int n) {
        ColorPickerDialog.show$lambda-0(colorPickerView, colorPickerDialog, sharedPref, dialogInterface, n);
    }

    public static /* synthetic */ void $r8$lambda$oRSjjoWqy3OIT0x6QNojmGLKJ-s(DismissListener dismissListener, DialogInterface dialogInterface) {
        ColorPickerDialog.show$lambda-2$lambda-1(dismissListener, dialogInterface);
    }

    private ColorPickerDialog(Context context, String string2, String string3, String string4, ColorListener colorListener, DismissListener dismissListener, String string5, ColorShape colorShape) {
        this.context = context;
        this.title = string2;
        this.positiveButton = string3;
        this.negativeButton = string4;
        this.colorListener = colorListener;
        this.dismissListener = dismissListener;
        this.defaultColor = string5;
        this.colorShape = colorShape;
    }

    public /* synthetic */ ColorPickerDialog(Context context, String string2, String string3, String string4, ColorListener colorListener, DismissListener dismissListener, String string5, ColorShape colorShape, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, string2, string3, string4, colorListener, dismissListener, string5, colorShape);
    }

    private static final void show$lambda-0(ColorPickerView colorPickerView, ColorPickerDialog colorPickerDialog, SharedPref sharedPref, DialogInterface dialogInterface, int n) {
        Intrinsics.checkNotNullParameter((Object)colorPickerDialog, (String)"this$0");
        Intrinsics.checkNotNullParameter((Object)sharedPref, (String)"$sharedPref");
        int n2 = colorPickerView.getColor();
        String string2 = ColorUtil.formatColor(n2);
        ColorListener colorListener = colorPickerDialog.getColorListener();
        if (colorListener != null) {
            colorListener.onColorSelected(n2, string2);
        }
        sharedPref.addColor(string2);
    }

    private static final void show$lambda-2$lambda-1(DismissListener dismissListener, DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter((Object)dismissListener, (String)"$listener");
        dismissListener.onDismiss();
    }

    public final ColorListener getColorListener() {
        return this.colorListener;
    }

    public final ColorShape getColorShape() {
        return this.colorShape;
    }

    public final Context getContext() {
        return this.context;
    }

    public final String getDefaultColor() {
        return this.defaultColor;
    }

    public final DismissListener getDismissListener() {
        return this.dismissListener;
    }

    public final String getNegativeButton() {
        return this.negativeButton;
    }

    public final String getPositiveButton() {
        return this.positiveButton;
    }

    public final String getTitle() {
        return this.title;
    }

    public final void setColorShape(ColorShape colorShape) {
        Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"<set-?>");
        this.colorShape = colorShape;
    }

    public final void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.context).setTitle((CharSequence)this.title).setNegativeButton((CharSequence)this.negativeButton, null);
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.context);
        Intrinsics.checkNotNullExpressionValue((Object)layoutInflater, (String)"from(context)");
        View view = layoutInflater.inflate(R.layout.dialog_color_picker, null);
        if (view != null) {
            builder.setView(view);
            ColorPickerView colorPickerView = (ColorPickerView)view.findViewById(R.id.colorPicker);
            MaterialCardView materialCardView = (MaterialCardView)view.findViewById(R.id.colorView);
            RecyclerView recyclerView = (RecyclerView)view.findViewById(R.id.recentColorsRV);
            CharSequence charSequence = this.defaultColor;
            boolean bl = charSequence == null || StringsKt.isBlank((CharSequence)charSequence);
            int n = !bl ? Color.parseColor((String)this.defaultColor) : ContextCompat.getColor((Context)this.context, (int)R.color.grey_500);
            materialCardView.setCardBackgroundColor(n);
            colorPickerView.setColor(n);
            colorPickerView.setColorListener((Function2<? super Integer, ? super String, Unit>)((Function2)new Function2<Integer, String, Unit>(materialCardView){
                final /* synthetic */ MaterialCardView $colorView;
                {
                    this.$colorView = materialCardView;
                    super(2);
                }

                public final void invoke(int n, String string2) {
                    Intrinsics.checkNotNullParameter((Object)string2, (String)"$noName_1");
                    this.$colorView.setCardBackgroundColor(n);
                }
            }));
            SharedPref sharedPref = new SharedPref(this.context);
            RecentColorAdapter recentColorAdapter = new RecentColorAdapter(sharedPref.getRecentColors());
            recentColorAdapter.setColorShape(this.colorShape);
            recentColorAdapter.setColorListener(new ColorListener(colorPickerView, materialCardView){
                final /* synthetic */ ColorPickerView $colorPicker;
                final /* synthetic */ MaterialCardView $colorView;
                {
                    this.$colorPicker = colorPickerView;
                    this.$colorView = materialCardView;
                }

                public void onColorSelected(int n, String string2) {
                    Intrinsics.checkNotNullParameter((Object)string2, (String)"colorHex");
                    this.$colorPicker.setColor(n);
                    this.$colorView.setCardBackgroundColor(n);
                }
            });
            recyclerView.setLayoutManager((RecyclerView.LayoutManager)new FlexboxLayoutManager(this.context));
            recyclerView.setAdapter((RecyclerView.Adapter)recentColorAdapter);
            builder.setPositiveButton((CharSequence)this.positiveButton, (DialogInterface.OnClickListener)new ColorPickerDialog$$ExternalSyntheticLambda0(colorPickerView, this, sharedPref));
            DismissListener dismissListener = this.dismissListener;
            if (dismissListener != null) {
                builder.setOnDismissListener((DialogInterface.OnDismissListener)new ColorPickerDialog$$ExternalSyntheticLambda1(dismissListener));
            }
            AlertDialog alertDialog = builder.create();
            Intrinsics.checkNotNullExpressionValue((Object)alertDialog, (String)"dialog.create()");
            alertDialog.show();
            DialogExtKt.setButtonTextColor(alertDialog);
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type android.view.View");
    }

    @Metadata(d1={"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u0012\u001a\u00020\u0013J \u0010\u0014\u001a\u00020\u00002\u0018\u0010\u0015\u001a\u0014\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00180\u0016J\u000e\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0006J\u000e\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ\u0010\u0010\u001a\u001a\u00020\u00002\b\b\u0001\u0010\u001b\u001a\u00020\u0017J\u000e\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\fJ\u0014\u0010\u001c\u001a\u00020\u00002\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00180\u001dJ\u0010\u0010\u001c\u001a\u00020\u00002\b\u0010\u0015\u001a\u0004\u0018\u00010\u000eJ\u0010\u0010\u001e\u001a\u00020\u00002\b\b\u0001\u0010\u001f\u001a\u00020\u0017J\u000e\u0010\u001e\u001a\u00020\u00002\u0006\u0010\u001f\u001a\u00020\fJ\u0010\u0010 \u001a\u00020\u00002\b\b\u0001\u0010\u001f\u001a\u00020\u0017J\u000e\u0010 \u001a\u00020\u00002\u0006\u0010\u001f\u001a\u00020\fJ\u0010\u0010!\u001a\u00020\u00002\b\b\u0001\u0010\u0011\u001a\u00020\u0017J\u000e\u0010!\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\fJ\u0006\u0010\"\u001a\u00020\u0018R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006#"}, d2={"Lcom/github/dhaval2404/colorpicker/ColorPickerDialog$Builder;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "getContext", "()Landroid/content/Context;", "defaultColor", "", "dismissListener", "Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "negativeButton", "positiveButton", "title", "build", "Lcom/github/dhaval2404/colorpicker/ColorPickerDialog;", "setColorListener", "listener", "Lkotlin/Function2;", "", "", "setColorShape", "setDefaultColor", "color", "setDismissListener", "Lkotlin/Function0;", "setNegativeButton", "text", "setPositiveButton", "setTitle", "show", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public static final class Builder {
        private ColorListener colorListener;
        private ColorShape colorShape;
        private final Context context;
        private String defaultColor;
        private DismissListener dismissListener;
        private String negativeButton;
        private String positiveButton;
        private String title;

        public Builder(Context context) {
            Intrinsics.checkNotNullParameter((Object)context, (String)"context");
            this.context = context;
            String string2 = context.getString(R.string.material_dialog_title);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(R.string.material_dialog_title)");
            this.title = string2;
            String string3 = context.getString(R.string.material_dialog_positive_button);
            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"context.getString(R.string.material_dialog_positive_button)");
            this.positiveButton = string3;
            String string4 = context.getString(R.string.material_dialog_negative_button);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"context.getString(R.string.material_dialog_negative_button)");
            this.negativeButton = string4;
            this.colorShape = ColorShape.CIRCLE;
        }

        public final ColorPickerDialog build() {
            ColorPickerDialog colorPickerDialog = new ColorPickerDialog(this.context, this.title, this.positiveButton, this.negativeButton, this.colorListener, this.dismissListener, this.defaultColor, this.colorShape, null);
            return colorPickerDialog;
        }

        public final Context getContext() {
            return this.context;
        }

        public final Builder setColorListener(ColorListener colorListener) {
            Intrinsics.checkNotNullParameter((Object)colorListener, (String)"listener");
            this.colorListener = colorListener;
            return this;
        }

        public final Builder setColorListener(Function2<? super Integer, ? super String, Unit> function2) {
            Intrinsics.checkNotNullParameter(function2, (String)"listener");
            this.colorListener = new ColorListener(function2){
                final /* synthetic */ Function2<Integer, String, Unit> $listener;
                {
                    this.$listener = function2;
                }

                public void onColorSelected(int n, String string2) {
                    Intrinsics.checkNotNullParameter((Object)string2, (String)"colorHex");
                    this.$listener.invoke((Object)n, (Object)string2);
                }
            };
            return this;
        }

        public final Builder setColorShape(ColorShape colorShape) {
            Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"colorShape");
            this.colorShape = colorShape;
            return this;
        }

        public final Builder setDefaultColor(int n) {
            this.defaultColor = ColorUtil.formatColor(n);
            return this;
        }

        public final Builder setDefaultColor(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
            this.defaultColor = string2;
            return this;
        }

        public final Builder setDismissListener(DismissListener dismissListener) {
            this.dismissListener = dismissListener;
            return this;
        }

        public final Builder setDismissListener(Function0<Unit> function0) {
            Intrinsics.checkNotNullParameter(function0, (String)"listener");
            this.dismissListener = new DismissListener(function0){
                final /* synthetic */ Function0<Unit> $listener;
                {
                    this.$listener = function0;
                }

                public void onDismiss() {
                    this.$listener.invoke();
                }
            };
            return this;
        }

        public final Builder setNegativeButton(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(text)");
            this.negativeButton = string2;
            return this;
        }

        public final Builder setNegativeButton(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"text");
            this.negativeButton = string2;
            return this;
        }

        public final Builder setPositiveButton(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(text)");
            this.positiveButton = string2;
            return this;
        }

        public final Builder setPositiveButton(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"text");
            this.positiveButton = string2;
            return this;
        }

        public final Builder setTitle(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(title)");
            this.title = string2;
            return this;
        }

        public final Builder setTitle(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"title");
            this.title = string2;
            return this;
        }

        public final void show() {
            this.build().show();
        }
    }

}

