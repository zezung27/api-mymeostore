/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.DialogInterface$OnDismissListener
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.fragment.app.FragmentManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.github.dhaval2404.colorpicker.MaterialColorPickerDialog$Builder$setColorListener
 *  com.github.dhaval2404.colorpicker.MaterialColorPickerDialog$Builder$setDismissListener
 *  com.google.android.flexbox.FlexboxLayoutManager
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.NullPointerException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.collections.ArraysKt
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package com.github.dhaval2404.colorpicker;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import com.github.dhaval2404.colorpicker.MaterialColorPickerBottomSheet;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog$$ExternalSyntheticLambda0;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog$$ExternalSyntheticLambda1;
import com.github.dhaval2404.colorpicker.R;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.listener.DismissListener;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.github.dhaval2404.colorpicker.model.ColorSwatch;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import com.github.dhaval2404.colorpicker.util.DialogExtKt;
import com.google.android.flexbox.FlexboxLayoutManager;
import dalvik.annotation.SourceDebugExtension;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Metadata(d1={"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0018\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001:\u00011Bq\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\u0006\u0010\u000f\u001a\u00020\u0010\u0012\u0010\b\u0002\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0012\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0014\u00a2\u0006\u0002\u0010\u0015J\u0006\u0010,\u001a\u00020-J\u000e\u0010.\u001a\u00020-2\u0006\u0010/\u001a\u000200R\u0013\u0010\b\u001a\u0004\u0018\u00010\t\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u000f\u001a\u00020\u0010X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\u0011\u0010\r\u001a\u00020\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0019\u0010\u0011\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\"\u0010#R\u0013\u0010\n\u001a\u0004\u0018\u00010\u000b\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u001a\u0010\u0013\u001a\u00020\u0014X\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0013\u0010&\"\u0004\b'\u0010(R\u0011\u0010\u0007\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b)\u0010#R\u0011\u0010\u0006\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010#R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010#\u00a8\u00062"}, d2={"Lcom/github/dhaval2404/colorpicker/MaterialColorPickerDialog;", "", "context", "Landroid/content/Context;", "title", "", "positiveButton", "negativeButton", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "dismissListener", "Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "defaultColor", "colorSwatch", "Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "colors", "", "isTickColorPerCard", "", "(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/github/dhaval2404/colorpicker/listener/ColorListener;Lcom/github/dhaval2404/colorpicker/listener/DismissListener;Ljava/lang/String;Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;Lcom/github/dhaval2404/colorpicker/model/ColorShape;Ljava/util/List;Z)V", "getColorListener", "()Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "getColorShape", "()Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "setColorShape", "(Lcom/github/dhaval2404/colorpicker/model/ColorShape;)V", "getColorSwatch", "()Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;", "getColors", "()Ljava/util/List;", "getContext", "()Landroid/content/Context;", "getDefaultColor", "()Ljava/lang/String;", "getDismissListener", "()Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "()Z", "setTickColorPerCard", "(Z)V", "getNegativeButton", "getPositiveButton", "getTitle", "show", "", "showBottomSheet", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "Builder", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class MaterialColorPickerDialog {
    private final ColorListener colorListener;
    private ColorShape colorShape;
    private final ColorSwatch colorSwatch;
    private final List<String> colors;
    private final Context context;
    private final String defaultColor;
    private final DismissListener dismissListener;
    private boolean isTickColorPerCard;
    private final String negativeButton;
    private final String positiveButton;
    private final String title;

    public static /* synthetic */ void $r8$lambda$rWipqyar85LPbYvyXQat6lSFBnc(DismissListener dismissListener, DialogInterface dialogInterface) {
        MaterialColorPickerDialog.show$lambda-2$lambda-1(dismissListener, dialogInterface);
    }

    public static /* synthetic */ void $r8$lambda$xAhmCZAlSyJRZLc8BJXQa1TkN1s(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerDialog materialColorPickerDialog, DialogInterface dialogInterface, int n) {
        MaterialColorPickerDialog.show$lambda-0(materialColorPickerAdapter, materialColorPickerDialog, dialogInterface, n);
    }

    private MaterialColorPickerDialog(Context context, String string2, String string3, String string4, ColorListener colorListener, DismissListener dismissListener, String string5, ColorSwatch colorSwatch, ColorShape colorShape, List<String> list, boolean bl) {
        this.context = context;
        this.title = string2;
        this.positiveButton = string3;
        this.negativeButton = string4;
        this.colorListener = colorListener;
        this.dismissListener = dismissListener;
        this.defaultColor = string5;
        this.colorSwatch = colorSwatch;
        this.colorShape = colorShape;
        this.colors = list;
        this.isTickColorPerCard = bl;
    }

    /* synthetic */ MaterialColorPickerDialog(Context context, String string2, String string3, String string4, ColorListener colorListener, DismissListener dismissListener, String string5, ColorSwatch colorSwatch, ColorShape colorShape, List list, boolean bl, int n, DefaultConstructorMarker defaultConstructorMarker) {
        List list2 = (n & 512) != 0 ? null : list;
        boolean bl2 = (n & 1024) != 0 ? false : bl;
        this(context, string2, string3, string4, colorListener, dismissListener, string5, colorSwatch, colorShape, (List<String>)list2, bl2);
    }

    public /* synthetic */ MaterialColorPickerDialog(Context context, String string2, String string3, String string4, ColorListener colorListener, DismissListener dismissListener, String string5, ColorSwatch colorSwatch, ColorShape colorShape, List list, boolean bl, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, string2, string3, string4, colorListener, dismissListener, string5, colorSwatch, colorShape, (List<String>)list, bl);
    }

    private static final void show$lambda-0(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerDialog materialColorPickerDialog, DialogInterface dialogInterface, int n) {
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorPickerAdapter), (String)"$adapter");
        Intrinsics.checkNotNullParameter((Object)materialColorPickerDialog, (String)"this$0");
        String string2 = materialColorPickerAdapter.getSelectedColor();
        if (true ^ StringsKt.isBlank((CharSequence)string2)) {
            ColorListener colorListener = materialColorPickerDialog.getColorListener();
            if (colorListener == null) {
                return;
            }
            colorListener.onColorSelected(ColorUtil.parseColor(string2), string2);
        }
    }

    private static final void show$lambda-2$lambda-1(DismissListener dismissListener, DialogInterface dialogInterface) {
        Intrinsics.checkNotNullParameter((Object)dismissListener, (String)"$listener");
        dismissListener.onDismiss();
    }

    public final ColorListener getColorListener() {
        return this.colorListener;
    }

    public final ColorShape getColorShape() {
        return this.colorShape;
    }

    public final ColorSwatch getColorSwatch() {
        return this.colorSwatch;
    }

    public final List<String> getColors() {
        return this.colors;
    }

    public final Context getContext() {
        return this.context;
    }

    public final String getDefaultColor() {
        return this.defaultColor;
    }

    public final DismissListener getDismissListener() {
        return this.dismissListener;
    }

    public final String getNegativeButton() {
        return this.negativeButton;
    }

    public final String getPositiveButton() {
        return this.positiveButton;
    }

    public final String getTitle() {
        return this.title;
    }

    public final boolean isTickColorPerCard() {
        return this.isTickColorPerCard;
    }

    public final void setColorShape(ColorShape colorShape) {
        Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"<set-?>");
        this.colorShape = colorShape;
    }

    public final void setTickColorPerCard(boolean bl) {
        this.isTickColorPerCard = bl;
    }

    public final void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this.context).setTitle((CharSequence)this.title).setNegativeButton((CharSequence)this.negativeButton, null);
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.context);
        Intrinsics.checkNotNullExpressionValue((Object)layoutInflater, (String)"from(context)");
        View view = layoutInflater.inflate(R.layout.dialog_material_color_picker, null);
        if (view != null) {
            builder.setView(view);
            List<String> list = this.colors;
            if (list == null) {
                list = ColorUtil.INSTANCE.getColors(this.context, this.colorSwatch.getValue());
            }
            MaterialColorPickerAdapter materialColorPickerAdapter = new MaterialColorPickerAdapter(list);
            materialColorPickerAdapter.setColorShape(this.colorShape);
            materialColorPickerAdapter.setTickColorPerCard(this.isTickColorPerCard);
            CharSequence charSequence = this.defaultColor;
            boolean bl = charSequence == null || StringsKt.isBlank((CharSequence)charSequence);
            if (!bl) {
                materialColorPickerAdapter.setDefaultColor(this.defaultColor);
            }
            RecyclerView recyclerView = (RecyclerView)view.findViewById(R.id.materialColorRV);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager((RecyclerView.LayoutManager)new FlexboxLayoutManager(this.context));
            recyclerView.setAdapter((RecyclerView.Adapter)materialColorPickerAdapter);
            builder.setPositiveButton((CharSequence)this.positiveButton, (DialogInterface.OnClickListener)new MaterialColorPickerDialog$$ExternalSyntheticLambda0(materialColorPickerAdapter, this));
            DismissListener dismissListener = this.dismissListener;
            if (dismissListener != null) {
                builder.setOnDismissListener((DialogInterface.OnDismissListener)new MaterialColorPickerDialog$$ExternalSyntheticLambda1(dismissListener));
            }
            AlertDialog alertDialog = builder.create();
            Intrinsics.checkNotNullExpressionValue((Object)alertDialog, (String)"dialog.create()");
            alertDialog.show();
            DialogExtKt.setButtonTextColor(alertDialog);
            return;
        }
        throw new NullPointerException("null cannot be cast to non-null type android.view.View");
    }

    public final void showBottomSheet(FragmentManager fragmentManager) {
        Intrinsics.checkNotNullParameter((Object)fragmentManager, (String)"fragmentManager");
        MaterialColorPickerBottomSheet.Companion.getInstance(this).setColorListener(this.colorListener).setDismissListener(this.dismissListener).show(fragmentManager, "");
    }

    @SourceDebugExtension(value="SMAP\nMaterialColorPickerDialog.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MaterialColorPickerDialog.kt\ncom/github/dhaval2404/colorpicker/MaterialColorPickerDialog$Builder\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,362:1\n1547#2:363\n1618#2,3:364\n11358#3:367\n11693#3,3:368\n*S KotlinDebug\n*F\n+ 1 MaterialColorPickerDialog.kt\ncom/github/dhaval2404/colorpicker/MaterialColorPickerDialog$Builder\n*L\n229#1:363\n229#1:364,3\n234#1:367\n234#1:368,3\n*E\n")
    @Metadata(d1={"\u0000r\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u0018\u001a\u00020\u0019J \u0010\u001a\u001a\u00020\u00002\u0018\u0010\u001b\u001a\u0014\u0012\u0004\u0012\u00020\u001d\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u001e0\u001cJ\u000e\u0010\u001a\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u0006J\u000e\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020 J\u0014\u0010\u001f\u001a\u00020\u00002\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u001d0\fJ\u000e\u0010!\u001a\u00020\u00002\u0006\u0010\u0007\u001a\u00020\bJ\u000e\u0010\"\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\nJ\u0019\u0010#\u001a\u00020\u00002\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0$\u00a2\u0006\u0002\u0010%J\u0014\u0010#\u001a\u00020\u00002\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fJ\u0010\u0010&\u001a\u00020\u00002\b\b\u0001\u0010'\u001a\u00020\u001dJ\u000e\u0010&\u001a\u00020\u00002\u0006\u0010'\u001a\u00020\rJ\u0014\u0010(\u001a\u00020\u00002\f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001e0)J\u0010\u0010(\u001a\u00020\u00002\b\u0010\u001b\u001a\u0004\u0018\u00010\u0012J\u0010\u0010*\u001a\u00020\u00002\b\b\u0001\u0010+\u001a\u00020\u001dJ\u000e\u0010*\u001a\u00020\u00002\u0006\u0010+\u001a\u00020\rJ\u0010\u0010,\u001a\u00020\u00002\b\b\u0001\u0010+\u001a\u00020\u001dJ\u000e\u0010,\u001a\u00020\u00002\u0006\u0010+\u001a\u00020\rJ\u000e\u0010-\u001a\u00020\u00002\u0006\u0010.\u001a\u00020\u0014J\u0010\u0010/\u001a\u00020\u00002\b\b\u0001\u0010\u0017\u001a\u00020\u001dJ\u000e\u0010/\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\rJ\u0006\u00100\u001a\u00020\u001eJ\u000e\u00101\u001a\u00020\u001e2\u0006\u00102\u001a\u000203R\u0010\u0010\u0005\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\r\u0018\u00010\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0010\u0010\u0010\u001a\u0004\u0018\u00010\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00064"}, d2={"Lcom/github/dhaval2404/colorpicker/MaterialColorPickerDialog$Builder;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "colorSwatch", "Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;", "colors", "", "", "getContext", "()Landroid/content/Context;", "defaultColor", "dismissListener", "Lcom/github/dhaval2404/colorpicker/listener/DismissListener;", "isTickColorPerCard", "", "negativeButton", "positiveButton", "title", "build", "Lcom/github/dhaval2404/colorpicker/MaterialColorPickerDialog;", "setColorListener", "listener", "Lkotlin/Function2;", "", "", "setColorRes", "", "setColorShape", "setColorSwatch", "setColors", "", "([Ljava/lang/String;)Lcom/github/dhaval2404/colorpicker/MaterialColorPickerDialog$Builder;", "setDefaultColor", "color", "setDismissListener", "Lkotlin/Function0;", "setNegativeButton", "text", "setPositiveButton", "setTickColorPerCard", "tickColorPerCard", "setTitle", "show", "showBottomSheet", "fragmentManager", "Landroidx/fragment/app/FragmentManager;", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public static final class Builder {
        private ColorListener colorListener;
        private ColorShape colorShape;
        private ColorSwatch colorSwatch;
        private List<String> colors;
        private final Context context;
        private String defaultColor;
        private DismissListener dismissListener;
        private boolean isTickColorPerCard;
        private String negativeButton;
        private String positiveButton;
        private String title;

        public Builder(Context context) {
            Intrinsics.checkNotNullParameter((Object)context, (String)"context");
            this.context = context;
            String string2 = context.getString(R.string.material_dialog_title);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(R.string.material_dialog_title)");
            this.title = string2;
            String string3 = context.getString(R.string.material_dialog_positive_button);
            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"context.getString(R.string.material_dialog_positive_button)");
            this.positiveButton = string3;
            String string4 = context.getString(R.string.material_dialog_negative_button);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"context.getString(R.string.material_dialog_negative_button)");
            this.negativeButton = string4;
            this.colorSwatch = ColorSwatch._300;
            this.colorShape = ColorShape.CIRCLE;
        }

        public final MaterialColorPickerDialog build() {
            Context context = this.context;
            String string2 = this.title;
            String string3 = this.positiveButton;
            String string4 = this.negativeButton;
            ColorListener colorListener = this.colorListener;
            DismissListener dismissListener = this.dismissListener;
            String string5 = this.defaultColor;
            ColorShape colorShape = this.colorShape;
            ColorSwatch colorSwatch = this.colorSwatch;
            List<String> list = this.colors;
            boolean bl = this.isTickColorPerCard;
            MaterialColorPickerDialog materialColorPickerDialog = new MaterialColorPickerDialog(context, string2, string3, string4, colorListener, dismissListener, string5, colorSwatch, colorShape, list, bl, null);
            return materialColorPickerDialog;
        }

        public final Context getContext() {
            return this.context;
        }

        public final Builder setColorListener(ColorListener colorListener) {
            Intrinsics.checkNotNullParameter((Object)colorListener, (String)"listener");
            this.colorListener = colorListener;
            return this;
        }

        public final Builder setColorListener(Function2<? super Integer, ? super String, Unit> function2) {
            Intrinsics.checkNotNullParameter(function2, (String)"listener");
            this.colorListener = new ColorListener(function2){
                final /* synthetic */ Function2<Integer, String, Unit> $listener;
                {
                    this.$listener = function2;
                }

                public void onColorSelected(int n, String string2) {
                    Intrinsics.checkNotNullParameter((Object)string2, (String)"colorHex");
                    this.$listener.invoke((Object)n, (Object)string2);
                }
            };
            return this;
        }

        public final Builder setColorRes(List<Integer> list) {
            Intrinsics.checkNotNullParameter(list, (String)"colors");
            Iterable iterable = (Iterable)list;
            Collection collection = (Collection)new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)iterable, (int)10));
            Iterator iterator = iterable.iterator();
            while (iterator.hasNext()) {
                int n = ((Number)iterator.next()).intValue();
                collection.add((Object)ColorUtil.formatColor(n));
            }
            this.colors = (List)collection;
            return this;
        }

        public final Builder setColorRes(int[] arrn) {
            Intrinsics.checkNotNullParameter((Object)arrn, (String)"colors");
            Collection collection = (Collection)new ArrayList(arrn.length);
            for (int n : arrn) {
                collection.add((Object)ColorUtil.formatColor(n));
            }
            this.colors = (List)collection;
            return this;
        }

        public final Builder setColorShape(ColorShape colorShape) {
            Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"colorShape");
            this.colorShape = colorShape;
            return this;
        }

        public final Builder setColorSwatch(ColorSwatch colorSwatch) {
            Intrinsics.checkNotNullParameter((Object)((Object)colorSwatch), (String)"colorSwatch");
            this.colorSwatch = colorSwatch;
            return this;
        }

        public final Builder setColors(List<String> list) {
            Intrinsics.checkNotNullParameter(list, (String)"colors");
            this.colors = list;
            return this;
        }

        public final Builder setColors(String[] arrstring) {
            Intrinsics.checkNotNullParameter((Object)arrstring, (String)"colors");
            this.colors = ArraysKt.toList((Object[])arrstring);
            return this;
        }

        public final Builder setDefaultColor(int n) {
            this.defaultColor = ColorUtil.formatColor(n);
            return this;
        }

        public final Builder setDefaultColor(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
            this.defaultColor = string2;
            return this;
        }

        public final Builder setDismissListener(DismissListener dismissListener) {
            this.dismissListener = dismissListener;
            return this;
        }

        public final Builder setDismissListener(Function0<Unit> function0) {
            Intrinsics.checkNotNullParameter(function0, (String)"listener");
            this.dismissListener = new DismissListener(function0){
                final /* synthetic */ Function0<Unit> $listener;
                {
                    this.$listener = function0;
                }

                public void onDismiss() {
                    this.$listener.invoke();
                }
            };
            return this;
        }

        public final Builder setNegativeButton(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(text)");
            this.negativeButton = string2;
            return this;
        }

        public final Builder setNegativeButton(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"text");
            this.negativeButton = string2;
            return this;
        }

        public final Builder setPositiveButton(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(text)");
            this.positiveButton = string2;
            return this;
        }

        public final Builder setPositiveButton(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"text");
            this.positiveButton = string2;
            return this;
        }

        public final Builder setTickColorPerCard(boolean bl) {
            this.isTickColorPerCard = bl;
            return this;
        }

        public final Builder setTitle(int n) {
            String string2 = this.context.getString(n);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(title)");
            this.title = string2;
            return this;
        }

        public final Builder setTitle(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"title");
            this.title = string2;
            return this;
        }

        public final void show() {
            this.build().show();
        }

        public final void showBottomSheet(FragmentManager fragmentManager) {
            Intrinsics.checkNotNullParameter((Object)fragmentManager, (String)"fragmentManager");
            this.build().showBottomSheet(fragmentManager);
        }
    }

}

