/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.PointF
 *  android.util.AttributeSet
 *  android.view.View
 *  androidx.core.content.ContextCompat
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.content.ContextCompat;
import com.github.dhaval2404.colorpicker.R;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B/\b\u0007\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\tJ\u0010\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0013H\u0014J\u000e\u0010\u0014\u001a\u00020\u00112\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\u0015\u001a\u00020\u00112\u0006\u0010\f\u001a\u00020\rR\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"}, d2={"Lcom/github/dhaval2404/colorpicker/widget/ColorPointer;", "Landroid/view/View;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyle", "", "defStyleRes", "(Landroid/content/Context;Landroid/util/AttributeSet;II)V", "point", "Landroid/graphics/PointF;", "pointerRadius", "", "selectorPaint", "Landroid/graphics/Paint;", "onDraw", "", "canvas", "Landroid/graphics/Canvas;", "setCurrentPoint", "setPointerRadius", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorPointer
extends View {
    private PointF point;
    private float pointerRadius;
    private Paint selectorPaint;

    public ColorPointer(Context context) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, null, 0, 0, 14, null);
    }

    public ColorPointer(Context context, AttributeSet attributeSet) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, attributeSet, 0, 0, 12, null);
    }

    public ColorPointer(Context context, AttributeSet attributeSet, int n) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, attributeSet, n, 0, 8, null);
    }

    public ColorPointer(Context context, AttributeSet attributeSet, int n, int n2) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        super(context, attributeSet, n, n2);
        this.pointerRadius = 8.0f;
        this.point = new PointF();
        this.setAlpha(0.5f);
        Paint paint = new Paint(1);
        paint.setColor(ContextCompat.getColor((Context)context, (int)R.color.colorPointer));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(8.0f);
        this.selectorPaint = paint;
    }

    public /* synthetic */ ColorPointer(Context context, AttributeSet attributeSet, int n, int n2, int n3, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n3 & 2) != 0) {
            attributeSet = null;
        }
        if ((n3 & 4) != 0) {
            n = 0;
        }
        if ((n3 & 8) != 0) {
            n2 = 0;
        }
        this(context, attributeSet, n, n2);
    }

    public void _$_clearFindViewByIdCache() {
    }

    protected void onDraw(Canvas canvas) {
        Intrinsics.checkNotNullParameter((Object)canvas, (String)"canvas");
        canvas.drawCircle(this.point.x, this.point.y, 0.66f * this.pointerRadius, this.selectorPaint);
    }

    public final void setCurrentPoint(PointF pointF) {
        Intrinsics.checkNotNullParameter((Object)pointF, (String)"point");
        this.point = pointF;
        this.invalidate();
    }

    public final void setPointerRadius(float f) {
        this.pointerRadius = f;
    }
}

