/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.model;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0010\b\u0087\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u00012\u00020\u0002B\u000f\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\t\u0010\b\u001a\u00020\tH\u00d6\u0001J\u0019\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\tH\u00d6\u0001R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007j\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018j\u0002\b\u0019j\u0002\b\u001aj\u0002\b\u001bj\u0002\b\u001c\u00a8\u0006\u001d"}, d2={"Lcom/github/dhaval2404/colorpicker/model/ColorSwatch;", "", "Landroid/os/Parcelable;", "value", "", "(Ljava/lang/String;ILjava/lang/String;)V", "getValue", "()Ljava/lang/String;", "describeContents", "", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "_50", "_100", "_200", "_300", "_400", "_500", "_600", "_700", "_800", "_900", "A100", "A200", "A300", "A400", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorSwatch
extends Enum<ColorSwatch>
implements Parcelable {
    private static final /* synthetic */ ColorSwatch[] $VALUES;
    public static final /* enum */ ColorSwatch A100;
    public static final /* enum */ ColorSwatch A200;
    public static final /* enum */ ColorSwatch A300;
    public static final /* enum */ ColorSwatch A400;
    public static final Parcelable.Creator<ColorSwatch> CREATOR;
    public static final /* enum */ ColorSwatch _100;
    public static final /* enum */ ColorSwatch _200;
    public static final /* enum */ ColorSwatch _300;
    public static final /* enum */ ColorSwatch _400;
    public static final /* enum */ ColorSwatch _50;
    public static final /* enum */ ColorSwatch _500;
    public static final /* enum */ ColorSwatch _600;
    public static final /* enum */ ColorSwatch _700;
    public static final /* enum */ ColorSwatch _800;
    public static final /* enum */ ColorSwatch _900;
    private final String value;

    static {
        _50 = new ColorSwatch("50");
        _100 = new ColorSwatch("100");
        _200 = new ColorSwatch("200");
        _300 = new ColorSwatch("300");
        _400 = new ColorSwatch("400");
        _500 = new ColorSwatch("500");
        _600 = new ColorSwatch("600");
        _700 = new ColorSwatch("700");
        _800 = new ColorSwatch("800");
        _900 = new ColorSwatch("900");
        A100 = new ColorSwatch("a100");
        A200 = new ColorSwatch("a200");
        A300 = new ColorSwatch("a300");
        A400 = new ColorSwatch("a400");
        $VALUES = arrcolorSwatch = new ColorSwatch[]{ColorSwatch._50, ColorSwatch._100, ColorSwatch._200, ColorSwatch._300, ColorSwatch._400, ColorSwatch._500, ColorSwatch._600, ColorSwatch._700, ColorSwatch._800, ColorSwatch._900, ColorSwatch.A100, ColorSwatch.A200, ColorSwatch.A300, ColorSwatch.A400};
        CREATOR = new Creator();
    }

    private ColorSwatch(String string3) {
        this.value = string3;
    }

    public static ColorSwatch valueOf(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"value");
        return (ColorSwatch)Enum.valueOf(ColorSwatch.class, (String)string2);
    }

    public static ColorSwatch[] values() {
        ColorSwatch[] arrcolorSwatch = $VALUES;
        return (ColorSwatch[])Arrays.copyOf((Object[])arrcolorSwatch, (int)arrcolorSwatch.length);
    }

    public int describeContents() {
        return 0;
    }

    public final String getValue() {
        return this.value;
    }

    public void writeToParcel(Parcel parcel, int n) {
        Intrinsics.checkNotNullParameter((Object)parcel, (String)"out");
        parcel.writeString(this.name());
    }

    @Metadata(k=3, mv={1, 5, 1}, xi=48)
    public static final class Creator
    implements Parcelable.Creator<ColorSwatch> {
        public final ColorSwatch createFromParcel(Parcel parcel) {
            Intrinsics.checkNotNullParameter((Object)parcel, (String)"parcel");
            return ColorSwatch.valueOf(parcel.readString());
        }

        public final ColorSwatch[] newArray(int n) {
            return new ColorSwatch[n];
        }
    }

}

