/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.nordan.dialog;

import android.app.Dialog;
import android.view.View;
import com.nordan.dialog.NordanAlertDialog;

public final class NordanAlertDialog$Builder$$ExternalSyntheticLambda1
implements View.OnClickListener {
    public final /* synthetic */ NordanAlertDialog.Builder f$0;
    public final /* synthetic */ Dialog f$1;

    public /* synthetic */ NordanAlertDialog$Builder$$ExternalSyntheticLambda1(NordanAlertDialog.Builder builder, Dialog dialog) {
        this.f$0 = builder;
        this.f$1 = dialog;
    }

    public final void onClick(View view) {
        this.f$0.lambda$build$1$com-nordan-dialog-NordanAlertDialog$Builder(this.f$1, view);
    }
}

