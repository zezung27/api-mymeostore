/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.Window
 *  java.lang.Object
 *  java.util.function.Consumer
 */
package com.nordan.dialog;

import android.view.Window;
import com.nordan.dialog.NordanAlertDialog;
import java.util.function.Consumer;

public final class NordanAlertDialog$Builder$$ExternalSyntheticLambda0
implements Consumer {
    public final void accept(Object object) {
        NordanAlertDialog.Builder.lambda$build$0((Window)object);
    }
}

