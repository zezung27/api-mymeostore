/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  android.widget.RelativeLayout
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.textview.MaterialTextView
 *  java.lang.CharSequence
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Optional
 *  java.util.function.Consumer
 */
package com.nordan.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import com.nordan.dialog.Animation;
import com.nordan.dialog.DialogType;
import com.nordan.dialog.NordanAlertDialog$Builder$$ExternalSyntheticLambda0;
import com.nordan.dialog.NordanAlertDialog$Builder$$ExternalSyntheticLambda1;
import com.nordan.dialog.NordanAlertDialog$Builder$$ExternalSyntheticLambda2;
import com.nordan.dialog.NordanAlertDialog$Builder$$ExternalSyntheticLambda3;
import com.nordan.dialog.NordanAlertDialog$Builder$$ExternalSyntheticLambda4;
import com.nordan.dialog.NordanAlertDialogListener;
import com.nordan.dialog.R;
import java.util.Optional;
import java.util.function.Consumer;
import pl.droidsonroids.gif.GifImageView;

public class NordanAlertDialog {
    private NordanAlertDialog() {
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    public static class Builder {
        private Activity activity;
        private Animation animation;
        private int dialogAccentColor;
        private DialogType dialogType;
        private int headerColor;
        private Bitmap headerIconDrawable;
        private int headerIconResource;
        private boolean isCancelable;
        private boolean isGif;
        private String message;
        private String negativeBtnText;
        private NordanAlertDialogListener negativeListener;
        private String positiveBtnText;
        private NordanAlertDialogListener positiveListener;
        private String title;

        public Builder(Activity activity) {
            this.activity = activity;
        }

        private Dialog getAnimationDialog() {
            if (this.animation == null) {
                return new Dialog((Context)this.activity);
            }
            int n = 1.$SwitchMap$com$nordan$dialog$Animation[this.animation.ordinal()];
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        return new Dialog((Context)this.activity);
                    }
                    return new Dialog((Context)this.activity, R.style.NordanDialogSlideTheme);
                }
                return new Dialog((Context)this.activity, R.style.NordanDialogSideTheme);
            }
            return new Dialog((Context)this.activity, R.style.NordanDialogPopTheme);
        }

        static /* synthetic */ void lambda$build$0(Window window) {
            window.setBackgroundDrawable((Drawable)new ColorDrawable(0));
        }

        static /* synthetic */ void lambda$build$2(Dialog dialog, View view) {
            dialog.dismiss();
        }

        static /* synthetic */ void lambda$build$4(Dialog dialog, View view) {
            dialog.dismiss();
        }

        private void setCustomDialog(Dialog dialog, GifImageView gifImageView, View view) {
            int n;
            RelativeLayout relativeLayout = (RelativeLayout)dialog.findViewById(R.id.relative_header);
            int n2 = this.headerIconResource;
            if (n2 == 0 && this.headerColor == 0 && this.headerIconDrawable == null) {
                relativeLayout.setVisibility(8);
                return;
            }
            if (n2 != 0) {
                gifImageView.setImageResource(n2);
                gifImageView.setVisibility(0);
                if (this.isGif) {
                    relativeLayout.getLayoutParams().height = 250;
                    gifImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                }
            }
            if ((n = this.headerColor) != 0) {
                view.setBackgroundColor(n);
            }
        }

        private void setErrorDialog(GifImageView gifImageView, View view) {
            gifImageView.setImageResource(R.drawable.ic_baseline_error_24);
            gifImageView.setVisibility(0);
            view.setBackgroundColor(this.activity.getColor(R.color.colorRed));
        }

        private void setInformationDialog(GifImageView gifImageView, View view) {
            gifImageView.setImageResource(R.drawable.ic_baseline_info_24);
            gifImageView.setVisibility(0);
            view.setBackgroundColor(this.activity.getColor(R.color.colorPurple));
        }

        private void setLevelCompleteDialog(GifImageView gifImageView, View view) {
            gifImageView.setImageResource(R.drawable.ic_baseline_check_circle_24);
            gifImageView.setVisibility(0);
            view.setBackgroundColor(this.activity.getColor(R.color.colorGreen));
        }

        private void setQuestionDialog(GifImageView gifImageView, View view) {
            gifImageView.setImageResource(R.drawable.ic_baseline_help_24);
            gifImageView.setVisibility(0);
            view.setBackgroundColor(this.activity.getColor(R.color.colorBlue));
        }

        private void setWarningDialog(GifImageView gifImageView, View view) {
            gifImageView.setImageResource(R.drawable.ic_baseline_warning_24);
            gifImageView.setVisibility(0);
            view.setBackgroundColor(this.activity.getColor(R.color.colorYellow));
        }

        public Dialog build() {
            String string2;
            String string3;
            String string4;
            Dialog dialog = this.getAnimationDialog();
            dialog.requestWindowFeature(1);
            Optional.ofNullable((Object)dialog.getWindow()).ifPresent((Consumer)new NordanAlertDialog$Builder$$ExternalSyntheticLambda0());
            dialog.setCancelable(this.isCancelable);
            dialog.setContentView(R.layout.nordan_alert_dialog);
            View view = dialog.findViewById(R.id.background);
            MaterialTextView materialTextView = (MaterialTextView)dialog.findViewById(R.id.title);
            MaterialTextView materialTextView2 = (MaterialTextView)dialog.findViewById(R.id.message);
            GifImageView gifImageView = (GifImageView)dialog.findViewById(R.id.icon);
            MaterialButton materialButton = (MaterialButton)dialog.findViewById(R.id.negativeBtn);
            MaterialButton materialButton2 = (MaterialButton)dialog.findViewById(R.id.positiveBtn);
            materialTextView.setText((CharSequence)this.title);
            materialTextView2.setText((CharSequence)this.message);
            if (this.dialogType != null) {
                int n = 1.$SwitchMap$com$nordan$dialog$DialogType[this.dialogType.ordinal()];
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            if (n != 4) {
                                if (n == 5) {
                                    this.setLevelCompleteDialog(gifImageView, view);
                                }
                            } else {
                                this.setInformationDialog(gifImageView, view);
                            }
                        } else {
                            this.setQuestionDialog(gifImageView, view);
                        }
                    } else {
                        this.setWarningDialog(gifImageView, view);
                    }
                } else {
                    this.setErrorDialog(gifImageView, view);
                }
            } else {
                this.setCustomDialog(dialog, gifImageView, view);
            }
            String string5 = this.positiveBtnText;
            if (string5 != null && !string5.isEmpty()) {
                materialButton2.setText((CharSequence)this.positiveBtnText);
            }
            if ((string4 = this.negativeBtnText) != null && !string4.isEmpty()) {
                materialButton.setText((CharSequence)this.negativeBtnText);
            } else {
                materialButton.setVisibility(8);
            }
            if (this.positiveListener != null && (string3 = this.positiveBtnText) != null && !string3.isEmpty()) {
                materialButton2.setOnClickListener((View.OnClickListener)new NordanAlertDialog$Builder$$ExternalSyntheticLambda1(this, dialog));
            } else {
                materialButton2.setOnClickListener((View.OnClickListener)new NordanAlertDialog$Builder$$ExternalSyntheticLambda2(dialog));
            }
            if (this.negativeListener != null && (string2 = this.negativeBtnText) != null && !string2.isEmpty()) {
                materialButton.setVisibility(0);
                materialButton.setOnClickListener((View.OnClickListener)new NordanAlertDialog$Builder$$ExternalSyntheticLambda3(this, dialog));
            } else {
                materialButton.setOnClickListener((View.OnClickListener)new NordanAlertDialog$Builder$$ExternalSyntheticLambda4(dialog));
            }
            int n = this.dialogAccentColor;
            if (n > 0) {
                materialButton2.setBackgroundColor(this.activity.getColor(n));
                materialButton.setTextColor(this.activity.getColor(this.dialogAccentColor));
            }
            return dialog;
        }

        public Builder isCancellable(boolean bl) {
            this.isCancelable = bl;
            return this;
        }

        /* synthetic */ void lambda$build$1$com-nordan-dialog-NordanAlertDialog$Builder(Dialog dialog, View view) {
            this.positiveListener.onClick();
            dialog.dismiss();
        }

        /* synthetic */ void lambda$build$3$com-nordan-dialog-NordanAlertDialog$Builder(Dialog dialog, View view) {
            this.negativeListener.onClick();
            dialog.dismiss();
        }

        public Builder onNegativeClicked(NordanAlertDialogListener nordanAlertDialogListener) {
            this.negativeListener = nordanAlertDialogListener;
            return this;
        }

        public Builder onPositiveClicked(NordanAlertDialogListener nordanAlertDialogListener) {
            this.positiveListener = nordanAlertDialogListener;
            return this;
        }

        public Builder setAnimation(Animation animation) {
            this.animation = animation;
            return this;
        }

        public Builder setDialogAccentColor(int n) {
            this.dialogAccentColor = n;
            return this;
        }

        public Builder setDialogType(DialogType dialogType) {
            this.dialogType = dialogType;
            return this;
        }

        public Builder setHeaderColor(int n) {
            this.headerColor = n;
            return this;
        }

        public Builder setIcon(int n, boolean bl) {
            this.headerIconResource = n;
            this.isGif = bl;
            return this;
        }

        public Builder setIcon(Bitmap bitmap, boolean bl) {
            this.headerIconDrawable = bitmap;
            this.isGif = bl;
            return this;
        }

        public Builder setMessage(String string2) {
            this.message = string2;
            return this;
        }

        public Builder setNegativeBtnText(String string2) {
            this.negativeBtnText = string2;
            return this;
        }

        public Builder setPositiveBtnText(String string2) {
            this.positiveBtnText = string2;
            return this;
        }

        public Builder setTitle(String string2) {
            this.title = string2;
            return this;
        }
    }

}

