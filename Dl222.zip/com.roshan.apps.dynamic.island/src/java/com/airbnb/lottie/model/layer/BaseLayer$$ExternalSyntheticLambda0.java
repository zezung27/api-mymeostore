/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie.model.layer;

import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.layer.BaseLayer;

public final class BaseLayer$$ExternalSyntheticLambda0
implements BaseKeyframeAnimation.AnimationListener {
    public final /* synthetic */ BaseLayer f$0;

    public /* synthetic */ BaseLayer$$ExternalSyntheticLambda0(BaseLayer baseLayer) {
        this.f$0 = baseLayer;
    }

    @Override
    public final void onValueChanged() {
        this.f$0.lambda$setupInOutAnimations$0$com-airbnb-lottie-model-layer-BaseLayer();
    }
}

