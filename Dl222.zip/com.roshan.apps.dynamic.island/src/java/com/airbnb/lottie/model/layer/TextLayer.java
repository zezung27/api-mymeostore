/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  androidx.collection.LongSparseArray
 *  androidx.collection.SparseArrayCompat
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 */
package com.airbnb.lottie.model.layer;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import androidx.collection.LongSparseArray;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.animation.content.ContentGroup;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TextKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.TransformKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.model.Font;
import com.airbnb.lottie.model.FontCharacter;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableTextFrame;
import com.airbnb.lottie.model.animatable.AnimatableTextProperties;
import com.airbnb.lottie.model.content.ShapeGroup;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TextLayer
extends BaseLayer {
    private final LongSparseArray<String> codePointCache = new LongSparseArray();
    private BaseKeyframeAnimation<Integer, Integer> colorAnimation;
    private BaseKeyframeAnimation<Integer, Integer> colorCallbackAnimation;
    private final LottieComposition composition;
    private final Map<FontCharacter, List<ContentGroup>> contentsForCharacter = new HashMap();
    private final Paint fillPaint = new Paint(1){
        {
            this.setStyle(Paint.Style.FILL);
        }
    };
    private final LottieDrawable lottieDrawable;
    private final Matrix matrix = new Matrix();
    private final RectF rectF = new RectF();
    private final StringBuilder stringBuilder = new StringBuilder(2);
    private BaseKeyframeAnimation<Integer, Integer> strokeColorAnimation;
    private BaseKeyframeAnimation<Integer, Integer> strokeColorCallbackAnimation;
    private final Paint strokePaint = new Paint(1){
        {
            this.setStyle(Paint.Style.STROKE);
        }
    };
    private BaseKeyframeAnimation<Float, Float> strokeWidthAnimation;
    private BaseKeyframeAnimation<Float, Float> strokeWidthCallbackAnimation;
    private final TextKeyframeAnimation textAnimation;
    private BaseKeyframeAnimation<Float, Float> textSizeCallbackAnimation;
    private BaseKeyframeAnimation<Float, Float> trackingAnimation;
    private BaseKeyframeAnimation<Float, Float> trackingCallbackAnimation;
    private BaseKeyframeAnimation<Typeface, Typeface> typefaceCallbackAnimation;

    TextLayer(LottieDrawable lottieDrawable, Layer layer) {
        super(lottieDrawable, layer);
        this.lottieDrawable = lottieDrawable;
        this.composition = layer.getComposition();
        BaseKeyframeAnimation baseKeyframeAnimation = layer.getText().createAnimation();
        this.textAnimation = baseKeyframeAnimation;
        baseKeyframeAnimation.addUpdateListener(this);
        this.addAnimation(baseKeyframeAnimation);
        AnimatableTextProperties animatableTextProperties = layer.getTextProperties();
        if (animatableTextProperties != null && animatableTextProperties.color != null) {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2 = animatableTextProperties.color.createAnimation();
            this.colorAnimation = baseKeyframeAnimation2;
            baseKeyframeAnimation2.addUpdateListener(this);
            this.addAnimation(this.colorAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.stroke != null) {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation3 = animatableTextProperties.stroke.createAnimation();
            this.strokeColorAnimation = baseKeyframeAnimation3;
            baseKeyframeAnimation3.addUpdateListener(this);
            this.addAnimation(this.strokeColorAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.strokeWidth != null) {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation4 = animatableTextProperties.strokeWidth.createAnimation();
            this.strokeWidthAnimation = baseKeyframeAnimation4;
            baseKeyframeAnimation4.addUpdateListener(this);
            this.addAnimation(this.strokeWidthAnimation);
        }
        if (animatableTextProperties != null && animatableTextProperties.tracking != null) {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation5 = animatableTextProperties.tracking.createAnimation();
            this.trackingAnimation = baseKeyframeAnimation5;
            baseKeyframeAnimation5.addUpdateListener(this);
            this.addAnimation(this.trackingAnimation);
        }
    }

    private void applyJustification(DocumentData.Justification justification, Canvas canvas, float f) {
        int n = 3.$SwitchMap$com$airbnb$lottie$model$DocumentData$Justification[justification.ordinal()];
        if (n != 2) {
            if (n != 3) {
                return;
            }
            canvas.translate(-f / 2.0f, 0.0f);
            return;
        }
        canvas.translate(-f, 0.0f);
    }

    private String codePointToString(String string2, int n) {
        int n2;
        int n3;
        int n4 = string2.codePointAt(n);
        for (n2 = n + Character.charCount((int)n4); n2 < string2.length() && this.isModifier(n3 = string2.codePointAt(n2)); n2 += Character.charCount((int)n3)) {
            n4 = n3 + n4 * 31;
        }
        LongSparseArray<String> longSparseArray = this.codePointCache;
        long l = n4;
        if (longSparseArray.containsKey(l)) {
            return (String)this.codePointCache.get(l);
        }
        this.stringBuilder.setLength(0);
        while (n < n2) {
            int n5 = string2.codePointAt(n);
            this.stringBuilder.appendCodePoint(n5);
            n += Character.charCount((int)n5);
        }
        String string3 = this.stringBuilder.toString();
        this.codePointCache.put(l, (Object)string3);
        return string3;
    }

    private void drawCharacter(String string2, Paint paint, Canvas canvas) {
        if (paint.getColor() == 0) {
            return;
        }
        if (paint.getStyle() == Paint.Style.STROKE && paint.getStrokeWidth() == 0.0f) {
            return;
        }
        canvas.drawText(string2, 0, string2.length(), 0.0f, 0.0f, paint);
    }

    private void drawCharacterAsGlyph(FontCharacter fontCharacter, Matrix matrix, float f, DocumentData documentData, Canvas canvas) {
        List<ContentGroup> list = this.getContentsForCharacter(fontCharacter);
        for (int i = 0; i < list.size(); ++i) {
            Path path = ((ContentGroup)list.get(i)).getPath();
            path.computeBounds(this.rectF, false);
            this.matrix.set(matrix);
            this.matrix.preTranslate(0.0f, -documentData.baselineShift * Utils.dpScale());
            this.matrix.preScale(f, f);
            path.transform(this.matrix);
            if (documentData.strokeOverFill) {
                this.drawGlyph(path, this.fillPaint, canvas);
                this.drawGlyph(path, this.strokePaint, canvas);
                continue;
            }
            this.drawGlyph(path, this.strokePaint, canvas);
            this.drawGlyph(path, this.fillPaint, canvas);
        }
    }

    private void drawCharacterFromFont(String string2, DocumentData documentData, Canvas canvas) {
        if (documentData.strokeOverFill) {
            this.drawCharacter(string2, this.fillPaint, canvas);
            this.drawCharacter(string2, this.strokePaint, canvas);
            return;
        }
        this.drawCharacter(string2, this.strokePaint, canvas);
        this.drawCharacter(string2, this.fillPaint, canvas);
    }

    private void drawFontTextLine(String string2, DocumentData documentData, Canvas canvas, float f) {
        String string3;
        for (int i = 0; i < string2.length(); i += string3.length()) {
            string3 = this.codePointToString(string2, i);
            this.drawCharacterFromFont(string3, documentData, canvas);
            canvas.translate(f + this.fillPaint.measureText(string3), 0.0f);
        }
    }

    private void drawGlyph(Path path, Paint paint, Canvas canvas) {
        if (paint.getColor() == 0) {
            return;
        }
        if (paint.getStyle() == Paint.Style.STROKE && paint.getStrokeWidth() == 0.0f) {
            return;
        }
        canvas.drawPath(path, paint);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void drawGlyphTextLine(String string2, DocumentData documentData, Matrix matrix, Font font2, Canvas canvas, float f, float f2) {
        int n = 0;
        do {
            block5 : {
                float f3;
                float f4;
                block8 : {
                    float f5;
                    block7 : {
                        block6 : {
                            if (n >= string2.length()) {
                                return;
                            }
                            int n2 = FontCharacter.hashFor(string2.charAt(n), font2.getFamily(), font2.getStyle());
                            FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(n2);
                            if (fontCharacter == null) break block5;
                            this.drawCharacterAsGlyph(fontCharacter, matrix, f2, documentData, canvas);
                            f3 = f * (f2 * (float)fontCharacter.getWidth() * Utils.dpScale());
                            f4 = (float)documentData.tracking / 10.0f;
                            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingCallbackAnimation;
                            if (baseKeyframeAnimation == null) break block6;
                            f5 = baseKeyframeAnimation.getValue().floatValue();
                            break block7;
                        }
                        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingAnimation;
                        if (baseKeyframeAnimation == null) break block8;
                        f5 = baseKeyframeAnimation.getValue().floatValue();
                    }
                    f4 += f5;
                }
                canvas.translate(f3 + f4 * f, 0.0f);
            }
            ++n;
        } while (true);
    }

    private void drawTextGlyphs(DocumentData documentData, Matrix matrix, Font font2, Canvas canvas) {
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.textSizeCallbackAnimation;
        float f = baseKeyframeAnimation != null ? baseKeyframeAnimation.getValue().floatValue() : documentData.size;
        float f2 = f / 100.0f;
        float f3 = Utils.getScale(matrix);
        String string2 = documentData.text;
        float f4 = documentData.lineHeight * Utils.dpScale();
        List<String> list = this.getTextLines(string2);
        int n = list.size();
        int n2 = 0;
        while (n2 < n) {
            String string3 = (String)list.get(n2);
            float f5 = this.getTextLineWidthForGlyphs(string3, font2, f2, f3);
            canvas.save();
            this.applyJustification(documentData.justification, canvas, f5);
            float f6 = f4 * (float)(n - 1) / 2.0f;
            canvas.translate(0.0f, f4 * (float)n2 - f6);
            int n3 = n2;
            this.drawGlyphTextLine(string3, documentData, matrix, font2, canvas, f3, f2);
            canvas.restore();
            n2 = n3 + 1;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private void drawTextWithFont(DocumentData documentData, Font font2, Canvas canvas) {
        float f;
        float f2;
        float f3;
        String string2;
        block9 : {
            float f4;
            block8 : {
                block7 : {
                    Typeface typeface = this.getTypeface(font2);
                    if (typeface == null) {
                        return;
                    }
                    string2 = documentData.text;
                    TextDelegate textDelegate = this.lottieDrawable.getTextDelegate();
                    if (textDelegate != null) {
                        string2 = textDelegate.getTextInternal(this.getName(), string2);
                    }
                    this.fillPaint.setTypeface(typeface);
                    BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.textSizeCallbackAnimation;
                    f3 = baseKeyframeAnimation != null ? baseKeyframeAnimation.getValue().floatValue() : documentData.size;
                    this.fillPaint.setTextSize(f3 * Utils.dpScale());
                    this.strokePaint.setTypeface(this.fillPaint.getTypeface());
                    this.strokePaint.setTextSize(this.fillPaint.getTextSize());
                    f2 = documentData.lineHeight * Utils.dpScale();
                    f = (float)documentData.tracking / 10.0f;
                    BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation2 = this.trackingCallbackAnimation;
                    if (baseKeyframeAnimation2 == null) break block7;
                    f4 = baseKeyframeAnimation2.getValue().floatValue();
                    break block8;
                }
                BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingAnimation;
                if (baseKeyframeAnimation == null) break block9;
                f4 = baseKeyframeAnimation.getValue().floatValue();
            }
            f += f4;
        }
        float f5 = f3 * (f * Utils.dpScale()) / 100.0f;
        List<String> list = this.getTextLines(string2);
        int n = list.size();
        int n2 = 0;
        while (n2 < n) {
            String string3 = (String)list.get(n2);
            float f6 = this.strokePaint.measureText(string3) + f5 * (float)(-1 + string3.length());
            canvas.save();
            this.applyJustification(documentData.justification, canvas, f6);
            float f7 = f2 * (float)(n - 1) / 2.0f;
            canvas.translate(0.0f, f2 * (float)n2 - f7);
            this.drawFontTextLine(string3, documentData, canvas, f5);
            canvas.restore();
            ++n2;
        }
        return;
    }

    private List<ContentGroup> getContentsForCharacter(FontCharacter fontCharacter) {
        if (this.contentsForCharacter.containsKey((Object)fontCharacter)) {
            return (List)this.contentsForCharacter.get((Object)fontCharacter);
        }
        List<ShapeGroup> list = fontCharacter.getShapes();
        int n = list.size();
        ArrayList arrayList = new ArrayList(n);
        for (int i = 0; i < n; ++i) {
            ShapeGroup shapeGroup = (ShapeGroup)list.get(i);
            arrayList.add((Object)new ContentGroup(this.lottieDrawable, this, shapeGroup));
        }
        this.contentsForCharacter.put((Object)fontCharacter, (Object)arrayList);
        return arrayList;
    }

    private float getTextLineWidthForGlyphs(String string2, Font font2, float f, float f2) {
        float f3 = 0.0f;
        for (int i = 0; i < string2.length(); ++i) {
            int n = FontCharacter.hashFor(string2.charAt(i), font2.getFamily(), font2.getStyle());
            FontCharacter fontCharacter = (FontCharacter)this.composition.getCharacters().get(n);
            if (fontCharacter == null) continue;
            f3 = (float)((double)f3 + fontCharacter.getWidth() * (double)f * (double)Utils.dpScale() * (double)f2);
        }
        return f3;
    }

    private List<String> getTextLines(String string2) {
        return Arrays.asList((Object[])string2.replaceAll("\r\n", "\r").replaceAll("\n", "\r").split("\r"));
    }

    private Typeface getTypeface(Font font2) {
        Typeface typeface;
        BaseKeyframeAnimation<Typeface, Typeface> baseKeyframeAnimation = this.typefaceCallbackAnimation;
        if (baseKeyframeAnimation != null && (typeface = baseKeyframeAnimation.getValue()) != null) {
            return typeface;
        }
        Typeface typeface2 = this.lottieDrawable.getTypeface(font2.getFamily(), font2.getStyle());
        if (typeface2 != null) {
            return typeface2;
        }
        return font2.getTypeface();
    }

    private boolean isModifier(int n) {
        return Character.getType((int)n) == 16 || Character.getType((int)n) == 27 || Character.getType((int)n) == 6 || Character.getType((int)n) == 28 || Character.getType((int)n) == 8 || Character.getType((int)n) == 19;
        {
        }
    }

    @Override
    public <T> void addValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        super.addValueCallback(t, lottieValueCallback);
        if (t == LottieProperty.COLOR) {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.colorCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.colorCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Integer, T> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Integer, T>(lottieValueCallback);
            this.colorCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.colorCallbackAnimation);
            return;
        }
        if (t == LottieProperty.STROKE_COLOR) {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.strokeColorCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.strokeColorCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Integer, T> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Integer, T>(lottieValueCallback);
            this.strokeColorCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.strokeColorCallbackAnimation);
            return;
        }
        if (t == LottieProperty.STROKE_WIDTH) {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.strokeWidthCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.strokeWidthCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Float, T> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Float, T>(lottieValueCallback);
            this.strokeWidthCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.strokeWidthCallbackAnimation);
            return;
        }
        if (t == LottieProperty.TEXT_TRACKING) {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.trackingCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.trackingCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Float, T> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Float, T>(lottieValueCallback);
            this.trackingCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.trackingCallbackAnimation);
            return;
        }
        if (t == LottieProperty.TEXT_SIZE) {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.textSizeCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.textSizeCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Float, String> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Float, String>(lottieValueCallback);
            this.textSizeCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.textSizeCallbackAnimation);
            return;
        }
        if (t == LottieProperty.TYPEFACE) {
            BaseKeyframeAnimation<Typeface, Typeface> baseKeyframeAnimation = this.typefaceCallbackAnimation;
            if (baseKeyframeAnimation != null) {
                this.removeAnimation(baseKeyframeAnimation);
            }
            if (lottieValueCallback == null) {
                this.typefaceCallbackAnimation = null;
                return;
            }
            ValueCallbackKeyframeAnimation<Typeface, String> valueCallbackKeyframeAnimation = new ValueCallbackKeyframeAnimation<Typeface, String>(lottieValueCallback);
            this.typefaceCallbackAnimation = valueCallbackKeyframeAnimation;
            valueCallbackKeyframeAnimation.addUpdateListener(this);
            this.addAnimation(this.typefaceCallbackAnimation);
            return;
        }
        if (t == LottieProperty.TEXT) {
            this.textAnimation.setStringValueCallback(lottieValueCallback);
        }
    }

    @Override
    void drawLayer(Canvas canvas, Matrix matrix, int n) {
        canvas.save();
        if (!this.lottieDrawable.useTextGlyphs()) {
            canvas.concat(matrix);
        }
        DocumentData documentData = (DocumentData)this.textAnimation.getValue();
        Font font2 = (Font)this.composition.getFonts().get((Object)documentData.fontName);
        if (font2 == null) {
            canvas.restore();
            return;
        }
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.colorCallbackAnimation;
        if (baseKeyframeAnimation != null) {
            this.fillPaint.setColor(baseKeyframeAnimation.getValue().intValue());
        } else {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation2 = this.colorAnimation;
            if (baseKeyframeAnimation2 != null) {
                this.fillPaint.setColor(baseKeyframeAnimation2.getValue().intValue());
            } else {
                this.fillPaint.setColor(documentData.color);
            }
        }
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation3 = this.strokeColorCallbackAnimation;
        if (baseKeyframeAnimation3 != null) {
            this.strokePaint.setColor(baseKeyframeAnimation3.getValue().intValue());
        } else {
            BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation4 = this.strokeColorAnimation;
            if (baseKeyframeAnimation4 != null) {
                this.strokePaint.setColor(baseKeyframeAnimation4.getValue().intValue());
            } else {
                this.strokePaint.setColor(documentData.strokeColor);
            }
        }
        int n2 = this.transform.getOpacity() == null ? 100 : this.transform.getOpacity().getValue();
        int n3 = n2 * 255 / 100;
        this.fillPaint.setAlpha(n3);
        this.strokePaint.setAlpha(n3);
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation5 = this.strokeWidthCallbackAnimation;
        if (baseKeyframeAnimation5 != null) {
            this.strokePaint.setStrokeWidth(baseKeyframeAnimation5.getValue().floatValue());
        } else {
            BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation6 = this.strokeWidthAnimation;
            if (baseKeyframeAnimation6 != null) {
                this.strokePaint.setStrokeWidth(baseKeyframeAnimation6.getValue().floatValue());
            } else {
                float f = Utils.getScale(matrix);
                this.strokePaint.setStrokeWidth(f * (documentData.strokeWidth * Utils.dpScale()));
            }
        }
        if (this.lottieDrawable.useTextGlyphs()) {
            this.drawTextGlyphs(documentData, matrix, font2, canvas);
        } else {
            this.drawTextWithFont(documentData, font2, canvas);
        }
        canvas.restore();
    }

    @Override
    public void getBounds(RectF rectF, Matrix matrix, boolean bl) {
        super.getBounds(rectF, matrix, bl);
        rectF.set(0.0f, 0.0f, (float)this.composition.getBounds().width(), (float)this.composition.getBounds().height());
    }

}

