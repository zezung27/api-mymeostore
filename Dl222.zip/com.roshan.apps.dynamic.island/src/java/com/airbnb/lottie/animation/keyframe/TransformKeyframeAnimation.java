/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.PointF
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.graphics.Matrix;
import android.graphics.PointF;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.FloatKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.SplitDimensionPathKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.ValueCallbackKeyframeAnimation;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.animatable.AnimatablePathValue;
import com.airbnb.lottie.model.animatable.AnimatableScaleValue;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.ScaleXY;
import java.util.Collections;
import java.util.List;

public class TransformKeyframeAnimation {
    private BaseKeyframeAnimation<PointF, PointF> anchorPoint;
    private BaseKeyframeAnimation<?, Float> endOpacity;
    private final Matrix matrix = new Matrix();
    private BaseKeyframeAnimation<Integer, Integer> opacity;
    private BaseKeyframeAnimation<?, PointF> position;
    private BaseKeyframeAnimation<Float, Float> rotation;
    private BaseKeyframeAnimation<ScaleXY, ScaleXY> scale;
    private FloatKeyframeAnimation skew;
    private FloatKeyframeAnimation skewAngle;
    private final Matrix skewMatrix1;
    private final Matrix skewMatrix2;
    private final Matrix skewMatrix3;
    private final float[] skewValues;
    private BaseKeyframeAnimation<?, Float> startOpacity;

    public TransformKeyframeAnimation(AnimatableTransform animatableTransform) {
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation = animatableTransform.getAnchorPoint() == null ? null : animatableTransform.getAnchorPoint().createAnimation();
        this.anchorPoint = baseKeyframeAnimation;
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation2 = animatableTransform.getPosition() == null ? null : animatableTransform.getPosition().createAnimation();
        this.position = baseKeyframeAnimation2;
        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation3 = animatableTransform.getScale() == null ? null : animatableTransform.getScale().createAnimation();
        this.scale = baseKeyframeAnimation3;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation4 = animatableTransform.getRotation() == null ? null : animatableTransform.getRotation().createAnimation();
        this.rotation = baseKeyframeAnimation4;
        FloatKeyframeAnimation floatKeyframeAnimation = animatableTransform.getSkew() == null ? null : (FloatKeyframeAnimation)animatableTransform.getSkew().createAnimation();
        this.skew = floatKeyframeAnimation;
        if (floatKeyframeAnimation != null) {
            this.skewMatrix1 = new Matrix();
            this.skewMatrix2 = new Matrix();
            this.skewMatrix3 = new Matrix();
            this.skewValues = new float[9];
        } else {
            this.skewMatrix1 = null;
            this.skewMatrix2 = null;
            this.skewMatrix3 = null;
            this.skewValues = null;
        }
        FloatKeyframeAnimation floatKeyframeAnimation2 = animatableTransform.getSkewAngle() == null ? null : (FloatKeyframeAnimation)animatableTransform.getSkewAngle().createAnimation();
        this.skewAngle = floatKeyframeAnimation2;
        if (animatableTransform.getOpacity() != null) {
            this.opacity = animatableTransform.getOpacity().createAnimation();
        }
        this.startOpacity = animatableTransform.getStartOpacity() != null ? animatableTransform.getStartOpacity().createAnimation() : null;
        if (animatableTransform.getEndOpacity() != null) {
            this.endOpacity = animatableTransform.getEndOpacity().createAnimation();
            return;
        }
        this.endOpacity = null;
    }

    private void clearSkewValues() {
        for (int i = 0; i < 9; ++i) {
            this.skewValues[i] = 0.0f;
        }
    }

    public void addAnimationsToLayer(BaseLayer baseLayer) {
        baseLayer.addAnimation(this.opacity);
        baseLayer.addAnimation(this.startOpacity);
        baseLayer.addAnimation(this.endOpacity);
        baseLayer.addAnimation(this.anchorPoint);
        baseLayer.addAnimation(this.position);
        baseLayer.addAnimation(this.scale);
        baseLayer.addAnimation(this.rotation);
        baseLayer.addAnimation(this.skew);
        baseLayer.addAnimation(this.skewAngle);
    }

    public void addListener(BaseKeyframeAnimation.AnimationListener animationListener) {
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation;
        FloatKeyframeAnimation floatKeyframeAnimation;
        BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation2;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation3;
        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation4;
        FloatKeyframeAnimation floatKeyframeAnimation2;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation5;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation6;
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation7 = this.opacity;
        if (baseKeyframeAnimation7 != null) {
            baseKeyframeAnimation7.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation6 = this.startOpacity) != null) {
            baseKeyframeAnimation6.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation3 = this.endOpacity) != null) {
            baseKeyframeAnimation3.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation = this.anchorPoint) != null) {
            baseKeyframeAnimation.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation2 = this.position) != null) {
            baseKeyframeAnimation2.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation4 = this.scale) != null) {
            baseKeyframeAnimation4.addUpdateListener(animationListener);
        }
        if ((baseKeyframeAnimation5 = this.rotation) != null) {
            baseKeyframeAnimation5.addUpdateListener(animationListener);
        }
        if ((floatKeyframeAnimation2 = this.skew) != null) {
            floatKeyframeAnimation2.addUpdateListener(animationListener);
        }
        if ((floatKeyframeAnimation = this.skewAngle) != null) {
            floatKeyframeAnimation.addUpdateListener(animationListener);
        }
    }

    public <T> boolean applyValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        block30 : {
            block20 : {
                block29 : {
                    block28 : {
                        block27 : {
                            block26 : {
                                block25 : {
                                    block24 : {
                                        block23 : {
                                            BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation;
                                            block22 : {
                                                BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation2;
                                                block21 : {
                                                    block19 : {
                                                        if (t != LottieProperty.TRANSFORM_ANCHOR_POINT) break block19;
                                                        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation3 = this.anchorPoint;
                                                        if (baseKeyframeAnimation3 == null) {
                                                            this.anchorPoint = new ValueCallbackKeyframeAnimation<PointF, PointF>(lottieValueCallback, new PointF());
                                                        } else {
                                                            baseKeyframeAnimation3.setValueCallback(lottieValueCallback);
                                                        }
                                                        break block20;
                                                    }
                                                    if (t != LottieProperty.TRANSFORM_POSITION) break block21;
                                                    BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation4 = this.position;
                                                    if (baseKeyframeAnimation4 == null) {
                                                        this.position = new ValueCallbackKeyframeAnimation(lottieValueCallback, new PointF());
                                                    } else {
                                                        baseKeyframeAnimation4.setValueCallback(lottieValueCallback);
                                                    }
                                                    break block20;
                                                }
                                                if (t != LottieProperty.TRANSFORM_POSITION_X || !((baseKeyframeAnimation2 = this.position) instanceof SplitDimensionPathKeyframeAnimation)) break block22;
                                                ((SplitDimensionPathKeyframeAnimation)baseKeyframeAnimation2).setXValueCallback(lottieValueCallback);
                                                break block20;
                                            }
                                            if (t != LottieProperty.TRANSFORM_POSITION_Y || !((baseKeyframeAnimation = this.position) instanceof SplitDimensionPathKeyframeAnimation)) break block23;
                                            ((SplitDimensionPathKeyframeAnimation)baseKeyframeAnimation).setYValueCallback(lottieValueCallback);
                                            break block20;
                                        }
                                        if (t != LottieProperty.TRANSFORM_SCALE) break block24;
                                        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation = this.scale;
                                        if (baseKeyframeAnimation == null) {
                                            this.scale = new ValueCallbackKeyframeAnimation<ScaleXY, ScaleXY>(lottieValueCallback, new ScaleXY());
                                        } else {
                                            baseKeyframeAnimation.setValueCallback(lottieValueCallback);
                                        }
                                        break block20;
                                    }
                                    if (t != LottieProperty.TRANSFORM_ROTATION) break block25;
                                    BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = this.rotation;
                                    if (baseKeyframeAnimation == null) {
                                        this.rotation = new ValueCallbackKeyframeAnimation<Float, Float>(lottieValueCallback, Float.valueOf((float)0.0f));
                                    } else {
                                        baseKeyframeAnimation.setValueCallback(lottieValueCallback);
                                    }
                                    break block20;
                                }
                                if (t != LottieProperty.TRANSFORM_OPACITY) break block26;
                                BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation = this.opacity;
                                if (baseKeyframeAnimation == null) {
                                    this.opacity = new ValueCallbackKeyframeAnimation<Integer, Integer>(lottieValueCallback, 100);
                                } else {
                                    baseKeyframeAnimation.setValueCallback(lottieValueCallback);
                                }
                                break block20;
                            }
                            if (t != LottieProperty.TRANSFORM_START_OPACITY) break block27;
                            BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.startOpacity;
                            if (baseKeyframeAnimation == null) {
                                this.startOpacity = new ValueCallbackKeyframeAnimation(lottieValueCallback, Float.valueOf((float)100.0f));
                            } else {
                                baseKeyframeAnimation.setValueCallback(lottieValueCallback);
                            }
                            break block20;
                        }
                        if (t != LottieProperty.TRANSFORM_END_OPACITY) break block28;
                        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.endOpacity;
                        if (baseKeyframeAnimation == null) {
                            this.endOpacity = new ValueCallbackKeyframeAnimation(lottieValueCallback, Float.valueOf((float)100.0f));
                        } else {
                            baseKeyframeAnimation.setValueCallback(lottieValueCallback);
                        }
                        break block20;
                    }
                    if (t != LottieProperty.TRANSFORM_SKEW) break block29;
                    if (this.skew == null) {
                        this.skew = new FloatKeyframeAnimation((List<Keyframe<Float>>)Collections.singletonList(new Keyframe<Float>(Float.valueOf((float)0.0f))));
                    }
                    this.skew.setValueCallback(lottieValueCallback);
                    break block20;
                }
                if (t != LottieProperty.TRANSFORM_SKEW_ANGLE) break block30;
                if (this.skewAngle == null) {
                    this.skewAngle = new FloatKeyframeAnimation((List<Keyframe<Float>>)Collections.singletonList(new Keyframe<Float>(Float.valueOf((float)0.0f))));
                }
                this.skewAngle.setValueCallback(lottieValueCallback);
            }
            return true;
        }
        return false;
    }

    public BaseKeyframeAnimation<?, Float> getEndOpacity() {
        return this.endOpacity;
    }

    public Matrix getMatrix() {
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation;
        FloatKeyframeAnimation floatKeyframeAnimation;
        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation2;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation3;
        ScaleXY scaleXY;
        PointF pointF;
        float f;
        this.matrix.reset();
        BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation4 = this.position;
        if (baseKeyframeAnimation4 != null && (pointF = baseKeyframeAnimation4.getValue()) != null && (pointF.x != 0.0f || pointF.y != 0.0f)) {
            this.matrix.preTranslate(pointF.x, pointF.y);
        }
        if ((baseKeyframeAnimation3 = this.rotation) != null && (f = baseKeyframeAnimation3 instanceof ValueCallbackKeyframeAnimation ? baseKeyframeAnimation3.getValue().floatValue() : ((FloatKeyframeAnimation)baseKeyframeAnimation3).getFloatValue()) != 0.0f) {
            this.matrix.preRotate(f);
        }
        if ((floatKeyframeAnimation = this.skew) != null) {
            float f2;
            FloatKeyframeAnimation floatKeyframeAnimation2 = this.skewAngle;
            float f3 = floatKeyframeAnimation2 == null ? 0.0f : (float)Math.cos((double)Math.toRadians((double)(90.0f + -floatKeyframeAnimation2.getFloatValue())));
            FloatKeyframeAnimation floatKeyframeAnimation3 = this.skewAngle;
            float f4 = floatKeyframeAnimation3 == null ? 1.0f : (float)Math.sin((double)Math.toRadians((double)(90.0f + -floatKeyframeAnimation3.getFloatValue())));
            float f5 = (float)Math.tan((double)Math.toRadians((double)floatKeyframeAnimation.getFloatValue()));
            this.clearSkewValues();
            float[] arrf = this.skewValues;
            arrf[0] = f3;
            arrf[1] = f4;
            arrf[3] = f2 = -f4;
            arrf[4] = f3;
            arrf[8] = 1.0f;
            this.skewMatrix1.setValues(arrf);
            this.clearSkewValues();
            float[] arrf2 = this.skewValues;
            arrf2[0] = 1.0f;
            arrf2[3] = f5;
            arrf2[4] = 1.0f;
            arrf2[8] = 1.0f;
            this.skewMatrix2.setValues(arrf2);
            this.clearSkewValues();
            float[] arrf3 = this.skewValues;
            arrf3[0] = f3;
            arrf3[1] = f2;
            arrf3[3] = f4;
            arrf3[4] = f3;
            arrf3[8] = 1.0f;
            this.skewMatrix3.setValues(arrf3);
            this.skewMatrix2.preConcat(this.skewMatrix1);
            this.skewMatrix3.preConcat(this.skewMatrix2);
            this.matrix.preConcat(this.skewMatrix3);
        }
        if ((baseKeyframeAnimation2 = this.scale) != null && ((scaleXY = baseKeyframeAnimation2.getValue()).getScaleX() != 1.0f || scaleXY.getScaleY() != 1.0f)) {
            this.matrix.preScale(scaleXY.getScaleX(), scaleXY.getScaleY());
        }
        if ((baseKeyframeAnimation = this.anchorPoint) != null) {
            PointF pointF2 = baseKeyframeAnimation.getValue();
            if (pointF2.x != 0.0f || pointF2.y != 0.0f) {
                this.matrix.preTranslate(-pointF2.x, -pointF2.y);
            }
        }
        return this.matrix;
    }

    public Matrix getMatrixForRepeater(float f) {
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation;
        BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation2 = this.position;
        PointF pointF = baseKeyframeAnimation2 == null ? null : baseKeyframeAnimation2.getValue();
        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation3 = this.scale;
        ScaleXY scaleXY = baseKeyframeAnimation3 == null ? null : baseKeyframeAnimation3.getValue();
        this.matrix.reset();
        if (pointF != null) {
            this.matrix.preTranslate(f * pointF.x, f * pointF.y);
        }
        if (scaleXY != null) {
            Matrix matrix = this.matrix;
            double d = scaleXY.getScaleX();
            double d2 = f;
            matrix.preScale((float)Math.pow((double)d, (double)d2), (float)Math.pow((double)scaleXY.getScaleY(), (double)d2));
        }
        if ((baseKeyframeAnimation = this.rotation) != null) {
            float f2 = baseKeyframeAnimation.getValue().floatValue();
            BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation4 = this.anchorPoint;
            PointF pointF2 = baseKeyframeAnimation4 == null ? null : baseKeyframeAnimation4.getValue();
            Matrix matrix = this.matrix;
            float f3 = f2 * f;
            float f4 = pointF2 == null ? 0.0f : pointF2.x;
            float f5 = pointF2 == null ? 0.0f : pointF2.y;
            matrix.preRotate(f3, f4, f5);
        }
        return this.matrix;
    }

    public BaseKeyframeAnimation<?, Integer> getOpacity() {
        return this.opacity;
    }

    public BaseKeyframeAnimation<?, Float> getStartOpacity() {
        return this.startOpacity;
    }

    public void setProgress(float f) {
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation;
        FloatKeyframeAnimation floatKeyframeAnimation;
        BaseKeyframeAnimation<?, PointF> baseKeyframeAnimation2;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation3;
        BaseKeyframeAnimation<ScaleXY, ScaleXY> baseKeyframeAnimation4;
        FloatKeyframeAnimation floatKeyframeAnimation2;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation5;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation6;
        BaseKeyframeAnimation<Integer, Integer> baseKeyframeAnimation7 = this.opacity;
        if (baseKeyframeAnimation7 != null) {
            baseKeyframeAnimation7.setProgress(f);
        }
        if ((baseKeyframeAnimation6 = this.startOpacity) != null) {
            baseKeyframeAnimation6.setProgress(f);
        }
        if ((baseKeyframeAnimation3 = this.endOpacity) != null) {
            baseKeyframeAnimation3.setProgress(f);
        }
        if ((baseKeyframeAnimation = this.anchorPoint) != null) {
            baseKeyframeAnimation.setProgress(f);
        }
        if ((baseKeyframeAnimation2 = this.position) != null) {
            baseKeyframeAnimation2.setProgress(f);
        }
        if ((baseKeyframeAnimation4 = this.scale) != null) {
            baseKeyframeAnimation4.setProgress(f);
        }
        if ((baseKeyframeAnimation5 = this.rotation) != null) {
            baseKeyframeAnimation5.setProgress(f);
        }
        if ((floatKeyframeAnimation2 = this.skew) != null) {
            floatKeyframeAnimation2.setProgress(f);
        }
        if ((floatKeyframeAnimation = this.skewAngle) != null) {
            floatKeyframeAnimation.setProgress(f);
        }
    }
}

