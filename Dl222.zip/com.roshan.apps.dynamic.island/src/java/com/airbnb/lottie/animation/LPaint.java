/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.Xfermode
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.LocaleList
 */
package com.airbnb.lottie.animation;

import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Xfermode;
import android.os.Build;
import android.os.LocaleList;
import com.airbnb.lottie.utils.MiscUtils;

public class LPaint
extends Paint {
    public LPaint() {
    }

    public LPaint(int n) {
        super(n);
    }

    public LPaint(int n, PorterDuff.Mode mode) {
        super(n);
        this.setXfermode((Xfermode)new PorterDuffXfermode(mode));
    }

    public LPaint(PorterDuff.Mode mode) {
        this.setXfermode((Xfermode)new PorterDuffXfermode(mode));
    }

    public void setAlpha(int n) {
        if (Build.VERSION.SDK_INT < 30) {
            int n2 = this.getColor();
            this.setColor(MiscUtils.clamp(n, 0, 255) << 24 | n2 & 16777215);
            return;
        }
        super.setAlpha(MiscUtils.clamp(n, 0, 255));
    }

    public void setTextLocales(LocaleList localeList) {
    }
}

