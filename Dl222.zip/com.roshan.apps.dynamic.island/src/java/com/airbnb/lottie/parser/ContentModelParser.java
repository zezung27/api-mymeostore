/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableTransform;
import com.airbnb.lottie.model.content.CircleShape;
import com.airbnb.lottie.model.content.ContentModel;
import com.airbnb.lottie.model.content.GradientFill;
import com.airbnb.lottie.model.content.GradientStroke;
import com.airbnb.lottie.model.content.MergePaths;
import com.airbnb.lottie.model.content.PolystarShape;
import com.airbnb.lottie.model.content.RectangleShape;
import com.airbnb.lottie.model.content.Repeater;
import com.airbnb.lottie.model.content.RoundedCorners;
import com.airbnb.lottie.model.content.ShapeFill;
import com.airbnb.lottie.model.content.ShapeGroup;
import com.airbnb.lottie.model.content.ShapePath;
import com.airbnb.lottie.model.content.ShapeStroke;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.parser.AnimatableTransformParser;
import com.airbnb.lottie.parser.CircleShapeParser;
import com.airbnb.lottie.parser.GradientFillParser;
import com.airbnb.lottie.parser.GradientStrokeParser;
import com.airbnb.lottie.parser.MergePathsParser;
import com.airbnb.lottie.parser.PolystarShapeParser;
import com.airbnb.lottie.parser.RectangleShapeParser;
import com.airbnb.lottie.parser.RepeaterParser;
import com.airbnb.lottie.parser.RoundedCornersParser;
import com.airbnb.lottie.parser.ShapeFillParser;
import com.airbnb.lottie.parser.ShapeGroupParser;
import com.airbnb.lottie.parser.ShapePathParser;
import com.airbnb.lottie.parser.ShapeStrokeParser;
import com.airbnb.lottie.parser.ShapeTrimPathParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.Logger;
import java.io.IOException;

class ContentModelParser {
    private static final JsonReader.Options NAMES = JsonReader.Options.of("ty", "d");

    private ContentModelParser() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static ContentModel parse(JsonReader var0, LottieComposition var1_1) throws IOException {
        block40 : {
            block41 : {
                block39 : {
                    var0.beginObject();
                    var3_3 = var2_2 = 2;
                    while (var0.hasNext() != false) {
                        var7_4 = var0.selectName(ContentModelParser.NAMES);
                        if (var7_4 != 0) {
                            if (var7_4 != 1) {
                                var0.skipName();
                                var0.skipValue();
                                continue;
                            }
                            var3_3 = var0.nextInt();
                            continue;
                        }
                        break block39;
                    }
                    return null;
                }
                var4_5 = var0.nextString();
                if (var4_5 == null) {
                    return null;
                }
                var4_5.hashCode();
                switch (var4_5.hashCode()) {
                    case 3710: {
                        if (!var4_5.equals((Object)"tr")) break;
                        var2_2 = 13;
                        ** break;
                    }
                    case 3705: {
                        if (!var4_5.equals((Object)"tm")) break;
                        var2_2 = 12;
                        ** break;
                    }
                    case 3681: {
                        if (!var4_5.equals((Object)"st")) break;
                        var2_2 = 11;
                        ** break;
                    }
                    case 3679: {
                        if (!var4_5.equals((Object)"sr")) break;
                        var2_2 = 10;
                        ** break;
                    }
                    case 3669: {
                        if (!var4_5.equals((Object)"sh")) break;
                        var2_2 = 9;
                        ** break;
                    }
                    case 3646: {
                        if (!var4_5.equals((Object)"rp")) break;
                        var2_2 = 8;
                        ** break;
                    }
                    case 3634: {
                        if (!var4_5.equals((Object)"rd")) break;
                        var2_2 = 7;
                        ** break;
                    }
                    case 3633: {
                        if (!var4_5.equals((Object)"rc")) break;
                        var2_2 = 6;
                        ** break;
                    }
                    case 3488: {
                        if (!var4_5.equals((Object)"mm")) break;
                        var2_2 = 5;
                        ** break;
                    }
                    case 3308: {
                        if (!var4_5.equals((Object)"gs")) break;
                        var2_2 = 4;
                        ** break;
                    }
                    case 3307: {
                        if (!var4_5.equals((Object)"gr")) break;
                        var2_2 = 3;
                        ** break;
                    }
                    case 3295: {
                        if (!var4_5.equals((Object)"gf")) {
                            break;
                        }
                        break block40;
                    }
                    case 3270: {
                        if (!var4_5.equals((Object)"fl")) break;
                        var2_2 = 1;
                        ** break;
                    }
                    case 3239: {
                        if (var4_5.equals((Object)"el")) break block41;
                    }
                }
                var2_2 = -1;
                ** break;
            }
            var2_2 = 0;
        }
        switch (var2_2) {
            default: {
                Logger.warning("Unknown shape type " + var4_5);
                var6_6 = null;
                ** break;
            }
            case 13: {
                var6_7 = AnimatableTransformParser.parse(var0, var1_1);
                ** break;
            }
            case 12: {
                var6_8 = ShapeTrimPathParser.parse(var0, var1_1);
                ** break;
            }
            case 11: {
                var6_9 = ShapeStrokeParser.parse(var0, var1_1);
                ** break;
            }
            case 10: {
                var6_10 = PolystarShapeParser.parse(var0, var1_1, var3_3);
                ** break;
            }
            case 9: {
                var6_11 = ShapePathParser.parse(var0, var1_1);
                ** break;
            }
            case 8: {
                var6_12 = RepeaterParser.parse(var0, var1_1);
                ** break;
            }
            case 7: {
                var6_13 = RoundedCornersParser.parse(var0, var1_1);
                ** break;
            }
            case 6: {
                var6_14 = RectangleShapeParser.parse(var0, var1_1);
                ** break;
            }
            case 5: {
                var6_15 = MergePathsParser.parse(var0);
                var1_1.addWarning("Animation contains merge paths. Merge paths are only supported on KitKat+ and must be manually enabled by calling enableMergePathsForKitKatAndAbove().");
                ** break;
            }
            case 4: {
                var6_16 = GradientStrokeParser.parse(var0, var1_1);
                ** break;
            }
            case 3: {
                var6_17 = ShapeGroupParser.parse(var0, var1_1);
                ** break;
            }
            case 2: {
                var6_18 = GradientFillParser.parse(var0, var1_1);
                ** break;
            }
            case 1: {
                var6_19 = ShapeFillParser.parse(var0, var1_1);
                ** break;
            }
            case 0: 
        }
        var6_20 = CircleShapeParser.parse(var0, var1_1, var3_3);
lbl126: // 15 sources:
        do {
            if (!var0.hasNext()) {
                var0.endObject();
                return var6_21;
            }
            var0.skipValue();
        } while (true);
    }
}

