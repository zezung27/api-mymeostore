/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 *  java.io.IOException
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.network;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

public interface LottieFetchResult
extends Closeable {
    public InputStream bodyByteStream() throws IOException;

    public String contentType();

    public String error();

    public boolean isSuccessful();
}

