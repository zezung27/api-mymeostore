/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.Animator$AnimatorPauseListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.graphics.drawable.Animatable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.widget.ImageView
 *  androidx.collection.SparseArrayCompat
 *  java.lang.Boolean
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.annotation.Annotation
 *  java.lang.annotation.Retention
 *  java.lang.annotation.RetentionPolicy
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 */
package com.airbnb.lottie;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.FontAssetDelegate;
import com.airbnb.lottie.ImageAssetDelegate;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda0;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda1;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda10;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda11;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda12;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda13;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda14;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda2;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda3;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda4;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda5;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda6;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda7;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda8;
import com.airbnb.lottie.LottieDrawable$$ExternalSyntheticLambda9;
import com.airbnb.lottie.LottieImageAsset;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.PerformanceTracker;
import com.airbnb.lottie.RenderMode;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.animation.LPaint;
import com.airbnb.lottie.manager.FontAssetManager;
import com.airbnb.lottie.manager.ImageAssetManager;
import com.airbnb.lottie.model.FontCharacter;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.KeyPathElement;
import com.airbnb.lottie.model.Marker;
import com.airbnb.lottie.model.layer.CompositionLayer;
import com.airbnb.lottie.model.layer.Layer;
import com.airbnb.lottie.parser.LayerParser;
import com.airbnb.lottie.utils.Logger;
import com.airbnb.lottie.utils.LottieValueAnimator;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class LottieDrawable
extends Drawable
implements Drawable.Callback,
Animatable {
    public static final int INFINITE = -1;
    public static final int RESTART = 1;
    public static final int REVERSE = 2;
    private int alpha;
    private final LottieValueAnimator animator;
    private Rect canvasClipBounds;
    private RectF canvasClipBoundsRectF;
    private boolean clipToCompositionBounds;
    private LottieComposition composition;
    private CompositionLayer compositionLayer;
    private boolean enableMergePaths;
    FontAssetDelegate fontAssetDelegate;
    private FontAssetManager fontAssetManager;
    private boolean ignoreSystemAnimationsDisabled;
    private ImageAssetDelegate imageAssetDelegate;
    private ImageAssetManager imageAssetManager;
    private String imageAssetsFolder;
    private boolean isApplyingOpacityToLayersEnabled;
    private boolean isDirty;
    private final ArrayList<LazyCompositionTask> lazyCompositionTasks;
    private boolean maintainOriginalImageBounds;
    private OnVisibleAction onVisibleAction;
    private boolean outlineMasksAndMattes;
    private boolean performanceTrackingEnabled;
    private final ValueAnimator.AnimatorUpdateListener progressUpdateListener;
    private RenderMode renderMode;
    private final Matrix renderingMatrix;
    private boolean safeMode;
    private Bitmap softwareRenderingBitmap;
    private Canvas softwareRenderingCanvas;
    private Rect softwareRenderingDstBoundsRect;
    private RectF softwareRenderingDstBoundsRectF;
    private Matrix softwareRenderingOriginalCanvasMatrix;
    private Matrix softwareRenderingOriginalCanvasMatrixInverse;
    private Paint softwareRenderingPaint;
    private Rect softwareRenderingSrcBoundsRect;
    private RectF softwareRenderingTransformedBounds;
    private boolean systemAnimationsEnabled;
    TextDelegate textDelegate;
    private boolean useSoftwareRendering;

    public LottieDrawable() {
        ValueAnimator.AnimatorUpdateListener animatorUpdateListener;
        LottieValueAnimator lottieValueAnimator;
        this.animator = lottieValueAnimator = new LottieValueAnimator();
        this.systemAnimationsEnabled = true;
        this.ignoreSystemAnimationsDisabled = false;
        this.safeMode = false;
        this.onVisibleAction = OnVisibleAction.NONE;
        this.lazyCompositionTasks = new ArrayList();
        this.progressUpdateListener = animatorUpdateListener = new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                if (LottieDrawable.this.compositionLayer != null) {
                    LottieDrawable.this.compositionLayer.setProgress(LottieDrawable.this.animator.getAnimatedValueAbsolute());
                }
            }
        };
        this.maintainOriginalImageBounds = false;
        this.clipToCompositionBounds = true;
        this.alpha = 255;
        this.renderMode = RenderMode.AUTOMATIC;
        this.useSoftwareRendering = false;
        this.renderingMatrix = new Matrix();
        this.isDirty = false;
        lottieValueAnimator.addUpdateListener(animatorUpdateListener);
    }

    private boolean animationsEnabled() {
        return this.systemAnimationsEnabled || this.ignoreSystemAnimationsDisabled;
        {
        }
    }

    private void buildCompositionLayer() {
        CompositionLayer compositionLayer;
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return;
        }
        this.compositionLayer = compositionLayer = new CompositionLayer(this, LayerParser.parse(lottieComposition), lottieComposition.getLayers(), lottieComposition);
        if (this.outlineMasksAndMattes) {
            compositionLayer.setOutlineMasksAndMattes(true);
        }
        this.compositionLayer.setClipToCompositionBounds(this.clipToCompositionBounds);
    }

    private void computeRenderMode() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return;
        }
        this.useSoftwareRendering = this.renderMode.useSoftwareRendering(Build.VERSION.SDK_INT, lottieComposition.hasDashPattern(), lottieComposition.getMaskAndMatteCount());
    }

    private void convertRect(Rect rect, RectF rectF) {
        rectF.set((float)rect.left, (float)rect.top, (float)rect.right, (float)rect.bottom);
    }

    private void convertRect(RectF rectF, Rect rect) {
        rect.set((int)Math.floor((double)rectF.left), (int)Math.floor((double)rectF.top), (int)Math.ceil((double)rectF.right), (int)Math.ceil((double)rectF.bottom));
    }

    private void drawDirectlyToCanvas(Canvas canvas) {
        CompositionLayer compositionLayer = this.compositionLayer;
        LottieComposition lottieComposition = this.composition;
        if (compositionLayer != null) {
            if (lottieComposition == null) {
                return;
            }
            this.renderingMatrix.reset();
            Rect rect = this.getBounds();
            if (!rect.isEmpty()) {
                float f = (float)rect.width() / (float)lottieComposition.getBounds().width();
                float f2 = (float)rect.height() / (float)lottieComposition.getBounds().height();
                this.renderingMatrix.preScale(f, f2);
            }
            compositionLayer.draw(canvas, this.renderingMatrix, this.alpha);
        }
    }

    private void ensureSoftwareRenderingBitmap(int n, int n2) {
        Bitmap bitmap = this.softwareRenderingBitmap;
        if (bitmap != null && bitmap.getWidth() >= n && this.softwareRenderingBitmap.getHeight() >= n2) {
            if (this.softwareRenderingBitmap.getWidth() > n || this.softwareRenderingBitmap.getHeight() > n2) {
                Bitmap bitmap2;
                this.softwareRenderingBitmap = bitmap2 = Bitmap.createBitmap((Bitmap)this.softwareRenderingBitmap, (int)0, (int)0, (int)n, (int)n2);
                this.softwareRenderingCanvas.setBitmap(bitmap2);
                this.isDirty = true;
                return;
            }
        } else {
            Bitmap bitmap3;
            this.softwareRenderingBitmap = bitmap3 = Bitmap.createBitmap((int)n, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            this.softwareRenderingCanvas.setBitmap(bitmap3);
            this.isDirty = true;
        }
    }

    private void ensureSoftwareRenderingObjectsInitialized() {
        if (this.softwareRenderingCanvas != null) {
            return;
        }
        this.softwareRenderingCanvas = new Canvas();
        this.softwareRenderingTransformedBounds = new RectF();
        this.softwareRenderingOriginalCanvasMatrix = new Matrix();
        this.softwareRenderingOriginalCanvasMatrixInverse = new Matrix();
        this.canvasClipBounds = new Rect();
        this.canvasClipBoundsRectF = new RectF();
        this.softwareRenderingPaint = new LPaint();
        this.softwareRenderingSrcBoundsRect = new Rect();
        this.softwareRenderingDstBoundsRect = new Rect();
        this.softwareRenderingDstBoundsRectF = new RectF();
    }

    private Context getContext() {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return null;
        }
        if (callback instanceof View) {
            return ((View)callback).getContext();
        }
        return null;
    }

    private FontAssetManager getFontAssetManager() {
        if (this.getCallback() == null) {
            return null;
        }
        if (this.fontAssetManager == null) {
            this.fontAssetManager = new FontAssetManager(this.getCallback(), this.fontAssetDelegate);
        }
        return this.fontAssetManager;
    }

    private ImageAssetManager getImageAssetManager() {
        if (this.getCallback() == null) {
            return null;
        }
        ImageAssetManager imageAssetManager = this.imageAssetManager;
        if (imageAssetManager != null && !imageAssetManager.hasSameContext(this.getContext())) {
            this.imageAssetManager = null;
        }
        if (this.imageAssetManager == null) {
            this.imageAssetManager = new ImageAssetManager(this.getCallback(), this.imageAssetsFolder, this.imageAssetDelegate, this.composition.getImages());
        }
        return this.imageAssetManager;
    }

    private boolean ignoreCanvasClipBounds() {
        Drawable.Callback callback = this.getCallback();
        if (!(callback instanceof View)) {
            return false;
        }
        ViewParent viewParent = ((View)callback).getParent();
        if (Build.VERSION.SDK_INT >= 18 && viewParent instanceof ViewGroup) {
            return true ^ ((ViewGroup)viewParent).getClipChildren();
        }
        return false;
    }

    private void renderAndDrawAsBitmap(Canvas canvas, CompositionLayer compositionLayer) {
        if (this.composition != null) {
            if (compositionLayer == null) {
                return;
            }
            this.ensureSoftwareRenderingObjectsInitialized();
            canvas.getMatrix(this.softwareRenderingOriginalCanvasMatrix);
            canvas.getClipBounds(this.canvasClipBounds);
            this.convertRect(this.canvasClipBounds, this.canvasClipBoundsRectF);
            this.softwareRenderingOriginalCanvasMatrix.mapRect(this.canvasClipBoundsRectF);
            this.convertRect(this.canvasClipBoundsRectF, this.canvasClipBounds);
            if (this.clipToCompositionBounds) {
                this.softwareRenderingTransformedBounds.set(0.0f, 0.0f, (float)this.getIntrinsicWidth(), (float)this.getIntrinsicHeight());
            } else {
                compositionLayer.getBounds(this.softwareRenderingTransformedBounds, null, false);
            }
            this.softwareRenderingOriginalCanvasMatrix.mapRect(this.softwareRenderingTransformedBounds);
            Rect rect = this.getBounds();
            float f = (float)rect.width() / (float)this.getIntrinsicWidth();
            float f2 = (float)rect.height() / (float)this.getIntrinsicHeight();
            this.scaleRect(this.softwareRenderingTransformedBounds, f, f2);
            if (!this.ignoreCanvasClipBounds()) {
                this.softwareRenderingTransformedBounds.intersect((float)this.canvasClipBounds.left, (float)this.canvasClipBounds.top, (float)this.canvasClipBounds.right, (float)this.canvasClipBounds.bottom);
            }
            int n = (int)Math.ceil((double)this.softwareRenderingTransformedBounds.width());
            int n2 = (int)Math.ceil((double)this.softwareRenderingTransformedBounds.height());
            if (n != 0) {
                if (n2 == 0) {
                    return;
                }
                this.ensureSoftwareRenderingBitmap(n, n2);
                if (this.isDirty) {
                    this.renderingMatrix.set(this.softwareRenderingOriginalCanvasMatrix);
                    this.renderingMatrix.preScale(f, f2);
                    this.renderingMatrix.postTranslate(-this.softwareRenderingTransformedBounds.left, -this.softwareRenderingTransformedBounds.top);
                    this.softwareRenderingBitmap.eraseColor(0);
                    compositionLayer.draw(this.softwareRenderingCanvas, this.renderingMatrix, this.alpha);
                    this.softwareRenderingOriginalCanvasMatrix.invert(this.softwareRenderingOriginalCanvasMatrixInverse);
                    this.softwareRenderingOriginalCanvasMatrixInverse.mapRect(this.softwareRenderingDstBoundsRectF, this.softwareRenderingTransformedBounds);
                    this.convertRect(this.softwareRenderingDstBoundsRectF, this.softwareRenderingDstBoundsRect);
                }
                this.softwareRenderingSrcBoundsRect.set(0, 0, n, n2);
                canvas.drawBitmap(this.softwareRenderingBitmap, this.softwareRenderingSrcBoundsRect, this.softwareRenderingDstBoundsRect, this.softwareRenderingPaint);
            }
        }
    }

    private void scaleRect(RectF rectF, float f, float f2) {
        rectF.set(f * rectF.left, f2 * rectF.top, f * rectF.right, f2 * rectF.bottom);
    }

    public void addAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.animator.addListener(animatorListener);
    }

    public void addAnimatorPauseListener(Animator.AnimatorPauseListener animatorPauseListener) {
        this.animator.addPauseListener(animatorPauseListener);
    }

    public void addAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.animator.addUpdateListener(animatorUpdateListener);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, LottieValueCallback<T> lottieValueCallback) {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda14(this, keyPath, t, lottieValueCallback));
            return;
        }
        KeyPath keyPath2 = KeyPath.COMPOSITION;
        boolean bl = true;
        if (keyPath == keyPath2) {
            this.compositionLayer.addValueCallback(t, lottieValueCallback);
        } else if (keyPath.getResolvedElement() != null) {
            keyPath.getResolvedElement().addValueCallback(t, lottieValueCallback);
        } else {
            List<KeyPath> list = this.resolveKeyPath(keyPath);
            for (int i = 0; i < list.size(); ++i) {
                ((KeyPath)list.get(i)).getResolvedElement().addValueCallback(t, lottieValueCallback);
            }
            bl ^= list.isEmpty();
        }
        if (bl) {
            this.invalidateSelf();
            if (t == LottieProperty.TIME_REMAP) {
                this.setProgress(this.getProgress());
            }
        }
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, final SimpleLottieValueCallback<T> simpleLottieValueCallback) {
        this.addValueCallback(keyPath, t, new LottieValueCallback<T>(){

            @Override
            public T getValue(LottieFrameInfo<T> lottieFrameInfo) {
                return simpleLottieValueCallback.getValue(lottieFrameInfo);
            }
        });
    }

    public void cancelAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.cancel();
        if (!this.isVisible()) {
            this.onVisibleAction = OnVisibleAction.NONE;
        }
    }

    public void clearComposition() {
        if (this.animator.isRunning()) {
            this.animator.cancel();
            if (!this.isVisible()) {
                this.onVisibleAction = OnVisibleAction.NONE;
            }
        }
        this.composition = null;
        this.compositionLayer = null;
        this.imageAssetManager = null;
        this.animator.clearComposition();
        this.invalidateSelf();
    }

    @Deprecated
    public void disableExtraScaleModeInFitXY() {
    }

    public void draw(Canvas canvas) {
        block7 : {
            L.beginSection("Drawable#draw");
            if (this.safeMode) {
                try {
                    if (this.useSoftwareRendering) {
                        this.renderAndDrawAsBitmap(canvas, this.compositionLayer);
                        break block7;
                    }
                    this.drawDirectlyToCanvas(canvas);
                }
                catch (Throwable throwable) {
                    Logger.error("Lottie crashed in draw!", throwable);
                }
            } else if (this.useSoftwareRendering) {
                this.renderAndDrawAsBitmap(canvas, this.compositionLayer);
            } else {
                this.drawDirectlyToCanvas(canvas);
            }
        }
        this.isDirty = false;
        L.endSection("Drawable#draw");
    }

    public void draw(Canvas canvas, Matrix matrix) {
        CompositionLayer compositionLayer = this.compositionLayer;
        LottieComposition lottieComposition = this.composition;
        if (compositionLayer != null) {
            if (lottieComposition == null) {
                return;
            }
            if (this.useSoftwareRendering) {
                canvas.save();
                canvas.concat(matrix);
                this.renderAndDrawAsBitmap(canvas, compositionLayer);
                canvas.restore();
            } else {
                compositionLayer.draw(canvas, matrix, this.alpha);
            }
            this.isDirty = false;
        }
    }

    public void enableMergePathsForKitKatAndAbove(boolean bl) {
        if (this.enableMergePaths == bl) {
            return;
        }
        if (Build.VERSION.SDK_INT < 19) {
            Logger.warning("Merge paths are not supported pre-Kit Kat.");
            return;
        }
        this.enableMergePaths = bl;
        if (this.composition != null) {
            this.buildCompositionLayer();
        }
    }

    public boolean enableMergePathsForKitKatAndAbove() {
        return this.enableMergePaths;
    }

    public void endAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.endAnimation();
        if (!this.isVisible()) {
            this.onVisibleAction = OnVisibleAction.NONE;
        }
    }

    public int getAlpha() {
        return this.alpha;
    }

    public Bitmap getBitmapForId(String string2) {
        ImageAssetManager imageAssetManager = this.getImageAssetManager();
        if (imageAssetManager != null) {
            return imageAssetManager.bitmapForId(string2);
        }
        return null;
    }

    public boolean getClipToCompositionBounds() {
        return this.clipToCompositionBounds;
    }

    public LottieComposition getComposition() {
        return this.composition;
    }

    public int getFrame() {
        return (int)this.animator.getFrame();
    }

    @Deprecated
    public Bitmap getImageAsset(String string2) {
        ImageAssetManager imageAssetManager = this.getImageAssetManager();
        if (imageAssetManager != null) {
            return imageAssetManager.bitmapForId(string2);
        }
        LottieComposition lottieComposition = this.composition;
        LottieImageAsset lottieImageAsset = lottieComposition == null ? null : (LottieImageAsset)lottieComposition.getImages().get((Object)string2);
        if (lottieImageAsset != null) {
            return lottieImageAsset.getBitmap();
        }
        return null;
    }

    public String getImageAssetsFolder() {
        return this.imageAssetsFolder;
    }

    public int getIntrinsicHeight() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return -1;
        }
        return lottieComposition.getBounds().height();
    }

    public int getIntrinsicWidth() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return -1;
        }
        return lottieComposition.getBounds().width();
    }

    public LottieImageAsset getLottieImageAssetForId(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            return null;
        }
        return (LottieImageAsset)lottieComposition.getImages().get((Object)string2);
    }

    public boolean getMaintainOriginalImageBounds() {
        return this.maintainOriginalImageBounds;
    }

    public float getMaxFrame() {
        return this.animator.getMaxFrame();
    }

    public float getMinFrame() {
        return this.animator.getMinFrame();
    }

    public int getOpacity() {
        return -3;
    }

    public PerformanceTracker getPerformanceTracker() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            return lottieComposition.getPerformanceTracker();
        }
        return null;
    }

    public float getProgress() {
        return this.animator.getAnimatedValueAbsolute();
    }

    public RenderMode getRenderMode() {
        if (this.useSoftwareRendering) {
            return RenderMode.SOFTWARE;
        }
        return RenderMode.HARDWARE;
    }

    public int getRepeatCount() {
        return this.animator.getRepeatCount();
    }

    public int getRepeatMode() {
        return this.animator.getRepeatMode();
    }

    public float getSpeed() {
        return this.animator.getSpeed();
    }

    public TextDelegate getTextDelegate() {
        return this.textDelegate;
    }

    public Typeface getTypeface(String string2, String string3) {
        FontAssetManager fontAssetManager = this.getFontAssetManager();
        if (fontAssetManager != null) {
            return fontAssetManager.getTypeface(string2, string3);
        }
        return null;
    }

    public boolean hasMasks() {
        CompositionLayer compositionLayer = this.compositionLayer;
        return compositionLayer != null && compositionLayer.hasMasks();
    }

    public boolean hasMatte() {
        CompositionLayer compositionLayer = this.compositionLayer;
        return compositionLayer != null && compositionLayer.hasMatte();
    }

    public void invalidateDrawable(Drawable drawable2) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.invalidateDrawable((Drawable)this);
    }

    public void invalidateSelf() {
        if (this.isDirty) {
            return;
        }
        this.isDirty = true;
        Drawable.Callback callback = this.getCallback();
        if (callback != null) {
            callback.invalidateDrawable((Drawable)this);
        }
    }

    public boolean isAnimating() {
        LottieValueAnimator lottieValueAnimator = this.animator;
        if (lottieValueAnimator == null) {
            return false;
        }
        return lottieValueAnimator.isRunning();
    }

    boolean isAnimatingOrWillAnimateOnVisible() {
        if (this.isVisible()) {
            return this.animator.isRunning();
        }
        return this.onVisibleAction == OnVisibleAction.PLAY || this.onVisibleAction == OnVisibleAction.RESUME;
        {
        }
    }

    public boolean isApplyingOpacityToLayersEnabled() {
        return this.isApplyingOpacityToLayersEnabled;
    }

    public boolean isLooping() {
        return this.animator.getRepeatCount() == -1;
    }

    public boolean isMergePathsEnabledForKitKatAndAbove() {
        return this.enableMergePaths;
    }

    public boolean isRunning() {
        return this.isAnimating();
    }

    /* synthetic */ void lambda$addValueCallback$14$com-airbnb-lottie-LottieDrawable(KeyPath keyPath, Object object, LottieValueCallback lottieValueCallback, LottieComposition lottieComposition) {
        this.addValueCallback(keyPath, object, lottieValueCallback);
    }

    /* synthetic */ void lambda$playAnimation$0$com-airbnb-lottie-LottieDrawable(LottieComposition lottieComposition) {
        this.playAnimation();
    }

    /* synthetic */ void lambda$resumeAnimation$1$com-airbnb-lottie-LottieDrawable(LottieComposition lottieComposition) {
        this.resumeAnimation();
    }

    /* synthetic */ void lambda$setFrame$12$com-airbnb-lottie-LottieDrawable(int n, LottieComposition lottieComposition) {
        this.setFrame(n);
    }

    /* synthetic */ void lambda$setMaxFrame$4$com-airbnb-lottie-LottieDrawable(int n, LottieComposition lottieComposition) {
        this.setMaxFrame(n);
    }

    /* synthetic */ void lambda$setMaxFrame$7$com-airbnb-lottie-LottieDrawable(String string2, LottieComposition lottieComposition) {
        this.setMaxFrame(string2);
    }

    /* synthetic */ void lambda$setMaxProgress$5$com-airbnb-lottie-LottieDrawable(float f, LottieComposition lottieComposition) {
        this.setMaxProgress(f);
    }

    /* synthetic */ void lambda$setMinAndMaxFrame$10$com-airbnb-lottie-LottieDrawable(int n, int n2, LottieComposition lottieComposition) {
        this.setMinAndMaxFrame(n, n2);
    }

    /* synthetic */ void lambda$setMinAndMaxFrame$8$com-airbnb-lottie-LottieDrawable(String string2, LottieComposition lottieComposition) {
        this.setMinAndMaxFrame(string2);
    }

    /* synthetic */ void lambda$setMinAndMaxFrame$9$com-airbnb-lottie-LottieDrawable(String string2, String string3, boolean bl, LottieComposition lottieComposition) {
        this.setMinAndMaxFrame(string2, string3, bl);
    }

    /* synthetic */ void lambda$setMinAndMaxProgress$11$com-airbnb-lottie-LottieDrawable(float f, float f2, LottieComposition lottieComposition) {
        this.setMinAndMaxProgress(f, f2);
    }

    /* synthetic */ void lambda$setMinFrame$2$com-airbnb-lottie-LottieDrawable(int n, LottieComposition lottieComposition) {
        this.setMinFrame(n);
    }

    /* synthetic */ void lambda$setMinFrame$6$com-airbnb-lottie-LottieDrawable(String string2, LottieComposition lottieComposition) {
        this.setMinFrame(string2);
    }

    /* synthetic */ void lambda$setMinProgress$3$com-airbnb-lottie-LottieDrawable(float f, LottieComposition lottieComposition) {
        this.setMinProgress(f);
    }

    /* synthetic */ void lambda$setProgress$13$com-airbnb-lottie-LottieDrawable(float f, LottieComposition lottieComposition) {
        this.setProgress(f);
    }

    @Deprecated
    public void loop(boolean bl) {
        LottieValueAnimator lottieValueAnimator = this.animator;
        int n = bl ? -1 : 0;
        lottieValueAnimator.setRepeatCount(n);
    }

    public void pauseAnimation() {
        this.lazyCompositionTasks.clear();
        this.animator.pauseAnimation();
        if (!this.isVisible()) {
            this.onVisibleAction = OnVisibleAction.NONE;
        }
    }

    public void playAnimation() {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda2(this));
            return;
        }
        this.computeRenderMode();
        if (this.animationsEnabled() || this.getRepeatCount() == 0) {
            if (this.isVisible()) {
                this.animator.playAnimation();
                this.onVisibleAction = OnVisibleAction.NONE;
            } else {
                this.onVisibleAction = OnVisibleAction.PLAY;
            }
        }
        if (!this.animationsEnabled()) {
            float f = this.getSpeed() < 0.0f ? this.getMinFrame() : this.getMaxFrame();
            this.setFrame((int)f);
            this.animator.endAnimation();
            if (!this.isVisible()) {
                this.onVisibleAction = OnVisibleAction.NONE;
            }
        }
    }

    public void removeAllAnimatorListeners() {
        this.animator.removeAllListeners();
    }

    public void removeAllUpdateListeners() {
        this.animator.removeAllUpdateListeners();
        this.animator.addUpdateListener(this.progressUpdateListener);
    }

    public void removeAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.animator.removeListener(animatorListener);
    }

    public void removeAnimatorPauseListener(Animator.AnimatorPauseListener animatorPauseListener) {
        this.animator.removePauseListener(animatorPauseListener);
    }

    public void removeAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.animator.removeUpdateListener(animatorUpdateListener);
    }

    public List<KeyPath> resolveKeyPath(KeyPath keyPath) {
        if (this.compositionLayer == null) {
            Logger.warning("Cannot resolve KeyPath. Composition is not set yet.");
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        this.compositionLayer.resolveKeyPath(keyPath, 0, (List<KeyPath>)arrayList, new KeyPath(new String[0]));
        return arrayList;
    }

    public void resumeAnimation() {
        if (this.compositionLayer == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda10(this));
            return;
        }
        this.computeRenderMode();
        if (this.animationsEnabled() || this.getRepeatCount() == 0) {
            if (this.isVisible()) {
                this.animator.resumeAnimation();
                this.onVisibleAction = OnVisibleAction.NONE;
            } else {
                this.onVisibleAction = OnVisibleAction.RESUME;
            }
        }
        if (!this.animationsEnabled()) {
            float f = this.getSpeed() < 0.0f ? this.getMinFrame() : this.getMaxFrame();
            this.setFrame((int)f);
            this.animator.endAnimation();
            if (!this.isVisible()) {
                this.onVisibleAction = OnVisibleAction.NONE;
            }
        }
    }

    public void reverseAnimationSpeed() {
        this.animator.reverseAnimationSpeed();
    }

    public void scheduleDrawable(Drawable drawable2, Runnable runnable, long l) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.scheduleDrawable((Drawable)this, runnable, l);
    }

    public void setAlpha(int n) {
        this.alpha = n;
        this.invalidateSelf();
    }

    public void setApplyingOpacityToLayersEnabled(boolean bl) {
        this.isApplyingOpacityToLayersEnabled = bl;
    }

    public void setClipToCompositionBounds(boolean bl) {
        if (bl != this.clipToCompositionBounds) {
            this.clipToCompositionBounds = bl;
            CompositionLayer compositionLayer = this.compositionLayer;
            if (compositionLayer != null) {
                compositionLayer.setClipToCompositionBounds(bl);
            }
            this.invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Logger.warning("Use addColorFilter instead.");
    }

    public boolean setComposition(LottieComposition lottieComposition) {
        if (this.composition == lottieComposition) {
            return false;
        }
        this.isDirty = true;
        this.clearComposition();
        this.composition = lottieComposition;
        this.buildCompositionLayer();
        this.animator.setComposition(lottieComposition);
        this.setProgress(this.animator.getAnimatedFraction());
        Iterator iterator = new ArrayList(this.lazyCompositionTasks).iterator();
        while (iterator.hasNext()) {
            LazyCompositionTask lazyCompositionTask = (LazyCompositionTask)iterator.next();
            if (lazyCompositionTask != null) {
                lazyCompositionTask.run(lottieComposition);
            }
            iterator.remove();
        }
        this.lazyCompositionTasks.clear();
        lottieComposition.setPerformanceTrackingEnabled(this.performanceTrackingEnabled);
        this.computeRenderMode();
        Drawable.Callback callback = this.getCallback();
        if (callback instanceof ImageView) {
            ImageView imageView = (ImageView)callback;
            imageView.setImageDrawable(null);
            imageView.setImageDrawable((Drawable)this);
        }
        return true;
    }

    public void setFontAssetDelegate(FontAssetDelegate fontAssetDelegate) {
        this.fontAssetDelegate = fontAssetDelegate;
        FontAssetManager fontAssetManager = this.fontAssetManager;
        if (fontAssetManager != null) {
            fontAssetManager.setDelegate(fontAssetDelegate);
        }
    }

    public void setFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda3(this, n));
            return;
        }
        this.animator.setFrame(n);
    }

    public void setIgnoreDisabledSystemAnimations(boolean bl) {
        this.ignoreSystemAnimationsDisabled = bl;
    }

    public void setImageAssetDelegate(ImageAssetDelegate imageAssetDelegate) {
        this.imageAssetDelegate = imageAssetDelegate;
        ImageAssetManager imageAssetManager = this.imageAssetManager;
        if (imageAssetManager != null) {
            imageAssetManager.setDelegate(imageAssetDelegate);
        }
    }

    public void setImagesAssetsFolder(String string2) {
        this.imageAssetsFolder = string2;
    }

    public void setMaintainOriginalImageBounds(boolean bl) {
        this.maintainOriginalImageBounds = bl;
    }

    public void setMaxFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda9(this, n));
            return;
        }
        this.animator.setMaxFrame(0.99f + (float)n);
    }

    public void setMaxFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda11(this, string2));
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            this.setMaxFrame((int)(marker.startFrame + marker.durationFrames));
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + string2 + ".");
    }

    public void setMaxProgress(float f) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda1(this, f));
            return;
        }
        this.animator.setMaxFrame(MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f));
    }

    public void setMinAndMaxFrame(int n, int n2) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda4(this, n, n2));
            return;
        }
        this.animator.setMinAndMaxFrames(n, 0.99f + (float)n2);
    }

    public void setMinAndMaxFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda5(this, string2));
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            int n = (int)marker.startFrame;
            this.setMinAndMaxFrame(n, n + (int)marker.durationFrames);
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + string2 + ".");
    }

    public void setMinAndMaxFrame(String string2, String string3, boolean bl) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda12(this, string2, string3, bl));
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            int n = (int)marker.startFrame;
            Marker marker2 = this.composition.getMarker(string3);
            if (marker2 != null) {
                float f = marker2.startFrame;
                float f2 = bl ? 1.0f : 0.0f;
                this.setMinAndMaxFrame(n, (int)(f + f2));
                return;
            }
            throw new IllegalArgumentException("Cannot find marker with name " + string3 + ".");
        }
        throw new IllegalArgumentException("Cannot find marker with name " + string2 + ".");
    }

    public void setMinAndMaxProgress(float f, float f2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda6(this, f, f2));
            return;
        }
        this.setMinAndMaxFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f), (int)MiscUtils.lerp(this.composition.getStartFrame(), this.composition.getEndFrame(), f2));
    }

    public void setMinFrame(int n) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda7(this, n));
            return;
        }
        this.animator.setMinFrame(n);
    }

    public void setMinFrame(String string2) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda13(this, string2));
            return;
        }
        Marker marker = lottieComposition.getMarker(string2);
        if (marker != null) {
            this.setMinFrame((int)marker.startFrame);
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + string2 + ".");
    }

    public void setMinProgress(float f) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda8(this, f));
            return;
        }
        this.setMinFrame((int)MiscUtils.lerp(lottieComposition.getStartFrame(), this.composition.getEndFrame(), f));
    }

    public void setOutlineMasksAndMattes(boolean bl) {
        if (this.outlineMasksAndMattes == bl) {
            return;
        }
        this.outlineMasksAndMattes = bl;
        CompositionLayer compositionLayer = this.compositionLayer;
        if (compositionLayer != null) {
            compositionLayer.setOutlineMasksAndMattes(bl);
        }
    }

    public void setPerformanceTrackingEnabled(boolean bl) {
        this.performanceTrackingEnabled = bl;
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            lottieComposition.setPerformanceTrackingEnabled(bl);
        }
    }

    public void setProgress(float f) {
        if (this.composition == null) {
            this.lazyCompositionTasks.add((Object)new LottieDrawable$$ExternalSyntheticLambda0(this, f));
            return;
        }
        L.beginSection("Drawable#setProgress");
        this.animator.setFrame(this.composition.getFrameForProgress(f));
        L.endSection("Drawable#setProgress");
    }

    public void setRenderMode(RenderMode renderMode) {
        this.renderMode = renderMode;
        this.computeRenderMode();
    }

    public void setRepeatCount(int n) {
        this.animator.setRepeatCount(n);
    }

    public void setRepeatMode(int n) {
        this.animator.setRepeatMode(n);
    }

    public void setSafeMode(boolean bl) {
        this.safeMode = bl;
    }

    public void setSpeed(float f) {
        this.animator.setSpeed(f);
    }

    public void setSystemAnimationsAreEnabled(Boolean bl) {
        this.systemAnimationsEnabled = bl;
    }

    public void setTextDelegate(TextDelegate textDelegate) {
        this.textDelegate = textDelegate;
    }

    public boolean setVisible(boolean bl, boolean bl2) {
        boolean bl3 = true ^ this.isVisible();
        boolean bl4 = super.setVisible(bl, bl2);
        if (bl) {
            if (this.onVisibleAction == OnVisibleAction.PLAY) {
                this.playAnimation();
                return bl4;
            }
            if (this.onVisibleAction == OnVisibleAction.RESUME) {
                this.resumeAnimation();
                return bl4;
            }
        } else {
            if (this.animator.isRunning()) {
                this.pauseAnimation();
                this.onVisibleAction = OnVisibleAction.RESUME;
                return bl4;
            }
            if (!bl3) {
                this.onVisibleAction = OnVisibleAction.NONE;
            }
        }
        return bl4;
    }

    public void start() {
        Drawable.Callback callback = this.getCallback();
        if (callback instanceof View && ((View)callback).isInEditMode()) {
            return;
        }
        this.playAnimation();
    }

    public void stop() {
        this.endAnimation();
    }

    public void unscheduleDrawable(Drawable drawable2, Runnable runnable) {
        Drawable.Callback callback = this.getCallback();
        if (callback == null) {
            return;
        }
        callback.unscheduleDrawable((Drawable)this, runnable);
    }

    public Bitmap updateBitmap(String string2, Bitmap bitmap) {
        ImageAssetManager imageAssetManager = this.getImageAssetManager();
        if (imageAssetManager == null) {
            Logger.warning("Cannot update bitmap. Most likely the drawable is not added to a View which prevents Lottie from getting a Context.");
            return null;
        }
        Bitmap bitmap2 = imageAssetManager.updateBitmap(string2, bitmap);
        this.invalidateSelf();
        return bitmap2;
    }

    public boolean useTextGlyphs() {
        return this.textDelegate == null && this.composition.getCharacters().size() > 0;
    }

    private static interface LazyCompositionTask {
        public void run(LottieComposition var1);
    }

    private static final class OnVisibleAction
    extends Enum<OnVisibleAction> {
        private static final /* synthetic */ OnVisibleAction[] $VALUES;
        public static final /* enum */ OnVisibleAction NONE;
        public static final /* enum */ OnVisibleAction PLAY;
        public static final /* enum */ OnVisibleAction RESUME;

        static {
            OnVisibleAction onVisibleAction;
            OnVisibleAction onVisibleAction2;
            OnVisibleAction onVisibleAction3;
            NONE = onVisibleAction3 = new OnVisibleAction();
            PLAY = onVisibleAction = new OnVisibleAction();
            RESUME = onVisibleAction2 = new OnVisibleAction();
            $VALUES = new OnVisibleAction[]{onVisibleAction3, onVisibleAction, onVisibleAction2};
        }

        public static OnVisibleAction valueOf(String string2) {
            return (OnVisibleAction)Enum.valueOf(OnVisibleAction.class, (String)string2);
        }

        public static OnVisibleAction[] values() {
            return (OnVisibleAction[])$VALUES.clone();
        }
    }

    @Retention(value=RetentionPolicy.SOURCE)
    public static @interface RepeatMode {
    }

}

