/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieResult;
import java.util.concurrent.Callable;

public final class LottieAnimationView$$ExternalSyntheticLambda3
implements Callable {
    public final /* synthetic */ LottieAnimationView f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda3(LottieAnimationView lottieAnimationView, String string2) {
        this.f$0 = lottieAnimationView;
        this.f$1 = string2;
    }

    public final Object call() {
        return this.f$0.lambda$fromAssets$2$com-airbnb-lottie-LottieAnimationView(this.f$1);
    }
}

