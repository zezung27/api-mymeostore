/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda11
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda11(LottieDrawable lottieDrawable, String string2) {
        this.f$0 = lottieDrawable;
        this.f$1 = string2;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$setMaxFrame$7$com-airbnb-lottie-LottieDrawable(this.f$1, lottieComposition);
    }
}

