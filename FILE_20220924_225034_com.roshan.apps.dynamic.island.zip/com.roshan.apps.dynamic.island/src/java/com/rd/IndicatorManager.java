/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.rd;

import com.rd.animation.AnimationManager;
import com.rd.animation.controller.ValueController;
import com.rd.animation.data.Value;
import com.rd.draw.DrawManager;
import com.rd.draw.data.Indicator;

public class IndicatorManager
implements ValueController.UpdateListener {
    private AnimationManager animationManager;
    private DrawManager drawManager;
    private Listener listener;

    IndicatorManager(Listener listener) {
        this.listener = listener;
        this.drawManager = new DrawManager();
        this.animationManager = new AnimationManager(this.drawManager.indicator(), this);
    }

    public AnimationManager animate() {
        return this.animationManager;
    }

    public DrawManager drawer() {
        return this.drawManager;
    }

    public Indicator indicator() {
        return this.drawManager.indicator();
    }

    @Override
    public void onValueUpdated(Value value) {
        this.drawManager.updateValue(value);
        Listener listener = this.listener;
        if (listener != null) {
            listener.onIndicatorUpdated();
        }
    }

    static interface Listener {
        public void onIndicatorUpdated();
    }

}

