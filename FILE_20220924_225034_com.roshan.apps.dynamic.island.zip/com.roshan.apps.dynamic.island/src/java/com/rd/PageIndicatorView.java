/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.database.DataSetObserver
 *  android.graphics.Canvas
 *  android.os.Handler
 *  android.os.Looper
 *  android.os.Parcelable
 *  android.util.AttributeSet
 *  android.util.Pair
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$OnTouchListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.view.ViewPropertyAnimator
 *  androidx.core.text.TextUtilsCompat
 *  androidx.viewpager.widget.PagerAdapter
 *  androidx.viewpager.widget.ViewPager
 *  androidx.viewpager.widget.ViewPager$OnAdapterChangeListener
 *  androidx.viewpager.widget.ViewPager$OnPageChangeListener
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.Locale
 */
package com.rd;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import androidx.core.text.TextUtilsCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.rd.IndicatorManager;
import com.rd.animation.AnimationManager;
import com.rd.animation.data.Value;
import com.rd.animation.type.AnimationType;
import com.rd.draw.DrawManager;
import com.rd.draw.controller.DrawController;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.data.PositionSavedState;
import com.rd.draw.data.RtlMode;
import com.rd.utils.CoordinatesUtils;
import com.rd.utils.DensityUtils;
import com.rd.utils.IdUtils;
import java.util.Locale;

public class PageIndicatorView
extends View
implements ViewPager.OnPageChangeListener,
IndicatorManager.Listener,
ViewPager.OnAdapterChangeListener,
View.OnTouchListener {
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private Runnable idleRunnable = new Runnable(){

        public void run() {
            PageIndicatorView.this.manager.indicator().setIdle(true);
            PageIndicatorView.this.hideWithAnimation();
        }
    };
    private boolean isInteractionEnabled;
    private IndicatorManager manager;
    private DataSetObserver setObserver;
    private ViewPager viewPager;

    public PageIndicatorView(Context context) {
        super(context);
        this.init(null);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(attributeSet);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(attributeSet);
    }

    public PageIndicatorView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.init(attributeSet);
    }

    private int adjustPosition(int n) {
        int n2 = -1 + this.manager.indicator().getCount();
        if (n < 0) {
            return 0;
        }
        if (n > n2) {
            n = n2;
        }
        return n;
    }

    private void displayWithAnimation() {
        this.animate().cancel();
        this.animate().alpha(1.0f).setDuration(250L);
    }

    private ViewPager findViewPager(ViewGroup viewGroup, int n) {
        if (viewGroup.getChildCount() <= 0) {
            return null;
        }
        View view = viewGroup.findViewById(n);
        if (view != null && view instanceof ViewPager) {
            return (ViewPager)view;
        }
        return null;
    }

    private void findViewPager(ViewParent viewParent) {
        boolean bl = viewParent != null && viewParent instanceof ViewGroup && ((ViewGroup)viewParent).getChildCount() > 0;
        if (!bl) {
            return;
        }
        int n = this.manager.indicator().getViewPagerId();
        ViewPager viewPager = this.findViewPager((ViewGroup)viewParent, n);
        if (viewPager != null) {
            this.setViewPager(viewPager);
            return;
        }
        this.findViewPager(viewParent.getParent());
    }

    private void hideWithAnimation() {
        this.animate().cancel();
        this.animate().alpha(0.0f).setDuration(250L);
    }

    private void init(AttributeSet attributeSet) {
        this.setupId();
        this.initIndicatorManager(attributeSet);
        if (this.manager.indicator().isFadeOnIdle()) {
            this.startIdleRunnable();
        }
    }

    private void initIndicatorManager(AttributeSet attributeSet) {
        IndicatorManager indicatorManager;
        this.manager = indicatorManager = new IndicatorManager(this);
        indicatorManager.drawer().initAttributes(this.getContext(), attributeSet);
        Indicator indicator = this.manager.indicator();
        indicator.setPaddingLeft(this.getPaddingLeft());
        indicator.setPaddingTop(this.getPaddingTop());
        indicator.setPaddingRight(this.getPaddingRight());
        indicator.setPaddingBottom(this.getPaddingBottom());
        this.isInteractionEnabled = indicator.isInteractiveAnimation();
    }

    private boolean isRtl() {
        int n;
        int n2 = 3.$SwitchMap$com$rd$draw$data$RtlMode[this.manager.indicator().getRtlMode().ordinal()];
        if (n2 != (n = 1)) {
            if (n2 != 3) {
                return false;
            }
            if (TextUtilsCompat.getLayoutDirectionFromLocale((Locale)this.getContext().getResources().getConfiguration().locale) == n) {
                return n;
            }
            n = 0;
        }
        return n;
    }

    private boolean isViewMeasured() {
        return this.getMeasuredHeight() != 0 || this.getMeasuredWidth() != 0;
        {
        }
    }

    private void onPageScroll(int n, float f) {
        Indicator indicator = this.manager.indicator();
        AnimationType animationType = indicator.getAnimationType();
        boolean bl = indicator.isInteractiveAnimation();
        boolean bl2 = this.isViewMeasured() && bl && animationType != AnimationType.NONE;
        if (!bl2) {
            return;
        }
        Pair<Integer, Float> pair = CoordinatesUtils.getProgress(indicator, n, f, this.isRtl());
        this.setProgress((Integer)pair.first, ((Float)pair.second).floatValue());
    }

    private void onPageSelect(int n) {
        Indicator indicator = this.manager.indicator();
        boolean bl = this.isViewMeasured();
        int n2 = indicator.getCount();
        if (bl) {
            if (this.isRtl()) {
                n = n2 - 1 - n;
            }
            this.setSelection(n);
        }
    }

    private void registerSetObserver() {
        ViewPager viewPager;
        if (this.setObserver == null && (viewPager = this.viewPager) != null) {
            if (viewPager.getAdapter() == null) {
                return;
            }
            this.setObserver = new DataSetObserver(){

                public void onChanged() {
                    PageIndicatorView.this.updateState();
                }
            };
            try {
                this.viewPager.getAdapter().registerDataSetObserver(this.setObserver);
                return;
            }
            catch (IllegalStateException illegalStateException) {
                illegalStateException.printStackTrace();
            }
        }
    }

    private void setupId() {
        if (this.getId() == -1) {
            this.setId(IdUtils.generateViewId());
        }
    }

    private void startIdleRunnable() {
        Handler handler = HANDLER;
        handler.removeCallbacks(this.idleRunnable);
        handler.postDelayed(this.idleRunnable, this.manager.indicator().getIdleDuration());
    }

    private void stopIdleRunnable() {
        HANDLER.removeCallbacks(this.idleRunnable);
        this.displayWithAnimation();
    }

    private void unRegisterSetObserver() {
        ViewPager viewPager;
        if (this.setObserver != null && (viewPager = this.viewPager) != null) {
            if (viewPager.getAdapter() == null) {
                return;
            }
            try {
                this.viewPager.getAdapter().unregisterDataSetObserver(this.setObserver);
                this.setObserver = null;
                return;
            }
            catch (IllegalStateException illegalStateException) {
                illegalStateException.printStackTrace();
            }
        }
    }

    private void updateState() {
        ViewPager viewPager = this.viewPager;
        if (viewPager != null) {
            if (viewPager.getAdapter() == null) {
                return;
            }
            int n = this.viewPager.getAdapter().getCount();
            int n2 = this.isRtl() ? n - 1 - this.viewPager.getCurrentItem() : this.viewPager.getCurrentItem();
            this.manager.indicator().setSelectedPosition(n2);
            this.manager.indicator().setSelectingPosition(n2);
            this.manager.indicator().setLastSelectedPosition(n2);
            this.manager.indicator().setCount(n);
            this.manager.animate().end();
            this.updateVisibility();
            this.requestLayout();
        }
    }

    private void updateVisibility() {
        if (!this.manager.indicator().isAutoVisibility()) {
            return;
        }
        int n = this.manager.indicator().getCount();
        int n2 = this.getVisibility();
        if (n2 != 0 && n > 1) {
            this.setVisibility(0);
            return;
        }
        if (n2 != 4 && n <= 1) {
            this.setVisibility(4);
        }
    }

    public void clearSelection() {
        Indicator indicator = this.manager.indicator();
        indicator.setInteractiveAnimation(false);
        indicator.setLastSelectedPosition(-1);
        indicator.setSelectingPosition(-1);
        indicator.setSelectedPosition(-1);
        this.manager.animate().basic();
    }

    public long getAnimationDuration() {
        return this.manager.indicator().getAnimationDuration();
    }

    public int getCount() {
        return this.manager.indicator().getCount();
    }

    public int getPadding() {
        return this.manager.indicator().getPadding();
    }

    public int getRadius() {
        return this.manager.indicator().getRadius();
    }

    public float getScaleFactor() {
        return this.manager.indicator().getScaleFactor();
    }

    public int getSelectedColor() {
        return this.manager.indicator().getSelectedColor();
    }

    public int getSelection() {
        return this.manager.indicator().getSelectedPosition();
    }

    public int getStrokeWidth() {
        return this.manager.indicator().getStroke();
    }

    public int getUnselectedColor() {
        return this.manager.indicator().getUnselectedColor();
    }

    public void onAdapterChanged(ViewPager viewPager, PagerAdapter pagerAdapter, PagerAdapter pagerAdapter2) {
        if (this.manager.indicator().isDynamicCount()) {
            DataSetObserver dataSetObserver;
            if (pagerAdapter != null && (dataSetObserver = this.setObserver) != null) {
                pagerAdapter.unregisterDataSetObserver(dataSetObserver);
                this.setObserver = null;
            }
            this.registerSetObserver();
        }
        this.updateState();
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.findViewPager(this.getParent());
    }

    protected void onDetachedFromWindow() {
        this.unRegisterSetObserver();
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        this.manager.drawer().draw(canvas);
    }

    @Override
    public void onIndicatorUpdated() {
        this.invalidate();
    }

    protected void onMeasure(int n, int n2) {
        Pair<Integer, Integer> pair = this.manager.drawer().measureViewSize(n, n2);
        this.setMeasuredDimension(((Integer)pair.first).intValue(), ((Integer)pair.second).intValue());
    }

    public void onPageScrollStateChanged(int n) {
        if (n == 0) {
            this.manager.indicator().setInteractiveAnimation(this.isInteractionEnabled);
        }
    }

    public void onPageScrolled(int n, float f, int n2) {
        this.onPageScroll(n, f);
    }

    public void onPageSelected(int n) {
        this.onPageSelect(n);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof PositionSavedState) {
            Indicator indicator = this.manager.indicator();
            PositionSavedState positionSavedState = (PositionSavedState)parcelable;
            indicator.setSelectedPosition(positionSavedState.getSelectedPosition());
            indicator.setSelectingPosition(positionSavedState.getSelectingPosition());
            indicator.setLastSelectedPosition(positionSavedState.getLastSelectedPosition());
            super.onRestoreInstanceState(positionSavedState.getSuperState());
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        Indicator indicator = this.manager.indicator();
        PositionSavedState positionSavedState = new PositionSavedState(super.onSaveInstanceState());
        positionSavedState.setSelectedPosition(indicator.getSelectedPosition());
        positionSavedState.setSelectingPosition(indicator.getSelectingPosition());
        positionSavedState.setLastSelectedPosition(indicator.getLastSelectedPosition());
        return positionSavedState;
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.manager.indicator().isFadeOnIdle()) {
            return false;
        }
        int n = motionEvent.getAction();
        if (n != 0) {
            if (n != 1) {
                return false;
            }
            this.startIdleRunnable();
            return false;
        }
        this.stopIdleRunnable();
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.manager.drawer().touch(motionEvent);
        return true;
    }

    public void releaseViewPager() {
        ViewPager viewPager = this.viewPager;
        if (viewPager != null) {
            viewPager.removeOnPageChangeListener((ViewPager.OnPageChangeListener)this);
            this.viewPager.removeOnAdapterChangeListener((ViewPager.OnAdapterChangeListener)this);
            this.viewPager = null;
        }
    }

    public void setAnimationDuration(long l) {
        this.manager.indicator().setAnimationDuration(l);
    }

    public void setAnimationType(AnimationType animationType) {
        this.manager.onValueUpdated(null);
        if (animationType != null) {
            this.manager.indicator().setAnimationType(animationType);
        } else {
            this.manager.indicator().setAnimationType(AnimationType.NONE);
        }
        this.invalidate();
    }

    public void setAutoVisibility(boolean bl) {
        if (!bl) {
            this.setVisibility(0);
        }
        this.manager.indicator().setAutoVisibility(bl);
        this.updateVisibility();
    }

    public void setClickListener(DrawController.ClickListener clickListener) {
        this.manager.drawer().setClickListener(clickListener);
    }

    public void setCount(int n) {
        if (n >= 0 && this.manager.indicator().getCount() != n) {
            this.manager.indicator().setCount(n);
            this.updateVisibility();
            this.requestLayout();
        }
    }

    public void setDynamicCount(boolean bl) {
        this.manager.indicator().setDynamicCount(bl);
        if (bl) {
            this.registerSetObserver();
            return;
        }
        this.unRegisterSetObserver();
    }

    public void setFadeOnIdle(boolean bl) {
        this.manager.indicator().setFadeOnIdle(bl);
        if (bl) {
            this.startIdleRunnable();
            return;
        }
        this.stopIdleRunnable();
    }

    public void setIdleDuration(long l) {
        this.manager.indicator().setIdleDuration(l);
        if (this.manager.indicator().isFadeOnIdle()) {
            this.startIdleRunnable();
            return;
        }
        this.stopIdleRunnable();
    }

    public void setInteractiveAnimation(boolean bl) {
        this.manager.indicator().setInteractiveAnimation(bl);
        this.isInteractionEnabled = bl;
    }

    public void setOrientation(Orientation orientation) {
        if (orientation != null) {
            this.manager.indicator().setOrientation(orientation);
            this.requestLayout();
        }
    }

    public void setPadding(float f) {
        if (f < 0.0f) {
            f = 0.0f;
        }
        this.manager.indicator().setPadding((int)f);
        this.invalidate();
    }

    public void setPadding(int n) {
        if (n < 0) {
            n = 0;
        }
        int n2 = DensityUtils.dpToPx(n);
        this.manager.indicator().setPadding(n2);
        this.invalidate();
    }

    public void setProgress(int n, float f) {
        Indicator indicator = this.manager.indicator();
        if (!indicator.isInteractiveAnimation()) {
            return;
        }
        int n2 = indicator.getCount();
        if (n2 > 0 && n >= 0) {
            int n3 = n2 - 1;
            if (n > n3) {
                n = n3;
            }
        } else {
            n = 0;
        }
        if (f < 0.0f) {
            f = 0.0f;
        } else if (f > 1.0f) {
            f = 1.0f;
        }
        if (f == 1.0f) {
            indicator.setLastSelectedPosition(indicator.getSelectedPosition());
            indicator.setSelectedPosition(n);
        }
        indicator.setSelectingPosition(n);
        this.manager.animate().interactive(f);
    }

    public void setRadius(float f) {
        if (f < 0.0f) {
            f = 0.0f;
        }
        this.manager.indicator().setRadius((int)f);
        this.invalidate();
    }

    public void setRadius(int n) {
        if (n < 0) {
            n = 0;
        }
        int n2 = DensityUtils.dpToPx(n);
        this.manager.indicator().setRadius(n2);
        this.invalidate();
    }

    public void setRtlMode(RtlMode rtlMode) {
        Indicator indicator = this.manager.indicator();
        if (rtlMode == null) {
            indicator.setRtlMode(RtlMode.Off);
        } else {
            indicator.setRtlMode(rtlMode);
        }
        if (this.viewPager == null) {
            return;
        }
        int n = indicator.getSelectedPosition();
        if (this.isRtl()) {
            n = -1 + indicator.getCount() - n;
        } else {
            ViewPager viewPager = this.viewPager;
            if (viewPager != null) {
                n = viewPager.getCurrentItem();
            }
        }
        indicator.setLastSelectedPosition(n);
        indicator.setSelectingPosition(n);
        indicator.setSelectedPosition(n);
        this.invalidate();
    }

    public void setScaleFactor(float f) {
        if (f > 1.0f) {
            f = 1.0f;
        } else if (f < 0.3f) {
            f = 0.3f;
        }
        this.manager.indicator().setScaleFactor(f);
    }

    public void setSelected(int n) {
        Indicator indicator = this.manager.indicator();
        AnimationType animationType = indicator.getAnimationType();
        indicator.setAnimationType(AnimationType.NONE);
        this.setSelection(n);
        indicator.setAnimationType(animationType);
    }

    public void setSelectedColor(int n) {
        this.manager.indicator().setSelectedColor(n);
        this.invalidate();
    }

    public void setSelection(int n) {
        Indicator indicator = this.manager.indicator();
        int n2 = this.adjustPosition(n);
        if (n2 != indicator.getSelectedPosition()) {
            if (n2 == indicator.getSelectingPosition()) {
                return;
            }
            indicator.setInteractiveAnimation(false);
            indicator.setLastSelectedPosition(indicator.getSelectedPosition());
            indicator.setSelectingPosition(n2);
            indicator.setSelectedPosition(n2);
            this.manager.animate().basic();
        }
    }

    public void setStrokeWidth(float f) {
        int n = this.manager.indicator().getRadius();
        if (f < 0.0f) {
            f = 0.0f;
        } else {
            float f2 = n;
            if (f > f2) {
                f = f2;
            }
        }
        this.manager.indicator().setStroke((int)f);
        this.invalidate();
    }

    public void setStrokeWidth(int n) {
        int n2 = DensityUtils.dpToPx(n);
        int n3 = this.manager.indicator().getRadius();
        if (n2 < 0) {
            n2 = 0;
        } else if (n2 > n3) {
            n2 = n3;
        }
        this.manager.indicator().setStroke(n2);
        this.invalidate();
    }

    public void setUnselectedColor(int n) {
        this.manager.indicator().setUnselectedColor(n);
        this.invalidate();
    }

    public void setViewPager(ViewPager viewPager) {
        this.releaseViewPager();
        if (viewPager == null) {
            return;
        }
        this.viewPager = viewPager;
        viewPager.addOnPageChangeListener((ViewPager.OnPageChangeListener)this);
        this.viewPager.addOnAdapterChangeListener((ViewPager.OnAdapterChangeListener)this);
        this.viewPager.setOnTouchListener((View.OnTouchListener)this);
        this.manager.indicator().setViewPagerId(this.viewPager.getId());
        this.setDynamicCount(this.manager.indicator().isDynamicCount());
        this.updateState();
    }

}

