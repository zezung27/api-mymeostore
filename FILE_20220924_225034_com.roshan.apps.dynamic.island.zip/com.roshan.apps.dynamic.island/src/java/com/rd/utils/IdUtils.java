/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.rd.utils;

import android.os.Build;
import android.view.View;
import java.util.concurrent.atomic.AtomicInteger;

public class IdUtils {
    private static final AtomicInteger nextGeneratedId = new AtomicInteger(1);

    private static int generateId() {
        int n;
        AtomicInteger atomicInteger;
        int n2;
        do {
            if ((n = (n2 = (atomicInteger = nextGeneratedId).get()) + 1) <= 16777215) continue;
            n = 1;
        } while (!atomicInteger.compareAndSet(n2, n));
        return n2;
    }

    public static int generateViewId() {
        if (Build.VERSION.SDK_INT < 17) {
            return IdUtils.generateId();
        }
        return View.generateViewId();
    }
}

