/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.ThinWormAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.drawer.type.WormDrawer;

public class ThinWormDrawer
extends WormDrawer {
    public ThinWormDrawer(Paint paint, Indicator indicator) {
        super(paint, indicator);
    }

    @Override
    public void draw(Canvas canvas, Value value, int n, int n2) {
        if (!(value instanceof ThinWormAnimationValue)) {
            return;
        }
        ThinWormAnimationValue thinWormAnimationValue = (ThinWormAnimationValue)value;
        int n3 = thinWormAnimationValue.getRectStart();
        int n4 = thinWormAnimationValue.getRectEnd();
        int n5 = thinWormAnimationValue.getHeight() / 2;
        int n6 = this.indicator.getRadius();
        int n7 = this.indicator.getUnselectedColor();
        int n8 = this.indicator.getSelectedColor();
        if (this.indicator.getOrientation() == Orientation.HORIZONTAL) {
            this.rect.left = n3;
            this.rect.right = n4;
            this.rect.top = n2 - n5;
            this.rect.bottom = n5 + n2;
        } else {
            this.rect.left = n - n5;
            this.rect.right = n5 + n;
            this.rect.top = n3;
            this.rect.bottom = n4;
        }
        this.paint.setColor(n7);
        float f = n;
        float f2 = n2;
        float f3 = n6;
        canvas.drawCircle(f, f2, f3, this.paint);
        this.paint.setColor(n8);
        canvas.drawRoundRect(this.rect, f3, f3, this.paint);
    }
}

