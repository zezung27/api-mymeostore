/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.DropAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.drawer.type.BaseDrawer;

public class DropDrawer
extends BaseDrawer {
    public DropDrawer(Paint paint, Indicator indicator) {
        super(paint, indicator);
    }

    public void draw(Canvas canvas, Value value, int n, int n2) {
        if (!(value instanceof DropAnimationValue)) {
            return;
        }
        DropAnimationValue dropAnimationValue = (DropAnimationValue)value;
        int n3 = this.indicator.getUnselectedColor();
        int n4 = this.indicator.getSelectedColor();
        float f = this.indicator.getRadius();
        this.paint.setColor(n3);
        canvas.drawCircle((float)n, (float)n2, f, this.paint);
        this.paint.setColor(n4);
        if (this.indicator.getOrientation() == Orientation.HORIZONTAL) {
            canvas.drawCircle((float)dropAnimationValue.getWidth(), (float)dropAnimationValue.getHeight(), (float)dropAnimationValue.getRadius(), this.paint);
            return;
        }
        canvas.drawCircle((float)dropAnimationValue.getHeight(), (float)dropAnimationValue.getWidth(), (float)dropAnimationValue.getRadius(), this.paint);
    }
}

