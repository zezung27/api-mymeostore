/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Pair
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 */
package com.rd.draw.controller;

import android.util.Pair;
import android.view.View;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;

public class MeasureController {
    public Pair<Integer, Integer> measureViewSize(Indicator indicator, int n, int n2) {
        int n3;
        int n4;
        int n5 = View.MeasureSpec.getMode((int)n);
        int n6 = View.MeasureSpec.getSize((int)n);
        int n7 = View.MeasureSpec.getMode((int)n2);
        int n8 = View.MeasureSpec.getSize((int)n2);
        int n9 = indicator.getCount();
        int n10 = indicator.getRadius();
        int n11 = indicator.getStroke();
        int n12 = indicator.getPadding();
        int n13 = indicator.getPaddingLeft();
        int n14 = indicator.getPaddingTop();
        int n15 = indicator.getPaddingRight();
        int n16 = indicator.getPaddingBottom();
        int n17 = n10 * 2;
        Orientation orientation = indicator.getOrientation();
        if (n9 != 0) {
            int n18 = n17 * n9;
            int n19 = n9 * (n11 * 2);
            n3 = n12 * (n9 - 1) + (n18 + n19);
            n4 = n17 + n11;
            if (orientation != Orientation.HORIZONTAL) {
                int n20 = n3;
                n3 = n4;
                n4 = n20;
            }
        } else {
            n4 = 0;
            n3 = 0;
        }
        if (indicator.getAnimationType() == AnimationType.DROP) {
            if (orientation == Orientation.HORIZONTAL) {
                n4 *= 2;
            } else {
                n3 *= 2;
            }
        }
        int n21 = n13 + n15;
        int n22 = n14 + n16;
        int n23 = n3 + n21;
        int n24 = n4 + n22;
        if (n5 != 1073741824) {
            n6 = n5 == Integer.MIN_VALUE ? Math.min((int)n23, (int)n6) : n23;
        }
        if (n7 != 1073741824) {
            n8 = n7 == Integer.MIN_VALUE ? Math.min((int)n24, (int)n8) : n24;
        }
        if (n6 < 0) {
            n6 = 0;
        }
        int n25 = n8 < 0 ? 0 : n8;
        indicator.setWidth(n6);
        indicator.setHeight(n25);
        return new Pair((Object)n6, (Object)n25);
    }
}

