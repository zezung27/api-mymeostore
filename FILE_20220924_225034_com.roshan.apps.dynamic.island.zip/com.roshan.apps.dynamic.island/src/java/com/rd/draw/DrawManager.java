/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Canvas
 *  android.util.AttributeSet
 *  android.util.Pair
 *  android.view.MotionEvent
 *  java.lang.Integer
 *  java.lang.Object
 */
package com.rd.draw;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.MotionEvent;
import com.rd.animation.data.Value;
import com.rd.draw.controller.AttributeController;
import com.rd.draw.controller.DrawController;
import com.rd.draw.controller.MeasureController;
import com.rd.draw.data.Indicator;

public class DrawManager {
    private AttributeController attributeController = new AttributeController(this.indicator);
    private DrawController drawController = new DrawController(this.indicator);
    private Indicator indicator = new Indicator();
    private MeasureController measureController = new MeasureController();

    public void draw(Canvas canvas) {
        this.drawController.draw(canvas);
    }

    public Indicator indicator() {
        if (this.indicator == null) {
            this.indicator = new Indicator();
        }
        return this.indicator;
    }

    public void initAttributes(Context context, AttributeSet attributeSet) {
        this.attributeController.init(context, attributeSet);
    }

    public Pair<Integer, Integer> measureViewSize(int n, int n2) {
        return this.measureController.measureViewSize(this.indicator, n, n2);
    }

    public void setClickListener(DrawController.ClickListener clickListener) {
        this.drawController.setClickListener(clickListener);
    }

    public void touch(MotionEvent motionEvent) {
        this.drawController.touch(motionEvent);
    }

    public void updateValue(Value value) {
        this.drawController.updateValue(value);
    }
}

