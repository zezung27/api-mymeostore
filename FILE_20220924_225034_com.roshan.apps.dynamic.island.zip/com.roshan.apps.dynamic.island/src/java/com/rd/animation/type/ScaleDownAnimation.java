/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.IntEvaluator
 *  android.animation.PropertyValuesHolder
 *  android.animation.TypeEvaluator
 *  java.lang.String
 */
package com.rd.animation.type;

import android.animation.IntEvaluator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import com.rd.animation.controller.ValueController;
import com.rd.animation.type.ScaleAnimation;

public class ScaleDownAnimation
extends ScaleAnimation {
    public ScaleDownAnimation(ValueController.UpdateListener updateListener) {
        super(updateListener);
    }

    @Override
    protected PropertyValuesHolder createScalePropertyHolder(boolean bl) {
        int n;
        String string;
        int n2;
        if (bl) {
            n = (int)((float)this.radius * this.scaleFactor);
            n2 = this.radius;
            string = "ANIMATION_SCALE_REVERSE";
        } else {
            n = this.radius;
            n2 = (int)((float)this.radius * this.scaleFactor);
            string = "ANIMATION_SCALE";
        }
        PropertyValuesHolder propertyValuesHolder = PropertyValuesHolder.ofInt((String)string, (int[])new int[]{n, n2});
        propertyValuesHolder.setEvaluator((TypeEvaluator)new IntEvaluator());
        return propertyValuesHolder;
    }
}

