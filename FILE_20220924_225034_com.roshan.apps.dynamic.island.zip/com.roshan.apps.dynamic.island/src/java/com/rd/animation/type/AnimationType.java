/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.rd.animation.type;

public final class AnimationType
extends Enum<AnimationType> {
    private static final /* synthetic */ AnimationType[] $VALUES;
    public static final /* enum */ AnimationType COLOR;
    public static final /* enum */ AnimationType DROP;
    public static final /* enum */ AnimationType FILL;
    public static final /* enum */ AnimationType NONE;
    public static final /* enum */ AnimationType SCALE;
    public static final /* enum */ AnimationType SCALE_DOWN;
    public static final /* enum */ AnimationType SLIDE;
    public static final /* enum */ AnimationType SWAP;
    public static final /* enum */ AnimationType THIN_WORM;
    public static final /* enum */ AnimationType WORM;

    static {
        AnimationType animationType;
        AnimationType animationType2;
        AnimationType animationType3;
        AnimationType animationType4;
        AnimationType animationType5;
        AnimationType animationType6;
        AnimationType animationType7;
        AnimationType animationType8;
        AnimationType animationType9;
        AnimationType animationType10;
        NONE = animationType8 = new AnimationType();
        COLOR = animationType2 = new AnimationType();
        SCALE = animationType6 = new AnimationType();
        WORM = animationType10 = new AnimationType();
        SLIDE = animationType = new AnimationType();
        FILL = animationType7 = new AnimationType();
        THIN_WORM = animationType5 = new AnimationType();
        DROP = animationType3 = new AnimationType();
        SWAP = animationType9 = new AnimationType();
        SCALE_DOWN = animationType4 = new AnimationType();
        $VALUES = new AnimationType[]{animationType8, animationType2, animationType6, animationType10, animationType, animationType7, animationType5, animationType3, animationType9, animationType4};
    }

    public static AnimationType valueOf(String string2) {
        return (AnimationType)Enum.valueOf(AnimationType.class, (String)string2);
    }

    public static AnimationType[] values() {
        return (AnimationType[])$VALUES.clone();
    }
}

