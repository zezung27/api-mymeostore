/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.AnimatorSet
 *  android.animation.AnimatorSet$Builder
 *  android.animation.PropertyValuesHolder
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.rd.animation.type;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import com.rd.animation.controller.ValueController;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.DropAnimationValue;
import com.rd.animation.type.BaseAnimation;
import java.util.ArrayList;
import java.util.Iterator;

public class DropAnimation
extends BaseAnimation<AnimatorSet> {
    private int heightEnd;
    private int heightStart;
    private int radius;
    private DropAnimationValue value = new DropAnimationValue();
    private int widthEnd;
    private int widthStart;

    public DropAnimation(ValueController.UpdateListener updateListener) {
        super(updateListener);
    }

    private ValueAnimator createValueAnimation(int n, int n2, long l, final AnimationType animationType) {
        ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])new int[]{n, n2});
        valueAnimator.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
        valueAnimator.setDuration(l);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                DropAnimation.this.onAnimatorUpdate(valueAnimator, animationType);
            }
        });
        return valueAnimator;
    }

    private boolean hasChanges(int n, int n2, int n3, int n4, int n5) {
        if (this.widthStart != n) {
            return true;
        }
        if (this.widthEnd != n2) {
            return true;
        }
        if (this.heightStart != n3) {
            return true;
        }
        if (this.heightEnd != n4) {
            return true;
        }
        return this.radius != n5;
    }

    private void onAnimatorUpdate(ValueAnimator valueAnimator, AnimationType animationType) {
        int n = (Integer)valueAnimator.getAnimatedValue();
        int n2 = 2.$SwitchMap$com$rd$animation$type$DropAnimation$AnimationType[animationType.ordinal()];
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 == 3) {
                    this.value.setRadius(n);
                }
            } else {
                this.value.setHeight(n);
            }
        } else {
            this.value.setWidth(n);
        }
        if (this.listener != null) {
            this.listener.onValueUpdated(this.value);
        }
    }

    @Override
    public AnimatorSet createAnimator() {
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
        return animatorSet;
    }

    @Override
    public DropAnimation duration(long l) {
        super.duration(l);
        return this;
    }

    @Override
    public DropAnimation progress(float f) {
        if (this.animator != null) {
            long l = (long)(f * (float)this.animationDuration);
            boolean bl = false;
            Iterator iterator = ((AnimatorSet)this.animator).getChildAnimations().iterator();
            while (iterator.hasNext()) {
                ValueAnimator valueAnimator = (ValueAnimator)((Animator)iterator.next());
                long l2 = valueAnimator.getDuration();
                long l3 = bl ? l - l2 : l;
                if (l3 < 0L) continue;
                if (l3 >= l2) {
                    l3 = l2;
                }
                if (valueAnimator.getValues() != null && valueAnimator.getValues().length > 0) {
                    valueAnimator.setCurrentPlayTime(l3);
                }
                if (bl || l2 < this.animationDuration) continue;
                bl = true;
            }
        }
        return this;
    }

    public DropAnimation with(int n, int n2, int n3, int n4, int n5) {
        if (this.hasChanges(n, n2, n3, n4, n5)) {
            this.animator = this.createAnimator();
            this.widthStart = n;
            this.widthEnd = n2;
            this.heightStart = n3;
            this.heightEnd = n4;
            this.radius = n5;
            int n6 = (int)((double)n5 / 1.5);
            long l = this.animationDuration / 2L;
            ValueAnimator valueAnimator = this.createValueAnimation(n, n2, this.animationDuration, AnimationType.Width);
            ValueAnimator valueAnimator2 = this.createValueAnimation(n3, n4, l, AnimationType.Height);
            ValueAnimator valueAnimator3 = this.createValueAnimation(n5, n6, l, AnimationType.Radius);
            ValueAnimator valueAnimator4 = this.createValueAnimation(n4, n3, l, AnimationType.Height);
            ValueAnimator valueAnimator5 = this.createValueAnimation(n6, n5, l, AnimationType.Radius);
            ((AnimatorSet)this.animator).play((Animator)valueAnimator2).with((Animator)valueAnimator3).with((Animator)valueAnimator).before((Animator)valueAnimator4).before((Animator)valueAnimator5);
        }
        return this;
    }

    private static final class AnimationType
    extends Enum<AnimationType> {
        private static final /* synthetic */ AnimationType[] $VALUES;
        public static final /* enum */ AnimationType Height;
        public static final /* enum */ AnimationType Radius;
        public static final /* enum */ AnimationType Width;

        static {
            AnimationType animationType;
            AnimationType animationType2;
            AnimationType animationType3;
            Width = animationType = new AnimationType();
            Height = animationType2 = new AnimationType();
            Radius = animationType3 = new AnimationType();
            $VALUES = new AnimationType[]{animationType, animationType2, animationType3};
        }

        public static AnimationType valueOf(String string2) {
            return (AnimationType)Enum.valueOf(AnimationType.class, (String)string2);
        }

        public static AnimationType[] values() {
            return (AnimationType[])$VALUES.clone();
        }
    }

}

