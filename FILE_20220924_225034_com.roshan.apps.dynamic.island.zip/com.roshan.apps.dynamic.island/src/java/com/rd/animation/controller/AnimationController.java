/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.rd.animation.type.FillAnimation
 *  com.rd.animation.type.ScaleAnimation
 *  com.rd.animation.type.ScaleDownAnimation
 *  com.rd.animation.type.ThinWormAnimation
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.rd.animation.controller;

import com.rd.animation.controller.ValueController;
import com.rd.animation.data.Value;
import com.rd.animation.type.AnimationType;
import com.rd.animation.type.BaseAnimation;
import com.rd.animation.type.ColorAnimation;
import com.rd.animation.type.DropAnimation;
import com.rd.animation.type.FillAnimation;
import com.rd.animation.type.ScaleAnimation;
import com.rd.animation.type.ScaleDownAnimation;
import com.rd.animation.type.SlideAnimation;
import com.rd.animation.type.SwapAnimation;
import com.rd.animation.type.ThinWormAnimation;
import com.rd.animation.type.WormAnimation;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.utils.CoordinatesUtils;

public class AnimationController {
    private Indicator indicator;
    private boolean isInteractive;
    private ValueController.UpdateListener listener;
    private float progress;
    private BaseAnimation runningAnimation;
    private ValueController valueController;

    public AnimationController(Indicator indicator, ValueController.UpdateListener updateListener) {
        this.valueController = new ValueController(updateListener);
        this.listener = updateListener;
        this.indicator = indicator;
    }

    private void animate() {
        AnimationType animationType = this.indicator.getAnimationType();
        switch (1.$SwitchMap$com$rd$animation$type$AnimationType[animationType.ordinal()]) {
            default: {
                return;
            }
            case 10: {
                this.scaleDownAnimation();
                return;
            }
            case 9: {
                this.swapAnimation();
                return;
            }
            case 8: {
                this.dropAnimation();
                return;
            }
            case 7: {
                this.thinWormAnimation();
                return;
            }
            case 6: {
                this.slideAnimation();
                return;
            }
            case 5: {
                this.fillAnimation();
                return;
            }
            case 4: {
                this.wormAnimation();
                return;
            }
            case 3: {
                this.scaleAnimation();
                return;
            }
            case 2: {
                this.colorAnimation();
                return;
            }
            case 1: 
        }
        this.listener.onValueUpdated(null);
    }

    private void colorAnimation() {
        int n = this.indicator.getSelectedColor();
        int n2 = this.indicator.getUnselectedColor();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.color().with(n2, n).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void dropAnimation() {
        int n = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectedPosition() : this.indicator.getLastSelectedPosition();
        int n2 = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectingPosition() : this.indicator.getSelectedPosition();
        int n3 = CoordinatesUtils.getCoordinate(this.indicator, n);
        int n4 = CoordinatesUtils.getCoordinate(this.indicator, n2);
        int n5 = this.indicator.getPaddingTop();
        int n6 = this.indicator.getPaddingLeft();
        if (this.indicator.getOrientation() != Orientation.HORIZONTAL) {
            n5 = n6;
        }
        int n7 = this.indicator.getRadius();
        int n8 = n5 + n7 * 3;
        int n9 = n7 + n5;
        long l = this.indicator.getAnimationDuration();
        DropAnimation dropAnimation = ((DropAnimation)this.valueController.drop().duration(l)).with(n3, n4, n8, n9, n7);
        if (this.isInteractive) {
            ((BaseAnimation)dropAnimation).progress(this.progress);
        } else {
            dropAnimation.start();
        }
        this.runningAnimation = dropAnimation;
    }

    private void fillAnimation() {
        int n = this.indicator.getSelectedColor();
        int n2 = this.indicator.getUnselectedColor();
        int n3 = this.indicator.getRadius();
        int n4 = this.indicator.getStroke();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.fill().with(n2, n, n3, n4).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void scaleAnimation() {
        int n = this.indicator.getSelectedColor();
        int n2 = this.indicator.getUnselectedColor();
        int n3 = this.indicator.getRadius();
        float f = this.indicator.getScaleFactor();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.scale().with(n2, n, n3, f).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void scaleDownAnimation() {
        int n = this.indicator.getSelectedColor();
        int n2 = this.indicator.getUnselectedColor();
        int n3 = this.indicator.getRadius();
        float f = this.indicator.getScaleFactor();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.scaleDown().with(n2, n, n3, f).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void slideAnimation() {
        int n = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectedPosition() : this.indicator.getLastSelectedPosition();
        int n2 = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectingPosition() : this.indicator.getSelectedPosition();
        int n3 = CoordinatesUtils.getCoordinate(this.indicator, n);
        int n4 = CoordinatesUtils.getCoordinate(this.indicator, n2);
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.slide().with(n3, n4).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void swapAnimation() {
        int n = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectedPosition() : this.indicator.getLastSelectedPosition();
        int n2 = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectingPosition() : this.indicator.getSelectedPosition();
        int n3 = CoordinatesUtils.getCoordinate(this.indicator, n);
        int n4 = CoordinatesUtils.getCoordinate(this.indicator, n2);
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.swap().with(n3, n4).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void thinWormAnimation() {
        int n = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectedPosition() : this.indicator.getLastSelectedPosition();
        int n2 = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectingPosition() : this.indicator.getSelectedPosition();
        int n3 = CoordinatesUtils.getCoordinate(this.indicator, n);
        int n4 = CoordinatesUtils.getCoordinate(this.indicator, n2);
        boolean bl = n2 > n;
        int n5 = this.indicator.getRadius();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.thinWorm().with(n3, n4, n5, bl).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    private void wormAnimation() {
        int n = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectedPosition() : this.indicator.getLastSelectedPosition();
        int n2 = this.indicator.isInteractiveAnimation() ? this.indicator.getSelectingPosition() : this.indicator.getSelectedPosition();
        int n3 = CoordinatesUtils.getCoordinate(this.indicator, n);
        int n4 = CoordinatesUtils.getCoordinate(this.indicator, n2);
        boolean bl = n2 > n;
        int n5 = this.indicator.getRadius();
        long l = this.indicator.getAnimationDuration();
        BaseAnimation baseAnimation = this.valueController.worm().with(n3, n4, n5, bl).duration(l);
        if (this.isInteractive) {
            baseAnimation.progress(this.progress);
        } else {
            baseAnimation.start();
        }
        this.runningAnimation = baseAnimation;
    }

    public void basic() {
        this.isInteractive = false;
        this.progress = 0.0f;
        this.animate();
    }

    public void end() {
        BaseAnimation baseAnimation = this.runningAnimation;
        if (baseAnimation != null) {
            baseAnimation.end();
        }
    }

    public void interactive(float f) {
        this.isInteractive = true;
        this.progress = f;
        this.animate();
    }

}

