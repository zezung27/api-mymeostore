/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.rd.animation.data.type;

import com.rd.animation.data.Value;

public class SwapAnimationValue
implements Value {
    private int coordinate;
    private int coordinateReverse;

    public int getCoordinate() {
        return this.coordinate;
    }

    public int getCoordinateReverse() {
        return this.coordinateReverse;
    }

    public void setCoordinate(int n) {
        this.coordinate = n;
    }

    public void setCoordinateReverse(int n) {
        this.coordinateReverse = n;
    }
}

