/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.rd.animation.data.type;

import com.rd.animation.data.Value;

public class WormAnimationValue
implements Value {
    private int rectEnd;
    private int rectStart;

    public int getRectEnd() {
        return this.rectEnd;
    }

    public int getRectStart() {
        return this.rectStart;
    }

    public void setRectEnd(int n) {
        this.rectEnd = n;
    }

    public void setRectStart(int n) {
        this.rectStart = n;
    }
}

