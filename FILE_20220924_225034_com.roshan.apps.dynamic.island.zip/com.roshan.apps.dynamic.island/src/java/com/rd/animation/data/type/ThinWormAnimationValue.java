/*
 * Decompiled with CFR 0.0.
 */
package com.rd.animation.data.type;

import com.rd.animation.data.Value;
import com.rd.animation.data.type.WormAnimationValue;

public class ThinWormAnimationValue
extends WormAnimationValue
implements Value {
    private int height;

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int n) {
        this.height = n;
    }
}

