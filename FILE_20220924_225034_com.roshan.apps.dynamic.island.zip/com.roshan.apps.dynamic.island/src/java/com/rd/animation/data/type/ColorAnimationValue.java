/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.rd.animation.data.type;

import com.rd.animation.data.Value;

public class ColorAnimationValue
implements Value {
    private int color;
    private int colorReverse;

    public int getColor() {
        return this.color;
    }

    public int getColorReverse() {
        return this.colorReverse;
    }

    public void setColor(int n) {
        this.color = n;
    }

    public void setColorReverse(int n) {
        this.colorReverse = n;
    }
}

