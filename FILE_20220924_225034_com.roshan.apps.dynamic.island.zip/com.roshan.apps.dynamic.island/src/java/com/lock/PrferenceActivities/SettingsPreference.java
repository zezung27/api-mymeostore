/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.Window
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  androidx.preference.PreferenceFragmentCompat
 *  java.lang.String
 */
package com.lock.PrferenceActivities;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsPreference
extends AppCompatActivity {
    public static String name;

    protected void onCreate(Bundle bundle) {
        this.setTheme(2131951985);
        super.onCreate(bundle);
        this.setContentView(2131558428);
        name = this.getIntent().getStringExtra("name");
        int n = Build.VERSION.SDK_INT;
        if (n < 23) {
            this.getWindow().setStatusBarColor(-3355444);
        } else if ((48 & this.getResources().getConfiguration().uiMode) == 32) {
            this.getWindow().setStatusBarColor(-16777216);
            if (n >= 26) {
                this.getWindow().setNavigationBarColor(-16777216);
            }
        } else {
            View view = this.getWindow().getDecorView();
            int n2 = n >= 26 ? 16 : 0;
            view.setSystemUiVisibility(n2 | 8192);
            if (n >= 26) {
                this.getWindow().setNavigationBarColor(this.getResources().getColor(2131099759, this.getTheme()));
            }
        }
        this.getSupportFragmentManager().beginTransaction().replace(2131362301, (Fragment)new SettingsPreferenceFragment()).commit();
    }

    public static class SettingsPreferenceFragment
    extends PreferenceFragmentCompat {
        public void onCreate(Bundle bundle) {
            super.onCreate(bundle);
            if (SettingsPreference.name.equalsIgnoreCase("Data")) {
                this.addPreferencesFromResource(2132082696);
            }
            if (SettingsPreference.name.equalsIgnoreCase("Layout")) {
                this.addPreferencesFromResource(2132082694);
            }
            if (SettingsPreference.name.equalsIgnoreCase("Color")) {
                this.addPreferencesFromResource(2132082691);
            }
            if (SettingsPreference.name.equalsIgnoreCase("Popup")) {
                this.addPreferencesFromResource(2132082695);
            }
            if (SettingsPreference.name.equalsIgnoreCase("Extra")) {
                this.addPreferencesFromResource(2132082693);
            }
            if (SettingsPreference.name.equalsIgnoreCase("EdgeTrigger")) {
                this.addPreferencesFromResource(2132082692);
            }
        }

        public void onCreatePreferences(Bundle bundle, String string) {
        }
    }

}

