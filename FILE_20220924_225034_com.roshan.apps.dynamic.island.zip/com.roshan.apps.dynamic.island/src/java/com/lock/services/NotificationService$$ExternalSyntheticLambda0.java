/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.service.notification.StatusBarNotification
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.services;

import android.service.notification.StatusBarNotification;
import com.lock.services.NotificationService;

public final class NotificationService$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ NotificationService f$0;
    public final /* synthetic */ StatusBarNotification f$1;

    public /* synthetic */ NotificationService$$ExternalSyntheticLambda0(NotificationService notificationService, StatusBarNotification statusBarNotification) {
        this.f$0 = notificationService;
        this.f$1 = statusBarNotification;
    }

    public final void run() {
        this.f$0.lambda$onNotificationRemoved$2$com-lock-services-NotificationService(this.f$1);
    }
}

