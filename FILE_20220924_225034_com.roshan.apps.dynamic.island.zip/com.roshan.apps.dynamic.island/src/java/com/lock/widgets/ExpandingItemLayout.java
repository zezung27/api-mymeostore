/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.AnimatorListenerAdapter
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.ViewPropertyAnimator
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  android.view.animation.AccelerateInterpolator
 *  android.view.animation.DecelerateInterpolator
 *  android.view.animation.Interpolator
 *  android.widget.LinearLayout
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.widgets;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import com.lock.widgets.MyAnimatorUpdateListner;

public class ExpandingItemLayout
extends LinearLayout {
    public static final int f11403m;
    public boolean isVisible;

    public ExpandingItemLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final void b() {
        int n = this.isVisible ? 0 : 8;
        for (int i = 1; i < this.getChildCount(); ++i) {
            this.getChildAt(i).setVisibility(n);
        }
    }

    public final void expandItem(boolean bl) {
        int n;
        int n2;
        if (bl) {
            ViewGroup viewGroup = (ViewGroup)this.getParent();
            for (int i = 0; i < viewGroup.getChildCount(); ++i) {
                View view = viewGroup.getChildAt(i);
                if (view == this || !(view instanceof ExpandingItemLayout)) continue;
                ExpandingItemLayout expandingItemLayout = (ExpandingItemLayout)view;
                if (!expandingItemLayout.isVisible) continue;
                expandingItemLayout.expandItem(false);
            }
        }
        boolean bl2 = this.isVisible;
        this.isVisible = bl2 ^ n;
        ViewPropertyAnimator viewPropertyAnimator = this.findViewById(2131362060).animate();
        float f = this.isVisible ? -180.0f : 180.0f;
        viewPropertyAnimator.rotationBy(f).setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator()).setDuration(200L).withEndAction((Runnable)new MyExpendRunable(this));
        int n3 = this.getHeight();
        if (this.isVisible) {
            this.b();
            n2 = this.getChildAt(0).getHeight();
            int n4 = View.MeasureSpec.makeMeasureSpec((int)this.getChildAt(0).getWidth(), (int)1073741824);
            for (n = 1; n < this.getChildCount(); ++n) {
                this.getChildAt(n).measure(n4, 0);
                n2 += this.getChildAt(n).getMeasuredHeight();
            }
        } else {
            n2 = this.getChildAt(0).getHeight();
        }
        this.getLayoutParams().height = n3;
        float f2 = this.isVisible ? 8.0f : 1.0f;
        AccelerateInterpolator accelerateInterpolator = new AccelerateInterpolator(f2);
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])new float[]{0.0f, 1.0f});
        valueAnimator.addUpdateListener((ValueAnimator.AnimatorUpdateListener)new MyAnimatorUpdateListner(this, (Interpolator)accelerateInterpolator, n3, n2));
        valueAnimator.setInterpolator((TimeInterpolator)new DecelerateInterpolator());
        valueAnimator.setDuration(250L);
        if (!this.isVisible) {
            valueAnimator.addListener((Animator.AnimatorListener)new AnimationEndListener());
        }
        valueAnimator.start();
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.getChildAt(0).setOnClickListener((View.OnClickListener)new onItemClickListner());
    }

    public class AnimationEndListener
    extends AnimatorListenerAdapter {
        public void onAnimationEnd(Animator animator2) {
            ExpandingItemLayout.this.b();
            ExpandingItemLayout.this.getLayoutParams().height = -2;
        }
    }

    public static final class MyExpendRunable
    implements Runnable {
        public final ExpandingItemLayout expandingItemLayout;

        public MyExpendRunable(ExpandingItemLayout expandingItemLayout) {
            this.expandingItemLayout = expandingItemLayout;
        }

        public final void run() {
            this.expandingItemLayout.getChildAt(0).setEnabled(true);
        }
    }

    public class onItemClickListner
    implements View.OnClickListener {
        public void onClick(View view) {
            view.setEnabled(false);
            ExpandingItemLayout.this.expandItem(true);
        }
    }

}

