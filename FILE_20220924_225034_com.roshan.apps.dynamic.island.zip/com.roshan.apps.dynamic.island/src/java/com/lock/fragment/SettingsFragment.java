/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.WallpaperManager
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.location.LocationManager
 *  android.net.Uri
 *  android.net.wifi.WifiManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.provider.Settings
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.ImageView
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.RadioGroup$OnCheckedChangeListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  android.widget.ToggleButton
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.core.content.ContextCompat
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.request.target.CustomTarget
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.transition.Transition
 *  com.google.android.gms.ads.AdListener
 *  com.google.android.gms.ads.AdLoader
 *  com.google.android.gms.ads.AdLoader$Builder
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.VideoOptions
 *  com.google.android.gms.ads.VideoOptions$Builder
 *  com.google.android.gms.ads.nativead.NativeAd
 *  com.google.android.gms.ads.nativead.NativeAd$OnNativeAdLoadedListener
 *  com.google.android.gms.ads.nativead.NativeAdOptions
 *  com.google.android.gms.ads.nativead.NativeAdOptions$Builder
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.lock.fragment;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.lock.Controllers.LocationSettingController;
import com.lock.PrferenceActivities.SettingsPreference;
import com.lock.activites.HelpActivity;
import com.lock.activites.HomeActivity;
import com.lock.activites.PrivacyPolicyActivity;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.fragment.SettingsFragment;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda0;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda1;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda10;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda11;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda2;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda3;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda4;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda5;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda6;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda7;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda8;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda9;
import com.lock.utils.Constants;
import com.lock.utils.MySettings;
import com.lock.utils.RatingDialog;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerDialog;
import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.flag.BubbleFlag;
import com.skydoves.colorpickerview.flag.FlagView;
import com.skydoves.colorpickerview.listeners.ColorPickerViewListener;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SettingsFragment
extends Fragment
implements View.OnClickListener {
    View backgroung_rl;
    Context context;
    private ToggleButton enable_controls_gesture;
    LocationManager locationManager;
    private NativeAd mNativeAd;
    RelativeLayout more_rl;
    PrefManager prefManager;
    RelativeLayout rateus_rl;
    RelativeLayout share_rl;
    TextView textViewBackgroundGallery;
    private ToggleButton toggle_hide_in_full_screen;
    private ToggleButton toggle_show_on_lock;
    TextView tv_more;
    TextView tv_rateus;
    private TextView tv_remove_ads;
    TextView tv_share;
    Typeface typefaceBold;
    private View viw;

    static /* synthetic */ View access$000(SettingsFragment settingsFragment) {
        return settingsFragment.viw;
    }

    static /* synthetic */ void access$100(SettingsFragment settingsFragment, View view) {
        settingsFragment.refreshNativeAd(view);
    }

    static /* synthetic */ NativeAd access$200(SettingsFragment settingsFragment) {
        return settingsFragment.mNativeAd;
    }

    static /* synthetic */ NativeAd access$202(SettingsFragment settingsFragment, NativeAd nativeAd) {
        settingsFragment.mNativeAd = nativeAd;
        return nativeAd;
    }

    private void checkMethod() {
        LocationSettingController locationSettingController = new LocationSettingController((Context)this.getActivity());
        Toast.makeText((Context)this.getActivity(), (CharSequence)("Name: " + locationSettingController.getName()), (int)0).show();
    }

    private void disableLockToggle() {
        MySettings.setLockscreen(false, this.context);
    }

    private void enableLockToggle() {
        MySettings.setLockscreen(true, this.context);
    }

    private void getPrivateFunc(boolean bl) {
        void var4_10;
        WallpaperManager.getInstance((Context)this.getActivity());
        WifiManager wifiManager = (WifiManager)this.getActivity().getApplicationContext().getSystemService("wifi");
        try {
            Class class_ = wifiManager.getClass();
            Class[] arrclass = new Class[]{Boolean.TYPE};
            Method method = class_.getMethod("setWifiEnabled", arrclass);
            Object[] arrobject = new Object[]{bl};
            method.invoke((Object)wifiManager, arrobject);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
            // empty catch block
        }
        var4_10.printStackTrace();
    }

    static /* synthetic */ void lambda$onClick$11(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
    }

    private void refreshNativeAd(View view) {
        AdLoader.Builder builder = new AdLoader.Builder(this.context, this.getString(2131886121));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener(this, view){
            final /* synthetic */ SettingsFragment this$0;
            final /* synthetic */ View val$view;
            {
                this.this$0 = settingsFragment;
                this.val$view = view;
            }

            public void onNativeAdLoaded(NativeAd nativeAd) {
                try {
                    if (SettingsFragment.access$200(this.this$0) != null) {
                        SettingsFragment.access$200(this.this$0).destroy();
                    }
                    SettingsFragment.access$202(this.this$0, nativeAd);
                    android.widget.FrameLayout frameLayout = (android.widget.FrameLayout)this.val$view.findViewById(2131362074);
                    com.google.android.gms.ads.nativead.NativeAdView nativeAdView = (com.google.android.gms.ads.nativead.NativeAdView)this.this$0.getLayoutInflater().inflate(2131558436, null);
                    Constants.populateNativeAdView(SettingsFragment.access$200(this.this$0), new com.lock.adaptar.NativeAdViewHolder((View)nativeAdView).getAdView());
                    frameLayout.removeAllViews();
                    frameLayout.addView((View)nativeAdView);
                    this.val$view.findViewById(2131362171).setVisibility(0);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)this.this$0.context, (CharSequence)((Object)((Object)exception) + ""), (int)1).show();
                    return;
                }
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(videoOptions).build());
        builder.withAdListener(new AdListener(this, view){
            final /* synthetic */ SettingsFragment this$0;
            final /* synthetic */ View val$view;
            {
                this.this$0 = settingsFragment;
                this.val$view = view;
            }

            public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                this.val$view.findViewById(2131362074).setVisibility(8);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    private void setLayoutColor(ColorEnvelope colorEnvelope) {
        ((ImageView)this.viw.findViewById(2131362149)).setColorFilter(colorEnvelope.getColor());
        new PrefManager((Context)this.getActivity()).setKeyDefaultColor(colorEnvelope.getColor());
        if (Constants.getRatingDailoge(this.context)) {
            new RatingDialog((Activity)((HomeActivity)this.context)).showDialog();
        }
    }

    private void showHelpScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), HelpActivity.class));
    }

    private void showPrivacyScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), PrivacyPolicyActivity.class));
    }

    public void askForPermission() {
        if (ContextCompat.checkSelfPermission((Context)this.getActivity(), (String)"android.permission.MODIFY_PHONE_STATE") == 0) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            String[] arrstring = new String[]{"android.permission.MODIFY_PHONE_STATE"};
            this.getActivity().requestPermissions(arrstring, 69);
        }
    }

    public void getCustomAppBackground() {
        ImagePicker.with(this).crop().compress(1024).maxResultSize(1080, 1920).start();
    }

    /* synthetic */ void lambda$onClick$10$com-lock-fragment-SettingsFragment(ColorEnvelope colorEnvelope, boolean bl) {
        this.setLayoutColor(colorEnvelope);
    }

    /* synthetic */ void lambda$onViewCreated$0$com-lock-fragment-SettingsFragment(View view) {
        this.getCustomAppBackground();
    }

    /* synthetic */ void lambda$onViewCreated$1$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.setControlEnabled(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$2$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.setShowOnLock(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$3$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.SetShowInFullScreen(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$4$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131362279) {
            this.prefManager.setCameraCount(1);
            return;
        }
        if (n == 2131362518) {
            this.prefManager.setCameraCount(2);
            return;
        }
        if (n == 2131362473) {
            this.prefManager.setCameraCount(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$5$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131362160) {
            this.prefManager.setCameraPos(1);
            return;
        }
        if (n == 2131361944) {
            this.prefManager.setCameraPos(2);
            return;
        }
        if (n == 2131362334) {
            this.prefManager.setCameraPos(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$6$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362562)).getText().toString();
        if (Integer.parseInt((String)string) < 20) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362562)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$7$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362562)).getText().toString();
        if (Integer.parseInt((String)string) >= 1) {
            int n = Integer.parseInt((String)string) - 1;
            ((TextView)view.findViewById(2131362562)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$8$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362559)).getText().toString();
        if (Integer.parseInt((String)string) < 40) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362559)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$9$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362559)).getText().toString();
        if (Integer.parseInt((String)string) >= 25) {
            int n = -1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362559)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        String string;
        Uri uri;
        if (intent != null && (uri = intent.getData()) != null && new File(string = uri.getPath()).exists()) {
            Glide.with((Context)this.context).asBitmap().load(string).into((Target)new CustomTarget<Bitmap>(){

                public void onLoadCleared(Drawable drawable) {
                }

                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                    if (bitmap.getWidth() > 300) {
                        Utils.saveToInternalSorage((Context)SettingsFragment.this.getActivity(), bitmap);
                    }
                }
            });
        }
        if (n == 1133) {
            Uri uri2;
            String string2;
            if (intent != null && (uri2 = intent.getData()) != null && (string2 = Constants.getPathFromUri(this.context, uri2)) != null && new File(string2).exists()) {
                Glide.with((Context)this.context).asBitmap().load(string2).into((Target)new CustomTarget<Bitmap>(){

                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        Utils.saveImage(bitmap);
                    }
                });
                return;
            }
        } else if (n == 9 && Build.VERSION.SDK_INT >= 23) {
            if (Settings.canDrawOverlays((Context)this.context)) {
                this.enableLockToggle();
                return;
            }
            this.disableLockToggle();
        }
    }

    public void onClick(View view) {
        Intent intent = new Intent((Context)this.getActivity(), SettingsPreference.class);
        switch (view.getId()) {
            default: {
                break;
            }
            case 2131362511: {
                intent.putExtra("name", "Popup");
                break;
            }
            case 2131362509: {
                intent.putExtra("name", "Layout");
                break;
            }
            case 2131362507: {
                intent.putExtra("name", "Extra");
                break;
            }
            case 2131362505: {
                intent.putExtra("name", "EdgeTrigger");
                break;
            }
            case 2131362504: {
                intent.putExtra("name", "Data");
                break;
            }
            case 2131362503: {
                intent.putExtra("name", "Color");
                break;
            }
            case 2131362307: {
                this.showPrivacyScreen();
                return;
            }
            case 2131362101: {
                this.showHelpScreen();
                return;
            }
            case 2131361995: {
                AlertDialog.Builder builder = new ColorPickerDialog.Builder(this.context).setTitle("Pick tiles color").setPositiveButton((CharSequence)this.getString(2131886172), (ColorPickerViewListener)new SettingsFragment$$ExternalSyntheticLambda1(this)).setNegativeButton(this.getString(2131886144), (DialogInterface.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda2());
                builder.getColorPickerView().setFlagView(new BubbleFlag(this.context));
                builder.show();
                return;
            }
        }
        this.startActivity(intent);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(2131558466, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        int n;
        ToggleButton toggleButton;
        ToggleButton toggleButton2;
        RelativeLayout relativeLayout;
        TextView textView;
        RelativeLayout relativeLayout2;
        ToggleButton toggleButton3;
        RelativeLayout relativeLayout3;
        super.onViewCreated(view, bundle);
        this.context = this.getActivity();
        this.prefManager = new PrefManager(this.context);
        this.textViewBackgroundGallery = (TextView)view.findViewById(2131362456);
        this.viw = view;
        this.typefaceBold = Typeface.createFromAsset((AssetManager)this.context.getAssets(), (String)"roboto_medium.ttf");
        view.findViewById(2131362101).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131362307).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131361995).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131361992).setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda0(this));
        this.enable_controls_gesture = toggleButton2 = (ToggleButton)view.findViewById(2131362049);
        toggleButton2.setChecked(Constants.getControlEnabled(this.context));
        this.enable_controls_gesture.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda3(this));
        this.toggle_show_on_lock = toggleButton = (ToggleButton)view.findViewById(2131362485);
        toggleButton.setChecked(Constants.getShowOnLock(this.context));
        this.toggle_show_on_lock.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda4(this));
        this.toggle_hide_in_full_screen = toggleButton3 = (ToggleButton)view.findViewById(2131362483);
        toggleButton3.setChecked(Constants.getShowInFullScreen(this.context));
        this.toggle_hide_in_full_screen.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda5(this));
        ((ImageView)view.findViewById(2131362149)).setColorFilter(this.prefManager.getDefaultColor());
        this.locationManager = (LocationManager)this.context.getSystemService("location");
        this.backgroung_rl = view.findViewById(2131361939);
        this.tv_remove_ads = textView = (TextView)view.findViewById(2131362513);
        textView.setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362517)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361993)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362457)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362515)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362508)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362100)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361934)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361935)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362492)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362491)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362562)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362559)).setTypeface(this.typefaceBold);
        this.tv_rateus = (TextView)view.findViewById(2131362512);
        this.tv_more = (TextView)view.findViewById(2131362510);
        this.tv_share = (TextView)view.findViewById(2131362514);
        this.rateus_rl = relativeLayout2 = (RelativeLayout)view.findViewById(2131362317);
        relativeLayout2.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((String)("market://details?id=" + this.this$0.context.getPackageName())));
                this.this$0.startActivity(intent);
            }
        });
        this.share_rl = relativeLayout3 = (RelativeLayout)view.findViewById(2131362375);
        relativeLayout3.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                this.this$0.shareLink("https://play.google.com/store/apps/details?id=" + this.this$0.context.getApplicationInfo().packageName);
            }
        });
        this.more_rl = relativeLayout = (RelativeLayout)view.findViewById(2131362218);
        relativeLayout.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                try {
                    this.this$0.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.this$0.context.getString(2131886117)))));
                    return;
                }
                catch (android.content.ActivityNotFoundException activityNotFoundException) {
                    this.this$0.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.this$0.context.getString(2131886117)))));
                    return;
                }
            }
        });
        this.tv_share.setTypeface(this.typefaceBold);
        this.tv_rateus.setTypeface(this.typefaceBold);
        this.tv_more.setTypeface(this.typefaceBold);
        this.textViewBackgroundGallery.setTypeface(this.typefaceBold);
        this.backgroung_rl.setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                Intent intent = new Intent(this.this$0.context, com.lock.background.WallpapersCategoryActivity.class);
                this.this$0.startActivity(intent);
            }
        });
        ((RelativeLayout)view.findViewById(2131362328)).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                ((HomeActivity)this.this$0.context).onRemoveAdButtonClicked();
            }
        });
        this.enable_controls_gesture.postDelayed(new Runnable(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            /*
             * Exception decompiling
             */
            public void run(}
        java.lang.IllegalStateException: Parameters not created
        
        