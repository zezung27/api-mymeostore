/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.widget.ScrollView
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.System
 */
package com.lock.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class CustomScrollView
extends ScrollView {
    private long lastScrollUpdate = -1L;
    private boolean mScrollable = true;

    public CustomScrollView(Context context) {
        super(context);
    }

    public CustomScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public CustomScrollView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    public CustomScrollView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
    }

    private void onScrollEnd() {
    }

    private void onScrollStart() {
    }

    public boolean isScrollable() {
        return this.mScrollable;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.mScrollable && super.onInterceptTouchEvent(motionEvent);
    }

    protected void onScrollChanged(int n, int n2, int n3, int n4) {
        super.onScrollChanged(n, n2, n3, n4);
        if (this.lastScrollUpdate == -1L) {
            this.onScrollStart();
            this.postDelayed((Runnable)new ScrollStateHandler(), 100L);
        }
        this.lastScrollUpdate = System.currentTimeMillis();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int n = motionEvent.getAction();
        if (n != 0 && n != 2) {
            return super.onTouchEvent(motionEvent);
        }
        return this.mScrollable && super.onTouchEvent(motionEvent);
    }

    public void setScrollingEnabled(boolean bl) {
        this.mScrollable = bl;
    }

    private class ScrollStateHandler
    implements Runnable {
        private ScrollStateHandler() {
        }

        public void run() {
            if (System.currentTimeMillis() - CustomScrollView.this.lastScrollUpdate > 100L) {
                CustomScrollView.this.lastScrollUpdate = -1L;
                CustomScrollView.this.onScrollEnd();
                return;
            }
            CustomScrollView.this.postDelayed((Runnable)this, 100L);
        }
    }

}

