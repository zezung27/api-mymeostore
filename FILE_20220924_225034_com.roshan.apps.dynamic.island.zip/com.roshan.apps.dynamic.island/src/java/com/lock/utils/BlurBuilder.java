/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.renderscript.Allocation
 *  android.renderscript.Element
 *  android.renderscript.RenderScript
 *  android.renderscript.ScriptIntrinsicBlur
 *  java.lang.Object
 */
package com.lock.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

public class BlurBuilder {
    private static final float BITMAP_SCALE = 0.1f;
    private static final float BLUR_RADIUS = 25.5f;

    public static Bitmap blur(Context context, Bitmap bitmap) {
        Bitmap bitmap2 = Bitmap.createScaledBitmap((Bitmap)bitmap, (int)bitmap.getWidth(), (int)bitmap.getHeight(), (boolean)false);
        Bitmap bitmap3 = Bitmap.createBitmap((Bitmap)bitmap2);
        RenderScript renderScript = RenderScript.create((Context)context);
        ScriptIntrinsicBlur scriptIntrinsicBlur = ScriptIntrinsicBlur.create((RenderScript)renderScript, (Element)Element.U8_4((RenderScript)renderScript));
        Allocation allocation = Allocation.createFromBitmap((RenderScript)renderScript, (Bitmap)bitmap2);
        Allocation allocation2 = Allocation.createFromBitmap((RenderScript)renderScript, (Bitmap)bitmap3);
        scriptIntrinsicBlur.setRadius(25.5f);
        scriptIntrinsicBlur.setInput(allocation);
        scriptIntrinsicBlur.forEach(allocation2);
        allocation2.copyTo(bitmap3);
        bitmap2.recycle();
        return bitmap3;
    }
}

