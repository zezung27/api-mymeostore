/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.app.Notification
 *  android.app.Notification$BigTextStyle
 *  android.app.Notification$Builder
 *  android.app.Notification$Style
 *  android.app.NotificationChannel
 *  android.app.NotificationManager
 *  android.app.Service
 *  android.bluetooth.BluetoothAdapter
 *  android.content.ActivityNotFoundException
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.BitmapFactory
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffColorFilter
 *  android.graphics.drawable.Drawable
 *  android.location.LocationManager
 *  android.media.AudioAttributes
 *  android.media.AudioManager
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.net.wifi.WifiManager
 *  android.os.BatteryManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcelable
 *  android.os.Vibrator
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  android.provider.Settings$SettingNotFoundException
 *  android.provider.Settings$System
 *  android.telephony.TelephonyManager
 *  android.text.format.DateFormat
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.WindowManager
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.widget.AppCompatSeekBar
 *  androidx.core.content.ContextCompat
 *  androidx.core.view.ViewCompat
 *  com.google.android.material.shape.MaterialShapeDrawable
 *  com.google.android.material.shape.ShapeAppearanceModel
 *  com.google.android.material.shape.ShapeAppearanceModel$Builder
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.Objects
 */
package com.lock.utils;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Parcelable;
import android.os.Vibrator;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.lock.background.PrefManager;
import com.lock.entity.ButtonState;
import com.lock.utils.Constants;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;

public class Utils {
    public static final String COLOR_UPDATE = "COLOR_UPDATE";
    private static final int DAY_MILLIS = 86400000;
    public static final String FROM_NOTIFICATION_SERVICE = "from_notification_service";
    private static final int HOUR_MILLIS = 3600000;
    private static final int MINUTE_MILLIS = 60000;
    private static final int SECOND_MILLIS = 1000;
    public Context context;
    boolean isLocationEnabled = false;
    private int titleTextColor;

    public Utils(Context context) {
        this.context = context;
        this.titleTextColor = new PrefManager(context).getDefaultColor();
    }

    public static boolean checkIfActivityFound(Context context, Intent intent) {
        return context.getPackageManager().resolveActivity(intent, 0) != null;
    }

    public void animateViewAlpha(final View view, final float f) {
        float[] arrf = new float[]{view.getAlpha(), f};
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                float f = ((Float)valueAnimator.getAnimatedValue()).floatValue();
                view.setAlpha(f);
            }
        });
        valueAnimator.addListener(new Animator.AnimatorListener(){

            public void onAnimationCancel(Animator animator2) {
            }

            public void onAnimationEnd(Animator animator2) {
                if (f == 0.0f) {
                    view.setVisibility(8);
                }
            }

            public void onAnimationRepeat(Animator animator2) {
            }

            public void onAnimationStart(Animator animator2) {
                if (f == 1.0f) {
                    view.setAlpha(0.0f);
                    view.setVisibility(0);
                }
            }
        });
        valueAnimator.setDuration(250L);
        valueAnimator.start();
    }

    public void animateViewHeight(final View view, int n) {
        int[] arrn = new int[]{view.getMeasuredHeight(), n};
        ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])arrn);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int n = (Integer)valueAnimator.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.height = n;
                view.setLayoutParams(layoutParams);
            }
        });
        valueAnimator.setDuration(250L);
        valueAnimator.start();
    }

    public void animateViewWeightSum(final LinearLayout linearLayout, float f) {
        float[] arrf = new float[]{linearLayout.getWeightSum(), f};
        ValueAnimator valueAnimator = ValueAnimator.ofFloat((float[])arrf);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(){

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                Float f = (Float)valueAnimator.getAnimatedValue();
                linearLayout.setWeightSum(f.floatValue());
                linearLayout.requestLayout();
            }
        });
        valueAnimator.setDuration(250L);
        valueAnimator.start();
    }

    public void applyRoundCorner(View view) {
        MaterialShapeDrawable materialShapeDrawable = new MaterialShapeDrawable(new ShapeAppearanceModel().toBuilder().setAllCorners(0, this.convertDpToPixel(10.0f, this.context)).build());
        materialShapeDrawable.setFillColor(ContextCompat.getColorStateList((Context)this.context, (int)2131100563));
        ViewCompat.setBackground((View)view, (Drawable)materialShapeDrawable);
    }

    public void changeSoundMode(Context context, boolean bl, LottieAnimationView lottieAnimationView) {
        TextView textView = (TextView)((RelativeLayout)lottieAnimationView.getParent()).getChildAt(1);
        AudioManager audioManager = (AudioManager)context.getSystemService("audio");
        int n = audioManager != null ? audioManager.getRingerMode() : 0;
        Vibrator vibrator = (Vibrator)context.getSystemService("vibrator");
        boolean bl2 = vibrator != null ? vibrator.hasVibrator() : false;
        if (audioManager != null) {
            if (bl2) {
                if (n == 2) {
                    if (bl) {
                        audioManager.setRingerMode(0);
                        textView.setText((CharSequence)"Mute");
                        this.setLottiViewState(lottieAnimationView, "sound", "mute", false);
                        return;
                    }
                    textView.setText((CharSequence)"Sound");
                    this.setLottiViewState(lottieAnimationView, "start", "sound", true);
                    return;
                }
                if (n == 0) {
                    if (bl) {
                        audioManager.setRingerMode(1);
                        textView.setText((CharSequence)"Vibrate");
                        this.setLottiViewState(lottieAnimationView, "mute", "viberate", false);
                        return;
                    }
                    textView.setText((CharSequence)"Mute");
                    this.setLottiViewState(lottieAnimationView, "sound", "mute", false);
                    return;
                }
                if (n == 1) {
                    if (bl) {
                        audioManager.setRingerMode(2);
                        textView.setText((CharSequence)"Sound");
                        this.setLottiViewState(lottieAnimationView, "start", "sound", true);
                        return;
                    }
                    textView.setText((CharSequence)"Vibrate");
                    this.setLottiViewState(lottieAnimationView, "mute", "viberate", false);
                    return;
                }
            } else {
                if (n == 2) {
                    if (bl) {
                        audioManager.setRingerMode(0);
                        textView.setText((CharSequence)"Mute");
                        this.setLottiViewState(lottieAnimationView, "sound", "mute", false);
                        return;
                    }
                    textView.setText((CharSequence)"Sound");
                    this.setLottiViewState(lottieAnimationView, "start", "sound", true);
                    return;
                }
                if (n == 0) {
                    if (bl) {
                        audioManager.setRingerMode(2);
                        textView.setText((CharSequence)"Sound");
                        this.setLottiViewState(lottieAnimationView, "start", "sound", true);
                        return;
                    }
                    textView.setText((CharSequence)"Mute");
                    this.setLottiViewState(lottieAnimationView, "sound", "mute", false);
                }
            }
        }
    }

    public float convertDpToPixel(float f, Context context) {
        return f * ((float)context.getResources().getDisplayMetrics().densityDpi / 160.0f);
    }

    public float convertPixelsToDp(float f, Context context) {
        return f / ((float)context.getResources().getDisplayMetrics().densityDpi / 160.0f);
    }

    public int getBatteryLevel() {
        return ((BatteryManager)this.context.getSystemService("batterymanager")).getIntProperty(4);
    }

    public Bitmap getBitmapFromByteArray(byte[] arrby) {
        if (arrby != null) {
            return BitmapFactory.decodeByteArray((byte[])arrby, (int)0, (int)arrby.length);
        }
        return null;
    }

    public void getBoxBrightness(AppCompatSeekBar appCompatSeekBar, Context context) {
        float f;
        int n;
        try {
            n = Settings.System.getInt((ContentResolver)context.getContentResolver(), (String)"screen_brightness");
        }
        catch (Settings.SettingNotFoundException settingNotFoundException) {
            settingNotFoundException.printStackTrace();
            f = 0.0f;
        }
        f = n;
        appCompatSeekBar.setProgress((int)f);
    }

    public int getBrightMode(Context context) {
        try {
            int n = Settings.System.getInt((ContentResolver)context.getContentResolver(), (String)"screen_brightness_mode");
            return n;
        }
        catch (Exception exception) {
            Log.d((String)"tag", (String)exception.toString());
            return 0;
        }
    }

    /*
     * Exception decompiling
     */
    public ButtonState getButtonSate(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl332.1 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public ArrayList<ButtonState> getButtonsList() {
        ArrayList arrayList = new ArrayList((Collection)Arrays.asList((Object[])(this.context.getString(2131886359) + this.context.getResources().getString(2131886360)).split(",")));
        ArrayList arrayList2 = new ArrayList();
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            ButtonState buttonState = this.getButtonSate((String)iterator.next());
            if (buttonState == null) continue;
            arrayList2.add((Object)buttonState);
        }
        return arrayList2;
    }

    public boolean getDndState() {
        AudioManager audioManager = (AudioManager)this.context.getSystemService("audio");
        int n = audioManager != null ? audioManager.getRingerMode() : 0;
        return n == 0;
    }

    public String getFormatedDate(long l) {
        long l2 = Calendar.getInstance().getTimeInMillis();
        if (l <= l2 && l > 0L) {
            long l3 = l2 - l;
            if (l3 < 60000L) {
                return "now";
            }
            if (l3 < 120000L) {
                return "1m";
            }
            if (l3 < 3000000L) {
                return l3 / 60000L + " m";
            }
            if (l3 < 5400000L) {
                return "1h";
            }
            if (l3 < 86400000L) {
                return l3 / 3600000L + " h";
            }
            if (l3 < 172800000L) {
                return "1d";
            }
            return l3 / 86400000L + " d";
        }
        return null;
    }

    public String getFormatedDate1(long l) {
        Calendar calendar = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTimeInMillis(l);
        if (calendar2.get(1) == calendar.get(1)) {
            if (calendar2.get(2) == calendar.get(2)) {
                if (calendar2.get(5) - calendar.get(5) == 1) {
                    return "Tomorrow at " + (Object)DateFormat.format((CharSequence)"HH:mm", (Calendar)calendar2);
                }
                if (calendar.get(5) == calendar2.get(5)) {
                    return "Today at " + (Object)DateFormat.format((CharSequence)"HH:mm", (Calendar)calendar2);
                }
                if (calendar.get(5) - calendar2.get(5) == 1) {
                    return "Yesterday at " + (Object)DateFormat.format((CharSequence)"HH:mm", (Calendar)calendar2);
                }
                return DateFormat.format((CharSequence)"MMMM d, HH:mm", (Calendar)calendar2).toString();
            }
            return DateFormat.format((CharSequence)"MMMM d, HH:mm", (Calendar)calendar2).toString();
        }
        return DateFormat.format((CharSequence)"MMMM dd yyyy, HH:mm", (Calendar)calendar2).toString();
    }

    public int getHeight(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getRealMetrics(displayMetrics);
        return displayMetrics.heightPixels;
    }

    public boolean getMobileDataState(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
            boolean bl = (Boolean)telephonyManager.getClass().getDeclaredMethod("getDataEnabled", new Class[0]).invoke((Object)telephonyManager, new Object[0]);
            return bl;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    public int getStatusBarHeight(Resources resources) {
        int n = resources.getIdentifier("android:dimen/status_bar_height", null, null);
        if (n > 0) {
            return resources.getDimensionPixelOffset(n);
        }
        int n2 = Build.VERSION.SDK_INT >= 23 ? 24 : 25;
        return (int)Math.ceil((double)((float)n2 * resources.getDisplayMetrics().density));
    }

    public int getTileColor() {
        return this.titleTextColor;
    }

    public int getTitleTextColor() {
        return this.titleTextColor;
    }

    public int getWidth(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getRealMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    public void gpsstate(Context context, LottieAnimationView lottieAnimationView) {
        if (((LocationManager)context.getSystemService("location")).isProviderEnabled("gps")) {
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            this.isLocationEnabled = true;
            return;
        }
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
        this.isLocationEnabled = false;
    }

    public void isAirplaneModeOn(Context context, LottieAnimationView lottieAnimationView, LottieAnimationView lottieAnimationView2) {
        boolean bl = Settings.Global.getInt((ContentResolver)context.getContentResolver(), (String)"airplane_mode_on", (int)0) != 0;
        if (bl) {
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            this.setLottiViewState(lottieAnimationView2, "start", "mid", true);
            return;
        }
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
        this.setLottiViewState(lottieAnimationView2, "mid", "end", false);
    }

    public boolean isAirplaneModeOn(Context context) {
        return Settings.Global.getInt((ContentResolver)context.getContentResolver(), (String)"airplane_mode_on", (int)0) != 0;
    }

    public void isAutoRotateOn(Context context, LottieAnimationView lottieAnimationView, LottieAnimationView lottieAnimationView2) {
        boolean bl = Settings.System.getInt((ContentResolver)context.getContentResolver(), (String)"accelerometer_rotation", (int)0) == 1;
        if (!bl) {
            Constants.setAutoOrientationEnabled(context, true);
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            this.setLottiViewState(lottieAnimationView2, "start", "mid", true);
            return;
        }
        Constants.setAutoOrientationEnabled(context, false);
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
        this.setLottiViewState(lottieAnimationView2, "mid", "end", false);
    }

    public void isBluetoothOn(LottieAnimationView lottieAnimationView) {
        if (BluetoothAdapter.getDefaultAdapter() != null) {
            if (BluetoothAdapter.getDefaultAdapter().isEnabled()) {
                this.setLottiViewState(lottieAnimationView, "start", "mid", true);
                return;
            }
            this.setLottiViewState(lottieAnimationView, "mid", "end", false);
            return;
        }
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
    }

    public boolean isConnectedToNetwork() {
        NetworkInfo networkInfo = ((ConnectivityManager)this.context.getSystemService("connectivity")).getActiveNetworkInfo();
        return networkInfo.isConnected() && networkInfo.getType() == 0;
    }

    public boolean isHotspotOn(Context context) {
        WifiManager wifiManager = (WifiManager)context.getApplicationContext().getSystemService("wifi");
        try {
            Method method = Class.forName((String)wifiManager.getClass().getName()).getDeclaredMethod("getWifiApState", new Class[0]);
            method.setAccessible(true);
            (Object[])null;
            int n = (Integer)method.invoke((Object)wifiManager, null);
            if (n == 11) {
                return false;
            }
            if (n == 13) {
                return true;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    public boolean isMobileDataEnable(Context context) {
        boolean bl;
        ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService("connectivity");
        bl = false;
        try {
            Method method = Class.forName((String)connectivityManager.getClass().getName()).getDeclaredMethod("getMobileDataEnabled", new Class[0]);
            method.setAccessible(true);
            bl = (Boolean)method.invoke((Object)connectivityManager, new Object[0]);
        }
        catch (Exception exception) {}
        return bl;
    }

    public boolean isSimPresent() {
        return ((TelephonyManager)this.context.getSystemService("phone")).getSimState() == 5;
    }

    public boolean isSupportHardwareCamera(Context context) {
        return context.getPackageManager().hasSystemFeature("android.hardware.camera.flash");
    }

    public boolean isWifiOn(Context context) {
        WifiManager wifiManager = (WifiManager)context.getApplicationContext().getSystemService("wifi");
        try {
            Method method = Class.forName((String)wifiManager.getClass().getName()).getDeclaredMethod("isWifiEnabled", new Class[0]);
            method.setAccessible(true);
            boolean bl = (Boolean)method.invoke((Object)wifiManager, new Object[0]);
            return bl;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    public boolean isWifiOn(Intent intent, LottieAnimationView lottieAnimationView) {
        if (((NetworkInfo)intent.getParcelableExtra("networkInfo")).isConnected()) {
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            return true;
        }
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
        return false;
    }

    public void mobilecheack(Context context, LottieAnimationView lottieAnimationView) {
        if (this.getMobileDataState(context)) {
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            return;
        }
        this.setLottiViewState(lottieAnimationView, "start", "mid", false);
    }

    public void modifyAirplanemode(Context context) {
        try {
            Intent intent = new Intent("android.settings.WIRELESS_SETTINGS");
            intent.setFlags(268435456);
            context.startActivity(intent);
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            Log.e((String)"exception", (String)((Object)((Object)activityNotFoundException) + ""));
            return;
        }
    }

    public void openDirectory(Uri uri) {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT_TREE");
        intent.addFlags(1);
        intent.putExtra("android.provider.extra.INITIAL_URI", (Parcelable)uri);
        this.context.startActivity(intent);
    }

    public void setBatteryImage(LottieAnimationView lottieAnimationView, boolean bl) {
        if (!bl) {
            lottieAnimationView.setMinAndMaxFrame("" + this.getBatteryLevel() / 10);
            this.setLottieAnimColor(lottieAnimationView, this.context.getResources().getColor(2131100448));
            return;
        }
        lottieAnimationView.setMinAndMaxFrame("charging");
        this.setLottieAnimColor(lottieAnimationView, this.context.getResources().getColor(2131100448));
    }

    public void setBrightness(int n, Context context) {
        if (this.getBrightMode(context) == 1) {
            Settings.System.putInt((ContentResolver)context.getContentResolver(), (String)"screen_brightness_mode", (int)0);
        }
        Settings.System.putInt((ContentResolver)context.getContentResolver(), (String)"screen_brightness", (int)n);
    }

    public void setLottiViewState(LottieAnimationView lottieAnimationView, String string2, String string3, boolean bl) {
    }

    public void setLottieAnimColor(LottieAnimationView lottieAnimationView, final int n) {
        lottieAnimationView.addValueCallback(new KeyPath("**"), LottieProperty.COLOR_FILTER, new SimpleLottieValueCallback<ColorFilter>(){

            @Override
            public ColorFilter getValue(LottieFrameInfo<ColorFilter> lottieFrameInfo) {
                return new PorterDuffColorFilter(n, PorterDuff.Mode.SRC_ATOP);
            }
        });
    }

    public void setMobileDataState(boolean bl, Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager)context.getSystemService("phone");
            Class class_ = ((TelephonyManager)Objects.requireNonNull((Object)telephonyManager)).getClass();
            Class[] arrclass = new Class[]{Boolean.TYPE};
            Method method = class_.getDeclaredMethod("setDataEnabled", arrclass);
            Object[] arrobject = new Object[]{bl};
            method.invoke((Object)telephonyManager, arrobject);
            return;
        }
        catch (Exception exception) {
            Log.e((String)"MainActivity", (String)"Error setting mobile data state", (Throwable)exception);
            return;
        }
    }

    public void setTileColor(int n) {
        this.titleTextColor = n;
    }

    public void setWifiState(boolean bl, LottieAnimationView lottieAnimationView) {
        if (bl) {
            this.setLottiViewState(lottieAnimationView, "start", "mid", true);
            return;
        }
        this.setLottiViewState(lottieAnimationView, "mid", "end", false);
    }

    public void startAppNotificationSetting(Context context) {
        Intent intent = new Intent("android.settings.ALL_APPS_NOTIFICATION_SETTINGS");
        if (context.getPackageManager().resolveActivity(intent, 0) == null) {
            intent.setAction("android.settings.APPLICATION_SETTINGS");
        }
        intent.setFlags(268435456);
        try {
            this.context.startActivity(intent);
            return;
        }
        catch (Exception exception) {
            Toast.makeText((Context)context, (CharSequence)"Setting not found!", (int)1).show();
            return;
        }
    }

    public void startForegroundService(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            Service service = (Service)context;
            NotificationManager notificationManager = (NotificationManager)context.getSystemService(NotificationManager.class);
            if (notificationManager.getNotificationChannel("FOREGROUND_INFO") == null) {
                NotificationChannel notificationChannel = new NotificationChannel("FOREGROUND_INFO", (CharSequence)"Keep Alive", 2);
                notificationChannel.setSound(null, null);
                notificationChannel.setVibrationPattern(null);
                notificationChannel.setShowBadge(false);
                notificationChannel.setDescription("Useful to keep the app running in the background");
                notificationManager.createNotificationChannel(notificationChannel);
            }
            Notification.BigTextStyle bigTextStyle = new Notification.BigTextStyle().setSummaryText((CharSequence)"Keep Alive");
            Notification.Builder builder = new Notification.Builder(context, "FOREGROUND_INFO");
            builder.setSmallIcon(2131230962);
            builder.setColor(context.getResources().getColor(2131099754));
            builder.setStyle((Notification.Style)bigTextStyle).setContentTitle((CharSequence)"Running").setContentText((CharSequence)"This notification helps to keep the app running");
            builder.setPriority(-1);
            service.startForeground(99, builder.build());
        }
    }

    public void stopForegroundService(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            ((Service)context).stopForeground(true);
        }
    }

}

