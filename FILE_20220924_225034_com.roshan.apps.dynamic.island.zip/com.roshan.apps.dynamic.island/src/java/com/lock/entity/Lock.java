/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.lock.entity;

import com.lock.entity.LockData;
import java.io.Serializable;
import java.util.ArrayList;

public class Lock
implements Serializable {
    ArrayList<LockData> AppLock;

    public ArrayList<LockData> getAppLock() {
        return this.AppLock;
    }

    public void setAppLock(ArrayList<LockData> arrayList) {
        this.AppLock = arrayList;
    }
}

