/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.entity;

public class ThemeData {
    public String bgColor;
    public String downloads;
    public String icon;
    public String id;
    public String image;
    public String name;
    public String pkg;
    public float rating;
    public String txtColor;

    public String getBgColor() {
        return this.bgColor;
    }

    public String getDownloads() {
        return this.downloads;
    }

    public String getIcon() {
        return this.icon;
    }

    public String getId() {
        return this.id;
    }

    public String getImage() {
        return this.image;
    }

    public String getName() {
        return this.name;
    }

    public String getPkg() {
        return this.pkg;
    }

    public float getRating() {
        return this.rating;
    }

    public String getTxtColor() {
        return this.txtColor;
    }

    public void setBgColor(String string2) {
        this.bgColor = string2;
    }

    public void setDownloads(String string2) {
        this.downloads = string2;
    }

    public void setIcon(String string2) {
        this.icon = string2;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setImage(String string2) {
        this.image = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setPkg(String string2) {
        this.pkg = string2;
    }

    public void setRating(float f) {
        this.rating = f;
    }

    public void setTxtColor(String string2) {
        this.txtColor = string2;
    }
}

