/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.entity;

public class LockData {
    public String id;
    public String image;
    public String name;
    public String pkg;

    public String getId() {
        return this.id;
    }

    public String getImage() {
        return this.image;
    }

    public String getName() {
        return this.name;
    }

    public String getPkg() {
        return this.pkg;
    }

    public void setId(String string2) {
        this.id = string2;
    }

    public void setImage(String string2) {
        this.image = string2;
    }

    public void setName(String string2) {
        this.name = string2;
    }

    public void setPkg(String string2) {
        this.pkg = string2;
    }
}

