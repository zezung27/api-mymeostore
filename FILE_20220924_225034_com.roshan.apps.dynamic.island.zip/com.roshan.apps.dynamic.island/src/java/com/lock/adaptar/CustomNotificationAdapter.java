/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.app.PendingIntent$CanceledException
 *  android.app.RemoteInput
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.text.Editable
 *  android.view.KeyEvent
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.widget.Chronometer
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  java.util.Set
 */
package com.lock.adaptar;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda0;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import de.hdodenhof.circleimageview.CircleImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

public class CustomNotificationAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private static final int DAY_MILLIS = 86400000;
    private static final int HOUR_MILLIS = 3600000;
    private static final int MINUTE_MILLIS = 60000;
    private static final int SECOND_MILLIS = 1000;
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    private Utils utils;
    ViewGroup viewGroup;

    public CustomNotificationAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
        this.utils = ((MAccessibilityService)context).utils;
    }

    private void addSubItemsToGroupContainer(final Notification notification, LinearLayout linearLayout) {
        CustomNotificationAdapter customNotificationAdapter = this;
        for (final String string2 : notification.keyMap.keySet()) {
            if (notification.keyMap.get((Object)string2) != null) {
                View view = LayoutInflater.from((Context)customNotificationAdapter.mContext).inflate(2131558529, null);
                TextView textView = (TextView)view.findViewById(2131362502);
                TextView textView2 = (TextView)view.findViewById(2131362516);
                final TextView textView3 = (TextView)view.findViewById(2131362425);
                CircleImageView circleImageView = (CircleImageView)view.findViewById(2131361960);
                final LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131362267);
                final RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131362271);
                final ImageView imageView = (ImageView)view.findViewById(2131361898);
                ImageView imageView2 = (ImageView)view.findViewById(2131362272);
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon != null) {
                    circleImageView.setVisibility(0);
                    circleImageView.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).senderIcon);
                } else {
                    circleImageView.setImageResource(0);
                    circleImageView.setVisibility(8);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    imageView2.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    imageView2.setImageBitmap(null);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture != null) {
                    ((ImageView)view.findViewById(2131362272)).setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).picture);
                } else {
                    ((ImageView)view.findViewById(2131362272)).setImageBitmap(null);
                }
                textView.setText((CharSequence)((MAccessibilityService)customNotificationAdapter.mContext).utils.getFormatedDate(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).postTime));
                textView2.setText(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_title);
                textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions == null && ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                    imageView.setVisibility(8);
                } else {
                    imageView.setVisibility(0);
                }
                View.OnClickListener onClickListener = new View.OnClickListener(){

                    public void onClick(View view) {
                        if (linearLayout2.getVisibility() == 0) {
                            imageView.setImageResource(2131230828);
                            linearLayout2.setVisibility(8);
                            relativeLayout.setVisibility(8);
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).tv_text.toString());
                            return;
                        }
                        if (!((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString().isEmpty()) {
                            textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).bigText.toString());
                        }
                        imageView.setImageResource(2131230829);
                        linearLayout2.setVisibility(0);
                        linearLayout2.removeAllViews();
                        if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).actions != null) {
                            new Handler().post(new Runnable(){

                                public void run() {
                                    linearLayout2.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.this.mContext));
                                    CustomNotificationAdapter.this.addViewToActionContainer((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2))), linearLayout2);
                                }
                            });
                            return;
                        }
                        linearLayout2.setPadding(0, 0, 0, 0);
                    }

                };
                imageView.setOnClickListener(onClickListener);
                view.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda0(notification, string2, linearLayout, view));
                linearLayout.addView(view);
            }
            customNotificationAdapter = this;
        }
    }

    private void addTitleAndTextSubItems(Notification notification, LinearLayout linearLayout) {
        for (String string2 : notification.keyMap.keySet()) {
            Notification notification2 = (Notification)notification.keyMap.get((Object)string2);
            if (notification.keyMap.size() == 1) {
                if (notification.tv_text.equals((Object)notification2.tv_text)) continue;
                linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
                continue;
            }
            linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
        }
    }

    private void addViewToActionContainer(final Notification notification, final LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        for (int i = 0; i < notification.actions.size(); ++i) {
            TextView textView = (TextView)LayoutInflater.from((Context)this.mContext).inflate(2131558525, null);
            Drawable drawable2 = ResourcesCompat.getDrawable((Resources)this.mContext.getResources(), (int)2131230921, null);
            try {
                drawable2 = ContextCompat.getDrawable((Context)this.mContext.createPackageContext(notification.pack, 0), (int)((ActionParsable)notification.actions.get((int)i)).actionIcon);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            textView.setText(((ActionParsable)notification.actions.get((int)i)).charSequence);
            textView.setTextColor(-1);
            if (notification.template.equals((Object)"MediaStyle")) {
                drawable2.setTint(-1);
                textView.setCompoundDrawablesWithIntrinsicBounds(drawable2, null, null, null);
                textView.setText((CharSequence)"");
            }
            if (i > 0) {
                textView.setPadding(50, 5, 5, 5);
            }
            linearLayout.addView((View)textView);
            textView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    new Handler().post(new Runnable(){

                        public void run() {
                            if (((ActionParsable)notification.actions.get((int)i)).remoteInputs != null) {
                                CustomNotificationAdapter.this.showReplyBox((View)linearLayout, (ArrayList<ActionParsable>)notification.actions, i);
                                return;
                            }
                            try {
                                if (((ActionParsable)notification.actions.get((int)i)).pendingIntent != null) {
                                    ((ActionParsable)notification.actions.get((int)i)).pendingIntent.send();
                                }
                                if (!notification.template.equals((Object)"MediaStyle")) {
                                    ((ImageView)((RelativeLayout)linearLayout.getParent().getParent()).findViewById(2131361898)).setImageResource(2131230828);
                                    linearLayout.setVisibility(8);
                                    return;
                                }
                            }
                            catch (Exception exception) {
                                exception.printStackTrace();
                            }
                        }
                    });
                }

            });
        }
    }

    private View getTitleAndTextViewForSubItems(CharSequence charSequence, CharSequence charSequence2) {
        LinearLayout linearLayout = (LinearLayout)LayoutInflater.from((Context)this.mContext).inflate(2131558532, null);
        int n = (int)Constants.convertDpToPixel(5.0f, this.mContext);
        if (charSequence.toString().isEmpty()) {
            linearLayout.findViewById(2131362139).setVisibility(8);
            linearLayout.findViewById(2131362140).setPadding(0, n, n, n);
        } else {
            ((TextView)linearLayout.findViewById(2131362139)).setText((CharSequence)charSequence.toString());
        }
        if (charSequence2.toString().isEmpty()) {
            linearLayout.findViewById(2131362140).setVisibility(8);
            return linearLayout;
        }
        ((TextView)linearLayout.findViewById(2131362140)).setText((CharSequence)charSequence2.toString());
        return linearLayout;
    }

    static /* synthetic */ void lambda$addSubItemsToGroupContainer$0(Notification notification, String string2, LinearLayout linearLayout, View view, View view2) {
        try {
            if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent != null) {
                ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string2)))).pendingIntent.send();
                linearLayout.removeView(view);
                notification.keyMap.remove((Object)string2);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void sendRemoteInput(PendingIntent pendingIntent, RemoteInput[] arrremoteInput, RemoteInput remoteInput, String string2) {
        Bundle bundle = new Bundle();
        bundle.putString(remoteInput.getResultKey(), string2);
        Intent intent = new Intent().addFlags(268435456);
        RemoteInput.addResultsToIntent((RemoteInput[])arrremoteInput, (Intent)intent, (Bundle)bundle);
        if (Build.VERSION.SDK_INT >= 28) {
            if (remoteInput.getAllowFreeFormInput()) {
                RemoteInput.setResultsSource((Intent)intent, (int)0);
            } else {
                RemoteInput.setResultsSource((Intent)intent, (int)1);
            }
        }
        try {
            pendingIntent.send(this.mContext, 0, intent);
            return;
        }
        catch (PendingIntent.CanceledException canceledException) {
            canceledException.printStackTrace();
            return;
        }
    }

    private void showReplyBox(final View view, final ArrayList<ActionParsable> arrayList, final int n) {
        final View view2 = ((LinearLayout)view.getParent()).getChildAt(0);
        if (view2 != null) {
            view2.setVisibility(0);
            view2.findViewById(2131362148).setVisibility(0);
            view2.findViewById(2131362148).setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    CustomNotificationAdapter.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362041)).getText().toString());
                    ((EditText)view2.findViewById(2131362041)).setText((CharSequence)"");
                    view2.setVisibility(8);
                    view.setVisibility(8);
                }
            });
            EditText editText = (EditText)view2.findViewById(2131362041);
            TextView.OnEditorActionListener onEditorActionListener = new TextView.OnEditorActionListener(){

                public boolean onEditorAction(TextView textView, int n2, KeyEvent keyEvent) {
                    boolean bl = false;
                    if (n2 == 4) {
                        CustomNotificationAdapter.this.sendRemoteInput(((ActionParsable)arrayList.get((int)n)).pendingIntent, ((ActionParsable)arrayList.get((int)n)).remoteInputs, ((ActionParsable)arrayList.get((int)n)).remoteInputs[0], ((EditText)view2.findViewById(2131362041)).getText().toString());
                        ((EditText)view2.findViewById(2131362041)).setText((CharSequence)"");
                        view2.setVisibility(8);
                        view.setVisibility(8);
                        bl = true;
                    }
                    return bl;
                }
            };
            editText.setOnEditorActionListener(onEditorActionListener);
        }
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        viewHolder.itemView.setOnLongClickListener(null);
        viewHolder.itemView.setLongClickable(false);
        final Notification notification = (Notification)this.notifications.get(viewHolder.getAbsoluteAdapterPosition());
        if (notification.picture != null && notification.keyMap.size() == 0) {
            viewHolder.picture_iv.setImageBitmap(notification.picture);
        } else {
            viewHolder.picture_iv.setImageBitmap(null);
        }
        viewHolder.tv_title.setText((CharSequence)notification.app_name);
        viewHolder.tv_title.setTag((Object)notification.isClearable);
        viewHolder.tv_text.setText(notification.tv_title);
        viewHolder.sub_text.setText((CharSequence)notification.tv_text.toString());
        viewHolder.group_message_parent.removeAllViews();
        this.addTitleAndTextSubItems(notification, viewHolder.group_message_parent);
        viewHolder.notification_action_container.setVisibility(8);
        viewHolder.notification_material_reply_container.setVisibility(8);
        if (notification.icon != null) {
            viewHolder.iv_app_icon.setVisibility(0);
            viewHolder.iv_app_icon.setImageBitmap(notification.icon);
        }
        if (notification.senderIcon != null) {
            viewHolder.iv_senderIcon2.setVisibility(4);
            viewHolder.iv_sender_icon.setVisibility(0);
            viewHolder.iv_sender_icon.setImageBitmap(notification.senderIcon);
            viewHolder.iv_sender_icon.setColorFilter(null);
        } else {
            viewHolder.iv_senderIcon2.setImageBitmap(notification.icon);
            viewHolder.iv_senderIcon2.setColorFilter(-1);
            viewHolder.iv_senderIcon2.setVisibility(0);
            viewHolder.iv_sender_icon.setVisibility(4);
            viewHolder.iv_app_icon.setVisibility(4);
        }
        if (notification.progressMax > 0) {
            if (notification.showChronometer) {
                viewHolder.chronometer.setVisibility(0);
                viewHolder.chronometer.start();
            } else {
                viewHolder.chronometer.setVisibility(8);
                viewHolder.chronometer.setBase(SystemClock.elapsedRealtime());
                viewHolder.chronometer.stop();
            }
            viewHolder.progressBar.setVisibility(0);
            viewHolder.progressBar.setMax(notification.progressMax);
            viewHolder.progressBar.setProgress(notification.progress);
            viewHolder.progressBar.setIndeterminate(notification.progressIndeterminate);
        } else {
            viewHolder.progressBar.setVisibility(8);
            viewHolder.chronometer.setVisibility(8);
            viewHolder.chronometer.setBase(SystemClock.elapsedRealtime());
            viewHolder.chronometer.stop();
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                try {
                    if (((Notification)CustomNotificationAdapter.access$900((CustomNotificationAdapter)CustomNotificationAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).pendingIntent != null) {
                        ((Notification)CustomNotificationAdapter.access$900((CustomNotificationAdapter)CustomNotificationAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).pendingIntent.send();
                        CustomNotificationAdapter.this.notificationListener.onItemClicked((Notification)CustomNotificationAdapter.this.notifications.get(viewHolder.getAbsoluteAdapterPosition()));
                    }
                    if (((Notification)CustomNotificationAdapter.access$900((CustomNotificationAdapter)CustomNotificationAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).isClearable) {
                        CustomNotificationAdapter.this.notifications.remove(viewHolder.getAbsoluteAdapterPosition());
                        CustomNotificationAdapter.this.notifyDataSetChanged();
                    }
                    ((MAccessibilityService)CustomNotificationAdapter.this.mContext).closeFullNotificationIsland();
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
                viewHolder.arrow_iv.setImageResource(2131230828);
                viewHolder.notification_action_container.setVisibility(8);
            }
        });
        if (notification.keyMap.size() <= 0 && (notification.bigText.toString().isEmpty() || notification.bigText.toString().equals((Object)notification.tv_text.toString())) && notification.actions == null) {
            viewHolder.arrow_iv.setVisibility(4);
        } else {
            viewHolder.arrow_iv.setVisibility(0);
            viewHolder.arrow_iv.setImageResource(2131230828);
        }
        if (((Notification)this.notifications.get((int)viewHolder.getAbsoluteAdapterPosition())).template.equals((Object)"MediaStyle")) {
            viewHolder.arrow_iv.setVisibility(4);
            viewHolder.notification_action_container.setVisibility(0);
            viewHolder.notification_action_container.removeAllViews();
            this.addViewToActionContainer(notification, viewHolder.notification_action_container);
        }
        viewHolder.arrow_iv.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (viewHolder.notification_action_container.getVisibility() == 0) {
                    viewHolder.arrow_iv.setImageResource(2131230828);
                    viewHolder.notification_action_container.setVisibility(8);
                    viewHolder.notification_material_reply_container.setVisibility(8);
                    viewHolder.sub_text.setText((CharSequence)((Notification)CustomNotificationAdapter.access$900((CustomNotificationAdapter)CustomNotificationAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).tv_text.toString());
                    viewHolder.group_message_parent.removeAllViews();
                    CustomNotificationAdapter.this.addTitleAndTextSubItems(notification, viewHolder.group_message_parent);
                    return;
                }
                if (!notification.bigText.toString().isEmpty()) {
                    viewHolder.sub_text.setText((CharSequence)((Notification)CustomNotificationAdapter.access$900((CustomNotificationAdapter)CustomNotificationAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).bigText.toString());
                }
                viewHolder.arrow_iv.setImageResource(2131230829);
                viewHolder.notification_action_container.setVisibility(0);
                viewHolder.notification_action_container.removeAllViews();
                viewHolder.group_message_parent.removeAllViews();
                if (notification.actions != null) {
                    CustomNotificationAdapter.this.addViewToActionContainer(notification, viewHolder.notification_action_container);
                    viewHolder.notification_action_container.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.this.mContext), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.this.mContext));
                    return;
                }
                CustomNotificationAdapter.this.addSubItemsToGroupContainer(notification, viewHolder.group_message_parent);
                viewHolder.notification_action_container.setPadding(0, 0, 0, 0);
            }
        });
        viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener(){

            public boolean onLongClick(View view) {
                return false;
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        return new ViewHolder(layoutInflater.inflate(2131558528, viewGroup, false));
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        viewHolder.clearAnimation();
        super.onViewDetachedFromWindow((RecyclerView.ViewHolder)viewHolder);
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView arrow_iv;
        private final Chronometer chronometer;
        private final View divider;
        private final LinearLayout group_message_parent;
        private final ImageView iv_app_icon;
        ImageView iv_senderIcon2;
        CircleImageView iv_sender_icon;
        private final View mRootLayout;
        private final LinearLayout notification_action_container;
        private final RelativeLayout notification_material_reply_container;
        private final ImageView picture_iv;
        private final ProgressBar progressBar;
        private final TextView sub_text;
        private final TextView tv_text;
        public final TextView tv_title;

        public ViewHolder(View view) {
            super(view);
            this.mRootLayout = view;
            this.progressBar = (ProgressBar)view.findViewById(2131362424);
            this.chronometer = (Chronometer)view.findViewById(2131361958);
            this.iv_app_icon = (ImageView)view.findViewById(2131362142);
            this.tv_title = (TextView)view.findViewById(2131362502);
            this.tv_text = (TextView)view.findViewById(2131362516);
            this.divider = view.findViewById(2131362021);
            this.iv_sender_icon = (CircleImageView)view.findViewById(2131361960);
            this.notification_action_container = (LinearLayout)view.findViewById(2131362267);
            this.notification_material_reply_container = (RelativeLayout)view.findViewById(2131362271);
            this.arrow_iv = (ImageView)view.findViewById(2131361898);
            this.sub_text = (TextView)view.findViewById(2131362425);
            this.picture_iv = (ImageView)view.findViewById(2131362272);
            this.group_message_parent = (LinearLayout)view.findViewById(2131362093);
            this.iv_senderIcon2 = (ImageView)view.findViewById(2131361961);
        }

        public void clearAnimation() {
            this.mRootLayout.clearAnimation();
        }
    }

}

