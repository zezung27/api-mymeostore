/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.entity.Notification;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.utils.Utils;
import java.util.ArrayList;

public class CustomNotificationIconAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    ViewGroup viewGroup;

    public CustomNotificationIconAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        viewHolder.itemView.setOnLongClickListener(null);
        viewHolder.itemView.setLongClickable(false);
        viewHolder.island_small_text_left.setTextColor(((MAccessibilityService)this.mContext).utils.getTileColor());
        viewHolder.island_small_text_right.setTextColor(((MAccessibilityService)this.mContext).utils.getTileColor());
        Notification notification = (Notification)this.notifications.get(viewHolder.getAbsoluteAdapterPosition());
        if (notification.icon != null) {
            viewHolder.island_small_left_iv.setImageBitmap(notification.icon);
            viewHolder.island_small_left_iv.setColorFilter(-1);
            viewHolder.island_small_text_left.setText((CharSequence)((MAccessibilityService)this.mContext).utils.getFormatedDate(notification.postTime));
        } else {
            viewHolder.island_small_left_iv.setImageBitmap(null);
        }
        if (notification.senderIcon != null) {
            viewHolder.island_small_image_right.setVisibility(0);
            viewHolder.island_small_text_right.setVisibility(8);
            viewHolder.island_small_image_right.setImageBitmap(notification.senderIcon);
        } else {
            viewHolder.island_small_image_right.setImageResource(0);
            viewHolder.island_small_image_right.setVisibility(8);
            if (notification.tv_title != null && notification.tv_title.length() > 0) {
                viewHolder.island_small_text_right.setVisibility(0);
                viewHolder.island_small_text_right.setText((CharSequence)notification.tv_title.toString().split(" ")[0]);
            } else {
                viewHolder.island_small_text_right.setVisibility(8);
            }
        }
        viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                CustomNotificationIconAdapter.this.notificationListener.onItemClicked((Notification)CustomNotificationIconAdapter.this.notifications.get(viewHolder.getAbsoluteAdapterPosition()));
                CustomNotificationIconAdapter.this.notificationListener.onItemClicked((Notification)CustomNotificationIconAdapter.this.notifications.get(viewHolder.getAbsoluteAdapterPosition()), viewHolder.getAbsoluteAdapterPosition());
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        return new ViewHolder(layoutInflater.inflate(2131558527, viewGroup, false));
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        viewHolder.clearAnimation();
        super.onViewDetachedFromWindow((RecyclerView.ViewHolder)viewHolder);
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView island_small_image_right;
        private final ImageView island_small_left_iv;
        private final TextView island_small_text_left;
        private final TextView island_small_text_right;
        private final View mRootLayout;

        public ViewHolder(View view) {
            super(view);
            this.mRootLayout = view;
            this.island_small_left_iv = (ImageView)view.findViewById(2131362134);
            this.island_small_text_left = (TextView)view.findViewById(2131362135);
            this.island_small_image_right = (ImageView)view.findViewById(2131362133);
            this.island_small_text_right = (TextView)view.findViewById(2131362136);
        }

        public void clearAnimation() {
            this.mRootLayout.clearAnimation();
        }
    }

}

