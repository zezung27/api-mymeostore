/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.hardware.camera2.CameraAccessException
 *  android.hardware.camera2.CameraCharacteristics
 *  android.hardware.camera2.CameraCharacteristics$Key
 *  android.hardware.camera2.CameraManager
 *  android.hardware.camera2.CameraManager$TorchCallback
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Message
 *  android.util.Log
 *  android.widget.Toast
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.lock.Controllers;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class CameraFlashController {
    public boolean aBoolean1;
    public String cameraId;
    public final CameraManager cameraManager;
    public final Context context;
    public Handler handler;
    public boolean isEnabled = false;
    public final CameraManager.TorchCallback torchCallback = new TorchCallBack();

    public CameraFlashController(Context context) {
        this.context = context;
        this.cameraManager = (CameraManager)context.getSystemService("camera");
        this.initTorch();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void initTorch() {
        block9 : {
            String string2;
            block8 : {
                for (String string3 : this.cameraManager.getCameraIdList()) {
                    CameraCharacteristics cameraCharacteristics = this.cameraManager.getCameraCharacteristics(string3);
                    Boolean bl = (Boolean)cameraCharacteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    Integer n = (Integer)cameraCharacteristics.get(CameraCharacteristics.LENS_FACING);
                    if (bl == null || !bl.booleanValue() || n == null || n != 1) continue;
                    string2 = string3;
                    break block8;
                }
                string2 = null;
            }
            this.cameraId = string2;
            if (string2 == null) return;
            CameraFlashController cameraFlashController = this;
            // MONITORENTER : cameraFlashController
            if (this.handler != null) break block9;
            this.handler = new Handler(new Handler.Callback(){

                public boolean handleMessage(Message message) {
                    return false;
                }
            });
        }
        // MONITOREXIT : cameraFlashController
        try {
            this.cameraManager.registerTorchCallback(this.torchCallback, this.handler);
            return;
        }
        catch (Throwable throwable) {
            Toast.makeText((Context)this.context, (CharSequence)"FlashlightController: Couldn't initialize.", (int)0).show();
            Log.e((String)"FlashlightController", (String)"Couldn't initialize.", (Throwable)throwable);
        }
    }

    public boolean isEnabled() {
        CameraFlashController cameraFlashController = this;
        synchronized (cameraFlashController) {
            boolean bl = this.isEnabled;
            return bl;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void setTorchMode(boolean bl) {
        CameraFlashController cameraFlashController = this;
        synchronized (cameraFlashController) {
            String string2 = this.cameraId;
            if (string2 != null && this.isEnabled != bl) {
                this.isEnabled = bl;
                try {
                    this.cameraManager.setTorchMode(string2, bl);
                }
                catch (CameraAccessException cameraAccessException) {
                    Toast.makeText((Context)this.context, (CharSequence)"FlashlightController: Couldn't set torch mode", (int)0).show();
                    Log.e((String)"FlashlightController", (String)"Couldn't set torch mode", (Throwable)cameraAccessException);
                    this.isEnabled = false;
                }
            }
            return;
        }
    }

    public class TorchCallBack
    extends CameraManager.TorchCallback {
        public void onTorchModeChanged(String string2, boolean bl) {
        }

        public void onTorchModeUnavailable(String string2) {
        }
    }

}

