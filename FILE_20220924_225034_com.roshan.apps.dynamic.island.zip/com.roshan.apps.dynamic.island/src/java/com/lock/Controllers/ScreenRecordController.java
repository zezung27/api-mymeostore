/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.widget.TextView
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class ScreenRecordController
extends ButtonState {
    private Context context;

    public ScreenRecordController(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return null;
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131886388);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231020);
            return;
        }
        lottieAnimationView.setImageResource(2131231019);
    }
}

