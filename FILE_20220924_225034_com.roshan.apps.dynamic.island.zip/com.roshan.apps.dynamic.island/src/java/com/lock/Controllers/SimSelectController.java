/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.telephony.SubscriptionInfo
 *  android.telephony.SubscriptionManager
 *  android.widget.TextView
 *  androidx.core.app.ActivityCompat
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 */
package com.lock.Controllers;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;
import java.lang.reflect.Method;

public class SimSelectController
extends ButtonState {
    int INVALID_SUBSCRIPTION_ID = -1;
    private final Context context;
    public final Intent intent;
    public final boolean isOnePlus = Build.MANUFACTURER.toLowerCase().contains((CharSequence)"plus");
    public final SubscriptionManager subscriptionManager;

    public SimSelectController(Context context, SubscriptionManager subscriptionManager) {
        Intent intent;
        super(context);
        this.context = context;
        this.intent = intent = new Intent();
        this.subscriptionManager = subscriptionManager;
        PackageManager packageManager = context.getPackageManager();
        intent.setComponent(new ComponentName("com.qualcomm.qti.simsettings", "com.qualcomm.qti.simsettings.SimSettingsActivity"));
        if (packageManager.resolveActivity(intent, 0) == null) {
            intent.setComponent(new ComponentName("com.sec.android.app.simsettingmgr", "com.sec.android.app.simsettingmgr.NetworkManagement"));
            if (packageManager.resolveActivity(intent, 0) == null) {
                intent.setComponent(new ComponentName("com.samsung.android.app.telephonyui", "com.samsung.android.app.telephonyui.netsettings.ui.simcardmanager.SimCardMgrActivity"));
                if (packageManager.resolveActivity(intent, 0) == null) {
                    intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.DualCardSettings"));
                    if (packageManager.resolveActivity(intent, 0) == null) {
                        intent.setComponent(null);
                        if (Build.VERSION.SDK_INT >= 29) {
                            intent.setAction("android.settings.AIRPLANE_MODE_SETTINGS");
                            return;
                        }
                        intent.setAction("android.settings.DATA_ROAMING_SETTINGS");
                    }
                }
            }
        }
    }

    public String getActiveSim() {
        int n = this.getDefaultDataSubscriptionId();
        if (n != this.INVALID_SUBSCRIPTION_ID) {
            if (ActivityCompat.checkSelfPermission((Context)this.context, (String)"android.permission.READ_PHONE_STATE") != 0) {
                return "No Permission";
            }
            SubscriptionInfo subscriptionInfo = this.subscriptionManager.getActiveSubscriptionInfo(n);
            if (subscriptionInfo != null && subscriptionInfo.getCarrierName() != null) {
                return subscriptionInfo.getCarrierName().toString();
            }
            return "No Permission";
        }
        return "Sim 1";
    }

    int getDefaultDataSubscriptionId() {
        int n;
        if (Build.VERSION.SDK_INT >= 24 && (n = SubscriptionManager.getDefaultDataSubscriptionId()) != -1) {
            return n;
        }
        Class class_ = Class.forName((String)this.subscriptionManager.getClass().getName());
        try {
            int n2 = (Integer)class_.getMethod("getDefaultDataSubId", new Class[0]).invoke((Object)this.subscriptionManager, new Object[0]);
            return n2;
        }
        catch (Exception exception) {
            try {
                exception.printStackTrace();
            }
            catch (ClassNotFoundException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }
        }
        return this.INVALID_SUBSCRIPTION_ID;
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return this.context.getString(2131886434);
    }

    /*
     * Exception decompiling
     */
    public int getSimCount() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl21.1 : ICONST_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }
}

