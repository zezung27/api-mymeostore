/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.ConnectivityManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.widget.TextView
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Build;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class DataUsageController
extends ButtonState {
    ConnectivityManager connectivity;
    private Context context;

    public DataUsageController(Context context) {
        super(context);
        this.context = context;
        this.connectivity = (ConnectivityManager)context.getSystemService("connectivity");
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.settings.DATA_USAGE_SETTINGS");
    }

    @Override
    public String getName() {
        return this.context.getString(2131886181);
    }

    @Override
    public boolean getState() {
        return Build.VERSION.SDK_INT >= 24 && this.connectivity.getRestrictBackgroundStatus() == 3;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }
}

