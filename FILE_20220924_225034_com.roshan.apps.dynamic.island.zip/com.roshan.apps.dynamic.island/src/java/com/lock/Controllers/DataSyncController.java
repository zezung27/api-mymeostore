/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.widget.TextView
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class DataSyncController
extends ButtonState {
    private Context context;
    private Intent intent;
    private String name;

    public DataSyncController(Context context) {
        super(context);
    }

    @Override
    public Intent getIntent() {
        return new Intent("android.settings.SYNC_SETTINGS");
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public boolean getState() {
        return ContentResolver.getMasterSyncAutomatically();
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (ContentResolver.getMasterSyncAutomatically()) {
            ContentResolver.setMasterSyncAutomatically((boolean)bl);
            return;
        }
        ContentResolver.setMasterSyncAutomatically((boolean)bl);
    }

    public void setSyncState(boolean bl) {
        ContentResolver.setMasterSyncAutomatically((boolean)bl);
    }
}

