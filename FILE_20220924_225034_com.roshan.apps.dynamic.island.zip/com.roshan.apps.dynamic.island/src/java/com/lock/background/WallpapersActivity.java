/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.Window
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.GridView
 *  android.widget.ListAdapter
 *  android.widget.ProgressBar
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  com.android.volley.DefaultRetryPolicy
 *  com.android.volley.Request
 *  com.android.volley.Response
 *  com.android.volley.Response$ErrorListener
 *  com.android.volley.Response$Listener
 *  com.android.volley.RetryPolicy
 *  com.android.volley.toolbox.JsonObjectRequest
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.FullScreenContentCallback
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.interstitial.InterstitialAd
 *  com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
 *  com.google.gson.Gson
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONObject
 */
package com.lock.background;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.lock.application.LauncherApp;
import com.lock.background.GridViewAdapter;
import com.lock.background.ImageList;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.background.Wallpaper;
import com.lock.background.WallpapersActivity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

public class WallpapersActivity
extends AppCompatActivity {
    AdRequest adRequest;
    private GridViewAdapter adapter;
    private int columnWidth;
    private GridView gridView;
    AdView mAdView;
    Context mContext;
    private InterstitialAd mInterstitialAd;
    private ProgressBar pbLoader;
    private ArrayList<ImageList> photosList = new ArrayList();
    private PrefManager pref;
    private Utils utils;
    private String wallpaperPosition;

    private void InitilizeGridLayout() {
        float f = TypedValue.applyDimension((int)1, (float)4.0f, (DisplayMetrics)this.getResources().getDisplayMetrics());
        this.columnWidth = (int)(((float)this.utils.getScreenWidth() - f * (float)(1 + this.pref.getNoOfGridColumns())) / (float)this.pref.getNoOfGridColumns());
        this.gridView.setNumColumns(this.pref.getNoOfGridColumns());
        this.gridView.setColumnWidth(this.columnWidth);
        this.gridView.setStretchMode(0);
        GridView gridView = this.gridView;
        int n = (int)f;
        gridView.setPadding(n, n, n, n);
        this.gridView.setHorizontalSpacing(n);
        this.gridView.setVerticalSpacing(n);
    }

    static /* synthetic */ ProgressBar access$000(WallpapersActivity wallpapersActivity) {
        return wallpapersActivity.pbLoader;
    }

    static /* synthetic */ String access$100(WallpapersActivity wallpapersActivity) {
        return wallpapersActivity.wallpaperPosition;
    }

    static /* synthetic */ String access$102(WallpapersActivity wallpapersActivity, String string) {
        wallpapersActivity.wallpaperPosition = string;
        return string;
    }

    static /* synthetic */ ArrayList access$200(WallpapersActivity wallpapersActivity) {
        return wallpapersActivity.photosList;
    }

    private void loadInterstitial() {
        InterstitialAd.load((Context)this, (String)this.getString(2131886082), (AdRequest)this.adRequest, (InterstitialAdLoadCallback)new InterstitialAdLoadCallback(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                WallpapersActivity.this.mInterstitialAd = null;
            }

            public void onAdLoaded(InterstitialAd interstitialAd) {
                WallpapersActivity.this.mInterstitialAd = interstitialAd;
                WallpapersActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(this){
                    final /* synthetic */ 4 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onAdDismissedFullScreenContent() {
                        Intent intent = new Intent(this.this$1.WallpapersActivity.this.mContext, com.lock.background.FullScreenViewActivity.class);
                        intent.putExtra("image_name", WallpapersActivity.access$100(this.this$1.WallpapersActivity.this));
                        this.this$1.WallpapersActivity.this.startActivity(intent);
                    }

                    public void onAdShowedFullScreenContent() {
                        WallpapersActivity.access$302(this.this$1.WallpapersActivity.this, null);
                    }
                });
            }
        });
    }

    public void getAllImages(JSONObject jSONObject) {
        try {
            Wallpaper wallpaper = (Wallpaper)new Gson().fromJson(jSONObject.toString(), Wallpaper.class);
            if (wallpaper.getStatus().equals((Object)"true")) {
                GridViewAdapter gridViewAdapter;
                this.photosList.clear();
                this.pbLoader.setVisibility(8);
                this.gridView.setVisibility(0);
                this.photosList.addAll(wallpaper.getAlbum_images());
                this.adapter = gridViewAdapter = new GridViewAdapter(this.mContext, (List<ImageList>)this.photosList, this.columnWidth);
                this.gridView.setAdapter((ListAdapter)gridViewAdapter);
                this.adapter.notifyDataSetChanged();
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    protected void onCreate(Bundle bundle) {
        ProgressBar progressBar;
        GridView gridView;
        super.onCreate(bundle);
        this.setContentView(2131558591);
        this.mContext = this;
        Toolbar toolbar = (Toolbar)this.findViewById(2131362487);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131099691));
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
        this.utils = new Utils(this.mContext);
        this.pref = new PrefManager(this.mContext);
        this.photosList = new ArrayList();
        this.getIntent();
        String string = this.getIntent().getStringExtra("album_id");
        String string2 = "http://45.55.46.214/wallpaper_ahmed/api/albumimageurl.php?package_name=" + this.mContext.getApplicationContext().getPackageName() + "&album_id=" + string;
        this.gridView = gridView = (GridView)this.findViewById(2131362091);
        gridView.setVisibility(8);
        this.InitilizeGridLayout();
        this.pbLoader = progressBar = (ProgressBar)this.findViewById(2131362293);
        progressBar.setVisibility(0);
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, string2, null, (Response.Listener)new Response.Listener<JSONObject>(this){
                final /* synthetic */ WallpapersActivity this$0;
                {
                    this.this$0 = wallpapersActivity;
                }

                public void onResponse(JSONObject jSONObject) {
                    this.this$0.getAllImages(jSONObject);
                }
            }, new Response.ErrorListener(this){
                final /* synthetic */ WallpapersActivity this$0;
                {
                    this.this$0 = wallpapersActivity;
                }

                public void onErrorResponse(com.android.volley.VolleyError volleyError) {
                    WallpapersActivity.access$000(this.this$0).setVisibility(8);
                    android.widget.Toast.makeText((Context)this.this$0.mContext, (java.lang.CharSequence)"Try Again in Few minutes", (int)1).show();
                }
            });
            jsonObjectRequest.setRetryPolicy((RetryPolicy)new DefaultRetryPolicy(10000, 2, 1.0f));
            jsonObjectRequest.setShouldCache(false);
            LauncherApp.getInstance().addToRequestQueue(jsonObjectRequest);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.mAdView = (AdView)this.findViewById(2131361908);
        if (!Utils.isAdsRemoved((Context)this)) {
            this.adRequest = new AdRequest.Builder().build();
            this.loadInterstitial();
            this.mAdView.loadAd(this.adRequest);
        } else {
            this.mAdView.setVisibility(8);
        }
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener(this){
            final /* synthetic */ WallpapersActivity this$0;
            {
                this.this$0 = wallpapersActivity;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                WallpapersActivity wallpapersActivity = this.this$0;
                WallpapersActivity.access$102(wallpapersActivity, ((ImageList)WallpapersActivity.access$200(wallpapersActivity).get(n)).getImage().trim());
                if (!Utils.isAdsRemoved(this.this$0.mContext) && WallpapersActivity.access$300(this.this$0) != null) {
                    WallpapersActivity.access$300(this.this$0).show((android.app.Activity)this.this$0);
                    return;
                }
                Intent intent = new Intent(this.this$0.mContext, com.lock.background.FullScreenViewActivity.class);
                intent.putExtra("image_name", ((ImageList)WallpapersActivity.access$200(this.this$0).get(n)).getImage().trim());
                this.this$0.startActivity(intent);
            }
        });
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

