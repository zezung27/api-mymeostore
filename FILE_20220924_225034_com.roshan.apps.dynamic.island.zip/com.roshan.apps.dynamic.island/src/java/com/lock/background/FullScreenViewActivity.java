/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Point
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.util.Log
 *  android.view.Display
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.view.WindowManager
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 */
package com.lock.background;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.background.Utils;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;

public class FullScreenViewActivity
extends Activity
implements View.OnClickListener {
    private static final String TAG = "FullScreenViewActivity";
    private Bitmap bitmap;
    private ImageView fullImageView;
    private LinearLayout llDownloadWallpaper;
    private LinearLayout llSetWallpaper;
    private LinearLayout llshare;
    Context mContxt;
    private ProgressBar pbLoader;
    private Utils utils;

    private void adjustImageAspect(int n, int n2) {
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        if (n != 0) {
            int n3;
            int n4;
            if (n2 == 0) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 13) {
                Display display = this.getWindowManager().getDefaultDisplay();
                Point point = new Point();
                display.getSize(point);
                n3 = point.y;
            } else {
                n3 = this.getWindowManager().getDefaultDisplay().getHeight();
            }
            layoutParams.width = n4 = (int)Math.floor((double)((double)n * (double)n3 / (double)n2));
            layoutParams.height = n3;
            Log.d((String)TAG, (String)("Fullscreen image new dimensions: w = " + n4 + ", h = " + n3));
            this.fullImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        }
    }

    private void fetchFullResolutionImage(String string2) {
        String string3 = "http://45.55.46.214/wallpaper_ahmed/images/" + string2;
        this.pbLoader.setVisibility(0);
        this.llSetWallpaper.setVisibility(8);
        this.llDownloadWallpaper.setVisibility(8);
        this.llshare.setVisibility(8);
        Glide.with((Context)this.mContxt).asBitmap().load(string3).listener((RequestListener)new RequestListener<Bitmap>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Bitmap> target, boolean bl) {
                FullScreenViewActivity.this.pbLoader.setVisibility(8);
                Toast.makeText((Context)FullScreenViewActivity.this.mContxt, (CharSequence)glideException.toString(), (int)1).show();
                return false;
            }

            public boolean onResourceReady(Bitmap bitmap, Object object, Target<Bitmap> target, DataSource dataSource, boolean bl) {
                FullScreenViewActivity.this.bitmap = bitmap;
                FullScreenViewActivity.this.pbLoader.setVisibility(8);
                FullScreenViewActivity.this.llSetWallpaper.setVisibility(0);
                FullScreenViewActivity.this.llDownloadWallpaper.setVisibility(0);
                FullScreenViewActivity.this.llshare.setVisibility(0);
                return false;
            }
        }).into(this.fullImageView);
    }

    public void downloadWallpaer() {
        final ProgressDialog progressDialog = new ProgressDialog((Context)this, 5);
        progressDialog.setTitle((CharSequence)"Downloading Wallpaper");
        progressDialog.setMessage((CharSequence)"Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Thread(new Runnable(){

            public void run() {
                FullScreenViewActivity.this.utils.saveImageToSDCard(FullScreenViewActivity.this.bitmap);
                FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        progressDialog.dismiss();
                    }
                });
            }

        }).start();
    }

    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case 2131362170: {
                if (this.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != 0) {
                    this.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 300);
                    return;
                }
                this.shareWallpaper();
                return;
            }
            case 2131362169: {
                final ProgressDialog progressDialog = new ProgressDialog((Context)this, 5);
                progressDialog.setTitle((CharSequence)"Setting Wallpaper");
                progressDialog.setMessage((CharSequence)"Please Wait...");
                progressDialog.setCancelable(false);
                progressDialog.show();
                new Thread(new Runnable(){

                    public void run() {
                        FullScreenViewActivity.this.utils.setAsWallpaper(FullScreenViewActivity.this.bitmap);
                        FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                            public void run() {
                                if (!FullScreenViewActivity.this.isFinishing()) {
                                    try {
                                        progressDialog.dismiss();
                                        return;
                                    }
                                    catch (Exception exception) {
                                        exception.printStackTrace();
                                    }
                                }
                            }
                        });
                    }

                }).start();
                return;
            }
            case 2131362168: 
        }
        if (this.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0) {
            this.requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 100);
            return;
        }
        this.downloadWallpaer();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131558430);
        this.mContxt = this;
        this.getWindow().setFlags(512, 512);
        this.fullImageView = (ImageView)this.findViewById(2131362125);
        this.llSetWallpaper = (LinearLayout)this.findViewById(2131362169);
        this.llDownloadWallpaper = (LinearLayout)this.findViewById(2131362168);
        this.llshare = (LinearLayout)this.findViewById(2131362170);
        this.pbLoader = (ProgressBar)this.findViewById(2131362293);
        this.utils = new Utils(this.mContxt);
        this.llSetWallpaper.setOnClickListener((View.OnClickListener)this);
        this.llDownloadWallpaper.setOnClickListener((View.OnClickListener)this);
        this.llshare.setOnClickListener((View.OnClickListener)this);
        this.llSetWallpaper.getBackground().setAlpha(70);
        this.llDownloadWallpaper.getBackground().setAlpha(70);
        this.llshare.getBackground().setAlpha(70);
        this.getIntent();
        String string2 = this.getIntent().getStringExtra("image_name");
        if (string2 != null) {
            this.fetchFullResolutionImage(string2);
            return;
        }
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)this.getString(2131886269), (int)0).show();
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        if (arrn.length > 0) {
            if (n == 100) {
                if (arrn[0] == 0) {
                    this.downloadWallpaer();
                } else {
                    Toast.makeText((Context)this, (CharSequence)"Until you grant the permission, we can't save wallpaper", (int)0).show();
                }
            }
            if (n == 200) {
                if (arrn[0] == 0) {
                    this.setWallpaper();
                } else {
                    Toast.makeText((Context)this, (CharSequence)"Until you grant the permission, we can't set wallpaper", (int)0).show();
                }
            }
            if (n == 300) {
                if (arrn.length > 0 && arrn[0] == 0) {
                    this.shareWallpaper();
                    return;
                }
                Toast.makeText((Context)this, (CharSequence)"Until you grant the permission, we can't share wallpaper", (int)0).show();
                return;
            }
        } else {
            Toast.makeText((Context)this, (CharSequence)"Until you grant the permission, we can't set or share wallpaper", (int)0).show();
        }
    }

    public void setWallpaper() {
        final ProgressDialog progressDialog = new ProgressDialog((Context)this, 5);
        progressDialog.setTitle((CharSequence)"Setting Wallpaper");
        progressDialog.setMessage((CharSequence)"Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Thread(new Runnable(){

            public void run() {
                Utils.saveImage(FullScreenViewActivity.this.bitmap);
                FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                    public void run() {
                        progressDialog.dismiss();
                    }
                });
            }

        }).start();
    }

    public void shareWallpaper() {
        final ProgressDialog progressDialog = new ProgressDialog((Context)this, 5);
        progressDialog.setTitle((CharSequence)"Sharing Wallpaper");
        progressDialog.setMessage((CharSequence)"Please Wait...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                try {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    FullScreenViewActivity.this.bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)byteArrayOutputStream);
                    String string2 = MediaStore.Images.Media.insertImage((ContentResolver)FullScreenViewActivity.this.getContentResolver(), (Bitmap)FullScreenViewActivity.this.bitmap, (String)"Title", null);
                    if (string2 != null) {
                        final Uri uri = Uri.parse((String)string2);
                        FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                            public void run() {
                                Intent intent = new Intent("android.intent.action.SEND");
                                intent.setType("image/jpeg");
                                intent.putExtra("android.intent.extra.STREAM", (Parcelable)uri);
                                FullScreenViewActivity.this.startActivity(Intent.createChooser((Intent)intent, (CharSequence)"Select"));
                                progressDialog.dismiss();
                            }
                        });
                        return;
                    }
                    FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                        public void run() {
                            Toast.makeText((Context)FullScreenViewActivity.this.mContxt, (CharSequence)"File not found! try again.", (int)1).show();
                        }
                    });
                    return;
                }
                catch (Exception exception) {
                    FullScreenViewActivity.this.runOnUiThread(new Runnable(){

                        public void run() {
                            Toast.makeText((Context)FullScreenViewActivity.this.mContxt, (CharSequence)"Some error occurred try again.", (int)1).show();
                        }
                    });
                    return;
                }
            }

        }).start();
    }

}

