/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.hardware.display.VirtualDisplay
 *  android.hardware.display.VirtualDisplay$Callback
 *  android.media.Image
 *  android.media.Image$Plane
 *  android.media.ImageReader
 *  android.media.ImageReader$OnImageAvailableListener
 *  android.media.projection.MediaProjection
 *  android.media.projection.MediaProjection$Callback
 *  android.media.projection.MediaProjectionManager
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.Handler
 *  android.os.Looper
 *  android.text.format.DateFormat
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.Surface
 *  android.view.WindowManager
 *  com.lock.utils.Constants
 *  com.lock.utils.screenShotRunable
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.util.Date
 *  java.util.Objects
 *  pub.devrel.easypermissions.EasyPermissions
 */
package com.lock.activites;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;
import com.lock.utils.Constants;
import com.lock.utils.screenShotRunable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Date;
import java.util.Objects;
import pub.devrel.easypermissions.EasyPermissions;

public class ScreenshotCaptureActivity
extends Activity {
    public static MediaProjection mediaProjection;
    public static String message;
    public String[] STORAGE_PERMISSION = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    public MediaProjectionManager f11371o;
    public Handler handler;
    public ImageReader imageReader;
    public int mHeightPixels;
    public int mWidthPixels;
    public VirtualDisplay virtualDisplay;

    public static void a(ScreenshotCaptureActivity screenshotCaptureActivity, Bitmap bitmap) {
        Objects.requireNonNull((Object)((Object)screenshotCaptureActivity));
        CharSequence charSequence = DateFormat.format((CharSequence)"yyyyMMdd-HHmmss", (Date)new Date());
        String string2 = message + "Screenshot_" + (Object)charSequence + ".jpg";
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(string2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            Intent intent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
            intent.setData(Uri.parse((String)("file://" + string2)));
            screenshotCaptureActivity.sendBroadcast(intent);
            fileOutputStream.close();
            return;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        catch (FileNotFoundException fileNotFoundException) {}
    }

    /*
     * Exception decompiling
     */
    private void startCapture() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : NEW : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void mOnImageAvailable(ImageReader imageReader) {
        int n;
        ByteBuffer byteBuffer;
        int n2;
        int n3;
        Image image;
        this.handler.post((Runnable)new screenShotRunable());
        try {
            image = imageReader.acquireLatestImage();
            Image.Plane[] arrplane = image.getPlanes();
            byteBuffer = arrplane[0].getBuffer();
            n2 = arrplane[0].getPixelStride();
            n = arrplane[0].getRowStride();
            n3 = this.mWidthPixels;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        int n4 = n - n2 * n3;
        Bitmap bitmap = Bitmap.createBitmap((int)(n3 + n4 / n2), (int)this.mHeightPixels, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer((Buffer)byteBuffer);
        image.close();
        imageReader.close();
        if (n4 / n2 == 0) {
            ScreenshotCaptureActivity.a(this, bitmap);
        } else {
            Bitmap bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)this.mWidthPixels, (int)this.mHeightPixels);
            bitmap.recycle();
            ScreenshotCaptureActivity.a(this, bitmap2);
        }
        Objects.requireNonNull((Object)((Object)this));
        this.finish();
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        if (n == 1) {
            MediaProjection mediaProjection;
            ScreenshotCaptureActivity.mediaProjection = mediaProjection = this.f11371o.getMediaProjection(n2, intent);
            if (mediaProjection != null) {
                ImageReader imageReader;
                int n3;
                int n4;
                message = Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DCIM).getAbsolutePath() + "/Screenshots/";
                File file = new File(message);
                if (!file.exists()) {
                    file.mkdirs();
                }
                DisplayMetrics displayMetrics = new DisplayMetrics();
                this.getWindowManager().getDefaultDisplay().getRealMetrics(displayMetrics);
                this.mWidthPixels = n3 = displayMetrics.widthPixels;
                this.mHeightPixels = n4 = displayMetrics.heightPixels;
                this.imageReader = imageReader = ImageReader.newInstance((int)n3, (int)n4, (int)256, (int)1);
                this.virtualDisplay = ScreenshotCaptureActivity.mediaProjection.createVirtualDisplay("screencap", this.mWidthPixels, this.mHeightPixels, displayMetrics.densityDpi, 9, imageReader.getSurface(), null, this.handler);
                this.imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener(){

                    public void onImageAvailable(ImageReader imageReader) {
                        ScreenshotCaptureActivity.this.mOnImageAvailable(imageReader);
                    }
                }, this.handler);
                ScreenshotCaptureActivity.mediaProjection.registerCallback((MediaProjection.Callback)new c(null), this.handler);
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (!Constants.hasPermissions((Context)this, (String[])this.STORAGE_PERMISSION)) {
            this.finish();
            return;
        }
        this.startCapture();
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        super.onRequestPermissionsResult(n, arrstring, arrn);
        EasyPermissions.onRequestPermissionsResult((int)n, (String[])arrstring, (int[])arrn, (Object[])new Object[]{this});
    }

    public class a
    extends Thread {
        public void run() {
            Looper.prepare();
            ScreenshotCaptureActivity.this.handler = new Handler();
            Looper.loop();
        }
    }

    public class c
    extends MediaProjection.Callback {
        public c(a a2) {
        }

        public void onStop() {
            ScreenshotCaptureActivity.this.handler.post((Runnable)new a());
        }

        public class a
        implements Runnable {
            public void run() {
                ImageReader imageReader;
                VirtualDisplay virtualDisplay = ScreenshotCaptureActivity.this.virtualDisplay;
                if (virtualDisplay != null) {
                    virtualDisplay.release();
                }
                if ((imageReader = ScreenshotCaptureActivity.this.imageReader) != null) {
                    imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener(){

                        public void onImageAvailable(ImageReader imageReader) {
                            ScreenshotCaptureActivity.this.mOnImageAvailable(imageReader);
                        }
                    }, ScreenshotCaptureActivity.this.handler);
                }
                ScreenshotCaptureActivity.mediaProjection.unregisterCallback((MediaProjection.Callback)c.this);
            }

        }

    }

}

