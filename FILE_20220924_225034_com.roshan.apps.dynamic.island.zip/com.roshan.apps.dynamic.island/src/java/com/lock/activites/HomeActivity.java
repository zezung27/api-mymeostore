/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.ProgressDialog
 *  android.content.ActivityNotFoundException
 *  android.content.ContentResolver
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.widget.TextView
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.graphics.drawable.DrawerArrowDrawable
 *  androidx.appcompat.widget.Toolbar
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.drawerlayout.widget.DrawerLayout$DrawerListener
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.viewpager2.widget.ViewPager2
 *  androidx.viewpager2.widget.ViewPager2$OnPageChangeCallback
 *  com.android.billingclient.api.AcknowledgePurchaseParams
 *  com.android.billingclient.api.AcknowledgePurchaseParams$Builder
 *  com.android.billingclient.api.AcknowledgePurchaseResponseListener
 *  com.android.billingclient.api.BillingClient
 *  com.android.billingclient.api.BillingClient$Builder
 *  com.android.billingclient.api.BillingClientStateListener
 *  com.android.billingclient.api.BillingFlowParams
 *  com.android.billingclient.api.BillingFlowParams$Builder
 *  com.android.billingclient.api.BillingResult
 *  com.android.billingclient.api.Purchase
 *  com.android.billingclient.api.PurchasesResponseListener
 *  com.android.billingclient.api.PurchasesUpdatedListener
 *  com.android.billingclient.api.QueryPurchasesParams
 *  com.android.billingclient.api.QueryPurchasesParams$Builder
 *  com.android.billingclient.api.SkuDetails
 *  com.android.billingclient.api.SkuDetailsParams
 *  com.android.billingclient.api.SkuDetailsParams$Builder
 *  com.android.billingclient.api.SkuDetailsResponseListener
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.FullScreenContentCallback
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.MobileAds
 *  com.google.android.gms.ads.RequestConfiguration
 *  com.google.android.gms.ads.RequestConfiguration$Builder
 *  com.google.android.gms.ads.interstitial.InterstitialAd
 *  com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
 *  com.google.android.material.bottomnavigation.BottomNavigationView
 *  com.google.android.material.navigation.NavigationBarView
 *  com.google.android.material.navigation.NavigationBarView$OnItemSelectedListener
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  java.util.List
 */
package com.lock.activites;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.graphics.drawable.DrawerArrowDrawable;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.github.mmin18.widget.RealtimeBlurView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.lock.activites.HomeActivity;
import com.lock.activites.PermissionsActivity;
import com.lock.adaptar.ViewPagerAdapter;
import com.lock.background.WallpapersCategoryActivity;
import com.lock.providers.InAppPurchaseProvider;
import com.lock.utils.Constants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class HomeActivity
extends AppCompatActivity
implements View.OnClickListener,
PurchasesUpdatedListener {
    static final int RC_REQUEST = 10001;
    static final String SKU_GAS = "no_ads";
    static final String TAG = "InAppPurchase";
    public String[] STORAGE_PERMISSION = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener = new AcknowledgePurchaseResponseListener(this){
        final /* synthetic */ HomeActivity this$0;
        {
            this.this$0 = homeActivity;
        }

        public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
            if (billingResult.getResponseCode() == 0) {
                android.widget.Toast.makeText((Context)this.this$0, (CharSequence)"Purchase successful", (int)1).show();
            }
        }
    };
    AdRequest adRequest;
    TextView bg_btn;
    private BillingClient billingClient;
    DrawerLayout drawer;
    Boolean isAdRemoved;
    public InterstitialAd mInterstitialAd;
    NavigationBarView.OnItemSelectedListener mOnNavigationItemSelectedListener = new NavigationBarView.OnItemSelectedListener(this){
        final /* synthetic */ HomeActivity this$0;
        {
            this.this$0 = homeActivity;
        }

        public boolean onNavigationItemSelected(MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                default: {
                    return false;
                }
                case 2131362256: {
                    HomeActivity.access$300(this.this$0).setCurrentItem(1);
                    return true;
                }
                case 2131362254: {
                    HomeActivity.access$300(this.this$0).setCurrentItem(2);
                    return true;
                }
                case 2131362253: {
                    HomeActivity.access$300(this.this$0).setCurrentItem(0);
                    return true;
                }
                case 2131362245: 
            }
            HomeActivity.access$300(this.this$0).setCurrentItem(3);
            return true;
        }
    };
    TextView more_btn;
    BottomNavigationView navigation;
    private ProgressDialog pd_progressDialog;
    TextView permission_btn;
    MenuItem prevMenuItem;
    TextView rate_us_btn;
    RealtimeBlurView real_time_blur;
    TextView remove_ads_btn;
    List<SkuDetails> skuDetailsList;
    private ViewPager2 viewPager;

    static /* synthetic */ void access$000(HomeActivity homeActivity) {
        homeActivity.querySKUDetails();
    }

    static /* synthetic */ void access$100(HomeActivity homeActivity) {
        homeActivity.queryPurchase();
    }

    static /* synthetic */ void access$200(HomeActivity homeActivity, boolean bl) {
        homeActivity.updatePurchase(bl);
    }

    static /* synthetic */ ViewPager2 access$300(HomeActivity homeActivity) {
        return homeActivity.viewPager;
    }

    static /* synthetic */ void access$400(HomeActivity homeActivity, ViewPager2 viewPager2) {
        homeActivity.setupViewPager(viewPager2);
    }

    static /* synthetic */ void access$500(HomeActivity homeActivity, Purchase purchase) {
        homeActivity.handlePurchase(purchase);
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == 1) {
            if (!purchase.isAcknowledged()) {
                AcknowledgePurchaseParams acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
                this.billingClient.acknowledgePurchase(acknowledgePurchaseParams, this.acknowledgePurchaseResponseListener);
            }
            if (purchase.getProducts().size() > 0 && ((String)purchase.getProducts().get(0)).equals((Object)SKU_GAS)) {
                this.updatePurchase(true);
            }
        }
    }

    private void loadApps() {
        new Thread(new Runnable(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void run() {
                try {
                    android.content.pm.PackageManager packageManager = this.this$0.getPackageManager();
                    Intent intent = new Intent("android.intent.action.MAIN", null);
                    intent.addCategory("android.intent.category.LAUNCHER");
                    for (android.content.pm.ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
                        String string = resolveInfo.loadLabel(packageManager).toString();
                        if (string.toLowerCase().equals((Object)"camera")) {
                            Constants.setCameraPkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                        }
                        if (!resolveInfo.loadLabel(packageManager).toString().toLowerCase().equals((Object)"phone") && !resolveInfo.activityInfo.name.toLowerCase().equals((Object)"dialler")) continue;
                        Constants.setPhonePkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }).start();
    }

    private void loadInterstitial() {
        InterstitialAd.load((Context)this, (String)this.getString(2131886082), (AdRequest)this.adRequest, (InterstitialAdLoadCallback)new InterstitialAdLoadCallback(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                HomeActivity.this.mInterstitialAd = null;
            }

            public void onAdLoaded(InterstitialAd interstitialAd) {
                HomeActivity.this.mInterstitialAd = interstitialAd;
                HomeActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(this){
                    final /* synthetic */ 9 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onAdDismissedFullScreenContent() {
                    }

                    public void onAdShowedFullScreenContent() {
                        this.this$1.HomeActivity.this.mInterstitialAd = null;
                    }
                });
            }
        });
    }

    private void makePurchase() {
        List<SkuDetails> list = this.skuDetailsList;
        if (list != null && list.size() > 0) {
            BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder().setSkuDetails((SkuDetails)this.skuDetailsList.get(0)).build();
            this.billingClient.launchBillingFlow((Activity)this, billingFlowParams).getResponseCode();
        }
    }

    private void queryPurchase() {
        this.billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType("inapp").build(), new PurchasesResponseListener(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void onQueryPurchasesResponse(BillingResult billingResult, List<Purchase> list) {
                if (list.size() > 0) {
                    for (Purchase purchase : list) {
                        HomeActivity.access$500(this.this$0, purchase);
                    }
                } else {
                    HomeActivity.access$200(this.this$0, false);
                }
            }
        });
    }

    private void querySKUDetails() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)SKU_GAS);
        SkuDetailsParams.Builder builder = SkuDetailsParams.newBuilder();
        builder.setSkusList((List)arrayList).setType("inapp");
        this.billingClient.querySkuDetailsAsync(builder.build(), new SkuDetailsResponseListener(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                this.this$0.skuDetailsList = list;
            }
        });
    }

    private void setFullScreen() {
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
    }

    private void setupViewPager(ViewPager2 viewPager2) {
        viewPager2.setAdapter((RecyclerView.Adapter)new ViewPagerAdapter((FragmentActivity)this));
        viewPager2.setSaveEnabled(false);
    }

    private void updatePurchase(boolean bl) {
        this.isAdRemoved = bl;
        this.saveData(bl);
        this.loadData();
    }

    void alert(String string) {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setMessage((CharSequence)string);
        builder.setNeutralButton((CharSequence)"OK", null);
        Log.d((String)TAG, (String)("Showing alert dialog: " + string));
        builder.create();
        if (!this.isFinishing()) {
            builder.show();
        }
    }

    void complain(String string) {
        Log.e((String)TAG, (String)("**** InAppPurchase Error: " + string));
        this.alert("Error: " + string);
    }

    public void initializeBilling() {
        if (this.billingClient == null) {
            this.billingClient = BillingClient.newBuilder((Context)this).enablePendingPurchases().setListener((PurchasesUpdatedListener)this).build();
        }
        this.billingClient.startConnection(new BillingClientStateListener(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void onBillingServiceDisconnected() {
            }

            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == 0) {
                    HomeActivity.access$000(this.this$0);
                    HomeActivity.access$100(this.this$0);
                    return;
                }
                HomeActivity.access$200(this.this$0, false);
            }
        });
    }

    void loadData() {
        Boolean bl;
        List list = Arrays.asList((Object[])new String[]{"62488F7DC24E4F985C4A4569D0E026BF"});
        MobileAds.setRequestConfiguration((RequestConfiguration)new RequestConfiguration.Builder().setTestDeviceIds(list).build());
        this.isAdRemoved = bl = Boolean.valueOf((boolean)this.getSharedPreferences("ads", 0).getBoolean("isAdRemoved", false));
        if (!bl.booleanValue()) {
            this.adRequest = new AdRequest.Builder().build();
            this.loadInterstitial();
            this.remove_ads_btn.setVisibility(0);
            return;
        }
        this.remove_ads_btn.setVisibility(8);
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        if (this.drawer.isDrawerOpen(8388611)) {
            this.drawer.closeDrawer(8388611);
            return;
        }
        super.onBackPressed();
    }

    /*
     * Loose catch block
     * Enabled aggressive exception aggregation
     */
    public void onClick(View view) {
        block16 : {
            switch (view.getId()) {
                default: {
                    return;
                }
                case 2131362326: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.onRemoveAdButtonClicked();
                    return;
                }
                case 2131362315: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/details?id=" + this.getPackageName()))));
                    return;
                }
                case 2131362296: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.startActivity(new Intent((Context)this, PermissionsActivity.class));
                    return;
                }
                case 2131362216: {
                    try {
                        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.getString(2131886117)))));
                        return;
                    }
                    catch (ActivityNotFoundException activityNotFoundException) {
                        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.getString(2131886117)))));
                        return;
                    }
                }
                case 2131361914: 
            }
            if (this.drawer.isDrawerOpen(8388611)) {
                this.drawer.closeDrawer(8388611);
            }
            this.startActivity(new Intent((Context)this, WallpapersCategoryActivity.class));
            break block16;
            {
                catch (Exception exception) {}
            }
        }
    }

    protected void onCreate(Bundle bundle) {
        ProgressDialog progressDialog;
        super.onCreate(bundle);
        this.setContentView(2131558429);
        this.setFullScreen();
        Toolbar toolbar = (Toolbar)this.findViewById(2131362487);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131099691));
        this.drawer = (DrawerLayout)this.findViewById(2131362032);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, this.drawer, toolbar, 2131886307, 2131886306);
        actionBarDrawerToggle.getDrawerArrowDrawable().setColor(this.getResources().getColor(2131099691, null));
        this.drawer.addDrawerListener((DrawerLayout.DrawerListener)actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        this.pd_progressDialog = progressDialog = new ProgressDialog((Context)this);
        progressDialog.setProgressStyle(0);
        this.pd_progressDialog.setMessage((CharSequence)" Please wait...");
        this.pd_progressDialog.setCancelable(false);
        this.pd_progressDialog.setTitle((CharSequence)"Loading");
        this.setWaitScreen(true);
        this.navigation = (BottomNavigationView)this.findViewById(2131362244);
        this.viewPager = (ViewPager2)this.findViewById(2131362538);
        this.remove_ads_btn = (TextView)this.findViewById(2131362326);
        this.rate_us_btn = (TextView)this.findViewById(2131362315);
        this.more_btn = (TextView)this.findViewById(2131362216);
        this.permission_btn = (TextView)this.findViewById(2131362296);
        this.bg_btn = (TextView)this.findViewById(2131361914);
        this.real_time_blur = (RealtimeBlurView)this.findViewById(2131362320);
        this.navigation.setOnItemSelectedListener(this.mOnNavigationItemSelectedListener);
        this.initializeBilling();
        ViewPager2.OnPageChangeCallback onPageChangeCallback = new ViewPager2.OnPageChangeCallback(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void onPageScrollStateChanged(int n) {
                super.onPageScrollStateChanged(n);
            }

            public void onPageScrolled(int n, float f, int n2) {
                if (this.this$0.prevMenuItem != null) {
                    this.this$0.prevMenuItem.setChecked(false);
                } else {
                    this.this$0.navigation.getMenu().getItem(0).setChecked(false);
                }
                Log.d((String)"page", (String)("onPageSelected: " + n));
                this.this$0.navigation.getMenu().getItem(n).setChecked(true);
                HomeActivity homeActivity = this.this$0;
                homeActivity.prevMenuItem = homeActivity.navigation.getMenu().getItem(n);
                super.onPageScrolled(n, f, n2);
            }

            public void onPageSelected(int n) {
                super.onPageSelected(n);
            }
        };
        this.viewPager.registerOnPageChangeCallback(onPageChangeCallback);
        this.viewPager.setOffscreenPageLimit(3);
        new Handler().postDelayed(new Runnable(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void run() {
                this.this$0.setWaitScreen(false);
                HomeActivity homeActivity = this.this$0;
                HomeActivity.access$400(homeActivity, HomeActivity.access$300(homeActivity));
            }
        }, 2000L);
        this.real_time_blur.setOnClickListener((View.OnClickListener)this);
        this.remove_ads_btn.setOnClickListener((View.OnClickListener)this);
        this.bg_btn.setOnClickListener((View.OnClickListener)this);
        this.rate_us_btn.setOnClickListener((View.OnClickListener)this);
        this.more_btn.setOnClickListener((View.OnClickListener)this);
        this.permission_btn.setOnClickListener((View.OnClickListener)this);
        if (Constants.getCameraPkg((Context)this).equals((Object)"")) {
            this.loadApps();
        }
    }

    protected void onDestroy() {
        BillingClient billingClient = this.billingClient;
        if (billingClient != null) {
            billingClient.endConnection();
        }
        super.onDestroy();
    }

    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
        if (billingResult.getResponseCode() == 0 && list != null) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                this.handlePurchase((Purchase)iterator.next());
            }
        } else {
            billingResult.getResponseCode();
        }
    }

    public void onRemoveAdButtonClicked() {
        if (this.isAdRemoved.booleanValue()) {
            this.complain(this.getString(2131886120));
            return;
        }
        BillingClient billingClient = this.billingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.makePurchase();
            return;
        }
        this.initializeBilling();
    }

    protected void onResume() {
        BillingClient billingClient = this.billingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.queryPurchase();
        } else {
            this.initializeBilling();
        }
        super.onResume();
    }

    void saveData(boolean bl) {
        SharedPreferences.Editor editor = this.getSharedPreferences("ads", 0).edit();
        if (!this.getSharedPreferences("ads", 0).getBoolean("isAdRemoved", false)) {
            Boolean bl2;
            editor.putBoolean("isAdRemoved", bl);
            editor.apply();
            this.isAdRemoved = bl2 = Boolean.valueOf((boolean)bl);
            if (bl2.booleanValue()) {
                this.remove_ads_btn.setVisibility(8);
            }
        }
    }

    public void setPurchase() {
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", Integer.valueOf((int)1));
        this.getContentResolver().insert(InAppPurchaseProvider.CONTENT_URI, contentValues);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    void setWaitScreen(boolean bl) {
        try {
            ProgressDialog progressDialog = this.pd_progressDialog;
            if (progressDialog == null) return;
            if (bl) {
                progressDialog.show();
                return;
            }
            if (this.isFinishing()) return;
            this.pd_progressDialog.dismiss();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

}

