/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.Window
 *  java.lang.Object
 *  java.util.function.Consumer
 */
package com.nordan.dialog;

import android.view.Window;
import com.nordan.dialog.NordanLoadingDialog;
import java.util.function.Consumer;

public final class NordanLoadingDialog$$ExternalSyntheticLambda0
implements Consumer {
    public final void accept(Object object) {
        NordanLoadingDialog.lambda$createLoadingDialog$0((Window)object);
    }
}

