/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.nordan.dialog;

import android.app.Dialog;
import android.view.View;
import com.nordan.dialog.NordanAlertDialog;

public final class NordanAlertDialog$Builder$$ExternalSyntheticLambda4
implements View.OnClickListener {
    public final /* synthetic */ Dialog f$0;

    public /* synthetic */ NordanAlertDialog$Builder$$ExternalSyntheticLambda4(Dialog dialog) {
        this.f$0 = dialog;
    }

    public final void onClick(View view) {
        NordanAlertDialog.Builder.lambda$build$4(this.f$0, view);
    }
}

