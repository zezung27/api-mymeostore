/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Point
 *  java.lang.Math
 *  java.lang.Object
 */
package com.skydoves.colorpickerview;

import android.graphics.Point;
import com.skydoves.colorpickerview.ColorPickerView;

class PointMapper {
    private PointMapper() {
    }

    private static Point approximatedPoint(ColorPickerView colorPickerView, Point point, Point point2) {
        if (PointMapper.getDistance(point, point2) <= 3) {
            return point2;
        }
        Point point3 = PointMapper.getCenterPoint(point, point2);
        if (colorPickerView.getColorFromBitmap(point3.x, point3.y) == 0) {
            return PointMapper.approximatedPoint(colorPickerView, point3, point2);
        }
        return PointMapper.approximatedPoint(colorPickerView, point, point3);
    }

    private static Point getCenterPoint(Point point, Point point2) {
        return new Point((point2.x + point.x) / 2, (point2.y + point.y) / 2);
    }

    protected static Point getColorPoint(ColorPickerView colorPickerView, Point point) {
        Point point2 = new Point(colorPickerView.getMeasuredWidth() / 2, colorPickerView.getMeasuredHeight() / 2);
        if (colorPickerView.isHuePalette()) {
            return PointMapper.getHuePoint(colorPickerView, point);
        }
        return PointMapper.approximatedPoint(colorPickerView, point, point2);
    }

    private static int getDistance(Point point, Point point2) {
        return (int)Math.sqrt((double)(Math.abs((int)(point2.x - point.x)) * Math.abs((int)(point2.x - point.x)) + Math.abs((int)(point2.y - point.y)) * Math.abs((int)(point2.y - point.y))));
    }

    private static Point getHuePoint(ColorPickerView colorPickerView, Point point) {
        double d;
        float f = 0.5f * (float)colorPickerView.getWidth();
        float f2 = 0.5f * (float)colorPickerView.getHeight();
        float f3 = (float)point.x - f;
        float f4 = (float)point.y - f2;
        float f5 = Math.min((float)f, (float)f2);
        double d2 = Math.sqrt((double)(f3 * f3 + f4 * f4));
        if (d2 > (d = (double)f5)) {
            double d3 = f3;
            double d4 = d / d2;
            f3 = (float)(d3 * d4);
            f4 = (float)(d4 * (double)f4);
        }
        return new Point((int)(f3 + f), (int)(f4 + f2));
    }
}

