/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Color
 *  android.graphics.Matrix
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  android.widget.ImageView
 *  androidx.appcompat.content.res.AppCompatResources
 *  androidx.core.content.ContextCompat
 *  androidx.lifecycle.Lifecycle
 *  androidx.lifecycle.Lifecycle$Event
 *  androidx.lifecycle.LifecycleObserver
 *  androidx.lifecycle.LifecycleOwner
 *  androidx.lifecycle.OnLifecycleEvent
 *  java.lang.IllegalAccessException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.skydoves.colorpickerview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.OnLifecycleEvent;
import com.skydoves.colorpickerview.ActionMode;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorHsvPalette;
import com.skydoves.colorpickerview.ColorPickerView$$ExternalSyntheticLambda0;
import com.skydoves.colorpickerview.ColorPickerView$$ExternalSyntheticLambda1;
import com.skydoves.colorpickerview.ColorPickerView$$ExternalSyntheticLambda2;
import com.skydoves.colorpickerview.Dp;
import com.skydoves.colorpickerview.PointMapper;
import com.skydoves.colorpickerview.R;
import com.skydoves.colorpickerview.SizeUtils;
import com.skydoves.colorpickerview.flag.FlagMode;
import com.skydoves.colorpickerview.flag.FlagView;
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;
import com.skydoves.colorpickerview.listeners.ColorListener;
import com.skydoves.colorpickerview.listeners.ColorPickerViewListener;
import com.skydoves.colorpickerview.preference.ColorPickerPreferenceManager;
import com.skydoves.colorpickerview.sliders.AlphaSlideBar;
import com.skydoves.colorpickerview.sliders.BrightnessSlideBar;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ColorPickerView
extends FrameLayout
implements LifecycleObserver {
    private boolean VISIBLE_FLAG = false;
    private ActionMode actionMode = ActionMode.ALWAYS;
    private AlphaSlideBar alphaSlideBar;
    private BrightnessSlideBar brightnessSlider;
    public ColorPickerViewListener colorListener;
    private long debounceDuration = 0L;
    private final Handler debounceHandler = new Handler();
    private FlagView flagView;
    private float flag_alpha = 1.0f;
    private boolean flag_isFlipAble = true;
    private ImageView palette;
    private Drawable paletteDrawable;
    private final ColorPickerPreferenceManager preferenceManager = ColorPickerPreferenceManager.getInstance(this.getContext());
    private String preferenceName;
    private int selectedColor;
    private Point selectedPoint;
    private int selectedPureColor;
    private ImageView selector;
    private Drawable selectorDrawable;
    private int selectorSize = 0;
    private float selector_alpha = 1.0f;

    public ColorPickerView(Context context) {
        super(context);
    }

    public ColorPickerView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.getAttrs(attributeSet);
        this.onCreate();
    }

    public ColorPickerView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.getAttrs(attributeSet);
        this.onCreate();
    }

    public ColorPickerView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.getAttrs(attributeSet);
        this.onCreate();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void getAttrs(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.ColorPickerView);
        try {
            int n;
            if (typedArray.hasValue(R.styleable.ColorPickerView_palette)) {
                this.paletteDrawable = typedArray.getDrawable(R.styleable.ColorPickerView_palette);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_selector) && (n = typedArray.getResourceId(R.styleable.ColorPickerView_selector, -1)) != -1) {
                this.selectorDrawable = AppCompatResources.getDrawable((Context)this.getContext(), (int)n);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_selector_alpha)) {
                this.selector_alpha = typedArray.getFloat(R.styleable.ColorPickerView_selector_alpha, this.selector_alpha);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_selector_size)) {
                this.selectorSize = typedArray.getDimensionPixelSize(R.styleable.ColorPickerView_selector_size, this.selectorSize);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_flag_alpha)) {
                this.flag_alpha = typedArray.getFloat(R.styleable.ColorPickerView_flag_alpha, this.flag_alpha);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_flag_isFlipAble)) {
                this.flag_isFlipAble = typedArray.getBoolean(R.styleable.ColorPickerView_flag_isFlipAble, this.flag_isFlipAble);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_actionMode)) {
                int n2 = typedArray.getInteger(R.styleable.ColorPickerView_actionMode, 0);
                if (n2 == 0) {
                    this.actionMode = ActionMode.ALWAYS;
                } else if (n2 == 1) {
                    this.actionMode = ActionMode.LAST;
                }
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_debounceDuration)) {
                this.debounceDuration = typedArray.getInteger(R.styleable.ColorPickerView_debounceDuration, (int)this.debounceDuration);
            }
            if (typedArray.hasValue(R.styleable.ColorPickerView_preferenceName)) {
                this.preferenceName = typedArray.getString(R.styleable.ColorPickerView_preferenceName);
            }
            if (!typedArray.hasValue(R.styleable.ColorPickerView_initialColor)) return;
            this.setInitialColor(typedArray.getColor(R.styleable.ColorPickerView_initialColor, -1));
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    private Point getCenterPoint(int n, int n2) {
        return new Point(n - this.selector.getMeasuredWidth() / 2, n2 - this.selector.getMeasuredHeight() / 2);
    }

    private void notifyColorChanged() {
        this.debounceHandler.removeCallbacksAndMessages(null);
        ColorPickerView$$ExternalSyntheticLambda0 colorPickerView$$ExternalSyntheticLambda0 = new ColorPickerView$$ExternalSyntheticLambda0(this);
        this.debounceHandler.postDelayed((Runnable)colorPickerView$$ExternalSyntheticLambda0, this.debounceDuration);
    }

    private void notifyToFlagView(Point point) {
        Point point2 = this.getCenterPoint(point.x, point.y);
        FlagView flagView = this.flagView;
        if (flagView != null) {
            if (flagView.getFlagMode() == FlagMode.ALWAYS) {
                this.flagView.visible();
            }
            int n = point2.x - this.flagView.getWidth() / 2 + this.selector.getWidth() / 2;
            if (this.flagView.isFlipAble()) {
                if (point2.y - this.flagView.getHeight() > 0) {
                    this.flagView.setRotation(0.0f);
                    this.flagView.setX((float)n);
                    this.flagView.setY((float)(point2.y - this.flagView.getHeight()));
                } else {
                    this.flagView.setRotation(180.0f);
                    this.flagView.setX((float)n);
                    this.flagView.setY((float)(point2.y + this.flagView.getHeight()) - 0.5f * (float)this.selector.getHeight());
                }
            } else {
                this.flagView.setRotation(0.0f);
                this.flagView.setX((float)n);
                this.flagView.setY((float)(point2.y - this.flagView.getHeight()));
            }
            this.flagView.onRefresh(this.getColorEnvelope());
            if (n < 0) {
                this.flagView.setX(0.0f);
            }
            if (n + this.flagView.getMeasuredWidth() > this.getMeasuredWidth()) {
                this.flagView.setX((float)(this.getMeasuredWidth() - this.flagView.getMeasuredWidth()));
            }
        }
    }

    private void notifyToSlideBars() {
        BrightnessSlideBar brightnessSlideBar;
        AlphaSlideBar alphaSlideBar = this.alphaSlideBar;
        if (alphaSlideBar != null) {
            alphaSlideBar.notifyColor();
        }
        if ((brightnessSlideBar = this.brightnessSlider) != null) {
            brightnessSlideBar.notifyColor();
            if (this.brightnessSlider.assembleColor() != -1) {
                this.selectedColor = this.brightnessSlider.assembleColor();
                return;
            }
            AlphaSlideBar alphaSlideBar2 = this.alphaSlideBar;
            if (alphaSlideBar2 != null) {
                this.selectedColor = alphaSlideBar2.assembleColor();
            }
        }
    }

    private void onCreate() {
        ImageView imageView;
        ImageView imageView2;
        this.setPadding(0, 0, 0, 0);
        this.palette = imageView2 = new ImageView(this.getContext());
        Drawable drawable2 = this.paletteDrawable;
        if (drawable2 != null) {
            imageView2.setImageDrawable(drawable2);
        }
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        layoutParams.gravity = 17;
        this.addView((View)this.palette, (ViewGroup.LayoutParams)layoutParams);
        this.selector = imageView = new ImageView(this.getContext());
        Drawable drawable3 = this.selectorDrawable;
        if (drawable3 != null) {
            imageView.setImageDrawable(drawable3);
        } else {
            imageView.setImageDrawable(ContextCompat.getDrawable((Context)this.getContext(), (int)R.drawable.wheel));
        }
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(-2, -2);
        if (this.selectorSize != 0) {
            layoutParams2.width = SizeUtils.dp2Px(this.getContext(), this.selectorSize);
            layoutParams2.height = SizeUtils.dp2Px(this.getContext(), this.selectorSize);
        }
        layoutParams2.gravity = 17;
        this.addView((View)this.selector, (ViewGroup.LayoutParams)layoutParams2);
        this.selector.setAlpha(this.selector_alpha);
        this.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener(){

            public void onGlobalLayout() {
                if (Build.VERSION.SDK_INT < 16) {
                    ColorPickerView.this.getViewTreeObserver().removeGlobalOnLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
                } else {
                    ColorPickerView.this.getViewTreeObserver().removeOnGlobalLayoutListener((ViewTreeObserver.OnGlobalLayoutListener)this);
                }
                ColorPickerView.this.onFinishInflated();
            }
        });
    }

    private void onFinishInflated() {
        if (this.getParent() != null && this.getParent() instanceof ViewGroup) {
            ((ViewGroup)this.getParent()).setClipChildren(false);
        }
        if (this.getPreferenceName() != null) {
            this.preferenceManager.restoreColorPickerData(this);
            int n = this.preferenceManager.getColor(this.getPreferenceName(), -1);
            if (this.palette.getDrawable() instanceof ColorHsvPalette && n != -1) {
                this.post((Runnable)new ColorPickerView$$ExternalSyntheticLambda1(this, n));
                return;
            }
        } else {
            this.selectCenter();
        }
    }

    private boolean onTouchReceived(MotionEvent motionEvent) {
        int n;
        Point point = PointMapper.getColorPoint(this, new Point((int)motionEvent.getX(), (int)motionEvent.getY()));
        this.selectedPureColor = n = this.getColorFromBitmap(point.x, point.y);
        this.selectedColor = n;
        this.selectedPoint = PointMapper.getColorPoint(this, new Point(point.x, point.y));
        this.setCoordinate(point.x, point.y);
        if (this.actionMode == ActionMode.LAST) {
            this.notifyToFlagView(this.selectedPoint);
            if (motionEvent.getAction() == 1) {
                this.notifyColorChanged();
                return true;
            }
        } else {
            this.notifyColorChanged();
        }
        return true;
    }

    public void attachAlphaSlider(AlphaSlideBar alphaSlideBar) {
        this.alphaSlideBar = alphaSlideBar;
        alphaSlideBar.attachColorPickerView(this);
        alphaSlideBar.notifyColor();
        if (this.getPreferenceName() != null) {
            alphaSlideBar.setPreferenceName(this.getPreferenceName());
        }
    }

    public void attachBrightnessSlider(BrightnessSlideBar brightnessSlideBar) {
        this.brightnessSlider = brightnessSlideBar;
        brightnessSlideBar.attachColorPickerView(this);
        brightnessSlideBar.notifyColor();
        if (this.getPreferenceName() != null) {
            brightnessSlideBar.setPreferenceName(this.getPreferenceName());
        }
    }

    public void fireColorListener(int n, boolean bl) {
        if (this.colorListener != null) {
            ColorPickerViewListener colorPickerViewListener;
            this.selectedColor = n;
            if (this.getAlphaSlideBar() != null) {
                this.getAlphaSlideBar().notifyColor();
                this.selectedColor = this.getAlphaSlideBar().assembleColor();
            }
            if (this.getBrightnessSlider() != null) {
                this.getBrightnessSlider().notifyColor();
                this.selectedColor = this.getBrightnessSlider().assembleColor();
            }
            if ((colorPickerViewListener = this.colorListener) instanceof ColorListener) {
                ((ColorListener)colorPickerViewListener).onColorSelected(this.selectedColor, bl);
            } else if (colorPickerViewListener instanceof ColorEnvelopeListener) {
                ColorEnvelope colorEnvelope = new ColorEnvelope(this.selectedColor);
                ((ColorEnvelopeListener)this.colorListener).onColorSelected(colorEnvelope, bl);
            }
            FlagView flagView = this.flagView;
            if (flagView != null) {
                flagView.onRefresh(this.getColorEnvelope());
                this.invalidate();
            }
            if (this.VISIBLE_FLAG) {
                FlagView flagView2;
                this.VISIBLE_FLAG = false;
                ImageView imageView = this.selector;
                if (imageView != null) {
                    imageView.setAlpha(this.selector_alpha);
                }
                if ((flagView2 = this.flagView) != null) {
                    flagView2.setAlpha(this.flag_alpha);
                }
            }
        }
    }

    public ActionMode getActionMode() {
        return this.actionMode;
    }

    public float getAlpha() {
        return (float)Color.alpha((int)this.getColor()) / 255.0f;
    }

    public AlphaSlideBar getAlphaSlideBar() {
        return this.alphaSlideBar;
    }

    public BrightnessSlideBar getBrightnessSlider() {
        return this.brightnessSlider;
    }

    public int getColor() {
        return this.selectedColor;
    }

    public ColorEnvelope getColorEnvelope() {
        return new ColorEnvelope(this.getColor());
    }

    protected int getColorFromBitmap(float f, float f2) {
        float f3;
        Matrix matrix = new Matrix();
        this.palette.getImageMatrix().invert(matrix);
        float[] arrf = new float[]{f, f2};
        matrix.mapPoints(arrf);
        if (this.palette.getDrawable() != null && this.palette.getDrawable() instanceof BitmapDrawable && (f3 = arrf[0]) >= 0.0f && arrf[1] >= 0.0f && f3 < (float)this.palette.getDrawable().getIntrinsicWidth() && arrf[1] < (float)this.palette.getDrawable().getIntrinsicHeight()) {
            this.invalidate();
            if (this.palette.getDrawable() instanceof ColorHsvPalette) {
                float f4 = f - 0.5f * (float)this.getWidth();
                float f5 = f2 - 0.5f * (float)this.getHeight();
                double d = Math.sqrt((double)(f4 * f4 + f5 * f5));
                float f6 = 0.5f * (float)Math.min((int)this.getWidth(), (int)this.getHeight());
                float[] arrf2 = new float[]{0.0f, 0.0f, 1.0f};
                arrf2[0] = 180.0f + (float)(180.0 * (Math.atan2((double)f5, (double)(-f4)) / 3.141592653589793));
                arrf2[1] = Math.max((float)0.0f, (float)Math.min((float)1.0f, (float)((float)(d / (double)f6))));
                return Color.HSVToColor((float[])arrf2);
            }
            Rect rect = this.palette.getDrawable().getBounds();
            int n = (int)(arrf[0] / (float)rect.width() * (float)((BitmapDrawable)this.palette.getDrawable()).getBitmap().getWidth());
            int n2 = (int)(arrf[1] / (float)rect.height() * (float)((BitmapDrawable)this.palette.getDrawable()).getBitmap().getHeight());
            return ((BitmapDrawable)this.palette.getDrawable()).getBitmap().getPixel(n, n2);
        }
        return 0;
    }

    public long getDebounceDuration() {
        return this.debounceDuration;
    }

    public FlagView getFlagView() {
        return this.flagView;
    }

    public String getPreferenceName() {
        return this.preferenceName;
    }

    public int getPureColor() {
        return this.selectedPureColor;
    }

    public Point getSelectedPoint() {
        return this.selectedPoint;
    }

    public ImageView getSelector() {
        return this.selector;
    }

    public float getSelectorX() {
        return this.selector.getX() - 0.5f * (float)this.selector.getMeasuredWidth();
    }

    public float getSelectorY() {
        return this.selector.getY() - 0.5f * (float)this.selector.getMeasuredHeight();
    }

    public boolean isHuePalette() {
        return this.palette.getDrawable() != null && this.palette.getDrawable() instanceof ColorHsvPalette;
    }

    /* synthetic */ void lambda$notifyColorChanged$1$com-skydoves-colorpickerview-ColorPickerView() {
        this.fireColorListener(this.getColor(), true);
        this.notifyToFlagView(this.selectedPoint);
    }

    /* synthetic */ void lambda$onFinishInflated$0$com-skydoves-colorpickerview-ColorPickerView(int n) {
        try {
            this.selectByHsvColor(n);
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return;
        }
    }

    /* synthetic */ void lambda$setInitialColor$2$com-skydoves-colorpickerview-ColorPickerView(int n) {
        try {
            this.selectByHsvColor(n);
            return;
        }
        catch (IllegalAccessException illegalAccessException) {
            illegalAccessException.printStackTrace();
            return;
        }
    }

    public void moveSelectorPoint(int n, int n2, int n3) {
        this.selectedPureColor = n3;
        this.selectedColor = n3;
        this.selectedPoint = new Point(n, n2);
        this.setCoordinate(n, n2);
        this.fireColorListener(this.getColor(), false);
        this.notifyToFlagView(this.selectedPoint);
    }

    protected void onCreateByBuilder(Builder builder) {
        this.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(SizeUtils.dp2Px(this.getContext(), builder.width), SizeUtils.dp2Px(this.getContext(), builder.height)));
        this.paletteDrawable = builder.paletteDrawable;
        this.selectorDrawable = builder.selectorDrawable;
        this.selector_alpha = builder.selector_alpha;
        this.flag_alpha = builder.flag_alpha;
        this.selectorSize = builder.selectorSize;
        this.debounceDuration = builder.debounceDuration;
        this.onCreate();
        if (builder.colorPickerViewListener != null) {
            this.setColorListener(builder.colorPickerViewListener);
        }
        if (builder.alphaSlideBar != null) {
            this.attachAlphaSlider(builder.alphaSlideBar);
        }
        if (builder.brightnessSlider != null) {
            this.attachBrightnessSlider(builder.brightnessSlider);
        }
        if (builder.actionMode != null) {
            this.actionMode = builder.actionMode;
        }
        if (builder.flagView != null) {
            this.setFlagView(builder.flagView);
        }
        if (builder.preferenceName != null) {
            this.setPreferenceName(builder.preferenceName);
        }
        if (builder.initialColor != 0) {
            this.setInitialColor(builder.initialColor);
        }
        if (builder.lifecycleOwner != null) {
            this.setLifecycleOwner(builder.lifecycleOwner);
        }
    }

    @OnLifecycleEvent(value=Lifecycle.Event.ON_DESTROY)
    public void onDestroy() {
        this.preferenceManager.saveColorPickerData(this);
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        super.onSizeChanged(n, n2, n3, n4);
        if (this.palette.getDrawable() == null) {
            Bitmap bitmap = Bitmap.createBitmap((int)n, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            this.palette.setImageDrawable((Drawable)new ColorHsvPalette(this.getResources(), bitmap));
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.isEnabled()) {
            return false;
        }
        int n = motionEvent.getActionMasked();
        if (n != 0 && n != 1 && n != 2) {
            this.selector.setPressed(false);
            return false;
        }
        if (this.getFlagView() != null) {
            this.getFlagView().receiveOnTouchEvent(motionEvent);
        }
        this.selector.setPressed(true);
        return this.onTouchReceived(motionEvent);
    }

    public void removeLifecycleOwner(LifecycleOwner lifecycleOwner) {
        lifecycleOwner.getLifecycle().removeObserver((LifecycleObserver)this);
    }

    public void selectByHsvColor(int n) throws IllegalAccessException {
        if (this.palette.getDrawable() instanceof ColorHsvPalette) {
            float[] arrf = new float[3];
            Color.colorToHSV((int)n, (float[])arrf);
            float f = 0.5f * (float)this.getWidth();
            float f2 = 0.5f * (float)this.getHeight();
            float f3 = arrf[1] * Math.min((float)f, (float)f2);
            Point point = PointMapper.getColorPoint(this, new Point((int)((double)f3 * Math.cos((double)Math.toRadians((double)arrf[0])) + (double)f), (int)((double)(-f3) * Math.sin((double)Math.toRadians((double)arrf[0])) + (double)f2)));
            this.selectedPureColor = n;
            this.selectedColor = n;
            this.selectedPoint = new Point(point.x, point.y);
            if (this.getAlphaSlideBar() != null) {
                this.getAlphaSlideBar().setSelectorByHalfSelectorPosition(this.getAlpha());
            }
            if (this.getBrightnessSlider() != null) {
                this.getBrightnessSlider().setSelectorByHalfSelectorPosition(arrf[2]);
            }
            this.setCoordinate(point.x, point.y);
            this.fireColorListener(this.getColor(), false);
            this.notifyToFlagView(this.selectedPoint);
            return;
        }
        throw new IllegalAccessException("selectByHsvColor(@ColorInt int color) can be called only when the palette is an instance of ColorHsvPalette. Use setHsvPaletteDrawable();");
    }

    public void selectByHsvColorRes(int n) throws IllegalAccessException {
        this.selectByHsvColor(ContextCompat.getColor((Context)this.getContext(), (int)n));
    }

    public void selectCenter() {
        this.setSelectorPoint(this.getMeasuredWidth() / 2, this.getMeasuredHeight() / 2);
    }

    public void setActionMode(ActionMode actionMode) {
        this.actionMode = actionMode;
    }

    public void setColorListener(ColorPickerViewListener colorPickerViewListener) {
        this.colorListener = colorPickerViewListener;
    }

    public void setCoordinate(int n, int n2) {
        ImageView imageView = this.selector;
        imageView.setX((float)n - 0.5f * (float)imageView.getMeasuredWidth());
        ImageView imageView2 = this.selector;
        imageView2.setY((float)n2 - 0.5f * (float)imageView2.getMeasuredHeight());
    }

    public void setDebounceDuration(long l) {
        this.debounceDuration = l;
    }

    public void setEnabled(boolean bl) {
        super.setEnabled(bl);
        ImageView imageView = this.selector;
        int n = bl ? 0 : 4;
        imageView.setVisibility(n);
        if (this.getAlphaSlideBar() != null) {
            this.getAlphaSlideBar().setEnabled(bl);
        }
        if (this.getBrightnessSlider() != null) {
            this.getBrightnessSlider().setEnabled(bl);
        }
        if (bl) {
            this.palette.clearColorFilter();
            return;
        }
        int n2 = Color.argb((int)70, (int)255, (int)255, (int)255);
        this.palette.setColorFilter(n2);
    }

    public void setFlagView(FlagView flagView) {
        flagView.gone();
        this.addView((View)flagView);
        this.flagView = flagView;
        flagView.setAlpha(this.flag_alpha);
        flagView.setFlipAble(this.flag_isFlipAble);
    }

    public void setHsvPaletteDrawable() {
        Bitmap bitmap = Bitmap.createBitmap((int)this.getWidth(), (int)this.getHeight(), (Bitmap.Config)Bitmap.Config.ARGB_8888);
        this.setPaletteDrawable((Drawable)new ColorHsvPalette(this.getResources(), bitmap));
    }

    public void setInitialColor(int n) {
        if (this.getPreferenceName() == null || this.getPreferenceName() != null && this.preferenceManager.getColor(this.getPreferenceName(), -1) == -1) {
            this.post((Runnable)new ColorPickerView$$ExternalSyntheticLambda2(this, n));
        }
    }

    public void setInitialColorRes(int n) {
        this.setInitialColor(ContextCompat.getColor((Context)this.getContext(), (int)n));
    }

    public void setLifecycleOwner(LifecycleOwner lifecycleOwner) {
        lifecycleOwner.getLifecycle().addObserver((LifecycleObserver)this);
    }

    public void setPaletteDrawable(Drawable drawable2) {
        ImageView imageView;
        this.removeView((View)this.palette);
        this.palette = imageView = new ImageView(this.getContext());
        this.paletteDrawable = drawable2;
        imageView.setImageDrawable(drawable2);
        this.addView((View)this.palette);
        this.removeView((View)this.selector);
        this.addView((View)this.selector);
        this.selectedPureColor = -1;
        this.notifyToSlideBars();
        FlagView flagView = this.flagView;
        if (flagView != null) {
            this.removeView((View)flagView);
            this.addView((View)this.flagView);
        }
        if (!this.VISIBLE_FLAG) {
            FlagView flagView2;
            this.VISIBLE_FLAG = true;
            ImageView imageView2 = this.selector;
            if (imageView2 != null) {
                this.selector_alpha = imageView2.getAlpha();
                this.selector.setAlpha(0.0f);
            }
            if ((flagView2 = this.flagView) != null) {
                this.flag_alpha = flagView2.getAlpha();
                this.flagView.setAlpha(0.0f);
            }
        }
    }

    public void setPreferenceName(String string2) {
        BrightnessSlideBar brightnessSlideBar;
        this.preferenceName = string2;
        AlphaSlideBar alphaSlideBar = this.alphaSlideBar;
        if (alphaSlideBar != null) {
            alphaSlideBar.setPreferenceName(string2);
        }
        if ((brightnessSlideBar = this.brightnessSlider) != null) {
            brightnessSlideBar.setPreferenceName(string2);
        }
    }

    public void setPureColor(int n) {
        this.selectedPureColor = n;
    }

    public void setSelectorDrawable(Drawable drawable2) {
        this.selector.setImageDrawable(drawable2);
    }

    public void setSelectorPoint(int n, int n2) {
        int n3;
        Point point = PointMapper.getColorPoint(this, new Point(n, n2));
        this.selectedPureColor = n3 = this.getColorFromBitmap(point.x, point.y);
        this.selectedColor = n3;
        this.selectedPoint = new Point(point.x, point.y);
        this.setCoordinate(point.x, point.y);
        this.fireColorListener(this.getColor(), false);
        this.notifyToFlagView(this.selectedPoint);
    }

    public static class Builder {
        private ActionMode actionMode = ActionMode.ALWAYS;
        private AlphaSlideBar alphaSlideBar;
        private BrightnessSlideBar brightnessSlider;
        private ColorPickerViewListener colorPickerViewListener;
        private final Context context;
        private int debounceDuration = 0;
        private FlagView flagView;
        private float flag_alpha = 1.0f;
        private boolean flag_isFlipAble = false;
        @Dp
        private int height = -1;
        private int initialColor = 0;
        private LifecycleOwner lifecycleOwner;
        private Drawable paletteDrawable;
        private String preferenceName;
        private Drawable selectorDrawable;
        @Dp
        private int selectorSize = 0;
        private float selector_alpha = 1.0f;
        @Dp
        private int width = -1;

        public Builder(Context context) {
            this.context = context;
        }

        public ColorPickerView build() {
            ColorPickerView colorPickerView = new ColorPickerView(this.context);
            colorPickerView.onCreateByBuilder(this);
            return colorPickerView;
        }

        public Builder setActionMode(ActionMode actionMode) {
            this.actionMode = actionMode;
            return this;
        }

        public Builder setAlphaSlideBar(AlphaSlideBar alphaSlideBar) {
            this.alphaSlideBar = alphaSlideBar;
            return this;
        }

        public Builder setBrightnessSlideBar(BrightnessSlideBar brightnessSlideBar) {
            this.brightnessSlider = brightnessSlideBar;
            return this;
        }

        public Builder setColorListener(ColorPickerViewListener colorPickerViewListener) {
            this.colorPickerViewListener = colorPickerViewListener;
            return this;
        }

        public Builder setDebounceDuration(int n) {
            this.debounceDuration = n;
            return this;
        }

        public Builder setFlagAlpha(float f) {
            this.flag_alpha = f;
            return this;
        }

        public Builder setFlagIsFlipAble(boolean bl) {
            this.flag_isFlipAble = bl;
            return this;
        }

        public Builder setFlagView(FlagView flagView) {
            this.flagView = flagView;
            return this;
        }

        public Builder setHeight(@Dp int n) {
            this.height = n;
            return this;
        }

        public Builder setInitialColor(int n) {
            this.initialColor = n;
            return this;
        }

        public Builder setInitialColorRes(int n) {
            this.initialColor = ContextCompat.getColor((Context)this.context, (int)n);
            return this;
        }

        public Builder setLifecycleOwner(LifecycleOwner lifecycleOwner) {
            this.lifecycleOwner = lifecycleOwner;
            return this;
        }

        public Builder setPaletteDrawable(Drawable drawable2) {
            this.paletteDrawable = drawable2;
            return this;
        }

        public Builder setPreferenceName(String string2) {
            this.preferenceName = string2;
            return this;
        }

        public Builder setSelectorAlpha(float f) {
            this.selector_alpha = f;
            return this;
        }

        public Builder setSelectorDrawable(Drawable drawable2) {
            this.selectorDrawable = drawable2;
            return this;
        }

        public Builder setSelectorSize(@Dp int n) {
            this.selectorSize = n;
            return this;
        }

        public Builder setWidth(@Dp int n) {
            this.width = n;
            return this;
        }
    }

}

