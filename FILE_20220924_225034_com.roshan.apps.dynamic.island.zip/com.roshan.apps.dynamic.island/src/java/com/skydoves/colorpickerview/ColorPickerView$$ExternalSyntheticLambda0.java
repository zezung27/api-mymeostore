/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.skydoves.colorpickerview;

import com.skydoves.colorpickerview.ColorPickerView;

public final class ColorPickerView$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ ColorPickerView f$0;

    public /* synthetic */ ColorPickerView$$ExternalSyntheticLambda0(ColorPickerView colorPickerView) {
        this.f$0 = colorPickerView;
    }

    public final void run() {
        this.f$0.lambda$notifyColorChanged$1$com-skydoves-colorpickerview-ColorPickerView();
    }
}

