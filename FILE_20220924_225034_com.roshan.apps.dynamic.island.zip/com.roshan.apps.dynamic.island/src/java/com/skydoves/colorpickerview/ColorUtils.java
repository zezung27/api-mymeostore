/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Locale
 */
package com.skydoves.colorpickerview;

import android.graphics.Color;
import java.util.Locale;

class ColorUtils {
    ColorUtils() {
    }

    public static int[] getColorARGB(int n) {
        int[] arrn = new int[]{Color.alpha((int)n), Color.red((int)n), Color.green((int)n), Color.blue((int)n)};
        return arrn;
    }

    public static String getHexCode(int n) {
        int n2 = Color.alpha((int)n);
        int n3 = Color.red((int)n);
        int n4 = Color.green((int)n);
        int n5 = Color.blue((int)n);
        Locale locale = Locale.getDefault();
        Object[] arrobject = new Object[]{n2, n3, n4, n5};
        return String.format((Locale)locale, (String)"%02X%02X%02X%02X", (Object[])arrobject);
    }
}

