/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  java.lang.Object
 */
package com.skydoves.colorpickerview;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.skydoves.colorpickerview.R;

public class FadeUtils {
    public static void fadeIn(View view) {
        Animation animation = AnimationUtils.loadAnimation((Context)view.getContext(), (int)R.anim.fade_in_colorpickerview_skydoves);
        animation.setFillAfter(true);
        view.startAnimation(animation);
    }

    public static void fadeOut(View view) {
        Animation animation = AnimationUtils.loadAnimation((Context)view.getContext(), (int)R.anim.fade_out_colorpickerview_skydoves);
        animation.setFillAfter(true);
        view.startAnimation(animation);
    }
}

