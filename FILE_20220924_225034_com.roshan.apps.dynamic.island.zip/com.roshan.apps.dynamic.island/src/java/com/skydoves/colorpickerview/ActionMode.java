/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.skydoves.colorpickerview;

public final class ActionMode
extends Enum<ActionMode> {
    private static final /* synthetic */ ActionMode[] $VALUES;
    public static final /* enum */ ActionMode ALWAYS;
    public static final /* enum */ ActionMode LAST;

    static {
        ActionMode actionMode;
        ActionMode actionMode2;
        ALWAYS = actionMode = new ActionMode();
        LAST = actionMode2 = new ActionMode();
        $VALUES = new ActionMode[]{actionMode, actionMode2};
    }

    public static ActionMode valueOf(String string2) {
        return (ActionMode)Enum.valueOf(ActionMode.class, (String)string2);
    }

    public static ActionMode[] values() {
        return (ActionMode[])$VALUES.clone();
    }
}

