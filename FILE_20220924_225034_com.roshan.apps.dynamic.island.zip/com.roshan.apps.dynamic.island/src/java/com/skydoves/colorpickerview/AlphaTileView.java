/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.util.AttributeSet
 *  android.view.View
 */
package com.skydoves.colorpickerview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import com.skydoves.colorpickerview.R;
import com.skydoves.colorpickerview.sliders.AlphaTileDrawable;

public class AlphaTileView
extends View {
    private Bitmap backgroundBitmap;
    private final AlphaTileDrawable.Builder builder = new AlphaTileDrawable.Builder();
    private Paint colorPaint;

    public AlphaTileView(Context context) {
        super(context);
        this.onCreate();
    }

    public AlphaTileView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.onCreate();
        this.getAttrs(attributeSet);
    }

    public AlphaTileView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.onCreate();
        this.getAttrs(attributeSet);
    }

    public AlphaTileView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
        this.onCreate();
        this.getAttrs(attributeSet);
    }

    private void getAttrs(AttributeSet attributeSet) {
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.AlphaTileView);
        try {
            if (typedArray.hasValue(R.styleable.AlphaTileView_tileSize)) {
                this.builder.setTileSize(typedArray.getInt(R.styleable.AlphaTileView_tileSize, this.builder.getTileSize()));
            }
            if (typedArray.hasValue(R.styleable.AlphaTileView_tileOddColor)) {
                this.builder.setTileOddColor(typedArray.getInt(R.styleable.AlphaTileView_tileOddColor, this.builder.getTileOddColor()));
            }
            if (typedArray.hasValue(R.styleable.AlphaTileView_tileEvenColor)) {
                this.builder.setTileEvenColor(typedArray.getInt(R.styleable.AlphaTileView_tileEvenColor, this.builder.getTileEvenColor()));
            }
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    private void onCreate() {
        this.colorPaint = new Paint(1);
        this.setBackgroundColor(-1);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawBitmap(this.backgroundBitmap, 0.0f, 0.0f, null);
        canvas.drawRect(0.0f, 0.0f, (float)this.getMeasuredWidth(), (float)this.getMeasuredHeight(), this.colorPaint);
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        Bitmap bitmap;
        super.onSizeChanged(n, n2, n3, n4);
        AlphaTileDrawable alphaTileDrawable = this.builder.build();
        this.backgroundBitmap = bitmap = Bitmap.createBitmap((int)n, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        if (bitmap != null && !bitmap.isRecycled()) {
            Canvas canvas = new Canvas(this.backgroundBitmap);
            alphaTileDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            alphaTileDrawable.draw(canvas);
        }
    }

    public void setBackgroundColor(int n) {
        this.setPaintColor(n);
    }

    public void setPaintColor(int n) {
        this.colorPaint.setColor(n);
        this.invalidate();
    }
}

