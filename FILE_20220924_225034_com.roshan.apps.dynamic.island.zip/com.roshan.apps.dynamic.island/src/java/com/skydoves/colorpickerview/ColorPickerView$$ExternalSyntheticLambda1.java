/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.skydoves.colorpickerview;

import com.skydoves.colorpickerview.ColorPickerView;

public final class ColorPickerView$$ExternalSyntheticLambda1
implements Runnable {
    public final /* synthetic */ ColorPickerView f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ ColorPickerView$$ExternalSyntheticLambda1(ColorPickerView colorPickerView, int n) {
        this.f$0 = colorPickerView;
        this.f$1 = n;
    }

    public final void run() {
        this.f$0.lambda$onFinishInflated$0$com-skydoves-colorpickerview-ColorPickerView(this.f$1);
    }
}

