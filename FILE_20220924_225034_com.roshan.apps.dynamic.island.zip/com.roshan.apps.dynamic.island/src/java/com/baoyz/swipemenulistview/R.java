/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.baoyz.swipemenulistview;

public final class R {
    private R() {
    }

    public static final class string {
        public static final int app_name = 2131886125;

        private string() {
        }
    }

}

