/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.lang.String
 */
package com.baoyz.swipemenulistview;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;

public class SwipeMenuItem {
    private Drawable background;
    private Drawable icon;
    private int id;
    private Context mContext;
    private String title;
    private int titleColor;
    private int titleSize;
    private int width;

    public SwipeMenuItem(Context context) {
        this.mContext = context;
    }

    public Drawable getBackground() {
        return this.background;
    }

    public Drawable getIcon() {
        return this.icon;
    }

    public int getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public int getTitleColor() {
        return this.titleColor;
    }

    public int getTitleSize() {
        return this.titleSize;
    }

    public int getWidth() {
        return this.width;
    }

    public void setBackground(int n) {
        this.background = this.mContext.getResources().getDrawable(n);
    }

    public void setBackground(Drawable drawable2) {
        this.background = drawable2;
    }

    public void setIcon(int n) {
        this.icon = this.mContext.getResources().getDrawable(n);
    }

    public void setIcon(Drawable drawable2) {
        this.icon = drawable2;
    }

    public void setId(int n) {
        this.id = n;
    }

    public void setTitle(int n) {
        this.setTitle(this.mContext.getString(n));
    }

    public void setTitle(String string2) {
        this.title = string2;
    }

    public void setTitleColor(int n) {
        this.titleColor = n;
    }

    public void setTitleSize(int n) {
        this.titleSize = n;
    }

    public void setWidth(int n) {
        this.width = n;
    }
}

