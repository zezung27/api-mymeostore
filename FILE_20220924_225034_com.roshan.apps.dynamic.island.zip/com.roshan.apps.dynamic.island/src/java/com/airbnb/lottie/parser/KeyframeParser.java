/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  android.view.animation.Interpolator
 *  android.view.animation.LinearInterpolator
 *  androidx.collection.SparseArrayCompat
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.ref.WeakReference
 */
package com.airbnb.lottie.parser;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.collection.SparseArrayCompat;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.parser.JsonUtils;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.value.Keyframe;
import java.io.IOException;
import java.lang.ref.WeakReference;

class KeyframeParser {
    static JsonReader.Options INTERPOLATOR_NAMES;
    private static final Interpolator LINEAR_INTERPOLATOR;
    private static final float MAX_CP_VALUE = 100.0f;
    static JsonReader.Options NAMES;
    private static SparseArrayCompat<WeakReference<Interpolator>> pathInterpolatorCache;

    static {
        LINEAR_INTERPOLATOR = new LinearInterpolator();
        NAMES = JsonReader.Options.of("t", "s", "e", "o", "i", "h", "to", "ti");
        INTERPOLATOR_NAMES = JsonReader.Options.of("x", "y");
    }

    KeyframeParser() {
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static WeakReference<Interpolator> getInterpolator(int n) {
        Class<KeyframeParser> class_ = KeyframeParser.class;
        synchronized (KeyframeParser.class) {
            return (WeakReference)KeyframeParser.pathInterpolatorCache().get(n);
        }
    }

    /*
     * Exception decompiling
     */
    private static Interpolator interpolatorFor(PointF var0, PointF var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    static <T> Keyframe<T> parse(JsonReader jsonReader, LottieComposition lottieComposition, float f, ValueParser<T> valueParser, boolean bl, boolean bl2) throws IOException {
        if (bl && bl2) {
            return KeyframeParser.parseMultiDimensionalKeyframe(lottieComposition, jsonReader, f, valueParser);
        }
        if (bl) {
            return KeyframeParser.parseKeyframe(lottieComposition, jsonReader, f, valueParser);
        }
        return KeyframeParser.parseStaticValue(jsonReader, f, valueParser);
    }

    private static <T> Keyframe<T> parseKeyframe(LottieComposition lottieComposition, JsonReader jsonReader, float f, ValueParser<T> valueParser) throws IOException {
        Interpolator interpolator2;
        Object t;
        jsonReader.beginObject();
        PointF pointF = null;
        boolean bl = false;
        Object t2 = null;
        Object t3 = null;
        PointF pointF2 = null;
        PointF pointF3 = null;
        float f2 = 0.0f;
        PointF pointF4 = null;
        block10 : while (jsonReader.hasNext()) {
            switch (jsonReader.selectName(NAMES)) {
                default: {
                    jsonReader.skipValue();
                    continue block10;
                }
                case 7: {
                    pointF3 = JsonUtils.jsonToPoint(jsonReader, f);
                    continue block10;
                }
                case 6: {
                    pointF2 = JsonUtils.jsonToPoint(jsonReader, f);
                    continue block10;
                }
                case 5: {
                    if (jsonReader.nextInt() == 1) {
                        bl = true;
                        continue block10;
                    }
                    bl = false;
                    continue block10;
                }
                case 4: {
                    pointF4 = JsonUtils.jsonToPoint(jsonReader, 1.0f);
                    continue block10;
                }
                case 3: {
                    pointF = JsonUtils.jsonToPoint(jsonReader, 1.0f);
                    continue block10;
                }
                case 2: {
                    t2 = valueParser.parse(jsonReader, f);
                    continue block10;
                }
                case 1: {
                    t3 = valueParser.parse(jsonReader, f);
                    continue block10;
                }
                case 0: 
            }
            f2 = (float)jsonReader.nextDouble();
        }
        jsonReader.endObject();
        if (bl) {
            interpolator2 = LINEAR_INTERPOLATOR;
            t = t3;
        } else {
            Interpolator interpolator3 = pointF != null && pointF4 != null ? KeyframeParser.interpolatorFor(pointF, pointF4) : LINEAR_INTERPOLATOR;
            interpolator2 = interpolator3;
            t = t2;
        }
        Keyframe<Object> keyframe = new Keyframe<Object>(lottieComposition, t3, t, interpolator2, f2, null);
        keyframe.pathCp1 = pointF2;
        keyframe.pathCp2 = pointF3;
        return keyframe;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private static <T> Keyframe<T> parseMultiDimensionalKeyframe(LottieComposition var0, JsonReader var1_1, float var2_2, ValueParser<T> var3_3) throws IOException {
        var1_1.beginObject();
        var4_4 = null;
        var5_5 = false;
        var6_6 = null;
        var7_7 = null;
        var8_8 = null;
        var9_9 = null;
        var10_10 = null;
        var11_11 = null;
        var12_12 = null;
        var13_13 = 0.0f;
        var14_14 = null;
        var15_15 = null;
        block10 : do {
            block27 : {
                block34 : {
                    block26 : {
                        block25 : {
                            block29 : {
                                block28 : {
                                    block24 : {
                                        if (!var1_1.hasNext()) break block24;
                                        switch (var1_1.selectName(KeyframeParser.NAMES)) {
                                            default: {
                                                var29_16 = var4_4;
                                                var1_1.skipValue();
                                                break;
                                            }
                                            case 7: {
                                                var4_4 = JsonUtils.jsonToPoint(var1_1, var2_2);
                                                continue block10;
                                            }
                                            case 6: {
                                                var14_14 = JsonUtils.jsonToPoint(var1_1, var2_2);
                                                continue block10;
                                            }
                                            case 5: {
                                                if (var1_1.nextInt() == 1) {
                                                    var5_5 = true;
                                                    continue block10;
                                                }
                                                var5_5 = false;
                                                continue block10;
                                            }
                                            case 4: {
                                                if (var1_1.peek() != JsonReader.Token.BEGIN_OBJECT) ** GOTO lbl41
                                                var1_1.beginObject();
                                                var46_26 = 0.0f;
                                                var47_27 = 0.0f;
                                                var48_28 = 0.0f;
                                                var49_29 = 0.0f;
                                                break block25;
lbl41: // 1 sources:
                                                var29_16 = var4_4;
                                                var7_7 = JsonUtils.jsonToPoint(var1_1, var2_2);
                                                break;
                                            }
                                            case 3: {
                                                var29_16 = var4_4;
                                                var35_17 = var13_13;
                                                var36_18 = var14_14;
                                                if (var1_1.peek() != JsonReader.Token.BEGIN_OBJECT) ** GOTO lbl55
                                                var1_1.beginObject();
                                                var37_19 = 0.0f;
                                                var38_20 = 0.0f;
                                                var39_21 = 0.0f;
                                                var40_22 = 0.0f;
                                                break block26;
lbl55: // 1 sources:
                                                var6_6 = JsonUtils.jsonToPoint(var1_1, var2_2);
                                                var13_13 = var35_17;
                                                var14_14 = var36_18;
                                                break;
                                            }
                                            case 2: {
                                                var29_16 = var4_4;
                                                var15_15 = var3_3.parse(var1_1, var2_2);
                                                break;
                                            }
                                            case 1: {
                                                var29_16 = var4_4;
                                                var9_9 = var3_3.parse(var1_1, var2_2);
                                                break;
                                            }
                                            case 0: {
                                                var29_16 = var4_4;
                                                var13_13 = (float)var1_1.nextDouble();
                                                break;
                                            }
                                        }
                                        break block27;
                                    }
                                    var16_37 = var4_4;
                                    var17_38 = var13_13;
                                    var18_39 = var14_14;
                                    var1_1.endObject();
                                    if (!var5_5) break block28;
                                    var19_40 = KeyframeParser.LINEAR_INTERPOLATOR;
                                    var20_41 = var9_9;
                                    ** GOTO lbl96
                                }
                                if (var6_6 == null || var7_7 == null) break block29;
                                var19_40 = KeyframeParser.interpolatorFor(var6_6, var7_7);
                                ** GOTO lbl95
                            }
                            if (var8_8 != null && var10_10 != null && var11_11 != null && var12_12 != null) {
                                var27_44 = KeyframeParser.interpolatorFor(var8_8, var11_11);
                                var28_45 = KeyframeParser.interpolatorFor(var10_10, var12_12);
                                var21_42 = var27_44;
                                var22_43 = var28_45;
                                var20_41 = var15_15;
                                var19_40 = null;
                            } else {
                                var19_40 = KeyframeParser.LINEAR_INTERPOLATOR;
lbl95: // 2 sources:
                                var20_41 = var15_15;
lbl96: // 2 sources:
                                var21_42 = null;
                                var22_43 = null;
                            }
                            if (var21_42 != null && var22_43 != null) {
                                var26_47 = var25_46;
                                var23_48 = var18_39;
                                super(var0, var9_9, var20_41, var21_42, var22_43, var17_38, null);
                            } else {
                                var23_48 = var18_39;
                                var25_46 = var24_49 = new Keyframe<Object>(var0, var9_9, var20_41, var19_40, var17_38, null);
                            }
                            var25_46.pathCp1 = var23_48;
                            var25_46.pathCp2 = var16_37;
                            return var25_46;
                        }
                        while (var1_1.hasNext()) {
                            block32 : {
                                block30 : {
                                    block33 : {
                                        block31 : {
                                            var53_32 = var14_14;
                                            var54_33 = var1_1.selectName(KeyframeParser.INTERPOLATOR_NAMES);
                                            if (var54_33 == 0) break block30;
                                            var55_34 = var4_4;
                                            if (var54_33 == 1) break block31;
                                            var1_1.skipValue();
                                            break block32;
                                        }
                                        if (var1_1.peek() != JsonReader.Token.NUMBER) break block33;
                                        var57_36 = var13_13;
                                        var49_29 = (float)var1_1.nextDouble();
                                        var13_13 = var57_36;
                                        var47_27 = var49_29;
                                        break block32;
                                    }
                                    var56_35 = var13_13;
                                    var1_1.beginArray();
                                    var47_27 = (float)var1_1.nextDouble();
                                    var49_29 = var1_1.peek() == JsonReader.Token.NUMBER ? (float)var1_1.nextDouble() : var47_27;
                                    var1_1.endArray();
                                    ** GOTO lbl143
                                }
                                var55_34 = var4_4;
                                var56_35 = var13_13;
                                if (var1_1.peek() == JsonReader.Token.NUMBER) {
                                    var48_28 = (float)var1_1.nextDouble();
                                    var13_13 = var56_35;
                                    var46_26 = var48_28;
                                } else {
                                    var1_1.beginArray();
                                    var46_26 = (float)var1_1.nextDouble();
                                    var48_28 = var1_1.peek() == JsonReader.Token.NUMBER ? (float)var1_1.nextDouble() : var46_26;
                                    var1_1.endArray();
lbl143: // 2 sources:
                                    var13_13 = var56_35;
                                }
                            }
                            var14_14 = var53_32;
                            var4_4 = var55_34;
                        }
                        var29_16 = var4_4;
                        var35_17 = var13_13;
                        var51_30 = new PointF(var46_26, var47_27);
                        var52_31 = new PointF(var48_28, var49_29);
                        var1_1.endObject();
                        var12_12 = var52_31;
                        var11_11 = var51_30;
                        break block34;
                    }
                    while (var1_1.hasNext()) {
                        var43_25 = var1_1.selectName(KeyframeParser.INTERPOLATOR_NAMES);
                        if (var43_25 != 0) {
                            if (var43_25 != 1) {
                                var1_1.skipValue();
                                continue;
                            }
                            if (var1_1.peek() == JsonReader.Token.NUMBER) {
                                var38_20 = var40_22 = (float)var1_1.nextDouble();
                                continue;
                            }
                            var1_1.beginArray();
                            var38_20 = (float)var1_1.nextDouble();
                            var40_22 = var1_1.peek() == JsonReader.Token.NUMBER ? (float)var1_1.nextDouble() : var38_20;
                            var1_1.endArray();
                            continue;
                        }
                        if (var1_1.peek() == JsonReader.Token.NUMBER) {
                            var37_19 = var39_21 = (float)var1_1.nextDouble();
                            continue;
                        }
                        var1_1.beginArray();
                        var37_19 = (float)var1_1.nextDouble();
                        var39_21 = var1_1.peek() == JsonReader.Token.NUMBER ? (float)var1_1.nextDouble() : var37_19;
                        var1_1.endArray();
                    }
                    var41_23 = new PointF(var37_19, var38_20);
                    var42_24 = new PointF(var39_21, var40_22);
                    var1_1.endObject();
                    var10_10 = var42_24;
                    var8_8 = var41_23;
                    var14_14 = var36_18;
                }
                var13_13 = var35_17;
            }
            var4_4 = var29_16;
        } while (true);
    }

    private static <T> Keyframe<T> parseStaticValue(JsonReader jsonReader, float f, ValueParser<T> valueParser) throws IOException {
        return new Keyframe<T>(valueParser.parse(jsonReader, f));
    }

    private static SparseArrayCompat<WeakReference<Interpolator>> pathInterpolatorCache() {
        if (pathInterpolatorCache == null) {
            pathInterpolatorCache = new SparseArrayCompat();
        }
        return pathInterpolatorCache;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void putInterpolator(int n, WeakReference<Interpolator> weakReference) {
        Class<KeyframeParser> class_ = KeyframeParser.class;
        synchronized (KeyframeParser.class) {
            pathInterpolatorCache.put(n, weakReference);
            // ** MonitorExit[var3_2] (shouldn't be in output)
            return;
        }
    }
}

