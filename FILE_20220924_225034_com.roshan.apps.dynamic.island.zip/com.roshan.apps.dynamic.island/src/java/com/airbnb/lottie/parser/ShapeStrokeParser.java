/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.content.ShapeStroke;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.value.Keyframe;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class ShapeStrokeParser {
    private static final JsonReader.Options DASH_PATTERN_NAMES;
    private static final JsonReader.Options NAMES;

    static {
        NAMES = JsonReader.Options.of("nm", "c", "w", "o", "lc", "lj", "ml", "hd", "d");
        DASH_PATTERN_NAMES = JsonReader.Options.of("n", "v");
    }

    private ShapeStrokeParser() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static ShapeStroke parse(JsonReader var0, LottieComposition var1_1) throws IOException {
        block27 : {
            block26 : {
                var2_2 = new ArrayList();
                var3_3 = false;
                var4_4 = 0.0f;
                var5_5 = null;
                var6_6 = null;
                var7_7 = null;
                var8_8 = null;
                var9_9 = null;
                var10_10 = null;
                var11_11 = null;
                while (var0.hasNext()) {
                    block0 : switch (var0.selectName(ShapeStrokeParser.NAMES)) {
                        default: {
                            var0.skipValue();
                            break;
                        }
                        case 8: {
                            var0.beginArray();
lbl18: // 4 sources:
                            do {
                                if (var0.hasNext()) {
                                    var0.beginObject();
                                    var14_12 = null;
                                    var15_13 = null;
                                    break block26;
                                }
                                var0.endArray();
                                if (var2_2.size() != 1) break block0;
                                var2_2.add((Object)((AnimatableFloatValue)var2_2.get(0)));
                                break block0;
                                break;
                            } while (true);
                        }
                        case 7: {
                            var3_3 = var0.nextBoolean();
                            break;
                        }
                        case 6: {
                            var4_4 = (float)var0.nextDouble();
                            break;
                        }
                        case 5: {
                            var10_10 = ShapeStroke.LineJoinType.values()[var0.nextInt() - 1];
                            break;
                        }
                        case 4: {
                            var9_9 = ShapeStroke.LineCapType.values()[var0.nextInt() - 1];
                            break;
                        }
                        case 3: {
                            var11_11 = AnimatableValueParser.parseInteger(var0, var1_1);
                            break;
                        }
                        case 2: {
                            var8_8 = AnimatableValueParser.parseFloat(var0, var1_1);
                            break;
                        }
                        case 1: {
                            var7_7 = AnimatableValueParser.parseColor(var0, var1_1);
                            break;
                        }
                        case 0: {
                            var5_5 = var0.nextString();
                            break;
                        }
                    }
                }
                if (var11_11 != null) return new ShapeStroke(var5_5, var6_6, (List<AnimatableFloatValue>)var2_2, var7_7, var11_11, var8_8, var9_9, var10_10, var4_4, var3_3);
                var11_11 = new AnimatableIntegerValue((List<Keyframe<Integer>>)Collections.singletonList(new Keyframe<Integer>((int)100)));
                return new ShapeStroke(var5_5, var6_6, (List<AnimatableFloatValue>)var2_2, var7_7, var11_11, var8_8, var9_9, var10_10, var4_4, var3_3);
            }
            while (var0.hasNext()) {
                var19_15 = var0.selectName(ShapeStrokeParser.DASH_PATTERN_NAMES);
                if (var19_15 != 0) {
                    if (var19_15 != 1) {
                        var0.skipName();
                        var0.skipValue();
                        continue;
                    }
                    var15_13 = AnimatableValueParser.parseFloat(var0, var1_1);
                    continue;
                }
                var14_12 = var0.nextString();
            }
            var0.endObject();
            var14_12.hashCode();
            switch (var14_12.hashCode()) {
                case 111: {
                    if (!var14_12.equals((Object)"o")) break;
                    var17_14 = 2;
                    ** break;
                }
                case 103: {
                    if (!var14_12.equals((Object)"g")) break;
                    var17_14 = 1;
                    ** break;
                }
                case 100: {
                    if (var14_12.equals((Object)"d")) break block27;
                }
            }
            var17_14 = -1;
            ** break;
        }
        var17_14 = 0;
lbl85: // 4 sources:
        switch (var17_14) {
            default: {
                ** GOTO lbl18
            }
            case 2: {
                var6_6 = var15_13;
                ** GOTO lbl18
            }
            case 0: 
            case 1: 
        }
        var1_1.setHasDashPattern(true);
        var2_2.add((Object)var15_13);
        ** while (true)
    }
}

