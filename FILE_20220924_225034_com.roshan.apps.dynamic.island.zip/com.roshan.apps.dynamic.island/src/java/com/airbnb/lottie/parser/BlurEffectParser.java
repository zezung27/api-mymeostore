/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.content.BlurEffect;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.io.IOException;

class BlurEffectParser {
    private static final JsonReader.Options BLUR_EFFECT_NAMES = JsonReader.Options.of("ef");
    private static final JsonReader.Options INNER_BLUR_EFFECT_NAMES = JsonReader.Options.of("ty", "v");

    BlurEffectParser() {
    }

    private static BlurEffect maybeParseInnerEffect(JsonReader jsonReader, LottieComposition lottieComposition) throws IOException {
        jsonReader.beginObject();
        BlurEffect blurEffect = null;
        block0 : do {
            boolean bl = false;
            while (jsonReader.hasNext()) {
                int n = jsonReader.selectName(INNER_BLUR_EFFECT_NAMES);
                if (n != 0) {
                    if (n != 1) {
                        jsonReader.skipName();
                        jsonReader.skipValue();
                        continue;
                    }
                    if (bl) {
                        blurEffect = new BlurEffect(AnimatableValueParser.parseFloat(jsonReader, lottieComposition));
                        continue;
                    }
                    jsonReader.skipValue();
                    continue;
                }
                if (jsonReader.nextInt() != 0) continue block0;
                bl = true;
            }
            break;
        } while (true);
        jsonReader.endObject();
        return blurEffect;
    }

    static BlurEffect parse(JsonReader jsonReader, LottieComposition lottieComposition) throws IOException {
        BlurEffect blurEffect = null;
        while (jsonReader.hasNext()) {
            if (jsonReader.selectName(BLUR_EFFECT_NAMES) != 0) {
                jsonReader.skipName();
                jsonReader.skipValue();
                continue;
            }
            jsonReader.beginArray();
            while (jsonReader.hasNext()) {
                BlurEffect blurEffect2 = BlurEffectParser.maybeParseInnerEffect(jsonReader, lottieComposition);
                if (blurEffect2 == null) continue;
                blurEffect = blurEffect2;
            }
            jsonReader.endArray();
        }
        return blurEffect;
    }
}

