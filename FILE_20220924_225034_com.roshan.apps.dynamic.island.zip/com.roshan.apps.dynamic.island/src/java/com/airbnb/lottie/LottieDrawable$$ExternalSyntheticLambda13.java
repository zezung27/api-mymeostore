/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda13
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda13(LottieDrawable lottieDrawable, String string2) {
        this.f$0 = lottieDrawable;
        this.f$1 = string2;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$setMinFrame$6$com-airbnb-lottie-LottieDrawable(this.f$1, lottieComposition);
    }
}

