/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.model.content;

import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.MergePathsContent;
import com.airbnb.lottie.model.content.ContentModel;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.Logger;

public class MergePaths
implements ContentModel {
    private final boolean hidden;
    private final MergePathsMode mode;
    private final String name;

    public MergePaths(String string2, MergePathsMode mergePathsMode, boolean bl) {
        this.name = string2;
        this.mode = mergePathsMode;
        this.hidden = bl;
    }

    public MergePathsMode getMode() {
        return this.mode;
    }

    public String getName() {
        return this.name;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    @Override
    public Content toContent(LottieDrawable lottieDrawable, BaseLayer baseLayer) {
        if (!lottieDrawable.enableMergePathsForKitKatAndAbove()) {
            Logger.warning("Animation contains merge paths but they are disabled.");
            return null;
        }
        return new MergePathsContent(this);
    }

    public String toString() {
        return "MergePaths{mode=" + (Object)((Object)this.mode) + '}';
    }

    public static final class MergePathsMode
    extends Enum<MergePathsMode> {
        private static final /* synthetic */ MergePathsMode[] $VALUES;
        public static final /* enum */ MergePathsMode ADD;
        public static final /* enum */ MergePathsMode EXCLUDE_INTERSECTIONS;
        public static final /* enum */ MergePathsMode INTERSECT;
        public static final /* enum */ MergePathsMode MERGE;
        public static final /* enum */ MergePathsMode SUBTRACT;

        static {
            MergePathsMode mergePathsMode;
            MergePathsMode mergePathsMode2;
            MergePathsMode mergePathsMode3;
            MergePathsMode mergePathsMode4;
            MergePathsMode mergePathsMode5;
            MERGE = mergePathsMode4 = new MergePathsMode();
            ADD = mergePathsMode3 = new MergePathsMode();
            SUBTRACT = mergePathsMode5 = new MergePathsMode();
            INTERSECT = mergePathsMode = new MergePathsMode();
            EXCLUDE_INTERSECTIONS = mergePathsMode2 = new MergePathsMode();
            $VALUES = new MergePathsMode[]{mergePathsMode4, mergePathsMode3, mergePathsMode5, mergePathsMode, mergePathsMode2};
        }

        public static MergePathsMode forId(int n) {
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        if (n != 4) {
                            if (n != 5) {
                                return MERGE;
                            }
                            return EXCLUDE_INTERSECTIONS;
                        }
                        return INTERSECT;
                    }
                    return SUBTRACT;
                }
                return ADD;
            }
            return MERGE;
        }

        public static MergePathsMode valueOf(String string2) {
            return (MergePathsMode)Enum.valueOf(MergePathsMode.class, (String)string2);
        }

        public static MergePathsMode[] values() {
            return (MergePathsMode[])$VALUES.clone();
        }
    }

}

