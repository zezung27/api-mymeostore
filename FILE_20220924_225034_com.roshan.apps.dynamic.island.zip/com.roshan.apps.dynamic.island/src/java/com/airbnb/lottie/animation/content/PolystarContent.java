/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.graphics.PointF
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Path;
import android.graphics.PointF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.CompoundTrimPathContent;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.content.TrimPathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.content.PolystarShape;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class PolystarContent
implements PathContent,
BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent {
    private static final float POLYGON_MAGIC_NUMBER = 0.25f;
    private static final float POLYSTAR_MAGIC_NUMBER = 0.47829f;
    private final boolean hidden;
    private final BaseKeyframeAnimation<?, Float> innerRadiusAnimation;
    private final BaseKeyframeAnimation<?, Float> innerRoundednessAnimation;
    private boolean isPathValid;
    private final boolean isReversed;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final BaseKeyframeAnimation<?, Float> outerRadiusAnimation;
    private final BaseKeyframeAnimation<?, Float> outerRoundednessAnimation;
    private final Path path = new Path();
    private final BaseKeyframeAnimation<?, Float> pointsAnimation;
    private final BaseKeyframeAnimation<?, PointF> positionAnimation;
    private final BaseKeyframeAnimation<?, Float> rotationAnimation;
    private final CompoundTrimPathContent trimPaths = new CompoundTrimPathContent();
    private final PolystarShape.Type type;

    public PolystarContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, PolystarShape polystarShape) {
        PolystarShape.Type type;
        this.lottieDrawable = lottieDrawable;
        this.name = polystarShape.getName();
        this.type = type = polystarShape.getType();
        this.hidden = polystarShape.isHidden();
        this.isReversed = polystarShape.isReversed();
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation = polystarShape.getPoints().createAnimation();
        this.pointsAnimation = baseKeyframeAnimation;
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation2 = polystarShape.getPosition().createAnimation();
        this.positionAnimation = baseKeyframeAnimation2;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation3 = polystarShape.getRotation().createAnimation();
        this.rotationAnimation = baseKeyframeAnimation3;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation4 = polystarShape.getOuterRadius().createAnimation();
        this.outerRadiusAnimation = baseKeyframeAnimation4;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation5 = polystarShape.getOuterRoundedness().createAnimation();
        this.outerRoundednessAnimation = baseKeyframeAnimation5;
        if (type == PolystarShape.Type.STAR) {
            this.innerRadiusAnimation = polystarShape.getInnerRadius().createAnimation();
            this.innerRoundednessAnimation = polystarShape.getInnerRoundedness().createAnimation();
        } else {
            this.innerRadiusAnimation = null;
            this.innerRoundednessAnimation = null;
        }
        baseLayer.addAnimation(baseKeyframeAnimation);
        baseLayer.addAnimation(baseKeyframeAnimation2);
        baseLayer.addAnimation(baseKeyframeAnimation3);
        baseLayer.addAnimation(baseKeyframeAnimation4);
        baseLayer.addAnimation(baseKeyframeAnimation5);
        if (type == PolystarShape.Type.STAR) {
            baseLayer.addAnimation(this.innerRadiusAnimation);
            baseLayer.addAnimation(this.innerRoundednessAnimation);
        }
        baseKeyframeAnimation.addUpdateListener(this);
        baseKeyframeAnimation2.addUpdateListener(this);
        baseKeyframeAnimation3.addUpdateListener(this);
        baseKeyframeAnimation4.addUpdateListener(this);
        baseKeyframeAnimation5.addUpdateListener(this);
        if (type == PolystarShape.Type.STAR) {
            this.innerRadiusAnimation.addUpdateListener(this);
            this.innerRoundednessAnimation.addUpdateListener(this);
        }
    }

    private void createPolygonPath() {
        int n = (int)Math.floor((double)this.pointsAnimation.getValue().floatValue());
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.rotationAnimation;
        double d = baseKeyframeAnimation == null ? 0.0 : (double)baseKeyframeAnimation.getValue().floatValue();
        double d2 = Math.toRadians((double)(d - 90.0));
        double d3 = n;
        float f = (float)(6.283185307179586 / d3);
        float f2 = this.outerRoundednessAnimation.getValue().floatValue() / 100.0f;
        float f3 = this.outerRadiusAnimation.getValue().floatValue();
        double d4 = f3;
        float f4 = (float)(d4 * Math.cos((double)d2));
        float f5 = (float)(d4 * Math.sin((double)d2));
        this.path.moveTo(f4, f5);
        double d5 = f;
        double d6 = d2 + d5;
        double d7 = Math.ceil((double)d3);
        int n2 = 0;
        while ((double)n2 < d7) {
            int n3;
            double d8;
            double d9;
            double d10;
            float f6 = (float)(d4 * Math.cos((double)d6));
            double d11 = Math.sin((double)d6);
            double d12 = d7;
            float f7 = (float)(d4 * d11);
            if (f2 != 0.0f) {
                d9 = d4;
                double d13 = f5;
                n3 = n2;
                d8 = d6;
                double d14 = (float)(Math.atan2((double)d13, (double)f4) - 1.5707963267948966);
                float f8 = (float)Math.cos((double)d14);
                float f9 = (float)Math.sin((double)d14);
                double d15 = f7;
                d10 = d5;
                double d16 = (float)(Math.atan2((double)d15, (double)f6) - 1.5707963267948966);
                float f10 = (float)Math.cos((double)d16);
                float f11 = (float)Math.sin((double)d16);
                float f12 = 0.25f * (f3 * f2);
                float f13 = f8 * f12;
                float f14 = f9 * f12;
                float f15 = f10 * f12;
                float f16 = f12 * f11;
                this.path.cubicTo(f4 - f13, f5 - f14, f6 + f15, f7 + f16, f6, f7);
            } else {
                d8 = d6;
                d9 = d4;
                d10 = d5;
                n3 = n2;
                this.path.lineTo(f6, f7);
            }
            d6 = d8 + d10;
            n2 = n3 + 1;
            f5 = f7;
            f4 = f6;
            d7 = d12;
            d4 = d9;
            d5 = d10;
        }
        PointF pointF = this.positionAnimation.getValue();
        this.path.offset(pointF.x, pointF.y);
        this.path.close();
    }

    private void createStarPath() {
        float f;
        double d;
        float f2;
        double d2;
        float f3;
        float f4;
        double d3;
        float f5 = this.pointsAnimation.getValue().floatValue();
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation = this.rotationAnimation;
        double d4 = baseKeyframeAnimation == null ? 0.0 : (double)baseKeyframeAnimation.getValue().floatValue();
        double d5 = Math.toRadians((double)(d4 - 90.0));
        double d6 = f5;
        float f6 = (float)(6.283185307179586 / d6);
        if (this.isReversed) {
            f6 *= -1.0f;
        }
        float f7 = f6 / 2.0f;
        float f8 = f5 - (float)((int)f5);
        float f9 = f8 FCMPL 0.0f;
        if (f9 != false) {
            d5 += (double)(f7 * (1.0f - f8));
        }
        float f10 = this.outerRadiusAnimation.getValue().floatValue();
        float f11 = this.innerRadiusAnimation.getValue().floatValue();
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2 = this.innerRoundednessAnimation;
        float f12 = baseKeyframeAnimation2 != null ? baseKeyframeAnimation2.getValue().floatValue() / 100.0f : 0.0f;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation3 = this.outerRoundednessAnimation;
        float f13 = baseKeyframeAnimation3 != null ? baseKeyframeAnimation3.getValue().floatValue() / 100.0f : 0.0f;
        if (f9 != false) {
            f = f11 + f8 * (f10 - f11);
            f4 = f9;
            double d7 = f;
            double d8 = Math.cos((double)d5);
            d2 = d6;
            f3 = (float)(d7 * d8);
            f2 = (float)(d7 * Math.sin((double)d5));
            this.path.moveTo(f3, f2);
            d = d5 + (double)(f6 * f8 / 2.0f);
        } else {
            d2 = d6;
            f4 = f9;
            double d9 = f10;
            float f14 = (float)(d9 * Math.cos((double)d5));
            float f15 = (float)(d9 * Math.sin((double)d5));
            this.path.moveTo(f14, f15);
            d = d5 + (double)f7;
            f3 = f14;
            f2 = f15;
            f = 0.0f;
        }
        double d10 = 2.0 * Math.ceil((double)d2);
        int n = 0;
        boolean bl = false;
        while ((d3 = (double)n) < d10) {
            float f16;
            float f17;
            double d11;
            float f18;
            float f19;
            float f20;
            float f21;
            float f22 = bl ? f10 : f11;
            float f23 = f FCMPL 0.0f;
            if (f23 != false && d3 == d10 - 2.0) {
                float f24 = f6 * f8 / 2.0f;
                f18 = f6;
                f17 = f24;
            } else {
                f18 = f6;
                f17 = f7;
            }
            if (f23 != false && d3 == d10 - 1.0) {
                f20 = f7;
                d11 = d3;
                f19 = f;
            } else {
                f20 = f7;
                d11 = d3;
                f19 = f22;
            }
            double d12 = f19;
            double d13 = Math.cos((double)d);
            double d14 = d10;
            float f25 = (float)(d12 * d13);
            float f26 = (float)(d12 * Math.sin((double)d));
            if (f12 == 0.0f && f13 == 0.0f) {
                this.path.lineTo(f25, f26);
                f16 = f12;
                f21 = f;
            } else {
                double d15 = f2;
                f16 = f12;
                f21 = f;
                double d16 = (float)(Math.atan2((double)d15, (double)f3) - 1.5707963267948966);
                float f27 = (float)Math.cos((double)d16);
                float f28 = (float)Math.sin((double)d16);
                double d17 = (float)(Math.atan2((double)f26, (double)f25) - 1.5707963267948966);
                float f29 = (float)Math.cos((double)d17);
                float f30 = (float)Math.sin((double)d17);
                float f31 = bl ? f16 : f13;
                float f32 = bl ? f13 : f16;
                float f33 = bl ? f11 : f10;
                float f34 = bl ? f10 : f11;
                float f35 = 0.47829f * (f33 * f31);
                float f36 = f27 * f35;
                float f37 = f35 * f28;
                float f38 = 0.47829f * (f34 * f32);
                float f39 = f29 * f38;
                float f40 = f38 * f30;
                if (f4 != false) {
                    if (n == 0) {
                        f36 *= f8;
                        f37 *= f8;
                    } else if (d11 == d14 - 1.0) {
                        f39 *= f8;
                        f40 *= f8;
                    }
                }
                this.path.cubicTo(f3 - f36, f2 - f37, f25 + f39, f26 + f40, f25, f26);
            }
            d += (double)f17;
            bl ^= true;
            ++n;
            f3 = f25;
            f2 = f26;
            f12 = f16;
            f = f21;
            f7 = f20;
            f6 = f18;
            d10 = d14;
        }
        PointF pointF = this.positionAnimation.getValue();
        this.path.offset(pointF.x, pointF.y);
        this.path.close();
    }

    private void invalidate() {
        this.isPathValid = false;
        this.lottieDrawable.invalidateSelf();
    }

    @Override
    public <T> void addValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2;
        if (t == LottieProperty.POLYSTAR_POINTS) {
            this.pointsAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POLYSTAR_ROTATION) {
            this.rotationAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POSITION) {
            this.positionAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POLYSTAR_INNER_RADIUS && (baseKeyframeAnimation = this.innerRadiusAnimation) != null) {
            baseKeyframeAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POLYSTAR_OUTER_RADIUS) {
            this.outerRadiusAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POLYSTAR_INNER_ROUNDEDNESS && (baseKeyframeAnimation2 = this.innerRoundednessAnimation) != null) {
            baseKeyframeAnimation2.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POLYSTAR_OUTER_ROUNDEDNESS) {
            this.outerRoundednessAnimation.setValueCallback(lottieValueCallback);
        }
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        if (this.isPathValid) {
            return this.path;
        }
        this.path.reset();
        if (this.hidden) {
            this.isPathValid = true;
            return this.path;
        }
        int n = 1.$SwitchMap$com$airbnb$lottie$model$content$PolystarShape$Type[this.type.ordinal()];
        if (n != 1) {
            if (n == 2) {
                this.createPolygonPath();
            }
        } else {
            this.createStarPath();
        }
        this.path.close();
        this.trimPaths.apply(this.path);
        this.isPathValid = true;
        return this.path;
    }

    @Override
    public void onValueChanged() {
        this.invalidate();
    }

    @Override
    public void resolveKeyPath(KeyPath keyPath, int n, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath(keyPath, n, list, keyPath2, this);
    }

    @Override
    public void setContents(List<Content> list, List<Content> list2) {
        for (int i = 0; i < list.size(); ++i) {
            TrimPathContent trimPathContent;
            Content content = (Content)list.get(i);
            if (!(content instanceof TrimPathContent) || (trimPathContent = (TrimPathContent)content).getType() != ShapeTrimPath.Type.SIMULTANEOUSLY) continue;
            this.trimPaths.addTrimPath(trimPathContent);
            trimPathContent.addListener(this);
        }
    }

}

