/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.InputStream
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieCompositionFactory;
import java.io.InputStream;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda8
implements Callable {
    public final /* synthetic */ InputStream f$0;
    public final /* synthetic */ String f$1;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda8(InputStream inputStream, String string2) {
        this.f$0 = inputStream;
        this.f$1 = string2;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromJsonInputStream$3(this.f$0, this.f$1);
    }
}

