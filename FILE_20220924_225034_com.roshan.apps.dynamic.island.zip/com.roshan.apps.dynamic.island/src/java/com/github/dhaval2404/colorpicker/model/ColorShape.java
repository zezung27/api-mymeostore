/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.model;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\u0001\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u00012\u00020\u0002B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0003J\t\u0010\u0004\u001a\u00020\u0005H\u00d6\u0001J\u0019\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005H\u00d6\u0001j\u0002\b\u000bj\u0002\b\f\u00a8\u0006\r"}, d2={"Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "", "Landroid/os/Parcelable;", "(Ljava/lang/String;I)V", "describeContents", "", "writeToParcel", "", "parcel", "Landroid/os/Parcel;", "flags", "CIRCLE", "SQAURE", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorShape
extends Enum<ColorShape>
implements Parcelable {
    private static final /* synthetic */ ColorShape[] $VALUES;
    public static final /* enum */ ColorShape CIRCLE = new ColorShape();
    public static final Parcelable.Creator<ColorShape> CREATOR;
    public static final /* enum */ ColorShape SQAURE;

    static {
        SQAURE = new ColorShape();
        $VALUES = arrcolorShape = new ColorShape[]{ColorShape.CIRCLE, ColorShape.SQAURE};
        CREATOR = new Creator();
    }

    public static ColorShape valueOf(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"value");
        return (ColorShape)Enum.valueOf(ColorShape.class, (String)string2);
    }

    public static ColorShape[] values() {
        ColorShape[] arrcolorShape = $VALUES;
        return (ColorShape[])Arrays.copyOf((Object[])arrcolorShape, (int)arrcolorShape.length);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        Intrinsics.checkNotNullParameter((Object)parcel, (String)"out");
        parcel.writeString(this.name());
    }

    @Metadata(k=3, mv={1, 5, 1}, xi=48)
    public static final class Creator
    implements Parcelable.Creator<ColorShape> {
        public final ColorShape createFromParcel(Parcel parcel) {
            Intrinsics.checkNotNullParameter((Object)parcel, (String)"parcel");
            return ColorShape.valueOf(parcel.readString());
        }

        public final ColorShape[] newArray(int n) {
            return new ColorShape[n];
        }
    }

}

