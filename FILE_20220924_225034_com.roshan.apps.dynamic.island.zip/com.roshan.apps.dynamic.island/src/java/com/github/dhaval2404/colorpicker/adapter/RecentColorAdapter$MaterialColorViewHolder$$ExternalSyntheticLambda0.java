/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker.adapter;

import android.view.View;
import com.github.dhaval2404.colorpicker.adapter.RecentColorAdapter;

public final class RecentColorAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ RecentColorAdapter f$0;

    public /* synthetic */ RecentColorAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0(RecentColorAdapter recentColorAdapter) {
        this.f$0 = recentColorAdapter;
    }

    public final void onClick(View view) {
        RecentColorAdapter.MaterialColorViewHolder.$r8$lambda$p3HHvRbNqY_UhT1oaiT60Iz-k1w(this.f$0, view);
    }
}

