/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.graphics.PointF
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  com.github.dhaval2404.colorpicker.ColorPickerView$setColorListener
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 */
package com.github.dhaval2404.colorpicker;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import com.github.dhaval2404.colorpicker.ColorPickerView;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import com.github.dhaval2404.colorpicker.widget.ColorPalette;
import com.github.dhaval2404.colorpicker.widget.ColorPointer;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

@Metadata(d1={"\u0000^\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\u0018\u0000 12\u00020\u0001:\u00011B%\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\bB)\b\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u00a2\u0006\u0002\u0010\nJ\u0006\u0010\u0017\u001a\u00020\u0007J\u0018\u0010\u0018\u001a\u00020\u00072\u0006\u0010\u0019\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\fH\u0002J\u0018\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001d\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u0007H\u0014J(\u0010\u001f\u001a\u00020\u001c2\u0006\u0010 \u001a\u00020\u00072\u0006\u0010!\u001a\u00020\u00072\u0006\u0010\"\u001a\u00020\u00072\u0006\u0010#\u001a\u00020\u0007H\u0014J\u0010\u0010$\u001a\u00020%2\u0006\u0010&\u001a\u00020'H\u0017J\u0010\u0010(\u001a\u00020\u001c2\u0006\u0010)\u001a\u00020\u0007H\u0002J\u000e\u0010*\u001a\u00020\u001c2\u0006\u0010)\u001a\u00020\u0007J \u0010+\u001a\u00020\u001c2\u0018\u0010,\u001a\u0014\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020.\u0012\u0004\u0012\u00020\u001c0-J\u0010\u0010/\u001a\u00020\u001c2\u0006\u0010&\u001a\u00020'H\u0002J\u0018\u00100\u001a\u00020\u001c2\u0006\u0010\u0019\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\fH\u0002R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u00062"}, d2={"Lcom/github/dhaval2404/colorpicker/ColorPickerView;", "Landroid/widget/FrameLayout;", "context", "Landroid/content/Context;", "attrs", "Landroid/util/AttributeSet;", "defStyleAttr", "", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "defStyleRes", "(Landroid/content/Context;Landroid/util/AttributeSet;II)V", "centerX", "", "centerY", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "colorPointer", "Lcom/github/dhaval2404/colorpicker/widget/ColorPointer;", "currentColor", "currentPoint", "Landroid/graphics/PointF;", "pointerRadiusPx", "radius", "getColor", "getColorAtPoint", "eventX", "eventY", "onMeasure", "", "widthMeasureSpec", "heightMeasureSpec", "onSizeChanged", "w", "h", "oldw", "oldh", "onTouchEvent", "", "event", "Landroid/view/MotionEvent;", "pickColor", "color", "setColor", "setColorListener", "listener", "Lkotlin/Function2;", "", "update", "updateSelector", "Companion", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorPickerView
extends FrameLayout {
    public static final float COLOR_POINTER_RADIUS_DP = 8.0f;
    public static final Companion Companion = new Companion(null);
    private float centerX;
    private float centerY;
    private ColorListener colorListener;
    private ColorPointer colorPointer;
    private int currentColor;
    private final PointF currentPoint;
    private float pointerRadiusPx;
    private float radius;

    public ColorPickerView(Context context) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, null, 0, 6, null);
    }

    public ColorPickerView(Context context, AttributeSet attributeSet) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        this(context, attributeSet, 0, 4, null);
    }

    public ColorPickerView(Context context, AttributeSet attributeSet, int n) {
        ColorPointer colorPointer;
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        super(context, attributeSet, n);
        this.pointerRadiusPx = 8.0f * this.getResources().getDisplayMetrics().density;
        this.currentColor = -65281;
        this.currentPoint = new PointF();
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        Context context2 = this.getContext();
        Intrinsics.checkNotNullExpressionValue((Object)context2, (String)"context");
        ColorPalette colorPalette = new ColorPalette(context2, null, 0, 0, 14, null);
        int n2 = (int)this.pointerRadiusPx;
        colorPalette.setPadding(n2, n2, n2, n2);
        View view = colorPalette;
        ViewGroup.LayoutParams layoutParams2 = (ViewGroup.LayoutParams)layoutParams;
        this.addView(view, layoutParams2);
        Context context3 = this.getContext();
        Intrinsics.checkNotNullExpressionValue((Object)context3, (String)"context");
        this.colorPointer = colorPointer = new ColorPointer(context3, null, 0, 0, 14, null);
        colorPointer.setPointerRadius(this.pointerRadiusPx);
        this.addView((View)this.colorPointer, layoutParams2);
    }

    public ColorPickerView(Context context, AttributeSet attributeSet, int n, int n2) {
        ColorPointer colorPointer;
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        super(context, attributeSet, n, n2);
        this.pointerRadiusPx = 8.0f * this.getResources().getDisplayMetrics().density;
        this.currentColor = -65281;
        this.currentPoint = new PointF();
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
        Context context2 = this.getContext();
        Intrinsics.checkNotNullExpressionValue((Object)context2, (String)"context");
        ColorPalette colorPalette = new ColorPalette(context2, null, 0, 0, 14, null);
        int n3 = (int)this.pointerRadiusPx;
        colorPalette.setPadding(n3, n3, n3, n3);
        View view = colorPalette;
        ViewGroup.LayoutParams layoutParams2 = (ViewGroup.LayoutParams)layoutParams;
        this.addView(view, layoutParams2);
        Context context3 = this.getContext();
        Intrinsics.checkNotNullExpressionValue((Object)context3, (String)"context");
        this.colorPointer = colorPointer = new ColorPointer(context3, null, 0, 0, 14, null);
        colorPointer.setPointerRadius(this.pointerRadiusPx);
        this.addView((View)this.colorPointer, layoutParams2);
    }

    public /* synthetic */ ColorPickerView(Context context, AttributeSet attributeSet, int n, int n2, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n2 & 2) != 0) {
            attributeSet = null;
        }
        if ((n2 & 4) != 0) {
            n = 0;
        }
        this(context, attributeSet, n);
    }

    private final int getColorAtPoint(float f, float f2) {
        float f3 = f - this.centerX;
        float f4 = f2 - this.centerY;
        double d = f3 * f3;
        double d2 = f4;
        double d3 = Math.sqrt((double)(d + d2 * d2));
        float[] arrf = new float[]{0.0f, 0.0f, 1.0f};
        arrf[0] = (float)(Math.atan2((double)d2, (double)(-((double)f3))) / 3.141592653589793 * (double)180.0f) + (float)180;
        arrf[1] = RangesKt.coerceAtLeast((float)0.0f, (float)RangesKt.coerceAtMost((float)1.0f, (float)((float)(d3 / (double)this.radius))));
        return Color.HSVToColor((float[])arrf);
    }

    private final void pickColor(int n) {
        ColorListener colorListener = this.colorListener;
        if (colorListener == null) {
            return;
        }
        colorListener.onColorSelected(n, ColorUtil.formatColor(n));
    }

    private final void update(MotionEvent motionEvent) {
        int n;
        float f = motionEvent.getX();
        float f2 = motionEvent.getY();
        this.currentColor = n = this.getColorAtPoint(f, f2);
        this.pickColor(n);
        this.updateSelector(f, f2);
    }

    private final void updateSelector(float f, float f2) {
        float f3;
        float f4 = f - this.centerX;
        double d = f4 * f4;
        float f5 = f2 - this.centerY;
        double d2 = f5;
        double d3 = Math.sqrt((double)(d + d2 * d2));
        if (d3 > (double)(f3 = this.radius)) {
            float f6 = (float)d3;
            f4 *= f3 / f6;
            f5 *= f3 / f6;
        }
        this.currentPoint.x = f4 + this.centerX;
        this.currentPoint.y = f5 + this.centerY;
        this.colorPointer.setCurrentPoint(this.currentPoint);
    }

    public void _$_clearFindViewByIdCache() {
    }

    public final int getColor() {
        return this.currentColor;
    }

    protected void onMeasure(int n, int n2) {
        int n3 = RangesKt.coerceAtMost((int)View.MeasureSpec.getSize((int)n), (int)View.MeasureSpec.getSize((int)n2));
        super.onMeasure(View.MeasureSpec.makeMeasureSpec((int)n3, (int)1073741824), View.MeasureSpec.makeMeasureSpec((int)n3, (int)1073741824));
    }

    protected void onSizeChanged(int n, int n2, int n3, int n4) {
        float f;
        int n5 = n - this.getPaddingLeft() - this.getPaddingRight();
        int n6 = n2 - this.getPaddingTop() - this.getPaddingBottom();
        this.radius = f = 0.5f * (float)RangesKt.coerceAtMost((int)n5, (int)n6) - this.pointerRadiusPx;
        if (f < 0.0f) {
            return;
        }
        this.centerX = 0.5f * (float)n5;
        this.centerY = 0.5f * (float)n6;
        this.setColor(this.currentColor);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        Intrinsics.checkNotNullParameter((Object)motionEvent, (String)"event");
        int n = motionEvent.getActionMasked();
        if (n != 0 && n != 1 && n != 2) {
            return super.onTouchEvent(motionEvent);
        }
        this.update(motionEvent);
        return true;
    }

    public final void setColor(int n) {
        float[] arrf = new float[3];
        Color.colorToHSV((int)n, (float[])arrf);
        float f = arrf[1] * this.radius;
        float f2 = (float)(3.141592653589793 * (double)(arrf[0] / 180.0f));
        double d = f;
        double d2 = f2;
        this.updateSelector((float)(d * Math.cos((double)d2) + (double)this.centerX), (float)((double)(-f) * Math.sin((double)d2) + (double)this.centerY));
        this.currentColor = n;
    }

    public final void setColorListener(Function2<? super Integer, ? super String, Unit> function2) {
        Intrinsics.checkNotNullParameter(function2, (String)"listener");
        this.colorListener = new ColorListener(function2){
            final /* synthetic */ Function2<Integer, String, Unit> $listener;
            {
                this.$listener = function2;
            }

            public void onColorSelected(int n, String string2) {
                Intrinsics.checkNotNullParameter((Object)string2, (String)"colorHex");
                this.$listener.invoke((Object)n, (Object)string2);
            }
        };
    }

    @Metadata(d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0005"}, d2={"Lcom/github/dhaval2404/colorpicker/ColorPickerView$Companion;", "", "()V", "COLOR_POINTER_RADIUS_DP", "", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

}

