/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  androidx.appcompat.widget.AppCompatImageView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.adapter;

import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.github.dhaval2404.colorpicker.R;
import com.github.dhaval2404.colorpicker.adapter.ColorViewBinding;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import com.github.dhaval2404.colorpicker.util.ViewExtKt;
import dalvik.annotation.SourceDebugExtension;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nMaterialColorPickerAdapter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MaterialColorPickerAdapter.kt\ncom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,98:1\n1768#2,4:99\n*S KotlinDebug\n*F\n+ 1 MaterialColorPickerAdapter.kt\ncom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter\n*L\n28#1:99,4\n*E\n")
@Metadata(d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u001dB\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u000fJ\b\u0010\u0010\u001a\u00020\u000fH\u0016J\u0006\u0010\u0011\u001a\u00020\u0005J\u001c\u0010\u0012\u001a\u00020\u00132\n\u0010\u0014\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u001c\u0010\u0015\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u000fH\u0016J\u000e\u0010\u0019\u001a\u00020\u00132\u0006\u0010\b\u001a\u00020\tJ\u000e\u0010\u001a\u001a\u00020\u00132\u0006\u0010\u0007\u001a\u00020\u0005J\u000e\u0010\u001b\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u000bR\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001e"}, d2={"Lcom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter$MaterialColorViewHolder;", "colors", "", "", "(Ljava/util/List;)V", "color", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "isDarkColor", "", "isTickColorPerCard", "getItem", "position", "", "getItemCount", "getSelectedColor", "onBindViewHolder", "", "holder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setColorShape", "setDefaultColor", "setTickColorPerCard", "tickColorPerCard", "MaterialColorViewHolder", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class MaterialColorPickerAdapter
extends RecyclerView.Adapter<MaterialColorViewHolder> {
    private String color;
    private ColorShape colorShape;
    private final List<String> colors;
    private boolean isDarkColor;
    private boolean isTickColorPerCard;

    public MaterialColorPickerAdapter(List<String> list) {
        int n;
        Intrinsics.checkNotNullParameter(list, (String)"colors");
        this.colors = list;
        this.color = "";
        this.colorShape = ColorShape.CIRCLE;
        Iterable iterable = (Iterable)list;
        if (iterable instanceof Collection && ((Collection)iterable).isEmpty()) {
            n = 0;
        } else {
            Iterator iterator = iterable.iterator();
            n = 0;
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                if (!ColorUtil.isDarkColor(string2) || ++n >= 0) continue;
                CollectionsKt.throwCountOverflow();
            }
        }
        int n2 = n * 2;
        int n3 = this.colors.size();
        boolean bl = false;
        if (n2 >= n3) {
            bl = true;
        }
        this.isDarkColor = bl;
    }

    public static final /* synthetic */ void access$setColor$p(MaterialColorPickerAdapter materialColorPickerAdapter, String string2) {
        materialColorPickerAdapter.color = string2;
    }

    public final String getItem(int n) {
        return (String)this.colors.get(n);
    }

    public int getItemCount() {
        return this.colors.size();
    }

    public final String getSelectedColor() {
        return this.color;
    }

    public void onBindViewHolder(MaterialColorViewHolder materialColorViewHolder, int n) {
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorViewHolder), (String)"holder");
        materialColorViewHolder.bind(n);
    }

    public MaterialColorViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        Intrinsics.checkNotNullParameter((Object)viewGroup, (String)"parent");
        return new MaterialColorViewHolder(ColorViewBinding.INSTANCE.inflateAdapterItemView(viewGroup));
    }

    public final void setColorShape(ColorShape colorShape) {
        Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"colorShape");
        this.colorShape = colorShape;
    }

    public final void setDefaultColor(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
        this.color = string2;
    }

    public final void setTickColorPerCard(boolean bl) {
        this.isTickColorPerCard = bl;
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    @Metadata(d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rR\u0016\u0010\u0005\u001a\n \u0007*\u0004\u0018\u00010\u00060\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u0010\b\u001a\n \u0007*\u0004\u0018\u00010\t0\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u000e"}, d2={"Lcom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter$MaterialColorViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "rootView", "Landroid/view/View;", "(Lcom/github/dhaval2404/colorpicker/adapter/MaterialColorPickerAdapter;Landroid/view/View;)V", "checkIcon", "Landroidx/appcompat/widget/AppCompatImageView;", "kotlin.jvm.PlatformType", "colorView", "Landroidx/cardview/widget/CardView;", "bind", "", "position", "", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public final class MaterialColorViewHolder
    extends RecyclerView.ViewHolder {
        private final AppCompatImageView checkIcon;
        private final CardView colorView;
        private final View rootView;

        public static /* synthetic */ void $r8$lambda$3IzHiaQC3ObNpnPQDkY2Nymqkic(MaterialColorPickerAdapter materialColorPickerAdapter, View view) {
            MaterialColorViewHolder._init_$lambda-0(materialColorPickerAdapter, view);
        }

        public MaterialColorViewHolder(View view) {
            Intrinsics.checkNotNullParameter((Object)((Object)MaterialColorPickerAdapter.this), (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)view, (String)"rootView");
            super(view);
            this.rootView = view;
            this.colorView = (CardView)view.findViewById(R.id.colorView);
            this.checkIcon = (AppCompatImageView)view.findViewById(R.id.checkIcon);
            view.setOnClickListener((View.OnClickListener)new MaterialColorPickerAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0(MaterialColorPickerAdapter.this));
        }

        private static final void _init_$lambda-0(MaterialColorPickerAdapter materialColorPickerAdapter, View view) {
            Intrinsics.checkNotNullParameter((Object)((Object)materialColorPickerAdapter), (String)"this$0");
            Object object = view.getTag();
            if (object != null) {
                int n = (Integer)object;
                String string2 = materialColorPickerAdapter.getItem(n);
                int n2 = materialColorPickerAdapter.colors.indexOf((Object)materialColorPickerAdapter.color);
                MaterialColorPickerAdapter.access$setColor$p(materialColorPickerAdapter, string2);
                materialColorPickerAdapter.notifyItemChanged(n2);
                materialColorPickerAdapter.notifyItemChanged(n);
                return;
            }
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
        }

        public final void bind(int n) {
            String string2 = MaterialColorPickerAdapter.this.getItem(n);
            this.rootView.setTag((Object)n);
            ColorViewBinding colorViewBinding = ColorViewBinding.INSTANCE;
            CardView cardView = this.colorView;
            Intrinsics.checkNotNullExpressionValue((Object)cardView, (String)"colorView");
            colorViewBinding.setBackgroundColor(cardView, string2);
            ColorViewBinding colorViewBinding2 = ColorViewBinding.INSTANCE;
            CardView cardView2 = this.colorView;
            Intrinsics.checkNotNullExpressionValue((Object)cardView2, (String)"colorView");
            colorViewBinding2.setCardRadius(cardView2, MaterialColorPickerAdapter.this.colorShape);
            boolean bl = Intrinsics.areEqual((Object)string2, (Object)MaterialColorPickerAdapter.this.color);
            AppCompatImageView appCompatImageView = this.checkIcon;
            Intrinsics.checkNotNullExpressionValue((Object)appCompatImageView, (String)"checkIcon");
            ViewExtKt.setVisibility((View)appCompatImageView, bl);
            boolean bl2 = MaterialColorPickerAdapter.this.isDarkColor;
            if (MaterialColorPickerAdapter.this.isTickColorPerCard) {
                bl2 = ColorUtil.isDarkColor(string2);
            }
            AppCompatImageView appCompatImageView2 = this.checkIcon;
            int n2 = bl2 ? -1 : -16777216;
            appCompatImageView2.setColorFilter(n2);
        }
    }

}

