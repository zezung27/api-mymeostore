/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.view.View;
import com.github.dhaval2404.colorpicker.MaterialColorPickerBottomSheet;

public final class MaterialColorPickerBottomSheet$$ExternalSyntheticLambda1
implements View.OnClickListener {
    public final /* synthetic */ MaterialColorPickerBottomSheet f$0;

    public /* synthetic */ MaterialColorPickerBottomSheet$$ExternalSyntheticLambda1(MaterialColorPickerBottomSheet materialColorPickerBottomSheet) {
        this.f$0 = materialColorPickerBottomSheet;
    }

    public final void onClick(View view) {
        MaterialColorPickerBottomSheet.$r8$lambda$Cc3tMDHWz-rSz7OD73s8S64i1ig(this.f$0, view);
    }
}

