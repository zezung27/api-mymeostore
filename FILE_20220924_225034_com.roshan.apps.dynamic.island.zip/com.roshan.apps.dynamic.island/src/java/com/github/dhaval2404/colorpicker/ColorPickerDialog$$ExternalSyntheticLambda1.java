/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnDismissListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.content.DialogInterface;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.listener.DismissListener;

public final class ColorPickerDialog$$ExternalSyntheticLambda1
implements DialogInterface.OnDismissListener {
    public final /* synthetic */ DismissListener f$0;

    public /* synthetic */ ColorPickerDialog$$ExternalSyntheticLambda1(DismissListener dismissListener) {
        this.f$0 = dismissListener;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        ColorPickerDialog.$r8$lambda$oRSjjoWqy3OIT0x6QNojmGLKJ-s(this.f$0, dialogInterface);
    }
}

