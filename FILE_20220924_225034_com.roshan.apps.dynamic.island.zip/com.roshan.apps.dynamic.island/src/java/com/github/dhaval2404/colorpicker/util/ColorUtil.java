/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Color
 *  androidx.core.graphics.ColorUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.json.JSONObject
 */
package com.github.dhaval2404.colorpicker.util;

import android.content.Context;
import android.graphics.Color;
import androidx.core.graphics.ColorUtils;
import com.github.dhaval2404.colorpicker.util.AssetUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONObject;

@Metadata(d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u0007\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\tH\u0007J8\u0010\n\u001a*\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00060\u000bj\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0006`\f2\u0006\u0010\r\u001a\u00020\u000eH\u0002J\u001e\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u000f2\u0006\u0010\r\u001a\u00020\u000e2\b\b\u0002\u0010\u0010\u001a\u00020\u0005J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\b\u001a\u00020\tH\u0007J\u0010\u0010\u0011\u001a\u00020\u00122\u0006\u0010\b\u001a\u00020\u0005H\u0007J\"\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\t2\b\b\u0002\u0010\u0016\u001a\u00020\tH\u0007J\"\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\u00052\b\b\u0002\u0010\u0016\u001a\u00020\tH\u0007J\u0010\u0010\u0017\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u0005H\u0007R \u0010\u0003\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00060\u0004X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0018"}, d2={"Lcom/github/dhaval2404/colorpicker/util/ColorUtil;", "", "()V", "mColorMap", "", "", "", "formatColor", "color", "", "getColors", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "context", "Landroid/content/Context;", "", "brightness", "isDarkColor", "", "isEqualColor", "color1", "color2", "tolerance", "parseColor", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class ColorUtil {
    public static final ColorUtil INSTANCE = new ColorUtil();
    private static Map<String, ? extends List<String>> mColorMap;

    private ColorUtil() {
    }

    @JvmStatic
    public static final String formatColor(int n) {
        Object[] arrobject = new Object[]{n & 16777215};
        String string2 = String.format((String)"#%06x", (Object[])Arrays.copyOf((Object[])arrobject, (int)1));
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"java.lang.String.format(format, *args)");
        return string2;
    }

    private final HashMap<String, List<String>> getColors(Context context) {
        JSONObject jSONObject = new JSONObject(AssetUtil.INSTANCE.readAssetFile(context, "material-colors.json"));
        HashMap hashMap = new HashMap();
        Iterator iterator = jSONObject.keys();
        Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"colorMain.keys()");
        while (iterator.hasNext()) {
            JSONObject jSONObject2 = jSONObject.getJSONObject((String)iterator.next());
            Iterator iterator2 = jSONObject2.keys();
            Intrinsics.checkNotNullExpressionValue((Object)iterator2, (String)"jsonObject.keys()");
            while (iterator2.hasNext()) {
                String string2 = (String)iterator2.next();
                String string3 = jSONObject2.getString(string2);
                List list = (List)hashMap.get((Object)string2);
                if (list == null) {
                    list = (List)new ArrayList();
                    Map map = (Map)hashMap;
                    Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"colorCode");
                    map.put((Object)string2, (Object)list);
                }
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"colorHex");
                list.add((Object)string3);
            }
        }
        return hashMap;
    }

    public static /* synthetic */ List getColors$default(ColorUtil colorUtil, Context context, String string2, int n, Object object) {
        if ((n & 2) != 0) {
            string2 = "500";
        }
        return colorUtil.getColors(context, string2);
    }

    @JvmStatic
    public static final boolean isDarkColor(int n) {
        return ColorUtils.calculateLuminance((int)n) <= 0.4;
    }

    @JvmStatic
    public static final boolean isDarkColor(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
        return ColorUtil.isDarkColor(ColorUtil.parseColor(string2));
    }

    @JvmStatic
    public static final boolean isEqualColor(int n, int n2, int n3) {
        int n4 = Color.red((int)n);
        int n5 = Color.green((int)n);
        int n6 = Color.blue((int)n);
        int n7 = Color.red((int)n2);
        int n8 = Color.green((int)n2);
        int n9 = Color.blue((int)n2);
        return n4 >= n7 - n3 && n4 <= n7 + n3 && n5 >= n8 - n3 && n5 <= n8 + n3 && n6 >= n9 - n3 && n6 <= n9 + n3;
    }

    @JvmStatic
    public static final boolean isEqualColor(String string2, String string3, int n) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"color1");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"color2");
        return ColorUtil.isEqualColor(ColorUtil.parseColor(string2), ColorUtil.parseColor(string3), n);
    }

    public static /* synthetic */ boolean isEqualColor$default(int n, int n2, int n3, int n4, Object object) {
        if ((n4 & 4) != 0) {
            n3 = 50;
        }
        return ColorUtil.isEqualColor(n, n2, n3);
    }

    public static /* synthetic */ boolean isEqualColor$default(String string2, String string3, int n, int n2, Object object) {
        if ((n2 & 4) != 0) {
            n = 50;
        }
        return ColorUtil.isEqualColor(string2, string3, n);
    }

    @JvmStatic
    public static final int parseColor(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
        if (StringsKt.isBlank((CharSequence)string2)) {
            return 0;
        }
        return Color.parseColor((String)string2);
    }

    public final List<String> getColors(Context context, String string2) {
        Map<String, ? extends List<String>> map;
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"brightness");
        if (mColorMap == null) {
            mColorMap = (Map)this.getColors(context);
        }
        if ((map = mColorMap) != null) {
            List list = (List)map.get((Object)string2);
            if (list == null) {
                list = Collections.emptyList();
                Intrinsics.checkNotNullExpressionValue((Object)list, (String)"emptyList()");
            }
            return list;
        }
        Intrinsics.throwUninitializedPropertyAccessException((String)"mColorMap");
        throw null;
    }
}

