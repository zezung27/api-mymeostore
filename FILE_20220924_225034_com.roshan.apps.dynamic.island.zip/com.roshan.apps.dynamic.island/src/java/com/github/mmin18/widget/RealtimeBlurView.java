/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Rect
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnPreDrawListener
 *  android.view.Window
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package com.github.mmin18.widget;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import com.github.mmin18.realtimeblurview.R;
import com.github.mmin18.widget.BlurImpl;

public class RealtimeBlurView
extends View {
    private static int BLUR_IMPL;
    private static int RENDERING_COUNT;
    private static StopException STOP_EXCEPTION;
    private Bitmap mBitmapToBlur;
    private final BlurImpl mBlurImpl = this.getBlurImpl();
    private float mBlurRadius;
    private Bitmap mBlurredBitmap;
    private Canvas mBlurringCanvas;
    private View mDecorView;
    private boolean mDifferentRoot;
    private boolean mDirty;
    private float mDownsampleFactor;
    private boolean mIsRendering;
    private int mOverlayColor;
    private Paint mPaint;
    private final Rect mRectDst = new Rect();
    private final Rect mRectSrc = new Rect();
    private final ViewTreeObserver.OnPreDrawListener preDrawListener = new ViewTreeObserver.OnPreDrawListener(){

        /*
         * Exception decompiling
         */
        public boolean onPreDraw() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl150.1 : ALOAD_0 : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }
    };

    static {
        STOP_EXCEPTION = new StopException();
    }

    public RealtimeBlurView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.RealtimeBlurView);
        this.mBlurRadius = typedArray.getDimension(R.styleable.RealtimeBlurView_realtimeBlurRadius, TypedValue.applyDimension((int)1, (float)10.0f, (DisplayMetrics)context.getResources().getDisplayMetrics()));
        this.mDownsampleFactor = typedArray.getFloat(R.styleable.RealtimeBlurView_realtimeDownsampleFactor, 4.0f);
        this.mOverlayColor = typedArray.getColor(R.styleable.RealtimeBlurView_realtimeOverlayColor, -1426063361);
        typedArray.recycle();
        this.mPaint = new Paint();
    }

    static /* synthetic */ Bitmap access$000(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mBlurredBitmap;
    }

    static /* synthetic */ View access$100(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mDecorView;
    }

    static /* synthetic */ int access$200(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mOverlayColor;
    }

    static /* synthetic */ Bitmap access$300(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mBitmapToBlur;
    }

    static /* synthetic */ Canvas access$400(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mBlurringCanvas;
    }

    static /* synthetic */ boolean access$502(RealtimeBlurView realtimeBlurView, boolean bl) {
        realtimeBlurView.mIsRendering = bl;
        return bl;
    }

    static /* synthetic */ int access$608() {
        int n = RENDERING_COUNT;
        RENDERING_COUNT = n + 1;
        return n;
    }

    static /* synthetic */ int access$610() {
        int n = RENDERING_COUNT;
        RENDERING_COUNT = n - 1;
        return n;
    }

    static /* synthetic */ boolean access$700(RealtimeBlurView realtimeBlurView) {
        return realtimeBlurView.mDifferentRoot;
    }

    private void releaseBitmap() {
        Bitmap bitmap;
        Bitmap bitmap2 = this.mBitmapToBlur;
        if (bitmap2 != null) {
            bitmap2.recycle();
            this.mBitmapToBlur = null;
        }
        if ((bitmap = this.mBlurredBitmap) != null) {
            bitmap.recycle();
            this.mBlurredBitmap = null;
        }
    }

    protected void blur(Bitmap bitmap, Bitmap bitmap2) {
        this.mBlurImpl.blur(bitmap, bitmap2);
    }

    public void draw(Canvas canvas) {
        if (!this.mIsRendering) {
            if (RENDERING_COUNT > 0) {
                return;
            }
            super.draw(canvas);
            return;
        }
        throw STOP_EXCEPTION;
    }

    protected void drawBlurredBitmap(Canvas canvas, Bitmap bitmap, int n) {
        if (bitmap != null) {
            this.mRectSrc.right = bitmap.getWidth();
            this.mRectSrc.bottom = bitmap.getHeight();
            this.mRectDst.right = this.getWidth();
            this.mRectDst.bottom = this.getHeight();
            canvas.drawBitmap(bitmap, this.mRectSrc, this.mRectDst, null);
        }
        this.mPaint.setColor(n);
        canvas.drawRect(this.mRectDst, this.mPaint);
    }

    protected View getActivityDecorView() {
        Context context = this.getContext();
        for (int i = 0; i < 4 && context != null && !(context instanceof Activity) && context instanceof ContextWrapper; ++i) {
            context = ((ContextWrapper)context).getBaseContext();
        }
        if (context instanceof Activity) {
            return ((Activity)context).getWindow().getDecorView();
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    protected BlurImpl getBlurImpl() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    protected void onAttachedToWindow() {
        View view;
        super.onAttachedToWindow();
        this.mDecorView = view = this.getActivityDecorView();
        if (view != null) {
            view.getViewTreeObserver().addOnPreDrawListener(this.preDrawListener);
            View view2 = this.mDecorView.getRootView();
            View view3 = this.getRootView();
            boolean bl = false;
            if (view2 != view3) {
                bl = true;
            }
            this.mDifferentRoot = bl;
            if (bl) {
                this.mDecorView.postInvalidate();
                return;
            }
        } else {
            this.mDifferentRoot = false;
        }
    }

    protected void onDetachedFromWindow() {
        View view = this.mDecorView;
        if (view != null) {
            view.getViewTreeObserver().removeOnPreDrawListener(this.preDrawListener);
        }
        this.release();
        super.onDetachedFromWindow();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.drawBlurredBitmap(canvas, this.mBlurredBitmap, this.mOverlayColor);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    protected boolean prepare() {
        Bitmap bitmap;
        float f = this.mBlurRadius;
        if (f == 0.0f) {
            this.release();
            return false;
        }
        float f2 = this.mDownsampleFactor;
        float f3 = f / f2;
        if (f3 > 25.0f) {
            f2 = f2 * f3 / 25.0f;
            f3 = 25.0f;
        }
        int n = this.getWidth();
        int n2 = this.getHeight();
        int n3 = Math.max((int)1, (int)((int)((float)n / f2)));
        int n4 = Math.max((int)1, (int)((int)((float)n2 / f2)));
        boolean bl = this.mDirty;
        if (this.mBlurringCanvas == null || (bitmap = this.mBlurredBitmap) == null || bitmap.getWidth() != n3 || this.mBlurredBitmap.getHeight() != n4) {
            block8 : {
                Bitmap bitmap2;
                block7 : {
                    Bitmap bitmap3;
                    this.releaseBitmap();
                    this.mBitmapToBlur = bitmap3 = Bitmap.createBitmap((int)n3, (int)n4, (Bitmap.Config)Bitmap.Config.ARGB_8888);
                    if (bitmap3 != null) break block7;
                    this.release();
                    return false;
                }
                this.mBlurringCanvas = new Canvas(this.mBitmapToBlur);
                this.mBlurredBitmap = bitmap2 = Bitmap.createBitmap((int)n3, (int)n4, (Bitmap.Config)Bitmap.Config.ARGB_8888);
                if (bitmap2 != null) break block8;
                this.release();
                return false;
            }
            bl = true;
        }
        if (!bl) return true;
        if (!this.mBlurImpl.prepare(this.getContext(), this.mBitmapToBlur, f3)) return false;
        this.mDirty = false;
        return true;
        catch (Throwable throwable) {
            this.release();
            return false;
        }
        catch (OutOfMemoryError outOfMemoryError) {
            this.release();
            return false;
        }
    }

    protected void release() {
        this.releaseBitmap();
        this.mBlurImpl.release();
    }

    public void setBlurRadius(float f) {
        if (this.mBlurRadius != f) {
            this.mBlurRadius = f;
            this.mDirty = true;
            this.invalidate();
        }
    }

    public void setDownsampleFactor(float f) {
        if (!(f <= 0.0f)) {
            if (this.mDownsampleFactor != f) {
                this.mDownsampleFactor = f;
                this.mDirty = true;
                this.releaseBitmap();
                this.invalidate();
            }
            return;
        }
        throw new IllegalArgumentException("Downsample factor must be greater than 0.");
    }

    public void setOverlayColor(int n) {
        if (this.mOverlayColor != n) {
            this.mOverlayColor = n;
            this.invalidate();
        }
    }

    private static class StopException
    extends RuntimeException {
        private StopException() {
        }
    }

}

