/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  java.lang.Object
 */
package com.github.mmin18.widget;

import android.content.Context;
import android.graphics.Bitmap;

interface BlurImpl {
    public void blur(Bitmap var1, Bitmap var2);

    public boolean prepare(Context var1, Bitmap var2, float var3);

    public void release();
}

