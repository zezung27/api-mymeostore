/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.github.mmin18.realtimeblurview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int realtimeBlurRadius = 2130904027;
        public static final int realtimeDownsampleFactor = 2130904028;
        public static final int realtimeOverlayColor = 2130904029;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] RealtimeBlurView = new int[]{2130904027, 2130904028, 2130904029};
        public static final int RealtimeBlurView_realtimeBlurRadius = 0;
        public static final int RealtimeBlurView_realtimeDownsampleFactor = 1;
        public static final int RealtimeBlurView_realtimeOverlayColor = 2;

        private styleable() {
        }
    }

}

