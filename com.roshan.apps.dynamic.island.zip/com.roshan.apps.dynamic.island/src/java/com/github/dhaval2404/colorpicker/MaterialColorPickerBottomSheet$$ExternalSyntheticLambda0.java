/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.view.View;
import com.github.dhaval2404.colorpicker.MaterialColorPickerBottomSheet;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter;

public final class MaterialColorPickerBottomSheet$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ MaterialColorPickerAdapter f$0;
    public final /* synthetic */ MaterialColorPickerBottomSheet f$1;

    public /* synthetic */ MaterialColorPickerBottomSheet$$ExternalSyntheticLambda0(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerBottomSheet materialColorPickerBottomSheet) {
        this.f$0 = materialColorPickerAdapter;
        this.f$1 = materialColorPickerBottomSheet;
    }

    public final void onClick(View view) {
        MaterialColorPickerBottomSheet.$r8$lambda$aoqYvJUQZuzN5X2gy5UnCHUyviQ(this.f$0, this.f$1, view);
    }
}

