/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.widget.Button
 *  androidx.appcompat.app.AlertDialog
 *  androidx.core.content.ContextCompat
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.util;

import android.content.Context;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import com.github.dhaval2404.colorpicker.R;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u00a8\u0006\u0003"}, d2={"setButtonTextColor", "", "Landroidx/appcompat/app/AlertDialog;", "colorpicker_release"}, k=2, mv={1, 5, 1}, xi=48)
public final class DialogExtKt {
    public static final void setButtonTextColor(AlertDialog alertDialog) {
        Intrinsics.checkNotNullParameter((Object)alertDialog, (String)"<this>");
        int n = ContextCompat.getColor((Context)alertDialog.getContext(), (int)R.color.positiveButtonTextColor);
        Button button = alertDialog.getButton(-1);
        if (button != null) {
            button.setTextColor(n);
        }
        int n2 = ContextCompat.getColor((Context)alertDialog.getContext(), (int)R.color.negativeButtonTextColor);
        Button button2 = alertDialog.getButton(-2);
        if (button2 == null) {
            return;
        }
        button2.setTextColor(n2);
    }
}

