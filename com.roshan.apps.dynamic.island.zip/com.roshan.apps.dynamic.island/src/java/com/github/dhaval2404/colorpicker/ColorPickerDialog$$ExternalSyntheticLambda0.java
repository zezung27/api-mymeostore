/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.content.DialogInterface;
import com.github.dhaval2404.colorpicker.ColorPickerDialog;
import com.github.dhaval2404.colorpicker.ColorPickerView;
import com.github.dhaval2404.colorpicker.util.SharedPref;

public final class ColorPickerDialog$$ExternalSyntheticLambda0
implements DialogInterface.OnClickListener {
    public final /* synthetic */ ColorPickerView f$0;
    public final /* synthetic */ ColorPickerDialog f$1;
    public final /* synthetic */ SharedPref f$2;

    public /* synthetic */ ColorPickerDialog$$ExternalSyntheticLambda0(ColorPickerView colorPickerView, ColorPickerDialog colorPickerDialog, SharedPref sharedPref) {
        this.f$0 = colorPickerView;
        this.f$1 = colorPickerDialog;
        this.f$2 = sharedPref;
    }

    public final void onClick(DialogInterface dialogInterface, int n) {
        ColorPickerDialog.$r8$lambda$gJ_vSXgZSUtxaazXKIfuGqWoOQw(this.f$0, this.f$1, this.f$2, dialogInterface, n);
    }
}

