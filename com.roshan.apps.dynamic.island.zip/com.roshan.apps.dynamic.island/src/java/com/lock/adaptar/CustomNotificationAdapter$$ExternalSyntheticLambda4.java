/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.LinearLayout
 *  com.lock.adaptar.CustomNotificationAdapter
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.adaptar;

import android.widget.LinearLayout;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.entity.Notification;

public final class CustomNotificationAdapter$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ CustomNotificationAdapter f$0;
    public final /* synthetic */ Notification f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ LinearLayout f$3;

    public /* synthetic */ CustomNotificationAdapter$$ExternalSyntheticLambda4(CustomNotificationAdapter customNotificationAdapter, Notification notification, int n, LinearLayout linearLayout) {
        this.f$0 = customNotificationAdapter;
        this.f$1 = notification;
        this.f$2 = n;
        this.f$3 = linearLayout;
    }

    public final void run() {
        this.f$0.lambda$addViewToActionContainer$1$com-lock-adaptar-CustomNotificationAdapter(this.f$1, this.f$2, this.f$3);
    }
}

