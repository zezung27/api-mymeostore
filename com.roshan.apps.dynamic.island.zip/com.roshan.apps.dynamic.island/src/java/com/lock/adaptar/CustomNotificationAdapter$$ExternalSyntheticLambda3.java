/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.lock.adaptar.CustomNotificationAdapter
 *  java.lang.Object
 */
package com.lock.adaptar;

import android.view.View;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.entity.Notification;

public final class CustomNotificationAdapter$$ExternalSyntheticLambda3
implements View.OnClickListener {
    public final /* synthetic */ CustomNotificationAdapter f$0;
    public final /* synthetic */ Notification f$1;

    public /* synthetic */ CustomNotificationAdapter$$ExternalSyntheticLambda3(CustomNotificationAdapter customNotificationAdapter, Notification notification) {
        this.f$0 = customNotificationAdapter;
        this.f$1 = notification;
    }

    public final void onClick(View view) {
        this.f$0.lambda$addNotificationClearBtn$8$com-lock-adaptar-CustomNotificationAdapter(this.f$1, view);
    }
}

