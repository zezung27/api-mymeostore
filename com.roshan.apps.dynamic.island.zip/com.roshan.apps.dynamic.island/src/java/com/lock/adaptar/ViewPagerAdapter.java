/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.viewpager2.adapter.FragmentStateAdapter
 */
package com.lock.adaptar;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.lock.fragment.ThemeFragment;

public class ViewPagerAdapter
extends FragmentStateAdapter {
    public ViewPagerAdapter(FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    public Fragment createFragment(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    return ThemeFragment.newInstance("http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/get_computer_launcher_themes.php", 1);
                }
                return ThemeFragment.newInstance("http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/get_computer_launcher_app.php", 3);
            }
            return ThemeFragment.newInstance("http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/get_computer_launcher_lock.php", 2);
        }
        return ThemeFragment.newInstance("http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/get_computer_launcher_themes.php", 1);
    }

    public int getItemCount() {
        return 3;
    }
}

