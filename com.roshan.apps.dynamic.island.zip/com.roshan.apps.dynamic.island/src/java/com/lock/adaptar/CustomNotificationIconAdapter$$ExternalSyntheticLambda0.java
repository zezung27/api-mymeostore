/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.lock.adaptar.CustomNotificationIconAdapter
 *  com.lock.adaptar.CustomNotificationIconAdapter$ViewHolder
 *  java.lang.Object
 */
package com.lock.adaptar;

import android.view.View;
import com.lock.adaptar.CustomNotificationIconAdapter;

public final class CustomNotificationIconAdapter$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ CustomNotificationIconAdapter f$0;
    public final /* synthetic */ CustomNotificationIconAdapter.ViewHolder f$1;

    public /* synthetic */ CustomNotificationIconAdapter$$ExternalSyntheticLambda0(CustomNotificationIconAdapter customNotificationIconAdapter, CustomNotificationIconAdapter.ViewHolder viewHolder) {
        this.f$0 = customNotificationIconAdapter;
        this.f$1 = viewHolder;
    }

    public final void onClick(View view) {
        this.f$0.lambda$onBindViewHolder$0$com-lock-adaptar-CustomNotificationIconAdapter(this.f$1, view);
    }
}

