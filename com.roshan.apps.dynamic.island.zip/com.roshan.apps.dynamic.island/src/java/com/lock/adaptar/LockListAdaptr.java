/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.adaptar.LockListAdaptr;
import com.lock.entity.LockData;
import java.util.ArrayList;

public class LockListAdaptr
extends RecyclerView.Adapter<MyViewHolder> {
    private LayoutInflater inflater = null;
    private Context mContext;
    public ArrayList<LockData> themeData;

    public LockListAdaptr(Context context, ArrayList<LockData> arrayList) {
        this.mContext = context;
        this.themeData = arrayList;
    }

    static /* synthetic */ Context access$000(LockListAdaptr lockListAdaptr) {
        return lockListAdaptr.mContext;
    }

    public int getItemCount() {
        return this.themeData.size();
    }

    public void onBindViewHolder(final MyViewHolder myViewHolder, int n) {
        LockData lockData = (LockData)this.themeData.get(n);
        Glide.with((Context)this.mContext).load(lockData.getImage()).listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                myViewHolder.progressBar.setVisibility(8);
                return false;
            }

            public boolean onResourceReady(Drawable drawable, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                myViewHolder.progressBar.setVisibility(8);
                return false;
            }
        }).into(myViewHolder.image);
        myViewHolder.name.setText((CharSequence)(lockData.getName() + " Lock"));
        myViewHolder.image.setOnClickListener(new View.OnClickListener(this, lockData){
            final /* synthetic */ LockListAdaptr this$0;
            final /* synthetic */ LockData val$lockData;
            {
                this.this$0 = lockListAdaptr;
                this.val$lockData = lockData;
            }

            public void onClick(View view) {
                if (com.lock.utils.Constants.isAppInstalled(LockListAdaptr.access$000(this.this$0), this.val$lockData.getPkg())) {
                    android.content.Intent intent = LockListAdaptr.access$000(this.this$0).getPackageManager().getLaunchIntentForPackage(this.val$lockData.getPkg());
                    LockListAdaptr.access$000(this.this$0).startActivity(intent);
                    return;
                }
                new android.app.AlertDialog$Builder((Context)new android.view.ContextThemeWrapper(LockListAdaptr.access$000(this.this$0), 2131886082)).setIcon(2131165299).setTitle((CharSequence)(this.val$lockData.getName() + " Lock")).setMessage((CharSequence)"Do You Want To Install It From PlayStore.....!!!").setPositiveButton((CharSequence)"Yes", new android.content.DialogInterface$OnClickListener(this){
                    final /* synthetic */ 2 this$1;
                    {
                        this.this$1 = var1_1;
                    }

                    public void onClick(android.content.DialogInterface dialogInterface, int n) {
                        LockListAdaptr.access$000(this.this$1.this$0).startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse((String)("https://play.google.com/store/apps/details?id=" + this.this$1.val$lockData.getPkg()))));
                    }
                }).setNegativeButton((CharSequence)"No", null).show();
            }
        });
    }

    public MyViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new MyViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492936, viewGroup, false));
    }

    public class MyViewHolder
    extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name;
        ProgressBar progressBar;

        public MyViewHolder(View view) {
            super(view);
            this.progressBar = (ProgressBar)view.findViewById(2131296815);
            this.image = (ImageView)view.findViewById(2131296362);
            this.name = (TextView)view.findViewById(2131296363);
        }
    }

}

