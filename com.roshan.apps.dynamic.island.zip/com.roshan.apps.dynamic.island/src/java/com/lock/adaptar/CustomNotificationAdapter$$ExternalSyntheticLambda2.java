/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.lock.adaptar.CustomNotificationAdapter
 *  java.lang.Object
 */
package com.lock.adaptar;

import android.view.View;
import com.lock.adaptar.CustomNotificationAdapter;

public final class CustomNotificationAdapter$$ExternalSyntheticLambda2
implements View.OnClickListener {
    public final /* synthetic */ CustomNotificationAdapter f$0;

    public /* synthetic */ CustomNotificationAdapter$$ExternalSyntheticLambda2(CustomNotificationAdapter customNotificationAdapter) {
        this.f$0 = customNotificationAdapter;
    }

    public final void onClick(View view) {
        this.f$0.lambda$addNotificationClearBtn$7$com-lock-adaptar-CustomNotificationAdapter(view);
    }
}

