/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.app.PendingIntent$CanceledException
 *  android.app.RemoteInput
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.SystemClock
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.widget.Chronometer
 *  android.widget.EditText
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.TextView$OnEditorActionListener
 *  android.widget.Toast
 *  androidx.core.content.ContextCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.google.android.material.imageview.ShapeableImageView
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.text.DecimalFormat
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Objects
 *  java.util.Set
 */
package com.lock.adaptar;

import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.imageview.ShapeableImageView;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda0;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda1;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda2;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda3;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda4;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda5;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda6;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda7;
import com.lock.adaptar.CustomNotificationAdapter$$ExternalSyntheticLambda8;
import com.lock.background.PrefManager;
import com.lock.entity.AppDetail;
import com.lock.entity.AppPackageList;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.services.NotificationService;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import de.hdodenhof.circleimageview.CircleImageView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CustomNotificationAdapter
extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int DAY_MILLIS = 86400000;
    private static final int HOUR_MILLIS = 3600000;
    private static final int MINUTE_MILLIS = 60000;
    private static final int SECOND_MILLIS = 1000;
    private static final int VIEW_TYPE_CALL = 2;
    private static final int VIEW_TYPE_NORMAL = 1;
    private static final DecimalFormat df = new DecimalFormat("00");
    int acceptIndex = 1;
    int declineIndex = 0;
    public HashMap<String, ViewHolder> holderHashMap = new HashMap();
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    private Utils utils;
    ViewGroup viewGroup;

    public CustomNotificationAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
        this.utils = ((MAccessibilityService)context).utils;
    }

    static /* synthetic */ Context access$000(CustomNotificationAdapter customNotificationAdapter) {
        return customNotificationAdapter.mContext;
    }

    static /* synthetic */ void access$1600(CustomNotificationAdapter customNotificationAdapter, Notification notification, LinearLayout linearLayout) {
        customNotificationAdapter.addSubItemsToGroupContainer(notification, linearLayout);
    }

    static /* synthetic */ void access$200(CustomNotificationAdapter customNotificationAdapter, PendingIntent pendingIntent, RemoteInput[] arrremoteInput, RemoteInput remoteInput, String string) {
        customNotificationAdapter.sendRemoteInput(pendingIntent, arrremoteInput, remoteInput, string);
    }

    static /* synthetic */ NotificationListener access$800(CustomNotificationAdapter customNotificationAdapter) {
        return customNotificationAdapter.notificationListener;
    }

    private void addNotificationClearBtn(Notification notification, ViewHolder viewHolder) {
        viewHolder.close_iv.setColorFilter(notification.color);
        viewHolder.block_iv.setColorFilter(notification.color);
        if (notification.isClearable) {
            viewHolder.close_iv.setImageResource(2131165388);
            viewHolder.close_iv.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda1(this, notification));
        } else {
            viewHolder.close_iv.setImageResource(2131165506);
            viewHolder.close_iv.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda2(this));
        }
        viewHolder.block_iv.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda3(this, notification));
    }

    private void addSubItemsToGroupContainer(Notification notification, LinearLayout linearLayout) {
        CustomNotificationAdapter customNotificationAdapter = this;
        for (String string : notification.keyMap.keySet()) {
            if (notification.keyMap.get((Object)string) != null) {
                View view = LayoutInflater.from((Context)customNotificationAdapter.mContext).inflate(2131492997, null);
                TextView textView = (TextView)view.findViewById(2131297023);
                TextView textView2 = (TextView)view.findViewById(2131297048);
                TextView textView3 = (TextView)view.findViewById(2131296940);
                CircleImageView circleImageView = (CircleImageView)view.findViewById(2131296438);
                LinearLayout linearLayout2 = (LinearLayout)view.findViewById(2131296773);
                RelativeLayout relativeLayout = (RelativeLayout)view.findViewById(2131296778);
                ImageView imageView = (ImageView)view.findViewById(2131296366);
                ImageView imageView2 = (ImageView)view.findViewById(2131296779);
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).senderIcon != null) {
                    circleImageView.setVisibility(0);
                    circleImageView.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).senderIcon);
                } else {
                    circleImageView.setImageResource(0);
                    circleImageView.setVisibility(8);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).picture != null) {
                    imageView2.setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).picture);
                } else {
                    imageView2.setImageBitmap(null);
                }
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).picture != null) {
                    ((ImageView)view.findViewById(2131296779)).setImageBitmap(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).picture);
                } else {
                    ((ImageView)view.findViewById(2131296779)).setImageBitmap(null);
                }
                textView.setText((CharSequence)((MAccessibilityService)customNotificationAdapter.mContext).utils.getFormatedDate(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).postTime));
                textView2.setText(((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).tv_title);
                textView3.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).tv_text.toString());
                if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).actions == null && ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).bigText.toString().isEmpty()) {
                    imageView.setVisibility(8);
                } else {
                    imageView.setVisibility(0);
                }
                View.OnClickListener onClickListener = new View.OnClickListener(this, linearLayout2, imageView, relativeLayout, textView3, notification, string){
                    final /* synthetic */ CustomNotificationAdapter this$0;
                    final /* synthetic */ ImageView val$arrow_iv;
                    final /* synthetic */ String val$key;
                    final /* synthetic */ Notification val$mNotification;
                    final /* synthetic */ LinearLayout val$notification_action_container;
                    final /* synthetic */ RelativeLayout val$notification_material_reply_container;
                    final /* synthetic */ TextView val$sub_text;
                    {
                        this.this$0 = customNotificationAdapter;
                        this.val$notification_action_container = linearLayout;
                        this.val$arrow_iv = imageView;
                        this.val$notification_material_reply_container = relativeLayout;
                        this.val$sub_text = textView;
                        this.val$mNotification = notification;
                        this.val$key = string;
                    }

                    public void onClick(View view) {
                        if (this.val$notification_action_container.getVisibility() == 0) {
                            this.val$arrow_iv.setImageResource(2131165304);
                            this.val$notification_action_container.setVisibility(8);
                            this.val$notification_material_reply_container.setVisibility(8);
                            this.val$sub_text.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)this.val$mNotification.keyMap.get((Object)this.val$key)))).tv_text.toString());
                            return;
                        }
                        if (!((Notification)Objects.requireNonNull((Object)((Notification)this.val$mNotification.keyMap.get((Object)this.val$key)))).bigText.toString().isEmpty()) {
                            this.val$sub_text.setText((CharSequence)((Notification)Objects.requireNonNull((Object)((Notification)this.val$mNotification.keyMap.get((Object)this.val$key)))).bigText.toString());
                        }
                        this.val$arrow_iv.setImageResource(2131165305);
                        this.val$notification_action_container.setVisibility(0);
                        this.val$notification_action_container.removeAllViews();
                        if (((Notification)Objects.requireNonNull((Object)((Notification)this.val$mNotification.keyMap.get((Object)this.val$key)))).actions != null) {
                            new Handler().post(new Runnable(this){
                                final /* synthetic */ 1 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void run() {
                                    this.this$1.val$notification_action_container.setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.access$000(this.this$1.this$0)), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.access$000(this.this$1.this$0)));
                                    CustomNotificationAdapter.access$100(this.this$1.this$0, (Notification)Objects.requireNonNull((Object)((Notification)this.this$1.val$mNotification.keyMap.get((Object)this.this$1.val$key))), this.this$1.val$notification_action_container);
                                }
                            });
                            return;
                        }
                        this.val$notification_action_container.setPadding(0, 0, 0, 0);
                    }
                };
                imageView.setOnClickListener(onClickListener);
                view.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda0(notification, string, linearLayout, view));
                linearLayout.addView(view);
            }
            customNotificationAdapter = this;
        }
    }

    private void addTitleAndTextSubItems(Notification notification, LinearLayout linearLayout) {
        for (String string : notification.keyMap.keySet()) {
            Notification notification2 = (Notification)notification.keyMap.get((Object)string);
            if (notification.keyMap.size() == 1) {
                if (notification.tv_text.equals((Object)notification2.tv_text)) continue;
                linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
                continue;
            }
            linearLayout.addView(this.getTitleAndTextViewForSubItems(notification2.tv_title, notification2.tv_text));
        }
    }

    private void addViewToActionContainer(Notification notification, LinearLayout linearLayout) {
        if (notification.actions == null) {
            return;
        }
        for (int i = 0; i < notification.actions.size(); ++i) {
            TextView textView = (TextView)LayoutInflater.from((Context)this.mContext).inflate(2131492992, null);
            Drawable drawable = ResourcesCompat.getDrawable((Resources)this.mContext.getResources(), (int)2131165437, null);
            try {
                drawable = ContextCompat.getDrawable((Context)this.mContext.createPackageContext(notification.pack, 0), (int)((ActionParsable)notification.actions.get((int)i)).actionIcon);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
            textView.setText(((ActionParsable)notification.actions.get((int)i)).charSequence);
            textView.setTextColor(notification.color);
            if (notification.template.equals((Object)"MediaStyle")) {
                drawable.setTint(notification.color);
                textView.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null);
                textView.setText((CharSequence)"");
            }
            if (i > 0) {
                textView.setPadding(50, 5, 5, 5);
            }
            linearLayout.addView((View)textView);
            textView.setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda5(this, notification, i, linearLayout));
        }
    }

    private void addViewToCallActionContainer(Notification notification, LinearLayout linearLayout) {
        int n;
        int n2;
        if (notification.actions == null) {
            return;
        }
        boolean bl = notification.pack.equalsIgnoreCase("com.skype.raider");
        int n3 = 1;
        if (!bl && !((MAccessibilityService)this.mContext).isCallPkgFound(notification.pack)) {
            this.declineIndex = 0;
            this.acceptIndex = n3;
        } else {
            this.declineIndex = n3;
            this.acceptIndex = 0;
        }
        if (notification.actions.size() == 2) {
            n2 = 0;
            n = 0;
            for (int i = 0; i < notification.actions.size(); ++i) {
                if (i == 0) {
                    linearLayout.findViewById(2131296317).setVisibility(0);
                    linearLayout.findViewById(2131296317).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda6(this, notification));
                    n2 = n3;
                }
                if (i != n3) continue;
                linearLayout.findViewById(2131296309).setVisibility(0);
                linearLayout.findViewById(2131296309).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda7(this, notification));
                n = n3;
            }
        } else {
            n2 = 0;
            n = 0;
        }
        if (notification.actions.size() == n3) {
            linearLayout.findViewById(2131296317).setVisibility(0);
            linearLayout.findViewById(2131296317).setOnClickListener((View.OnClickListener)new CustomNotificationAdapter$$ExternalSyntheticLambda8(this, notification));
        } else {
            n3 = n2;
        }
        if (n3 == 0) {
            linearLayout.findViewById(2131296317).setVisibility(8);
        }
        if (n == 0) {
            linearLayout.findViewById(2131296309).setVisibility(8);
        }
    }

    private String getFormattedTime(long l) {
        long l2 = l / 1000L;
        long l3 = l2 / 60L;
        long l4 = l2 % 60L;
        DecimalFormat decimalFormat = df;
        String string = decimalFormat.format(l3);
        String string2 = decimalFormat.format(l4);
        return string + ":" + string2;
    }

    private View getTitleAndTextViewForSubItems(CharSequence charSequence, CharSequence charSequence2) {
        LinearLayout linearLayout = (LinearLayout)LayoutInflater.from((Context)this.mContext).inflate(2131493000, null);
        int n = (int)Constants.convertDpToPixel(5.0f, this.mContext);
        if (charSequence.toString().isEmpty()) {
            linearLayout.findViewById(2131296635).setVisibility(8);
            linearLayout.findViewById(2131296636).setPadding(0, n, n, n);
        } else {
            ((TextView)linearLayout.findViewById(2131296635)).setText((CharSequence)charSequence.toString());
        }
        if (charSequence2.toString().isEmpty()) {
            linearLayout.findViewById(2131296636).setVisibility(8);
            return linearLayout;
        }
        ((TextView)linearLayout.findViewById(2131296636)).setText((CharSequence)charSequence2.toString());
        return linearLayout;
    }

    static /* synthetic */ void lambda$addSubItemsToGroupContainer$0(Notification notification, String string, LinearLayout linearLayout, View view, View view2) {
        try {
            if (((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).pendingIntent != null) {
                ((Notification)Objects.requireNonNull((Object)((Notification)notification.keyMap.get((Object)string)))).pendingIntent.send();
                linearLayout.removeView(view);
                notification.keyMap.remove((Object)string);
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void sendRemoteInput(PendingIntent pendingIntent, RemoteInput[] arrremoteInput, RemoteInput remoteInput, String string) {
        Bundle bundle = new Bundle();
        bundle.putString(remoteInput.getResultKey(), string);
        Intent intent = new Intent().addFlags(268435456);
        RemoteInput.addResultsToIntent((RemoteInput[])arrremoteInput, (Intent)intent, (Bundle)bundle);
        if (Build.VERSION.SDK_INT >= 28) {
            if (remoteInput.getAllowFreeFormInput()) {
                RemoteInput.setResultsSource((Intent)intent, (int)0);
            } else {
                RemoteInput.setResultsSource((Intent)intent, (int)1);
            }
        }
        try {
            pendingIntent.send(this.mContext, 0, intent);
            return;
        }
        catch (PendingIntent.CanceledException canceledException) {
            canceledException.printStackTrace();
            return;
        }
    }

    private void showReplyBox(View view, ArrayList<ActionParsable> arrayList, int n) {
        View view2 = ((LinearLayout)view.getParent().getParent()).getChildAt(0);
        if (view2 != null) {
            view2.setVisibility(0);
            view2.findViewById(2131296648).setVisibility(0);
            view2.findViewById(2131296648).setOnClickListener(new View.OnClickListener(this, arrayList, n, view2){
                final /* synthetic */ CustomNotificationAdapter this$0;
                final /* synthetic */ ArrayList val$actions;
                final /* synthetic */ int val$index;
                final /* synthetic */ View val$viewStub;
                {
                    this.this$0 = customNotificationAdapter;
                    this.val$actions = arrayList;
                    this.val$index = n;
                    this.val$viewStub = view;
                }

                public void onClick(View view) {
                    CustomNotificationAdapter.access$200(this.this$0, ((ActionParsable)this.val$actions.get((int)this.val$index)).pendingIntent, ((ActionParsable)this.val$actions.get((int)this.val$index)).remoteInputs, ((ActionParsable)this.val$actions.get((int)this.val$index)).remoteInputs[0], ((EditText)this.val$viewStub.findViewById(2131296520)).getText().toString());
                    ((EditText)this.val$viewStub.findViewById(2131296520)).setText((CharSequence)"");
                    this.val$viewStub.setVisibility(8);
                    view.setVisibility(8);
                }
            });
            EditText editText = (EditText)view2.findViewById(2131296520);
            TextView.OnEditorActionListener onEditorActionListener = new TextView.OnEditorActionListener(this, arrayList, n, view2, view){
                final /* synthetic */ CustomNotificationAdapter this$0;
                final /* synthetic */ ArrayList val$actions;
                final /* synthetic */ int val$index;
                final /* synthetic */ View val$view;
                final /* synthetic */ View val$viewStub;
                {
                    this.this$0 = customNotificationAdapter;
                    this.val$actions = arrayList;
                    this.val$index = n;
                    this.val$viewStub = view;
                    this.val$view = view2;
                }

                public boolean onEditorAction(TextView textView, int n, android.view.KeyEvent keyEvent) {
                    boolean bl = false;
                    if (n == 4) {
                        CustomNotificationAdapter.access$200(this.this$0, ((ActionParsable)this.val$actions.get((int)this.val$index)).pendingIntent, ((ActionParsable)this.val$actions.get((int)this.val$index)).remoteInputs, ((ActionParsable)this.val$actions.get((int)this.val$index)).remoteInputs[0], ((EditText)this.val$viewStub.findViewById(2131296520)).getText().toString());
                        ((EditText)this.val$viewStub.findViewById(2131296520)).setText((CharSequence)"");
                        this.val$viewStub.setVisibility(8);
                        this.val$view.setVisibility(8);
                        bl = true;
                    }
                    return bl;
                }
            };
            editText.setOnEditorActionListener(onEditorActionListener);
        }
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public int getItemViewType(int n) {
        if (((Notification)this.notifications.get((int)n)).useIphoneCallDesign && ((Notification)this.notifications.get((int)n)).category.equalsIgnoreCase("call") && ((Notification)this.notifications.get((int)n)).isOngoing) {
            return 2;
        }
        return super.getItemViewType(n);
    }

    /* synthetic */ void lambda$addNotificationClearBtn$6$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
        if (notification.isClearable) {
            NotificationService.getInstance().cancelNotificationById(notification.key);
        }
    }

    /* synthetic */ void lambda$addNotificationClearBtn$7$com-lock-adaptar-CustomNotificationAdapter(View view) {
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    /* synthetic */ void lambda$addNotificationClearBtn$8$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        AppPackageList appPackageList = this.utils.prefManager.getFilterPkg(this.mContext);
        if (appPackageList == null) {
            appPackageList = new AppPackageList();
        }
        AppDetail appDetail = new AppDetail();
        appDetail.pkg = notification.pack;
        appPackageList.appDetailList.add((Object)appDetail);
        this.utils.prefManager.setFilterPkg(this.mContext, appPackageList);
        if (notification.isClearable) {
            NotificationService.getInstance().cancelNotificationById(notification.key);
        }
        Toast.makeText((Context)this.mContext, (CharSequence)"Notification is block from Dynamic Island", (int)1).show();
    }

    /* synthetic */ void lambda$addViewToActionContainer$1$com-lock-adaptar-CustomNotificationAdapter(Notification notification, int n, LinearLayout linearLayout) {
        if (((ActionParsable)notification.actions.get((int)n)).remoteInputs != null) {
            this.showReplyBox((View)linearLayout, notification.actions, n);
            return;
        }
        try {
            if (((ActionParsable)notification.actions.get((int)n)).pendingIntent != null) {
                ((ActionParsable)notification.actions.get((int)n)).pendingIntent.send();
            }
            if (!notification.template.equals((Object)"MediaStyle")) {
                ((ImageView)((RelativeLayout)linearLayout.getParent().getParent()).findViewById(2131296366)).setImageResource(2131165304);
                linearLayout.setVisibility(8);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        if (notification.category.equalsIgnoreCase("call")) {
            ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
        }
    }

    /* synthetic */ void lambda$addViewToActionContainer$2$com-lock-adaptar-CustomNotificationAdapter(Notification notification, int n, LinearLayout linearLayout, View view) {
        new Handler().post((Runnable)new CustomNotificationAdapter$$ExternalSyntheticLambda4(this, notification, n, linearLayout));
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$3$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)this.declineIndex)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)this.declineIndex)).pendingIntent.send();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$4$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)this.acceptIndex)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)this.acceptIndex)).pendingIntent.send();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    /* synthetic */ void lambda$addViewToCallActionContainer$5$com-lock-adaptar-CustomNotificationAdapter(Notification notification, View view) {
        if (((ActionParsable)notification.actions.get((int)0)).pendingIntent != null) {
            try {
                ((ActionParsable)notification.actions.get((int)0)).pendingIntent.send();
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        ((MAccessibilityService)this.mContext).closeFullNotificationIsland();
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int n) {
        if (((Notification)this.notifications.get((int)n)).useIphoneCallDesign && ((Notification)this.notifications.get((int)n)).category.equalsIgnoreCase("call") && ((Notification)this.notifications.get((int)n)).isOngoing) {
            ((ViewHolderCall)viewHolder).bind(this.notifications);
            return;
        }
        ViewHolder viewHolder2 = (ViewHolder)viewHolder;
        viewHolder2.bind(this.notifications);
        if (((Notification)this.notifications.get((int)n)).template.equals((Object)"MediaStyle")) {
            this.holderHashMap.put((Object)((Notification)this.notifications.get((int)n)).key, (Object)viewHolder2);
        }
    }

    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        if (n == 2) {
            return new ViewHolderCall(layoutInflater.inflate(2131492994, viewGroup, false));
        }
        return new ViewHolder(layoutInflater.inflate(2131492996, viewGroup, false));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void updateMediaProgress(long l, long l2, int n, int n2) {
        try {
            for (String string : this.holderHashMap.keySet()) {
                ViewHolder viewHolder;
                int n3;
                if (this.holderHashMap.get((Object)string) == null || (viewHolder = (ViewHolder)((Object)this.holderHashMap.get((Object)string))) == null || (n3 = viewHolder.getAbsoluteAdapterPosition()) < 0 || !((Notification)this.notifications.get((int)n3)).isPlaying) continue;
                String string2 = this.getFormattedTime(l);
                String string3 = this.getFormattedTime(l2);
                viewHolder.tv_duration.setText((CharSequence)string2);
                viewHolder.tv_position.setText((CharSequence)string3);
                viewHolder.progressBar.setProgress(n);
                viewHolder.progressBar.setVisibility(0);
                viewHolder.progressBar.setMax(n2);
            }
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView arrow_iv;
        private final ImageView block_iv;
        private final Chronometer chronometer;
        private final ImageView close_iv;
        private final LinearLayout group_message_parent;
        private ViewHolder holder;
        private final ImageView iv_app_icon;
        ImageView iv_senderIcon2;
        ShapeableImageView iv_sender_icon;
        private final LinearLayout notification_action_container;
        private final RelativeLayout notification_material_reply_container;
        private final ImageView picture_iv;
        private final ProgressBar progressBar;
        private final TextView sub_text;
        private final TextView tv_duration;
        private final TextView tv_position;
        private final TextView tv_text;
        public final TextView tv_title;

        public ViewHolder(View view) {
            super(view);
            this.holder = this;
            this.block_iv = (ImageView)view.findViewById(2131296383);
            this.close_iv = (ImageView)view.findViewById(2131296444);
            this.tv_position = (TextView)view.findViewById(2131296707);
            this.tv_duration = (TextView)view.findViewById(2131296706);
            this.progressBar = (ProgressBar)view.findViewById(2131296939);
            this.chronometer = (Chronometer)view.findViewById(2131296436);
            this.iv_app_icon = (ImageView)view.findViewById(2131296638);
            this.tv_title = (TextView)view.findViewById(2131297023);
            this.tv_text = (TextView)view.findViewById(2131297048);
            this.iv_sender_icon = (ShapeableImageView)view.findViewById(2131296438);
            this.notification_action_container = (LinearLayout)view.findViewById(2131296773);
            this.notification_material_reply_container = (RelativeLayout)view.findViewById(2131296778);
            this.arrow_iv = (ImageView)view.findViewById(2131296366);
            this.sub_text = (TextView)view.findViewById(2131296940);
            this.picture_iv = (ImageView)view.findViewById(2131296779);
            this.group_message_parent = (LinearLayout)view.findViewById(2131296586);
            this.iv_senderIcon2 = (ImageView)view.findViewById(2131296439);
        }

        static /* synthetic */ LinearLayout access$1000(ViewHolder viewHolder) {
            return viewHolder.notification_action_container;
        }

        static /* synthetic */ RelativeLayout access$1300(ViewHolder viewHolder) {
            return viewHolder.notification_material_reply_container;
        }

        static /* synthetic */ TextView access$1400(ViewHolder viewHolder) {
            return viewHolder.sub_text;
        }

        static /* synthetic */ LinearLayout access$1500(ViewHolder viewHolder) {
            return viewHolder.group_message_parent;
        }

        static /* synthetic */ ViewHolder access$700(ViewHolder viewHolder) {
            return viewHolder.holder;
        }

        static /* synthetic */ ImageView access$900(ViewHolder viewHolder) {
            return viewHolder.arrow_iv;
        }

        public void bind(ArrayList<Notification> arrayList) {
            this.holder.itemView.setOnLongClickListener(null);
            this.holder.itemView.setLongClickable(false);
            this.holder.progressBar.setVisibility(8);
            Notification notification = (Notification)arrayList.get(this.holder.getAbsoluteAdapterPosition());
            if (notification.picture != null && notification.keyMap.size() == 0) {
                this.holder.picture_iv.setImageBitmap(notification.picture);
            } else {
                this.holder.picture_iv.setImageBitmap(null);
            }
            this.holder.tv_title.setText((CharSequence)notification.app_name);
            this.holder.tv_title.setTag((Object)notification.isClearable);
            this.holder.tv_text.setText(notification.tv_title);
            this.holder.sub_text.setText((CharSequence)notification.tv_text.toString());
            this.holder.group_message_parent.removeAllViews();
            CustomNotificationAdapter.this.addTitleAndTextSubItems(notification, this.holder.group_message_parent);
            this.holder.notification_action_container.setVisibility(8);
            this.holder.notification_material_reply_container.setVisibility(8);
            if (notification.icon != null) {
                this.holder.iv_app_icon.setVisibility(0);
                this.holder.iv_app_icon.setImageBitmap(notification.icon);
            }
            if (notification.senderIcon != null) {
                this.holder.iv_senderIcon2.setVisibility(4);
                this.holder.iv_sender_icon.setVisibility(0);
                this.holder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.holder.iv_sender_icon.setColorFilter(null);
            } else {
                this.holder.iv_senderIcon2.setImageBitmap(notification.icon);
                this.holder.iv_senderIcon2.setColorFilter(-1);
                this.holder.iv_senderIcon2.setVisibility(0);
                this.holder.iv_sender_icon.setVisibility(4);
                this.holder.iv_app_icon.setVisibility(4);
            }
            if (notification.progressMax > 0) {
                if (notification.showChronometer) {
                    this.holder.chronometer.setVisibility(0);
                    this.holder.chronometer.start();
                } else {
                    this.holder.chronometer.setVisibility(8);
                    this.holder.chronometer.setBase(SystemClock.elapsedRealtime());
                    this.holder.chronometer.stop();
                }
                this.holder.progressBar.setVisibility(0);
                this.holder.progressBar.setMax(notification.progressMax);
                this.holder.progressBar.setProgress(notification.progress);
                this.holder.progressBar.setIndeterminate(notification.progressIndeterminate);
            } else {
                this.holder.progressBar.setVisibility(8);
                this.holder.chronometer.setVisibility(8);
                this.holder.chronometer.setBase(SystemClock.elapsedRealtime());
                this.holder.chronometer.stop();
            }
            this.holder.itemView.setOnClickListener(new View.OnClickListener(this, arrayList){
                final /* synthetic */ ViewHolder this$1;
                final /* synthetic */ ArrayList val$notifications;
                {
                    this.this$1 = viewHolder;
                    this.val$notifications = arrayList;
                }

                public void onClick(View view) {
                    try {
                        if (((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter.access$800(this.this$1.CustomNotificationAdapter.this).onItemClicked((Notification)this.val$notifications.get(ViewHolder.access$700(this.this$1).getAbsoluteAdapterPosition()));
                        }
                        if (((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).isClearable) {
                            NotificationService.getInstance().cancelNotificationById(((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).key);
                        }
                        ((MAccessibilityService)CustomNotificationAdapter.access$000(this.this$1.CustomNotificationAdapter.this)).closeFullNotificationIsland();
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                    }
                    ViewHolder.access$900(ViewHolder.access$700(this.this$1)).setImageResource(2131165304);
                    ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).setVisibility(8);
                }
            });
            if (notification.keyMap.size() <= 0 && (notification.bigText.toString().isEmpty() || notification.bigText.toString().equals((Object)notification.tv_text.toString())) && notification.actions == null) {
                this.holder.arrow_iv.setVisibility(4);
            } else {
                this.holder.arrow_iv.setVisibility(0);
                this.holder.arrow_iv.setImageResource(2131165304);
            }
            CustomNotificationAdapter.this.addNotificationClearBtn(notification, this.holder);
            if (((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                this.holder.arrow_iv.setVisibility(4);
                this.holder.notification_action_container.setVisibility(0);
                this.holder.notification_action_container.removeAllViews();
                CustomNotificationAdapter.this.addViewToActionContainer(notification, this.holder.notification_action_container);
                if (notification.template.equals((Object)"MediaStyle")) {
                    this.holder.tv_duration.setVisibility(0);
                    this.holder.tv_position.setVisibility(0);
                    String string = CustomNotificationAdapter.this.getFormattedTime(((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).duration);
                    String string2 = CustomNotificationAdapter.this.getFormattedTime(((Notification)arrayList.get((int)this.holder.getAbsoluteAdapterPosition())).position);
                    this.holder.tv_duration.setText((CharSequence)string);
                    this.holder.tv_position.setText((CharSequence)string2);
                    ViewHolder viewHolder = this.holder;
                    viewHolder.progressBar.setProgress(((Notification)arrayList.get((int)viewHolder.getAbsoluteAdapterPosition())).progress);
                    this.holder.progressBar.setVisibility(0);
                    ViewHolder viewHolder2 = this.holder;
                    viewHolder2.progressBar.setMax(((Notification)arrayList.get((int)viewHolder2.getAbsoluteAdapterPosition())).progressMax);
                } else {
                    this.holder.tv_duration.setVisibility(8);
                    this.holder.tv_position.setVisibility(8);
                    this.holder.progressBar.setVisibility(8);
                }
            } else {
                if (notification.isClearable) {
                    this.holder.notification_action_container.setVisibility(0);
                    this.holder.notification_action_container.removeAllViews();
                } else {
                    this.holder.notification_action_container.setVisibility(8);
                }
                this.holder.tv_duration.setVisibility(8);
                this.holder.tv_position.setVisibility(8);
            }
            this.holder.arrow_iv.setOnClickListener(new View.OnClickListener(this, arrayList, notification){
                final /* synthetic */ ViewHolder this$1;
                final /* synthetic */ Notification val$mNotification;
                final /* synthetic */ ArrayList val$notifications;
                {
                    this.this$1 = viewHolder;
                    this.val$notifications = arrayList;
                    this.val$mNotification = notification;
                }

                public void onClick(View view) {
                    int n = ViewHolder.access$700(this.this$1).getAbsoluteAdapterPosition();
                    if (n >= 0 && n < this.val$notifications.size()) {
                        if (ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).getVisibility() == 0) {
                            ViewHolder.access$900(ViewHolder.access$700(this.this$1)).setImageResource(2131165304);
                            ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).setVisibility(8);
                            ViewHolder.access$1300(ViewHolder.access$700(this.this$1)).setVisibility(8);
                            ViewHolder.access$1400(ViewHolder.access$700(this.this$1)).setText((CharSequence)((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).tv_text.toString());
                            ViewHolder.access$1500(ViewHolder.access$700(this.this$1)).removeAllViews();
                            CustomNotificationAdapter.access$600(this.this$1.CustomNotificationAdapter.this, this.val$mNotification, ViewHolder.access$1500(ViewHolder.access$700(this.this$1)));
                            return;
                        }
                        if (!this.val$mNotification.bigText.toString().isEmpty()) {
                            ViewHolder.access$1400(ViewHolder.access$700(this.this$1)).setText((CharSequence)((Notification)this.val$notifications.get((int)ViewHolder.access$700((ViewHolder)this.this$1).getAbsoluteAdapterPosition())).bigText.toString());
                        }
                        ViewHolder.access$900(ViewHolder.access$700(this.this$1)).setImageResource(2131165305);
                        ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).setVisibility(0);
                        ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).removeAllViews();
                        ViewHolder.access$1500(ViewHolder.access$700(this.this$1)).removeAllViews();
                        if (this.val$mNotification.actions != null) {
                            CustomNotificationAdapter.access$100(this.this$1.CustomNotificationAdapter.this, this.val$mNotification, ViewHolder.access$1000(ViewHolder.access$700(this.this$1)));
                            ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).setPadding(0, (int)Constants.convertDpToPixel(10.0f, CustomNotificationAdapter.access$000(this.this$1.CustomNotificationAdapter.this)), 0, (int)Constants.convertDpToPixel(5.0f, CustomNotificationAdapter.access$000(this.this$1.CustomNotificationAdapter.this)));
                            return;
                        }
                        CustomNotificationAdapter.access$1600(this.this$1.CustomNotificationAdapter.this, this.val$mNotification, ViewHolder.access$1500(ViewHolder.access$700(this.this$1)));
                        ViewHolder.access$1000(ViewHolder.access$700(this.this$1)).setPadding(0, 0, 0, 0);
                    }
                }
            });
            this.holder.itemView.setOnLongClickListener(new View.OnLongClickListener(this){
                final /* synthetic */ ViewHolder this$1;
                {
                    this.this$1 = viewHolder;
                }

                public boolean onLongClick(View view) {
                    return false;
                }
            });
        }
    }

    public class ViewHolderCall
    extends RecyclerView.ViewHolder {
        CircleImageView iv_sender_icon;
        private final LinearLayout notification_action_container;
        private final TextView tv_text;
        public final TextView tv_title;
        private ViewHolderCall viewHolder;

        public ViewHolderCall(View view) {
            super(view);
            this.viewHolder = this;
            this.tv_title = (TextView)view.findViewById(2131297023);
            this.tv_text = (TextView)view.findViewById(2131297048);
            this.iv_sender_icon = (CircleImageView)view.findViewById(2131296438);
            this.notification_action_container = (LinearLayout)view.findViewById(2131296774);
        }

        static /* synthetic */ ViewHolderCall access$1900(ViewHolderCall viewHolderCall) {
            return viewHolderCall.viewHolder;
        }

        public void bind(ArrayList<Notification> arrayList) {
            this.viewHolder.itemView.setOnLongClickListener(null);
            this.viewHolder.itemView.setLongClickable(false);
            Notification notification = (Notification)arrayList.get(this.viewHolder.getAbsoluteAdapterPosition());
            this.viewHolder.tv_title.setText((CharSequence)notification.app_name);
            this.viewHolder.tv_title.setTag((Object)notification.isClearable);
            this.viewHolder.tv_text.setText(notification.tv_title);
            if (notification.senderIcon != null) {
                this.viewHolder.iv_sender_icon.setVisibility(0);
                this.viewHolder.iv_sender_icon.setImageBitmap(notification.senderIcon);
                this.viewHolder.iv_sender_icon.setColorFilter(null);
            } else {
                this.viewHolder.iv_sender_icon.setVisibility(4);
            }
            this.viewHolder.itemView.setOnClickListener(new View.OnClickListener(this, arrayList){
                final /* synthetic */ ViewHolderCall this$1;
                final /* synthetic */ ArrayList val$notifications;
                {
                    this.this$1 = viewHolderCall;
                    this.val$notifications = arrayList;
                }

                public void onClick(View view) {
                    try {
                        if (((Notification)this.val$notifications.get((int)ViewHolderCall.access$1900((ViewHolderCall)this.this$1).getAbsoluteAdapterPosition())).pendingIntent != null) {
                            ((Notification)this.val$notifications.get((int)ViewHolderCall.access$1900((ViewHolderCall)this.this$1).getAbsoluteAdapterPosition())).pendingIntent.send();
                            CustomNotificationAdapter.access$800(this.this$1.CustomNotificationAdapter.this).onItemClicked((Notification)this.val$notifications.get(ViewHolderCall.access$1900(this.this$1).getAbsoluteAdapterPosition()));
                        }
                        ((MAccessibilityService)CustomNotificationAdapter.access$000(this.this$1.CustomNotificationAdapter.this)).closeFullNotificationIsland();
                        return;
                    }
                    catch (Exception exception) {
                        exception.printStackTrace();
                        return;
                    }
                }
            });
            if (((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions != null && ((Notification)arrayList.get((int)this.viewHolder.getAbsoluteAdapterPosition())).actions.size() > 0) {
                CustomNotificationAdapter.this.addViewToCallActionContainer(notification, this.viewHolder.notification_action_container);
            }
        }
    }

}

