/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffColorFilter
 *  android.graphics.drawable.Drawable
 *  android.os.SystemClock
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.widget.Chronometer
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.core.content.ContextCompat
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.adaptar.CustomNotificationIconAdapter;
import com.lock.adaptar.CustomNotificationIconAdapter$$ExternalSyntheticLambda0;
import com.lock.background.PrefManager;
import com.lock.entity.Notification;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import java.util.ArrayList;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CustomNotificationIconAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private boolean isHalf;
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    ViewGroup viewGroup;

    public CustomNotificationIconAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
    }

    static /* synthetic */ ArrayList access$000(CustomNotificationIconAdapter customNotificationIconAdapter) {
        return customNotificationIconAdapter.notifications;
    }

    static /* synthetic */ Context access$100(CustomNotificationIconAdapter customNotificationIconAdapter) {
        return customNotificationIconAdapter.mContext;
    }

    private void setTextViewDrawableColor(TextView textView, int n) {
        for (Drawable drawable : textView.getCompoundDrawablesRelative()) {
            if (drawable == null) continue;
            drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(ContextCompat.getColor((Context)textView.getContext(), (int)n), PorterDuff.Mode.SRC_IN));
        }
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    /* synthetic */ void lambda$onBindViewHolder$0$com-lock-adaptar-CustomNotificationIconAdapter(ViewHolder viewHolder, View view) {
        int n = viewHolder.getAbsoluteAdapterPosition();
        if (n >= 0 && n < this.notifications.size()) {
            this.notificationListener.onItemClicked((Notification)this.notifications.get(n));
            this.notificationListener.onItemClicked((Notification)this.notifications.get(n), n);
        }
    }

    public void onBindViewHolder(ViewHolder viewHolder, int n) {
        boolean bl;
        Notification notification = (Notification)this.notifications.get(viewHolder.getAbsoluteAdapterPosition());
        viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener(this, viewHolder){
            final /* synthetic */ CustomNotificationIconAdapter this$0;
            final /* synthetic */ ViewHolder val$holder;
            {
                this.this$0 = customNotificationIconAdapter;
                this.val$holder = viewHolder;
            }

            public boolean onLongClick(View view) {
                int n = this.val$holder.getAbsoluteAdapterPosition();
                if (n >= 0) {
                    Notification notification = (Notification)CustomNotificationIconAdapter.access$000(this.this$0).get(n);
                    if (notification.isClearable) {
                        CustomNotificationIconAdapter.access$000(this.this$0).remove((Object)notification);
                        if (!notification.isLocal) {
                            com.lock.services.NotificationService.getInstance().cancelNotificationById(notification.key);
                        }
                        this.this$0.notifyDataSetChanged();
                        if (CustomNotificationIconAdapter.access$000(this.this$0).size() == 0) {
                            ((MAccessibilityService)CustomNotificationIconAdapter.access$100(this.this$0)).closeSmallIslandNotification();
                        }
                    }
                }
                return false;
            }
        });
        viewHolder.mChronometer.setVisibility(8);
        if (!notification.isChronometerRunning) {
            viewHolder.mChronometer.setBase(SystemClock.elapsedRealtime());
            viewHolder.mChronometer.stop();
        }
        viewHolder.mLottieAnimationView.setVisibility(8);
        viewHolder.mLottieAnimationView.pauseAnimation();
        viewHolder.island_small_image_left.clearColorFilter();
        viewHolder.island_small_image_right.clearColorFilter();
        viewHolder.island_small_image_left.setImageResource(0);
        viewHolder.island_small_image_right.setImageResource(0);
        viewHolder.island_small_image_left.setVisibility(0);
        viewHolder.island_small_image_right.setVisibility(0);
        viewHolder.island_small_text_left.setVisibility(0);
        viewHolder.island_small_text_right.setVisibility(0);
        viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        viewHolder.island_small_text_left.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        viewHolder.island_small_text_left.setTextColor(((MAccessibilityService)this.mContext).utils.prefManager.getTitleColor());
        viewHolder.island_small_text_right.setTextColor(((MAccessibilityService)this.mContext).utils.prefManager.getTitleColor());
        if (notification.type.equalsIgnoreCase("TYPE_AIRBUDS")) {
            viewHolder.island_small_image_left.setImageResource(2131165402);
            viewHolder.island_small_text_right.setTextColor(notification.color);
            if (notification.local_right_icon != -1) {
                int n2 = ((MAccessibilityService)this.mContext).utils.getAirPodBatteryLevel();
                viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, notification.local_right_icon, 0);
                viewHolder.island_small_text_right.setCompoundDrawablePadding((int)Constants.convertDpToPixel(5.0f, this.mContext));
                String string = n2 + this.mContext.getString(2131820802);
                int n3 = n2 / 10;
                if (n3 >= 6) {
                    viewHolder.island_small_text_right.setTextColor(this.mContext.getColor(2131034352));
                } else if (n3 >= 2) {
                    viewHolder.island_small_text_right.setTextColor(this.mContext.getColor(2131034167));
                } else {
                    viewHolder.island_small_text_right.setTextColor(this.mContext.getColor(2131034981));
                }
                viewHolder.island_small_text_right.setText((CharSequence)string);
            } else {
                viewHolder.island_small_text_right.setText(2131820592);
            }
            viewHolder.island_small_text_left.setVisibility(8);
            viewHolder.island_small_image_right.setVisibility(8);
            bl = false;
        } else {
            bl = true;
        }
        if (notification.type.equalsIgnoreCase("CAT_CHARGING")) {
            viewHolder.island_small_image_right.setVisibility(8);
            viewHolder.island_small_text_right.setText(notification.tv_text);
            int n4 = ((MAccessibilityService)this.mContext).utils.getBatteryImage();
            viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, n4, 0);
            viewHolder.island_small_text_right.setCompoundDrawablePadding((int)Constants.convertDpToPixel(5.0f, this.mContext));
            int n5 = ((MAccessibilityService)this.mContext).utils.getBatteryLevel() / 10;
            notification.color = n5 >= 6 ? this.mContext.getColor(2131034352) : (n5 >= 2 ? this.mContext.getColor(2131034167) : this.mContext.getColor(2131034981));
            viewHolder.island_small_text_right.setTextColor(notification.color);
            viewHolder.island_small_text_left.setVisibility(8);
            viewHolder.island_small_image_left.setImageResource(2131165356);
            bl = false;
        }
        if (notification.type.equalsIgnoreCase("CAT_SILENT")) {
            viewHolder.island_small_image_left.clearColorFilter();
            viewHolder.island_small_image_left.setImageResource(notification.local_left_icon);
            viewHolder.island_small_text_left.setText((CharSequence)"");
            viewHolder.island_small_text_right.setText(notification.tv_title);
            viewHolder.island_small_text_right.setTextColor(notification.color);
            viewHolder.island_small_image_right.setImageResource(0);
            viewHolder.island_small_image_right.setVisibility(8);
            bl = false;
        }
        if (bl) {
            if (notification.icon != null) {
                viewHolder.island_small_image_left.setImageBitmap(notification.icon);
                viewHolder.island_small_image_left.setColorFilter(-1);
                if (notification.showChronometer) {
                    viewHolder.mChronometer.setVisibility(0);
                    viewHolder.mChronometer.start();
                    notification.isChronometerRunning = true;
                    viewHolder.island_small_text_left.setText((CharSequence)"");
                    viewHolder.island_small_image_left.setColorFilter(this.mContext.getColor(2131034352));
                } else {
                    viewHolder.island_small_text_left.setText((CharSequence)((MAccessibilityService)this.mContext).utils.getFormatedDate(notification.postTime));
                }
            } else {
                viewHolder.island_small_image_left.setImageBitmap(null);
            }
            if (notification.senderIcon == null && !notification.template.equals((Object)"MediaStyle")) {
                viewHolder.mLottieAnimationView.setVisibility(8);
                viewHolder.island_small_image_right.setImageResource(0);
                viewHolder.island_small_image_right.setVisibility(8);
                if (notification.tv_title != null && notification.tv_title.length() > 0) {
                    viewHolder.island_small_text_right.setVisibility(0);
                    String[] arrstring = notification.tv_title.toString().split(" ");
                    if (arrstring.length > 0) {
                        viewHolder.island_small_text_right.setText((CharSequence)arrstring[0]);
                    } else {
                        viewHolder.island_small_text_right.setText((CharSequence)"");
                    }
                } else {
                    viewHolder.island_small_text_right.setVisibility(8);
                }
            } else if (notification.showChronometer && notification.category.equalsIgnoreCase("call") && notification.isOngoing) {
                viewHolder.island_small_text_right.setVisibility(8);
                viewHolder.island_small_image_right.setVisibility(8);
                viewHolder.island_small_text_right.setText((CharSequence)"");
                viewHolder.mLottieAnimationView.setAnimation(2131755010);
                viewHolder.mLottieAnimationView.setVisibility(0);
                if (!viewHolder.mLottieAnimationView.isAnimating()) {
                    viewHolder.mLottieAnimationView.playAnimation();
                }
            } else if (notification.template.equals((Object)"MediaStyle") && !notification.isClearable && ((MAccessibilityService)this.mContext).utils.isMusicActive()) {
                viewHolder.mLottieAnimationView.setAnimation(2131755008);
                viewHolder.mLottieAnimationView.setVisibility(0);
                if (!viewHolder.mLottieAnimationView.isAnimating()) {
                    viewHolder.mLottieAnimationView.playAnimation();
                }
                if (!((MAccessibilityService)this.mContext).utils.prefManager.getMusicAnimation(this.mContext)) {
                    viewHolder.mLottieAnimationView.pauseAnimation();
                }
                viewHolder.island_small_text_right.setVisibility(8);
                viewHolder.island_small_image_right.setVisibility(8);
            } else {
                viewHolder.mLottieAnimationView.setVisibility(8);
                viewHolder.island_small_text_right.setVisibility(8);
                viewHolder.island_small_image_right.setVisibility(0);
                viewHolder.island_small_image_right.setImageBitmap(notification.senderIcon);
            }
        }
        viewHolder.itemView.setOnClickListener((View.OnClickListener)new CustomNotificationIconAdapter$$ExternalSyntheticLambda0(this, viewHolder));
        if (this.isHalf) {
            viewHolder.island_small_text_right.setVisibility(8);
            viewHolder.island_small_image_right.setVisibility(8);
            viewHolder.mLottieAnimationView.setVisibility(8);
        }
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        return new ViewHolder(layoutInflater.inflate(2131492995, viewGroup, false));
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        super.onViewDetachedFromWindow((RecyclerView.ViewHolder)viewHolder);
    }

    public void setHalfMode(boolean bl) {
        this.isHalf = bl;
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView island_small_image_left;
        private final ImageView island_small_image_right;
        private final TextView island_small_text_left;
        private final TextView island_small_text_right;
        private final Chronometer mChronometer;
        private final LottieAnimationView mLottieAnimationView;
        private final View mRootLayout;

        public ViewHolder(View view) {
            super(view);
            this.mRootLayout = view;
            this.island_small_image_left = (ImageView)view.findViewById(2131296630);
            this.island_small_text_left = (TextView)view.findViewById(2131296631);
            this.mLottieAnimationView = (LottieAnimationView)view.findViewById(2131296843);
            this.island_small_image_right = (ImageView)view.findViewById(2131296629);
            this.island_small_text_right = (TextView)view.findViewById(2131296632);
            this.mChronometer = (Chronometer)view.findViewById(2131296436);
        }
    }

}

