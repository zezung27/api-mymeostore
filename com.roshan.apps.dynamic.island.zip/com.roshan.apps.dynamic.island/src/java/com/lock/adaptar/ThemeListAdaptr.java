/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.adaptar.ThemeListAdaptr;
import com.lock.entity.ThemeData;
import java.util.ArrayList;

public class ThemeListAdaptr
extends RecyclerView.Adapter<ViewHolder> {
    int index;
    private Activity mContext;
    String nameTittle;
    public ArrayList<ThemeData> themeData;

    public ThemeListAdaptr(Activity activity, ArrayList<ThemeData> arrayList, int n) {
        this.mContext = activity;
        this.themeData = arrayList;
        this.index = n;
    }

    static /* synthetic */ Activity access$000(ThemeListAdaptr themeListAdaptr) {
        return themeListAdaptr.mContext;
    }

    public int getItemCount() {
        return this.themeData.size();
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        String string;
        String string2;
        ThemeData themeData = (ThemeData)this.themeData.get(n);
        viewHolder.rating.setText((CharSequence)(themeData.getRating() + ""));
        viewHolder.name.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.rating.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.rating_image.setColorFilter(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.cardView.setCardBackgroundColor(Color.parseColor((String)themeData.bgColor));
        viewHolder.downloadTxt.setText((CharSequence)themeData.getDownloads());
        viewHolder.downloadTxt.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.intallBtn.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        if (themeData.txtColor.equalsIgnoreCase("#FFFFFF")) {
            viewHolder.intallBtn.setBackgroundResource(2131165335);
        } else {
            viewHolder.intallBtn.setBackgroundResource(2131165334);
        }
        if (this.index == 1) {
            this.nameTittle = themeData.getName() + " Theme";
            string = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/big_image/";
            string2 = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/small_image/";
        } else {
            string2 = string = "";
        }
        if (this.index == 2) {
            this.nameTittle = themeData.getName() + " Lock";
            string = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/big_image/";
            string2 = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/small_image/";
        }
        if (this.index == 3) {
            this.nameTittle = themeData.getName() + "";
            string = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/big_image/";
            string2 = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/small_image/";
        }
        Glide.with((Activity)this.mContext).load(string + themeData.getImage() + ".jpg").listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                viewHolder.progressBar.setVisibility(8);
                return false;
            }

            public boolean onResourceReady(Drawable drawable, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                viewHolder.progressBar.setVisibility(8);
                return false;
            }
        }).into(viewHolder.banner);
        Glide.with((Activity)this.mContext).load(string2 + themeData.getIcon() + ".png").listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                return false;
            }

            public boolean onResourceReady(Drawable drawable, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                return false;
            }
        }).into(viewHolder.image);
        viewHolder.name.setText((CharSequence)this.nameTittle);
        viewHolder.intallBtn.setOnClickListener(new View.OnClickListener(this, themeData){
            final /* synthetic */ ThemeListAdaptr this$0;
            final /* synthetic */ ThemeData val$course;
            {
                this.this$0 = themeListAdaptr;
                this.val$course = themeData;
            }

            public void onClick(View view) {
                if (this.this$0.index == 1) {
                    this.this$0.nameTittle = this.val$course.getName() + " Theme";
                }
                if (this.this$0.index == 2) {
                    this.this$0.nameTittle = this.val$course.getName() + " Lock";
                }
                if (this.this$0.index == 3) {
                    this.this$0.nameTittle = this.val$course.getName() + "";
                }
                if (com.lock.utils.Constants.isAppInstalled((Context)ThemeListAdaptr.access$000(this.this$0), this.val$course.getPkg())) {
                    android.content.Intent intent = ThemeListAdaptr.access$000(this.this$0).getPackageManager().getLaunchIntentForPackage(this.val$course.getPkg());
                    if (ThemeListAdaptr.access$000(this.this$0) != null) {
                        ThemeListAdaptr.access$000(this.this$0).startActivity(intent);
                        return;
                    }
                } else {
                    new android.app.AlertDialog$Builder((Context)new android.view.ContextThemeWrapper((Context)ThemeListAdaptr.access$000(this.this$0), 2131886082)).setTitle((CharSequence)this.this$0.nameTittle).setMessage((CharSequence)"Do You Want To Install It From PlayStore.....!!!").setPositiveButton((CharSequence)"Yes", new android.content.DialogInterface$OnClickListener(this){
                        final /* synthetic */ 3 this$1;
                        {
                            this.this$1 = var1_1;
                        }

                        public void onClick(android.content.DialogInterface dialogInterface, int n) {
                            try {
                                ThemeListAdaptr.access$000(this.this$1.this$0).startActivity(new android.content.Intent("android.intent.action.VIEW", android.net.Uri.parse((String)("https://play.google.com/store/apps/details?id=" + this.this$1.val$course.getPkg()))));
                            }
                            catch (java.lang.Exception exception) {}
                        }
                    }).setNegativeButton((CharSequence)"No", null).show();
                }
            }
        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131492937, viewGroup, false));
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        ImageView banner;
        CardView cardView;
        TextView downloadTxt;
        ImageView image;
        TextView intallBtn;
        TextView name;
        ProgressBar progressBar;
        TextView rating;
        ImageView rating_image;

        public ViewHolder(View view) {
            super(view);
            this.progressBar = (ProgressBar)view.findViewById(2131296815);
            this.image = (ImageView)view.findViewById(2131296362);
            this.rating_image = (ImageView)view.findViewById(2131296825);
            this.cardView = (CardView)view.findViewById(2131296415);
            this.banner = (ImageView)view.findViewById(2131296360);
            this.name = (TextView)view.findViewById(2131296363);
            this.downloadTxt = (TextView)view.findViewById(2131296501);
            this.intallBtn = (TextView)view.findViewById(2131296624);
            this.rating = (TextView)view.findViewById(2131296364);
        }
    }

}

