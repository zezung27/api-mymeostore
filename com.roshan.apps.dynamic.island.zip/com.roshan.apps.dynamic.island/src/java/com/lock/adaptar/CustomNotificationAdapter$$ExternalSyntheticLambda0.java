/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.LinearLayout
 *  com.lock.adaptar.CustomNotificationAdapter
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.adaptar;

import android.view.View;
import android.widget.LinearLayout;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.entity.Notification;

public final class CustomNotificationAdapter$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ Notification f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ LinearLayout f$2;
    public final /* synthetic */ View f$3;

    public /* synthetic */ CustomNotificationAdapter$$ExternalSyntheticLambda0(Notification notification, String string2, LinearLayout linearLayout, View view) {
        this.f$0 = notification;
        this.f$1 = string2;
        this.f$2 = linearLayout;
        this.f$3 = view;
    }

    public final void onClick(View view) {
        CustomNotificationAdapter.lambda$addSubItemsToGroupContainer$0((Notification)this.f$0, (String)this.f$1, (LinearLayout)this.f$2, (View)this.f$3, (View)view);
    }
}

