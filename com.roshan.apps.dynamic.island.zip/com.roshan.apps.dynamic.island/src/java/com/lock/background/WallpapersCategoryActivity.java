/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.Window
 *  android.widget.AdapterView
 *  android.widget.AdapterView$OnItemClickListener
 *  android.widget.GridView
 *  android.widget.ListAdapter
 *  android.widget.ProgressBar
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBar
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  com.android.volley.DefaultRetryPolicy
 *  com.android.volley.Request
 *  com.android.volley.Response
 *  com.android.volley.Response$ErrorListener
 *  com.android.volley.Response$Listener
 *  com.android.volley.RetryPolicy
 *  com.android.volley.VolleyError
 *  com.android.volley.toolbox.JsonObjectRequest
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.FullScreenContentCallback
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.interstitial.InterstitialAd
 *  com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
 *  com.google.gson.Gson
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.List
 *  org.json.JSONObject
 */
package com.lock.background;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.lock.application.LauncherApp;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.background.WallpaperCategory;
import com.lock.background.WallpaperCategoryAdapter;
import com.lock.background.WallpaperCategoryList;
import com.lock.background.WallpapersActivity;
import com.lock.background.WallpapersCategoryActivity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

public class WallpapersCategoryActivity
extends AppCompatActivity {
    AdRequest adRequest;
    private WallpaperCategoryAdapter adapter;
    private int columnWidth;
    private GridView gridView;
    AdView mAdView;
    Context mContext;
    private InterstitialAd mInterstitialAd;
    private ProgressBar pbLoader;
    private ArrayList<WallpaperCategoryList> photosList = new ArrayList();
    private PrefManager pref;
    private Utils utils;
    private String wallpaperPosition;

    private void InitilizeGridLayout() {
        float f = TypedValue.applyDimension((int)1, (float)4.0f, (DisplayMetrics)this.getResources().getDisplayMetrics());
        this.columnWidth = (int)(((float)this.utils.getScreenWidth() - f * (float)(1 + this.pref.getNoOfGridColumnsCategory())) / (float)this.pref.getNoOfGridColumnsCategory());
        this.gridView.setNumColumns(this.pref.getNoOfGridColumnsCategory());
        this.gridView.setColumnWidth(this.columnWidth);
        this.gridView.setStretchMode(0);
        GridView gridView = this.gridView;
        int n = (int)f;
        gridView.setPadding(n, n, n, n);
        this.gridView.setHorizontalSpacing(n);
        this.gridView.setVerticalSpacing(n);
    }

    static /* synthetic */ String access$102(WallpapersCategoryActivity wallpapersCategoryActivity, String string) {
        wallpapersCategoryActivity.wallpaperPosition = string;
        return string;
    }

    static /* synthetic */ ArrayList access$200(WallpapersCategoryActivity wallpapersCategoryActivity) {
        return wallpapersCategoryActivity.photosList;
    }

    private void loadInterstitial() {
        InterstitialAd.load((Context)this, (String)this.getString(2131820546), (AdRequest)this.adRequest, (InterstitialAdLoadCallback)new InterstitialAdLoadCallback(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                WallpapersCategoryActivity.this.mInterstitialAd = null;
            }

            public void onAdLoaded(InterstitialAd interstitialAd) {
                WallpapersCategoryActivity.this.mInterstitialAd = interstitialAd;
                WallpapersCategoryActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){

                    public void onAdDismissedFullScreenContent() {
                        Intent intent = new Intent(WallpapersCategoryActivity.this.mContext, WallpapersActivity.class);
                        intent.putExtra("image_name", WallpapersCategoryActivity.this.wallpaperPosition);
                        WallpapersCategoryActivity.this.startActivity(intent);
                    }

                    public void onAdShowedFullScreenContent() {
                        WallpapersCategoryActivity.this.mInterstitialAd = null;
                    }
                });
            }

        });
    }

    public void getAllImages(JSONObject jSONObject) {
        try {
            WallpaperCategoryAdapter wallpaperCategoryAdapter;
            WallpaperCategory wallpaperCategory = (WallpaperCategory)new Gson().fromJson(jSONObject.toString(), WallpaperCategory.class);
            this.photosList.clear();
            this.pbLoader.setVisibility(8);
            this.gridView.setVisibility(0);
            this.photosList.addAll(wallpaperCategory.getCategory());
            this.adapter = wallpaperCategoryAdapter = new WallpaperCategoryAdapter(this.mContext, (List<WallpaperCategoryList>)this.photosList, this.columnWidth);
            this.gridView.setAdapter((ListAdapter)wallpaperCategoryAdapter);
            this.adapter.notifyDataSetChanged();
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    protected void onCreate(Bundle bundle) {
        ProgressBar progressBar;
        GridView gridView;
        super.onCreate(bundle);
        this.setContentView(2131493058);
        this.mContext = this;
        Toolbar toolbar = (Toolbar)this.findViewById(2131297006);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131034999));
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.getSupportActionBar().setDisplayShowHomeEnabled(true);
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
        Drawable drawable = toolbar.getNavigationIcon();
        if (drawable != null) {
            drawable.setTint(this.getResources().getColor(2131034999));
        }
        this.utils = new Utils(this.mContext);
        this.pref = new PrefManager(this.mContext);
        this.photosList = new ArrayList();
        this.gridView = gridView = (GridView)this.findViewById(2131296584);
        gridView.setVisibility(8);
        this.InitilizeGridLayout();
        this.pbLoader = progressBar = (ProgressBar)this.findViewById(2131296800);
        progressBar.setVisibility(0);
        try {
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(0, "http://45.55.46.214/wallpaper_ahmed/getCatagory.php", null, (Response.Listener)new Response.Listener<JSONObject>(){

                public void onResponse(JSONObject jSONObject) {
                    WallpapersCategoryActivity.this.getAllImages(jSONObject);
                }
            }, new Response.ErrorListener(){

                public void onErrorResponse(VolleyError volleyError) {
                    WallpapersCategoryActivity.this.pbLoader.setVisibility(8);
                    Toast.makeText((Context)WallpapersCategoryActivity.this.mContext, (CharSequence)"Try Again in Few minutes", (int)1).show();
                }
            });
            jsonObjectRequest.setRetryPolicy((RetryPolicy)new DefaultRetryPolicy(10000, 2, 1.0f));
            jsonObjectRequest.setShouldCache(false);
            LauncherApp.getInstance().addToRequestQueue(jsonObjectRequest);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        this.mAdView = (AdView)this.findViewById(2131296376);
        if (!Utils.isAdsRemoved((Context)this)) {
            this.adRequest = new AdRequest.Builder().build();
            this.loadInterstitial();
            this.mAdView.loadAd(this.adRequest);
        } else {
            this.mAdView.setVisibility(8);
        }
        this.gridView.setOnItemClickListener(new AdapterView.OnItemClickListener(this){
            final /* synthetic */ WallpapersCategoryActivity this$0;
            {
                this.this$0 = wallpapersCategoryActivity;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int n, long l) {
                WallpapersCategoryActivity wallpapersCategoryActivity = this.this$0;
                WallpapersCategoryActivity.access$102(wallpapersCategoryActivity, ((WallpaperCategoryList)WallpapersCategoryActivity.access$200(wallpapersCategoryActivity).get(n)).getId().trim());
                if (!Utils.isAdsRemoved(this.this$0.mContext) && WallpapersCategoryActivity.access$300(this.this$0) != null) {
                    WallpapersCategoryActivity.access$300(this.this$0).show((android.app.Activity)this.this$0);
                    return;
                }
                Intent intent = new Intent(this.this$0.mContext, WallpapersActivity.class);
                intent.putExtra("album_id", ((WallpaperCategoryList)WallpapersCategoryActivity.access$200(this.this$0).get(n)).getId().trim());
                this.this$0.startActivity(intent);
            }
        });
    }

    public boolean onSupportNavigateUp() {
        this.onBackPressed();
        return true;
    }

}

