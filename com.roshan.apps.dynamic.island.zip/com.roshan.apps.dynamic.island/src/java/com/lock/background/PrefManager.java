/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.graphics.Color
 *  com.google.gson.Gson
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.background;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import com.frybits.harmony.Harmony;
import com.google.gson.Gson;
import com.lock.entity.AppPackageList;

public class PrefManager {
    public static final String APP_PREF_NAME = "DYNAMIC_ISLAN_PREF";
    public static final String AUTO_CLOSE_NOTI = "AUTO_CLOSE_NOTI1";
    public static final String CAM_COUNT = "CAM_COUNT1";
    public static final String CAM_MARGIN = "CAM_MARGIN1";
    public static final String CAM_POS = "CAM_POS1";
    public static final String CONTROL_ENABLE = "CONTROL_ENABLE";
    private static final String DATA_DEFAULT_COLOR = "DATA_DEFAULT_COLOR1";
    public static final String ENABLE_GLOW = "ENABLE_GLOW1";
    public static final String ENABLE_MUSIC_ANIM = "ENABLE_MUSIC_ANIM1";
    public static final String FILTER_PKG = "FILTER_PKG1";
    public static final String GLOW_WIDTH = "GLOW_WIDTH1";
    public static final String GRADIANT_END_COLOR = "GRADIANT_END_COLOR1";
    public static final String GRADIANT_START_COLOR = "GRADIANT_START_COLOR1";
    public static final String IPHONE_CALL = "IPHONE_CALL1";
    public static final String KEY_DEFAULT_COLOR = "default_color1";
    private static final String KEY_NO_OF_COLUMNS = "no_of_columns1";
    private static final String KEY_NO_OF_COLUMNS_CATEGORY = "no_of_columns_category1";
    public static final String SELECTED_PKG = "SELECTED_PKG1";
    public static final String SHOW_IN_FULL_SCREEN = "SHOW_IN_FULL_SCREEN1";
    public static final String SHOW_IN_LAND = "SHOW_IN_LAND1";
    public static final String SHOW_IN_LOCK = "SHOW_IN_LOCK1";
    private static final String TAG = "PrefManager";
    private static final String TORCH_DEFAULT_COLOR = "TORCH_DEFAULT_COLOR1";
    private static final int VERSION = 1;
    private static final String WIFI_DEFAULT_COLOR = "WIFI_DEFAULT_COLOR1";
    public static final String Y_HEIGHT = "Y_HEIGHT1";
    public static final String Y_POS = "Y_POS1";
    Context mContext;
    SharedPreferences pref;

    public PrefManager(Context context) {
        this.mContext = context;
        this.pref = Harmony.getSharedPreferences(context, APP_PREF_NAME);
    }

    public void SetShowInFullScreen(Context context, boolean bl) {
        this.pref.edit().putBoolean(SHOW_IN_FULL_SCREEN, bl).apply();
    }

    public void SetShowInLand(Context context, boolean bl) {
        this.pref.edit().putBoolean(SHOW_IN_LAND, bl).apply();
    }

    public boolean getAutoCloseNoti(Context context) {
        return this.pref.getBoolean(AUTO_CLOSE_NOTI, false);
    }

    public AppPackageList getCallPkg(Context context) {
        return (AppPackageList)new Gson().fromJson(this.pref.getString(SELECTED_PKG, ""), AppPackageList.class);
    }

    public int getCameraCount() {
        return this.pref.getInt(CAM_COUNT, 1);
    }

    public int getCameraMargin() {
        return this.pref.getInt(CAM_MARGIN, 25);
    }

    public int getCameraPos() {
        return this.pref.getInt(CAM_POS, 2);
    }

    public boolean getControlEnabled() {
        return this.pref.getBoolean(CONTROL_ENABLE, true);
    }

    public int getDataDefaultColor() {
        return this.pref.getInt(DATA_DEFAULT_COLOR, Color.parseColor((String)"#04CB69"));
    }

    public AppPackageList getFilterPkg(Context context) {
        return (AppPackageList)new Gson().fromJson(this.pref.getString(FILTER_PKG, ""), AppPackageList.class);
    }

    public String getGalleryName() {
        return this.pref.getString(APP_PREF_NAME, "Awesome Wallpapers");
    }

    public boolean getGlow(Context context) {
        return this.pref.getBoolean(ENABLE_GLOW, true);
    }

    public int getGlowWidth() {
        return this.pref.getInt(GLOW_WIDTH, 2);
    }

    public int getGradiantEndColor() {
        return this.pref.getInt(GRADIANT_END_COLOR, this.mContext.getColor(2131034336));
    }

    public int getGradiantStartColor() {
        return this.pref.getInt(GRADIANT_START_COLOR, this.mContext.getColor(2131035002));
    }

    public boolean getIphoneCall(Context context) {
        return this.pref.getBoolean(IPHONE_CALL, false);
    }

    public int getMinHeight() {
        return this.pref.getInt(Y_HEIGHT, 30);
    }

    public boolean getMusicAnimation(Context context) {
        return this.pref.getBoolean(ENABLE_MUSIC_ANIM, true);
    }

    public int getNoOfGridColumns() {
        return this.pref.getInt(KEY_NO_OF_COLUMNS, 3);
    }

    public int getNoOfGridColumnsCategory() {
        return this.pref.getInt(KEY_NO_OF_COLUMNS_CATEGORY, 3);
    }

    public boolean getShowInFullScreen(Context context) {
        return this.pref.getBoolean(SHOW_IN_FULL_SCREEN, false);
    }

    public boolean getShowOnLock(Context context) {
        return this.pref.getBoolean(SHOW_IN_LOCK, true);
    }

    public int getTitleColor() {
        return this.pref.getInt(KEY_DEFAULT_COLOR, Color.parseColor((String)"#ffffff"));
    }

    public int getYPosOfIsland() {
        return this.pref.getInt(Y_POS, 5);
    }

    public boolean gethideInLand(Context context) {
        return this.pref.getBoolean(SHOW_IN_LAND, true);
    }

    public void setAutoCloseNoti(Context context, boolean bl) {
        this.pref.edit().putBoolean(AUTO_CLOSE_NOTI, bl).apply();
    }

    public void setCallPkg(Context context, AppPackageList appPackageList) {
        String string2 = new Gson().toJson((Object)appPackageList);
        this.pref.edit().putString(SELECTED_PKG, string2).apply();
    }

    public void setCameraCount(int n) {
        this.pref.edit().putInt(CAM_COUNT, n).apply();
    }

    public void setCameraMargin(int n) {
        this.pref.edit().putInt(CAM_MARGIN, n).apply();
    }

    public void setCameraPos(int n) {
        this.pref.edit().putInt(CAM_POS, n).apply();
    }

    public void setControlEnabled(boolean bl) {
        this.pref.edit().putBoolean(CONTROL_ENABLE, bl).apply();
    }

    public void setDataDefaultColor(int n) {
        this.pref.edit().putInt(DATA_DEFAULT_COLOR, n).apply();
    }

    public void setFilterPkg(Context context, AppPackageList appPackageList) {
        String string2 = new Gson().toJson((Object)appPackageList);
        this.pref.edit().putString(FILTER_PKG, string2).apply();
    }

    public void setGlow(Context context, boolean bl) {
        this.pref.edit().putBoolean(ENABLE_GLOW, bl).apply();
    }

    public void setGlowWidth(int n) {
        this.pref.edit().putInt(GLOW_WIDTH, n).apply();
    }

    public void setGradiantEndColor(int n) {
        this.pref.edit().putInt(GRADIANT_END_COLOR, n).apply();
    }

    public void setGradiantStartColor(int n) {
        this.pref.edit().putInt(GRADIANT_START_COLOR, n).apply();
    }

    public void setHeightOfIsland(int n) {
        this.pref.edit().putInt(Y_HEIGHT, n).apply();
    }

    public void setIphoneCall(Context context, boolean bl) {
        this.pref.edit().putBoolean(IPHONE_CALL, bl).apply();
    }

    public void setMusicAnimation(Context context, boolean bl) {
        this.pref.edit().putBoolean(ENABLE_MUSIC_ANIM, bl).apply();
    }

    public void setShowOnLock(Context context, boolean bl) {
        this.pref.edit().putBoolean(SHOW_IN_LOCK, bl).apply();
    }

    public void setTitleColor(int n) {
        this.pref.edit().putInt(KEY_DEFAULT_COLOR, n).apply();
    }

    public void setYPosOfIsland(int n) {
        this.pref.edit().putInt(Y_POS, n).apply();
    }
}

