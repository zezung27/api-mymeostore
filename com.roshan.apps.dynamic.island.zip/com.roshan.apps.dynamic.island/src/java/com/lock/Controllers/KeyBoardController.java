/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.TextView
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class KeyBoardController
extends ButtonState {
    private Context context;

    public KeyBoardController(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return null;
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131820693);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }

    public void showKeyboardPicker() {
        this.context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        InputMethodManager inputMethodManager = (InputMethodManager)this.context.getApplicationContext().getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.showInputMethodPicker();
        }
    }
}

