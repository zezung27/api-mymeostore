/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.wifi.WifiManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class WifiController
extends ButtonState {
    private final Context context;
    private final Intent intent;
    private final WifiManager wifiManager;

    public WifiController(Context context) {
        super(context);
        this.context = context;
        this.intent = Build.VERSION.SDK_INT >= 29 ? new Intent("android.settings.panel.action.INTERNET_CONNECTIVITY") : new Intent("android.net.wifi.PICK_WIFI_NETWORK");
        this.wifiManager = (WifiManager)context.getApplicationContext().getSystemService("wifi");
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131165543);
            textView2.setText((CharSequence)this.context.getString(2131820888));
        } else {
            lottieAnimationView.setImageResource(2131165542);
            textView2.setText((CharSequence)this.context.getString(2131820887));
        }
        textView.setText((CharSequence)this.context.getString(2131820839));
    }
}

