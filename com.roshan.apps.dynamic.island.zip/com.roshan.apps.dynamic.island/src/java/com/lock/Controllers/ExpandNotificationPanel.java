/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.widget.TextView
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ExpandNotificationPanel
extends ButtonState {
    private Context context;

    public ExpandNotificationPanel(Context context) {
        super(context);
        this.context = context;
    }

    public void closeStatusBar() {
        this.context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS").putExtra("noRespond", true));
    }

    @Override
    public Intent getIntent() {
        return null;
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131820796);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    public void openStatusBar() {
        void var2_6;
        Object object = this.context.getSystemService("statusbar");
        try {
            Class.forName((String)"android.app.StatusBarManager").getMethod("expandNotificationsPanel", new Class[0]).invoke(object, new Object[0]);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (ClassNotFoundException classNotFoundException) {
            // empty catch block
        }
        var2_6.printStackTrace();
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }
}

