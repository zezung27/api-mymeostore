/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.net.wifi.WifiConfiguration
 *  android.net.wifi.WifiManager
 *  android.widget.TextView
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.lock.Controllers;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;
import com.lock.utils.Utils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class HotSpotController
extends ButtonState {
    private Context context;
    public WifiManager wifiManager;

    public HotSpotController(Context context) {
        super(context);
        this.context = context;
        this.wifiManager = (WifiManager)context.getApplicationContext().getSystemService("wifi");
    }

    @Override
    public Intent getIntent() {
        Intent intent = new Intent().setComponent(new ComponentName("com.android.settings", "com.android.settings.TetherSettings"));
        if (Utils.checkIfActivityFound(this.context, intent)) {
            return intent;
        }
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public String getName() {
        Resources resources;
        int n;
        try {
            n = this.context.getResources().getIdentifier("com.android.systemui:string/mobileap", null, null);
            resources = this.context.getResources();
            if (n != 0) return resources.getString(n);
        }
        catch (Exception exception) {
            return "User";
        }
        n = this.context.getResources().getIdentifier("com.android.systemui:string/quick_settings_hotspot_label", null, null);
        return resources.getString(n);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        void var5_13;
        try {
            Class class_ = this.wifiManager.getClass();
            Class[] arrclass = new Class[]{WifiConfiguration.class, Boolean.TYPE};
            Method method = class_.getMethod("setWifiApEnabled", arrclass);
            WifiManager wifiManager = this.wifiManager;
            Object[] arrobject = new Object[]{null, bl};
            method.invoke((Object)wifiManager, arrobject);
            return;
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (IllegalAccessException illegalAccessException) {
            // empty catch block
        }
        var5_13.printStackTrace();
    }
}

