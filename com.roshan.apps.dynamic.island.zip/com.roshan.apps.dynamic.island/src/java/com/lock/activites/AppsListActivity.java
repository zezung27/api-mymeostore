/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ActivityInfo
 *  android.content.pm.LauncherApps
 *  android.content.pm.PackageManager
 *  android.content.pm.ResolveInfo
 *  android.net.Uri
 *  android.os.Bundle
 *  android.os.UserManager
 *  android.text.Editable
 *  android.text.TextWatcher
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.EditText
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  com.lock.adaptar.AppsRecyclerViewAdapter
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.List
 */
package com.lock.activites;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.LauncherApps;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.UserManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.AppsRecyclerViewAdapter;
import com.lock.background.PrefManager;
import com.lock.entity.AppDetail;
import com.lock.entity.AppPackageList;
import com.lock.utils.Utils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

public class AppsListActivity
extends Activity {
    AppsRecyclerViewAdapter adapter;
    public HashMap<String, AppDetail> appDetailHashMap = new HashMap();
    private final ArrayList<AppDetail> applications = new ArrayList();
    private ArrayList<AppDetail> apps;
    private PrefManager prefManager;

    private void addClickListener() {
        this.findViewById(2131297041).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                AppPackageList appPackageList = new AppPackageList();
                appPackageList.appDetailList = new ArrayList();
                for (int i = 0; i < AppsListActivity.this.apps.size(); ++i) {
                    if (!((AppDetail)AppsListActivity.access$100((AppsListActivity)AppsListActivity.this).get((int)i)).isSelected) continue;
                    appPackageList.appDetailList.add((Object)((AppDetail)AppsListActivity.this.apps.get(i)));
                }
                AppsListActivity.this.prefManager.setCallPkg(AppsListActivity.this.getApplicationContext(), appPackageList);
                AppsListActivity.this.finish();
            }
        });
        this.findViewById(2131297025).setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                AppsListActivity.this.finish();
            }
        });
    }

    private void getFilteredList(String string2) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.apps.size(); ++i) {
            if (this.apps.get(i) == null || ((AppDetail)this.apps.get((int)i)).label == null || !((AppDetail)this.apps.get((int)i)).label.toUpperCase().startsWith(string2) && !((AppDetail)this.apps.get((int)i)).label.toUpperCase().contains((CharSequence)string2)) continue;
            arrayList.add((Object)((AppDetail)this.apps.get(i)));
        }
        ArrayList<AppDetail> arrayList2 = Utils.sortAppsAlphabetically((ArrayList<AppDetail>)arrayList);
        this.applications.clear();
        this.applications.addAll(arrayList2);
        this.adapter.notifyDataSetChanged();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private void loadApps() {
        try {
            ArrayList<AppDetail> arrayList = this.apps;
            if (arrayList != null) {
                arrayList.clear();
            } else {
                this.apps = new ArrayList();
            }
            if (!this.appDetailHashMap.isEmpty()) {
                this.appDetailHashMap.clear();
            }
            (UserManager)this.getSystemService("user");
            (LauncherApps)this.getSystemService("launcherapps");
            Intent intent = new Intent("android.intent.action.MAIN", null);
            intent.addCategory("android.intent.category.LAUNCHER");
            PackageManager packageManager = this.getPackageManager();
            for (ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
                AppDetail appDetail = new AppDetail();
                appDetail.label = resolveInfo.loadLabel(packageManager).toString();
                appDetail.pkg = resolveInfo.activityInfo.packageName;
                appDetail.activityInfoName = resolveInfo.activityInfo.name;
                appDetail.isSorted = false;
                this.apps.add((Object)appDetail);
                this.appDetailHashMap.put((Object)(appDetail.label + appDetail.activityInfoName + appDetail.pkg), (Object)appDetail);
            }
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void loadListView() {
        AppsRecyclerViewAdapter appsRecyclerViewAdapter;
        ((EditText)this.findViewById(2131296874)).addTextChangedListener(new TextWatcher(){

            public void afterTextChanged(Editable editable) {
                if (!editable.toString().equals((Object)"")) {
                    AppsListActivity.this.getFilteredList(editable.toString().toUpperCase());
                    return;
                }
                AppsListActivity.this.apps.addAll(Utils.sortAppsAlphabetically((ArrayList<AppDetail>)AppsListActivity.this.apps));
                AppsListActivity.this.applications.clear();
                AppsListActivity.this.applications.addAll((Collection)AppsListActivity.this.apps);
                AppsListActivity.this.adapter.notifyDataSetChanged();
            }

            public void beforeTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }

            public void onTextChanged(CharSequence charSequence, int n, int n2, int n3) {
            }
        });
        RecyclerView recyclerView = (RecyclerView)this.findViewById(2131296854);
        recyclerView.setLayoutManager((RecyclerView.LayoutManager)new LinearLayoutManager((Context)this));
        ArrayList<AppDetail> arrayList = this.apps;
        arrayList.addAll(Utils.sortAppsAlphabetically(arrayList));
        this.applications.clear();
        this.applications.addAll(this.apps);
        this.adapter = appsRecyclerViewAdapter = new AppsRecyclerViewAdapter((Activity)this, this.applications, this.appDetailHashMap);
        recyclerView.setAdapter((RecyclerView.Adapter)appsRecyclerViewAdapter);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492903);
        this.prefManager = new PrefManager((Context)this);
        this.loadApps();
        this.loadListView();
        this.addClickListener();
        AppPackageList appPackageList = this.prefManager.getCallPkg((Context)this);
        if (appPackageList != null && this.apps != null) {
            for (int i = 0; i < appPackageList.appDetailList.size(); ++i) {
                AppDetail appDetail = (AppDetail)appPackageList.appDetailList.get(i);
                for (int j = 0; j < this.apps.size(); ++j) {
                    if (!((AppDetail)this.apps.get((int)j)).pkg.equals((Object)appDetail.pkg) || !((AppDetail)this.apps.get((int)j)).activityInfoName.equals((Object)appDetail.activityInfoName)) continue;
                    ((AppDetail)this.apps.get((int)j)).isSelected = true;
                }
            }
            this.adapter.notifyDataSetChanged();
        }
    }

}

