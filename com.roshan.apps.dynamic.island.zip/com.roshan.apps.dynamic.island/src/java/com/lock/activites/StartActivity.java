/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.os.Bundle
 *  android.os.Handler
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.view.View
 *  android.view.Window
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  android.widget.ImageView
 *  com.lock.activites.HomeActivity
 *  com.lock.activites.PermissionsActivity
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.lock.activites;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.lock.activites.HomeActivity;
import com.lock.activites.PermissionsActivity;
import com.lock.utils.Constants;

public class StartActivity
extends Activity {
    Context mContxt;

    public boolean checkNotificationEnabled(Context context) {
        try {
            boolean bl = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"enabled_notification_listeners").contains((CharSequence)context.getPackageName());
            return bl;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492900);
        this.mContxt = this;
        Window window = this.getWindow();
        window.setFlags(512, 512);
        try {
            window.addFlags(Integer.MIN_VALUE);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        try {
            window.clearFlags(67108864);
        }
        catch (Resources.NotFoundException notFoundException) {
            notFoundException.printStackTrace();
        }
        try {
            window.setStatusBarColor(this.getResources().getColor(17170445));
        }
        catch (Resources.NotFoundException notFoundException) {
            notFoundException.printStackTrace();
        }
        this.getWindow().getDecorView().setSystemUiVisibility(1280);
        this.getWindow().setStatusBarColor(0);
        ((ImageView)this.findViewById(2131296614)).startAnimation(AnimationUtils.loadAnimation((Context)this, (int)2130772019));
        new Handler().postDelayed(new Runnable(){

            public void run() {
                StartActivity startActivity;
                if (Constants.checkAccessibilityEnabled(StartActivity.this.mContxt) && (startActivity = StartActivity.this).checkNotificationEnabled(startActivity.mContxt)) {
                    StartActivity.this.startActivity(new Intent(StartActivity.this.mContxt, HomeActivity.class));
                    StartActivity.this.overridePendingTransition(2130771980, 2130771981);
                    StartActivity.this.finish();
                    return;
                }
                StartActivity.this.startActivity(new Intent(StartActivity.this.mContxt, PermissionsActivity.class));
                StartActivity.this.overridePendingTransition(2130771980, 2130771981);
                StartActivity.this.finish();
            }
        }, 2000L);
    }

}

