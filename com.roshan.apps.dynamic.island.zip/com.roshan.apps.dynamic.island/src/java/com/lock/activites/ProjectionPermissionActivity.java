/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.media.projection.MediaProjectionManager
 *  android.os.Bundle
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.activites;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Toast;

public class ProjectionPermissionActivity
extends Activity {
    public void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
        if (n == 1 && n2 != -1) {
            Toast.makeText((Context)this, (CharSequence)"Permission not granted for screen blur", (int)1).show();
        }
        this.finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        try {
            this.startActivityForResult(((MediaProjectionManager)this.getSystemService("media_projection")).createScreenCaptureIntent(), 1);
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            Toast.makeText((Context)this, (CharSequence)"Unfortunately, screen recording isn't supported on your device.", (int)1).show();
            return;
        }
    }
}

