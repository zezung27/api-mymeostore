/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ProgressDialog
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.widget.TextView
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.widget.Toolbar
 *  androidx.fragment.app.FragmentActivity
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.viewpager2.widget.ViewPager2
 *  androidx.viewpager2.widget.ViewPager2$OnPageChangeCallback
 *  com.google.android.material.bottomnavigation.BottomNavigationView
 *  com.google.android.material.navigation.NavigationBarView
 *  com.google.android.material.navigation.NavigationBarView$OnItemSelectedListener
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 */
package com.lock.activites;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.github.mmin18.widget.RealtimeBlurView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.lock.activites.MoreActivity;
import com.lock.adaptar.ViewPagerAdapter;
import com.lock.utils.Constants;

public class MoreActivity
extends AppCompatActivity {
    static final String TAG = "InAppPurchase";
    public String[] STORAGE_PERMISSION = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    TextView bg_btn;
    NavigationBarView.OnItemSelectedListener mOnNavigationItemSelectedListener = new NavigationBarView.OnItemSelectedListener(){

        public boolean onNavigationItemSelected(MenuItem menuItem) {
            int n = menuItem.getItemId();
            if (n != 2131296752) {
                if (n != 2131296760) {
                    if (n != 2131296762) {
                        return false;
                    }
                    MoreActivity.this.viewPager.setCurrentItem(0);
                    return true;
                }
                MoreActivity.this.viewPager.setCurrentItem(1);
                return true;
            }
            MoreActivity.this.viewPager.setCurrentItem(2);
            return true;
        }
    };
    TextView more_btn;
    BottomNavigationView navigation;
    private ProgressDialog pd_progressDialog;
    TextView permission_btn;
    MenuItem prevMenuItem;
    TextView rate_us_btn;
    RealtimeBlurView real_time_blur;
    TextView remove_ads_btn;
    private ViewPager2 viewPager;

    static /* synthetic */ void access$100(MoreActivity moreActivity, ViewPager2 viewPager2) {
        moreActivity.setupViewPager(viewPager2);
    }

    private void loadApps() {
        new Thread(new Runnable(this){
            final /* synthetic */ MoreActivity this$0;
            {
                this.this$0 = moreActivity;
            }

            public void run() {
                try {
                    android.content.pm.PackageManager packageManager = this.this$0.getPackageManager();
                    Intent intent = new Intent("android.intent.action.MAIN", null);
                    intent.addCategory("android.intent.category.LAUNCHER");
                    for (android.content.pm.ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
                        String string = resolveInfo.loadLabel(packageManager).toString();
                        if (string.toLowerCase().equals((Object)"camera")) {
                            Constants.setCameraPkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                        }
                        if (!resolveInfo.loadLabel(packageManager).toString().toLowerCase().equals((Object)"phone") && !resolveInfo.activityInfo.name.toLowerCase().equals((Object)"dialler")) continue;
                        Constants.setPhonePkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }).start();
    }

    private void setFullScreen() {
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
    }

    private void setupViewPager(ViewPager2 viewPager2) {
        viewPager2.setAdapter((RecyclerView.Adapter)new ViewPagerAdapter((FragmentActivity)this));
        viewPager2.setSaveEnabled(false);
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    protected void onCreate(Bundle bundle) {
        ProgressDialog progressDialog;
        super.onCreate(bundle);
        this.setContentView(2131492897);
        this.setFullScreen();
        Toolbar toolbar = (Toolbar)this.findViewById(2131297006);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131034155));
        this.pd_progressDialog = progressDialog = new ProgressDialog((Context)this);
        progressDialog.setProgressStyle(0);
        this.pd_progressDialog.setMessage((CharSequence)" Please wait...");
        this.pd_progressDialog.setCancelable(false);
        this.pd_progressDialog.setTitle((CharSequence)"Loading");
        this.setWaitScreen(true);
        this.navigation = (BottomNavigationView)this.findViewById(2131296751);
        this.viewPager = (ViewPager2)this.findViewById(2131297070);
        this.navigation.setOnItemSelectedListener(this.mOnNavigationItemSelectedListener);
        ViewPager2.OnPageChangeCallback onPageChangeCallback = new ViewPager2.OnPageChangeCallback(){

            public void onPageScrollStateChanged(int n) {
                super.onPageScrollStateChanged(n);
            }

            public void onPageScrolled(int n, float f, int n2) {
                if (MoreActivity.this.prevMenuItem != null) {
                    MoreActivity.this.prevMenuItem.setChecked(false);
                } else {
                    MoreActivity.this.navigation.getMenu().getItem(0).setChecked(false);
                }
                Log.d((String)"page", (String)("onPageSelected: " + n));
                MoreActivity.this.navigation.getMenu().getItem(n).setChecked(true);
                MoreActivity moreActivity = MoreActivity.this;
                moreActivity.prevMenuItem = moreActivity.navigation.getMenu().getItem(n);
                super.onPageScrolled(n, f, n2);
            }

            public void onPageSelected(int n) {
                super.onPageSelected(n);
            }
        };
        this.viewPager.registerOnPageChangeCallback(onPageChangeCallback);
        this.viewPager.setOffscreenPageLimit(3);
        new Handler().postDelayed(new Runnable(this){
            final /* synthetic */ MoreActivity this$0;
            {
                this.this$0 = moreActivity;
            }

            public void run() {
                this.this$0.setWaitScreen(false);
                MoreActivity moreActivity = this.this$0;
                MoreActivity.access$100(moreActivity, MoreActivity.access$000(moreActivity));
            }
        }, 2000L);
        if (Constants.getCameraPkg((Context)this).equals((Object)"")) {
            this.loadApps();
        }
    }

    void setWaitScreen(boolean bl) {
        ProgressDialog progressDialog = this.pd_progressDialog;
        if (progressDialog != null) {
            if (bl) {
                progressDialog.show();
                return;
            }
            if (!this.isFinishing()) {
                try {
                    this.pd_progressDialog.dismiss();
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }
    }

}

