/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.appcompat.app.AppCompatActivity
 */
package com.lock.activites;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.lock.activites.HelpActivity;

public class HelpActivity
extends AppCompatActivity {
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492895);
        this.findViewById(2131296783).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ HelpActivity this$0;
            {
                this.this$0 = helpActivity;
            }

            public void onClick(View view) {
                this.this$0.finish();
            }
        });
    }
}

