/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.net.Uri
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.app.ActionBarDrawerToggle
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.appcompat.graphics.drawable.DrawerArrowDrawable
 *  androidx.appcompat.widget.Toolbar
 *  androidx.drawerlayout.widget.DrawerLayout
 *  androidx.drawerlayout.widget.DrawerLayout$DrawerListener
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  androidx.fragment.app.FragmentManager
 *  androidx.fragment.app.FragmentTransaction
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.viewpager2.widget.ViewPager2
 *  com.android.billingclient.api.AcknowledgePurchaseParams
 *  com.android.billingclient.api.AcknowledgePurchaseParams$Builder
 *  com.android.billingclient.api.AcknowledgePurchaseResponseListener
 *  com.android.billingclient.api.BillingClient
 *  com.android.billingclient.api.BillingClient$Builder
 *  com.android.billingclient.api.BillingClientStateListener
 *  com.android.billingclient.api.BillingFlowParams
 *  com.android.billingclient.api.BillingFlowParams$Builder
 *  com.android.billingclient.api.BillingResult
 *  com.android.billingclient.api.Purchase
 *  com.android.billingclient.api.PurchasesResponseListener
 *  com.android.billingclient.api.PurchasesUpdatedListener
 *  com.android.billingclient.api.QueryPurchasesParams
 *  com.android.billingclient.api.QueryPurchasesParams$Builder
 *  com.android.billingclient.api.SkuDetails
 *  com.android.billingclient.api.SkuDetailsParams
 *  com.android.billingclient.api.SkuDetailsParams$Builder
 *  com.android.billingclient.api.SkuDetailsResponseListener
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.FullScreenContentCallback
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.MobileAds
 *  com.google.android.gms.ads.RequestConfiguration
 *  com.google.android.gms.ads.RequestConfiguration$Builder
 *  com.google.android.gms.ads.interstitial.InterstitialAd
 *  com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  java.util.List
 */
package com.lock.activites;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.graphics.drawable.DrawerArrowDrawable;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryPurchasesParams;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.github.mmin18.widget.RealtimeBlurView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.lock.activites.HomeActivity;
import com.lock.activites.MoreActivity;
import com.lock.activites.PermissionsActivity;
import com.lock.adaptar.ViewPagerAdapter;
import com.lock.background.Utils;
import com.lock.background.WallpapersCategoryActivity;
import com.lock.fragment.SettingsFragment;
import com.lock.utils.Constants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class HomeActivity
extends AppCompatActivity
implements View.OnClickListener,
PurchasesUpdatedListener {
    static final String SKU_GAS = "no_ads";
    static final String TAG = "InAppPurchase";
    public String[] STORAGE_PERMISSION = new String[]{"android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"};
    AcknowledgePurchaseResponseListener acknowledgePurchaseResponseListener = new AcknowledgePurchaseResponseListener(){

        public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
            if (billingResult.getResponseCode() == 0) {
                Toast.makeText((Context)HomeActivity.this, (CharSequence)"Purchase successful", (int)1).show();
            }
        }
    };
    AdRequest adRequest;
    TextView bg_btn;
    private BillingClient billingClient;
    DrawerLayout drawer;
    private boolean fromAdScreen = false;
    Boolean isAdRemoved;
    public InterstitialAd mInterstitialAd;
    TextView more_btn;
    TextView permission_btn;
    MenuItem prevMenuItem;
    TextView rate_us_btn;
    RealtimeBlurView real_time_blur;
    TextView remove_ads_btn;
    List<SkuDetails> skuDetailsList;

    static /* synthetic */ void access$000(HomeActivity homeActivity) {
        homeActivity.querySKUDetails();
    }

    static /* synthetic */ void access$100(HomeActivity homeActivity) {
        homeActivity.queryPurchase();
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == 1) {
            if (!purchase.isAcknowledged()) {
                AcknowledgePurchaseParams acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
                this.billingClient.acknowledgePurchase(acknowledgePurchaseParams, this.acknowledgePurchaseResponseListener);
            }
            if (purchase.getProducts().size() > 0 && ((String)purchase.getProducts().get(0)).equals((Object)SKU_GAS)) {
                this.updatePurchase(true);
            }
        }
    }

    private void loadAdsForWallpaperActivity() {
        InterstitialAd.load((Context)this, (String)this.getString(2131820546), (AdRequest)this.adRequest, (InterstitialAdLoadCallback)new InterstitialAdLoadCallback(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                HomeActivity.this.fromAdScreen = true;
                HomeActivity.this.mInterstitialAd = null;
            }

            public void onAdLoaded(InterstitialAd interstitialAd) {
                HomeActivity.this.mInterstitialAd = interstitialAd;
                HomeActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback(){

                    public void onAdDismissedFullScreenContent() {
                        HomeActivity.this.fromAdScreen = true;
                    }

                    public void onAdShowedFullScreenContent() {
                        HomeActivity.this.fromAdScreen = true;
                        HomeActivity.this.mInterstitialAd = null;
                        HomeActivity.this.loadAdsForWallpaperActivity();
                    }
                });
            }

        });
    }

    private void loadApps() {
        new Thread(new Runnable(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void run() {
                try {
                    android.content.pm.PackageManager packageManager = this.this$0.getPackageManager();
                    Intent intent = new Intent("android.intent.action.MAIN", null);
                    intent.addCategory("android.intent.category.LAUNCHER");
                    for (android.content.pm.ResolveInfo resolveInfo : packageManager.queryIntentActivities(intent, 0)) {
                        String string = resolveInfo.loadLabel(packageManager).toString();
                        if (string.toLowerCase().equals((Object)"camera")) {
                            Constants.setCameraPkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                        }
                        if (!resolveInfo.loadLabel(packageManager).toString().toLowerCase().equals((Object)"phone") && !resolveInfo.activityInfo.name.toLowerCase().equals((Object)"dialler")) continue;
                        Constants.setPhonePkg((Context)this.this$0, resolveInfo.activityInfo.packageName);
                    }
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                }
            }
        }).start();
    }

    private void makePurchase() {
        List<SkuDetails> list = this.skuDetailsList;
        if (list != null && list.size() > 0) {
            BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder().setSkuDetails((SkuDetails)this.skuDetailsList.get(0)).build();
            this.billingClient.launchBillingFlow((Activity)this, billingFlowParams).getResponseCode();
        }
    }

    private void queryPurchase() {
        this.billingClient.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType("inapp").build(), new PurchasesResponseListener(){

            public void onQueryPurchasesResponse(BillingResult billingResult, List<Purchase> list) {
                if (list.size() > 0) {
                    for (Purchase purchase : list) {
                        HomeActivity.this.handlePurchase(purchase);
                    }
                } else {
                    HomeActivity.this.updatePurchase(false);
                }
            }
        });
    }

    private void querySKUDetails() {
        ArrayList arrayList = new ArrayList();
        arrayList.add((Object)SKU_GAS);
        SkuDetailsParams.Builder builder = SkuDetailsParams.newBuilder();
        builder.setSkusList((List)arrayList).setType("inapp");
        this.billingClient.querySkuDetailsAsync(builder.build(), new SkuDetailsResponseListener(){

            public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> list) {
                HomeActivity.this.skuDetailsList = list;
            }
        });
    }

    private void setFullScreen() {
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
    }

    private void setupViewPager(ViewPager2 viewPager2) {
        viewPager2.setAdapter((RecyclerView.Adapter)new ViewPagerAdapter((FragmentActivity)this));
        viewPager2.setSaveEnabled(false);
    }

    private void showAds() {
        InterstitialAd interstitialAd;
        if (!Utils.isAdsRemoved((Context)this) && (interstitialAd = this.mInterstitialAd) != null) {
            interstitialAd.show((Activity)this);
        }
    }

    private void updatePurchase(boolean bl) {
        this.isAdRemoved = bl;
        this.saveData(bl);
        this.loadData();
    }

    void alert(String string) {
        AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
        builder.setMessage((CharSequence)string);
        builder.setNeutralButton((CharSequence)"OK", null);
        Log.d((String)TAG, (String)("Showing alert dialog: " + string));
        builder.create();
        if (!this.isFinishing()) {
            builder.show();
        }
    }

    void complain(String string) {
        Log.e((String)TAG, (String)("**** InAppPurchase Error: " + string));
        this.alert("Error: " + string);
    }

    public void initializeBilling() {
        if (this.billingClient == null) {
            this.billingClient = BillingClient.newBuilder((Context)this).enablePendingPurchases().setListener((PurchasesUpdatedListener)this).build();
        }
        this.billingClient.startConnection(new BillingClientStateListener(this){
            final /* synthetic */ HomeActivity this$0;
            {
                this.this$0 = homeActivity;
            }

            public void onBillingServiceDisconnected() {
            }

            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == 0) {
                    HomeActivity.access$000(this.this$0);
                    HomeActivity.access$100(this.this$0);
                    return;
                }
                HomeActivity.access$200(this.this$0, false);
            }
        });
    }

    void loadData() {
        Boolean bl;
        List list = Arrays.asList((Object[])new String[]{"62488F7DC24E4F985C4A4569D0E026BF"});
        MobileAds.setRequestConfiguration((RequestConfiguration)new RequestConfiguration.Builder().setTestDeviceIds(list).build());
        this.isAdRemoved = bl = Boolean.valueOf((boolean)this.getSharedPreferences("ads", 0).getBoolean("isAdRemoved", false));
        if (!bl.booleanValue()) {
            this.adRequest = new AdRequest.Builder().build();
            this.loadAdsForWallpaperActivity();
            this.remove_ads_btn.setVisibility(0);
            return;
        }
        this.remove_ads_btn.setVisibility(8);
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        if (this.drawer.isDrawerOpen(8388611)) {
            this.drawer.closeDrawer(8388611);
            return;
        }
        super.onBackPressed();
    }

    /*
     * Loose catch block
     * Enabled aggressive exception aggregation
     */
    public void onClick(View view) {
        block16 : {
            switch (view.getId()) {
                default: {
                    return;
                }
                case 2131296833: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.onRemoveAdButtonClicked();
                    return;
                }
                case 2131296822: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/details?id=" + this.getPackageName()))));
                    return;
                }
                case 2131296803: {
                    if (this.drawer.isDrawerOpen(8388611)) {
                        this.drawer.closeDrawer(8388611);
                    }
                    this.startActivity(new Intent((Context)this, PermissionsActivity.class));
                    return;
                }
                case 2131296720: {
                    try {
                        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.getString(2131820583)))));
                        return;
                    }
                    catch (ActivityNotFoundException activityNotFoundException) {
                        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.getString(2131820583)))));
                        return;
                    }
                }
                case 2131296382: 
            }
            if (this.drawer.isDrawerOpen(8388611)) {
                this.drawer.closeDrawer(8388611);
            }
            this.startActivity(new Intent((Context)this, WallpapersCategoryActivity.class));
            break block16;
            {
                catch (Exception exception) {}
            }
        }
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(2131492893);
        this.setFullScreen();
        Toolbar toolbar = (Toolbar)this.findViewById(2131297006);
        this.setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(this.getResources().getColor(2131034999));
        this.drawer = (DrawerLayout)this.findViewById(2131296511);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle((Activity)this, this.drawer, toolbar, 2131820779, 2131820778);
        actionBarDrawerToggle.getDrawerArrowDrawable().setColor(this.getResources().getColor(2131034999, null));
        this.drawer.addDrawerListener((DrawerLayout.DrawerListener)actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        this.remove_ads_btn = (TextView)this.findViewById(2131296833);
        this.rate_us_btn = (TextView)this.findViewById(2131296822);
        this.more_btn = (TextView)this.findViewById(2131296720);
        this.permission_btn = (TextView)this.findViewById(2131296803);
        this.bg_btn = (TextView)this.findViewById(2131296382);
        this.real_time_blur = (RealtimeBlurView)this.findViewById(2131296827);
        this.initializeBilling();
        this.real_time_blur.setOnClickListener((View.OnClickListener)this);
        this.remove_ads_btn.setOnClickListener((View.OnClickListener)this);
        this.bg_btn.setOnClickListener((View.OnClickListener)this);
        this.rate_us_btn.setOnClickListener((View.OnClickListener)this);
        this.more_btn.setOnClickListener((View.OnClickListener)this);
        this.permission_btn.setOnClickListener((View.OnClickListener)this);
        if (Constants.getCameraPkg((Context)this).equals((Object)"")) {
            this.loadApps();
        }
        this.getSupportFragmentManager().beginTransaction().replace(2131296886, (Fragment)new SettingsFragment(), "stuff").commit();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(2131558400, menu);
        return true;
    }

    protected void onDestroy() {
        BillingClient billingClient = this.billingClient;
        if (billingClient != null) {
            billingClient.endConnection();
        }
        super.onDestroy();
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 2131296327) {
            this.startActivity(new Intent((Context)this, MoreActivity.class));
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> list) {
        if (billingResult.getResponseCode() == 0 && list != null) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                this.handlePurchase((Purchase)iterator.next());
            }
        } else {
            billingResult.getResponseCode();
        }
    }

    public void onRemoveAdButtonClicked() {
        if (this.isAdRemoved.booleanValue()) {
            this.complain(this.getString(2131820586));
            return;
        }
        BillingClient billingClient = this.billingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.makePurchase();
            return;
        }
        this.initializeBilling();
    }

    protected void onResume() {
        BillingClient billingClient = this.billingClient;
        if (billingClient != null && billingClient.isReady()) {
            this.queryPurchase();
        } else {
            this.initializeBilling();
        }
        if (!this.fromAdScreen) {
            this.showAds();
        } else {
            this.fromAdScreen = false;
        }
        super.onResume();
    }

    void saveData(boolean bl) {
        SharedPreferences.Editor editor = this.getSharedPreferences("ads", 0).edit();
        if (!this.getSharedPreferences("ads", 0).getBoolean("isAdRemoved", false)) {
            Boolean bl2;
            editor.putBoolean("isAdRemoved", bl);
            editor.apply();
            this.isAdRemoved = bl2 = Boolean.valueOf((boolean)bl);
            if (bl2.booleanValue()) {
                this.remove_ads_btn.setVisibility(8);
            }
        }
    }

}

