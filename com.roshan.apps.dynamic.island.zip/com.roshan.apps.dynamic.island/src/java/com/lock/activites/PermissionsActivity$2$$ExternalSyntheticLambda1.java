/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.lock.activites;

import com.lock.activites.PermissionsActivity;
import com.nordan.dialog.NordanAlertDialogListener;

public final class PermissionsActivity$2$$ExternalSyntheticLambda1
implements NordanAlertDialogListener {
    public final /* synthetic */ PermissionsActivity.2 f$0;

    public /* synthetic */ PermissionsActivity$2$$ExternalSyntheticLambda1(PermissionsActivity.2 var1_1) {
        this.f$0 = var1_1;
    }

    @Override
    public final void onClick() {
        this.f$0.lambda$onCheckedChanged$1$com-lock-activites-PermissionsActivity$2();
    }
}

