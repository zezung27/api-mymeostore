/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  com.lock.activites.PermissionsActivity
 *  java.lang.Object
 */
package com.lock.activites;

import android.view.View;
import com.lock.activites.PermissionsActivity;

public final class PermissionsActivity$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ PermissionsActivity f$0;

    public /* synthetic */ PermissionsActivity$$ExternalSyntheticLambda0(PermissionsActivity permissionsActivity) {
        this.f$0 = permissionsActivity;
    }

    public final void onClick(View view) {
        this.f$0.lambda$onCreate$0$com-lock-activites-PermissionsActivity(view);
    }
}

