/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageManager
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.Picasso$LoadedFrom
 *  com.squareup.picasso.Request
 *  com.squareup.picasso.RequestHandler
 *  com.squareup.picasso.RequestHandler$Result
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 */
package com.lock.handler;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import com.lock.entity.AppDetail;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Request;
import com.squareup.picasso.RequestHandler;
import java.util.HashMap;

public class ChangeAppIconRequestHandler
extends RequestHandler {
    private static final String SCHEME_APP_ICON = "app-icon";
    private final HashMap<String, AppDetail> appDetailHashMap;
    private final Activity context;
    private final PackageManager mPackageManager;

    public ChangeAppIconRequestHandler(Activity activity, HashMap<String, AppDetail> hashMap) {
        this.context = activity;
        this.mPackageManager = activity.getPackageManager();
        this.appDetailHashMap = hashMap;
    }

    public static Uri getUri(String string) {
        return Uri.fromParts((String)SCHEME_APP_ICON, (String)string, null);
    }

    public boolean canHandleRequest(Request request) {
        return SCHEME_APP_ICON.equals((Object)request.uri.getScheme());
    }

    public RequestHandler.Result load(Request request, int n) {
        ActivityInfo activityInfo;
        String string = request.uri.getSchemeSpecificPart();
        AppDetail appDetail = (AppDetail)this.appDetailHashMap.get((Object)string);
        Bitmap bitmap = appDetail != null && (activityInfo = Utils.getActivityInfo((Context)this.context, appDetail.pkg, appDetail.activityInfoName)) != null ? Constants.drawableToBmp(this.context, activityInfo.loadIcon(this.mPackageManager), 35) : null;
        RequestHandler.Result result = null;
        if (bitmap != null) {
            result = new RequestHandler.Result(bitmap, Picasso.LoadedFrom.DISK);
        }
        return result;
    }
}

