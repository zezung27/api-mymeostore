/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.TextUtils
 *  android.text.TextUtils$TruncateAt
 *  android.util.AttributeSet
 *  androidx.appcompat.widget.AppCompatTextView
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.widgets;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatTextView;

public class AutoMarqueeTextView
extends AppCompatTextView {
    public boolean isEnableMarquee = false;

    public AutoMarqueeTextView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.setSelected(true);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.setSelected(false);
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.onVisibilityAggregated(true);
    }

    public void onVisibilityAggregated(boolean bl) {
        if (Build.VERSION.SDK_INT >= 24) {
            super.onVisibilityAggregated(bl);
        }
        if (bl != this.isEnableMarquee) {
            this.isEnableMarquee = bl;
            this.post(new Runnable(this){
                public final AutoMarqueeTextView autoMarqueeTextView;
                {
                    this.autoMarqueeTextView = autoMarqueeTextView;
                }

                public final void run() {
                    AutoMarqueeTextView autoMarqueeTextView = this.autoMarqueeTextView;
                    if (autoMarqueeTextView.isEnableMarquee) {
                        autoMarqueeTextView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                        return;
                    }
                    autoMarqueeTextView.setEllipsize(TextUtils.TruncateAt.END);
                }
            });
        }
    }

}

