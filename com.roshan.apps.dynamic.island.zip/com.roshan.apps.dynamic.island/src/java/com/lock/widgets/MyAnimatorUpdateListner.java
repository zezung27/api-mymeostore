/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.Interpolator
 *  com.google.android.material.math.MathUtils
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Objects
 */
package com.lock.widgets;

import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import com.google.android.material.math.MathUtils;
import com.lock.widgets.ExpandingItemLayout;
import java.util.Objects;

public final class MyAnimatorUpdateListner
implements ValueAnimator.AnimatorUpdateListener {
    public final ExpandingItemLayout a;
    public final Interpolator b;
    public final int f10532c;
    public final int f10533d;

    public MyAnimatorUpdateListner(ExpandingItemLayout expandingItemLayout, Interpolator interpolator2, int n, int n2) {
        this.a = expandingItemLayout;
        this.b = interpolator2;
        this.f10532c = n;
        this.f10533d = n2;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        ExpandingItemLayout expandingItemLayout = this.a;
        Interpolator interpolator2 = this.b;
        int n = this.f10532c;
        int n2 = this.f10533d;
        Objects.requireNonNull((Object)((Object)expandingItemLayout));
        float f = ((Float)valueAnimator.getAnimatedValue()).floatValue();
        float f2 = expandingItemLayout.isVisible ? f : 1.0f - f;
        float f3 = interpolator2.getInterpolation(f2);
        for (int i = 1; i < expandingItemLayout.getChildCount(); ++i) {
            expandingItemLayout.getChildAt(i).setAlpha(f3);
        }
        expandingItemLayout.getLayoutParams().height = (int)MathUtils.lerp((float)n, (float)n2, (float)f);
        expandingItemLayout.requestLayout();
    }
}

