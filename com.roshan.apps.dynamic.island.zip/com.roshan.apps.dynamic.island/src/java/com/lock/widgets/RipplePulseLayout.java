/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.AnimatorSet
 *  android.animation.ObjectAnimator
 *  android.animation.TimeInterpolator
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  android.widget.FrameLayout
 *  android.widget.FrameLayout$LayoutParams
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.widgets;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;

public class RipplePulseLayout
extends FrameLayout {
    public AnimatorSet animatorSet;
    public Context mContext;
    public Paint paint;
    public RippleView rippleView;

    public RipplePulseLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mContext = context;
        this.setVisibility(0);
    }

    public static int pixelToDp(Context context, int n) {
        return (int)TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)context.getResources().getDisplayMetrics());
    }

    public void setVisibility(int n) {
        super.setVisibility(n);
        if (!this.isInEditMode() && this.getVisibility() != 8) {
            Paint paint;
            float f = RipplePulseLayout.pixelToDp(this.mContext, 24);
            float f2 = RipplePulseLayout.pixelToDp(this.mContext, 30);
            int n2 = this.getResources().getColor(2131034218);
            this.paint = paint = new Paint();
            paint.setColor(n2);
            this.paint.setAntiAlias(true);
            this.paint.setStyle(Paint.Style.STROKE);
            this.paint.setStrokeWidth(4.0f);
            this.rippleView = new RippleView(this.mContext, this.paint, f);
            int n3 = 2 * (int)(4.0f + f2);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(n3, n3);
            layoutParams.gravity = 17;
            this.addView((View)this.rippleView, (ViewGroup.LayoutParams)layoutParams);
            this.rippleView.setVisibility(8);
            this.animatorSet = new AnimatorSet();
            ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)((Object)this.rippleView), (String)"radius", (float[])new float[]{f, f2});
            objectAnimator.setRepeatCount(-1);
            ObjectAnimator objectAnimator2 = ObjectAnimator.ofFloat((Object)((Object)this.rippleView), (String)"alpha", (float[])new float[]{0.0f, 1.0f, 0.0f});
            objectAnimator2.setRepeatCount(-1);
            this.animatorSet.setDuration(2000L);
            this.animatorSet.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
            this.animatorSet.playTogether(new Animator[]{objectAnimator, objectAnimator2});
            return;
        }
        this.paint = null;
        this.rippleView = null;
        AnimatorSet animatorSet = this.animatorSet;
        if (animatorSet != null) {
            animatorSet.cancel();
            this.animatorSet = null;
        }
    }

    public class RippleView
    extends View {
        public float radius;

        public RippleView(Context context, Paint paint, float f) {
            super(context);
            RipplePulseLayout.this.mContext = context;
            RipplePulseLayout.this.paint = paint;
            this.radius = f;
        }

        public void onDraw(Canvas canvas) {
            canvas.drawCircle((float)(this.getWidth() / 2), (float)(this.getHeight() / 2), this.radius, RipplePulseLayout.this.paint);
        }

        public void setRadius(float f) {
            this.radius = f;
            this.invalidate();
        }
    }

}

