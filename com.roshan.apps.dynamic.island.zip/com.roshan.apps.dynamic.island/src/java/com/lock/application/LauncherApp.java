/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 *  com.android.volley.Request
 *  com.android.volley.RequestQueue
 *  com.android.volley.toolbox.Volley
 *  com.lock.background.LruBitmapCache
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.application;

import android.app.Application;
import android.content.Context;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.lock.background.LruBitmapCache;

public class LauncherApp
extends Application {
    public static final String TAG = "LauncherApp";
    private static LauncherApp mInstance;
    LruBitmapCache mLruBitmapCache;
    private RequestQueue mRequestQueue;

    public static LauncherApp getInstance() {
        Class<LauncherApp> class_ = LauncherApp.class;
        synchronized (LauncherApp.class) {
            LauncherApp launcherApp = mInstance;
            // ** MonitorExit[var2] (shouldn't be in output)
            return launcherApp;
        }
    }

    public <T> void addToRequestQueue(Request<T> request) {
        request.setTag((Object)TAG);
        this.getRequestQueue().add(request);
    }

    public LruBitmapCache getLruBitmapCache() {
        if (this.mLruBitmapCache == null) {
            this.mLruBitmapCache = new LruBitmapCache();
        }
        return this.mLruBitmapCache;
    }

    public RequestQueue getRequestQueue() {
        if (this.mRequestQueue == null) {
            this.mRequestQueue = Volley.newRequestQueue((Context)this.getApplicationContext());
        }
        return this.mRequestQueue;
    }

    public void onCreate() {
        super.onCreate();
        mInstance = this;
    }
}

