/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  com.lock.fragment.SettingsFragment
 *  java.lang.Object
 */
package com.lock.fragment;

import android.content.DialogInterface;
import com.lock.fragment.SettingsFragment;

public final class SettingsFragment$$ExternalSyntheticLambda18
implements DialogInterface.OnClickListener {
    public final void onClick(DialogInterface dialogInterface, int n) {
        SettingsFragment.lambda$onClick$26((DialogInterface)dialogInterface, (int)n);
    }
}

