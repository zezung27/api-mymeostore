/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.WallpaperManager
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.location.LocationManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.provider.Settings
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.FrameLayout
 *  android.widget.ImageView
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.RadioGroup$OnCheckedChangeListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  android.widget.ToggleButton
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.request.target.CustomTarget
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.transition.Transition
 *  com.google.android.gms.ads.AdListener
 *  com.google.android.gms.ads.AdLoader
 *  com.google.android.gms.ads.AdLoader$Builder
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.LoadAdError
 *  com.google.android.gms.ads.VideoOptions
 *  com.google.android.gms.ads.VideoOptions$Builder
 *  com.google.android.gms.ads.nativead.NativeAd
 *  com.google.android.gms.ads.nativead.NativeAd$OnNativeAdLoadedListener
 *  com.google.android.gms.ads.nativead.NativeAdOptions
 *  com.google.android.gms.ads.nativead.NativeAdOptions$Builder
 *  com.google.android.gms.ads.nativead.NativeAdView
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.lock.fragment;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.lock.activites.AppsFilterListActivity;
import com.lock.activites.AppsListActivity;
import com.lock.activites.HelpActivity;
import com.lock.activites.HomeActivity;
import com.lock.activites.PrivacyPolicyActivity;
import com.lock.adaptar.NativeAdViewHolder;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.background.WallpapersCategoryActivity;
import com.lock.fragment.SettingsFragment;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda0;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda1;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda10;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda11;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda12;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda13;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda14;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda15;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda16;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda17;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda18;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda19;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda2;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda20;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda21;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda22;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda23;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda24;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda25;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda26;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda27;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda28;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda3;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda4;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda5;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda6;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda7;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda8;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda9;
import com.lock.utils.Constants;
import com.lock.utils.MySettings;
import com.lock.utils.RatingDialog;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerDialog;
import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.flag.BubbleFlag;
import com.skydoves.colorpickerview.flag.FlagView;
import com.skydoves.colorpickerview.listeners.ColorPickerViewListener;
import java.io.File;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SettingsFragment
extends Fragment
implements View.OnClickListener {
    View backgroung_rl;
    Context context;
    private ToggleButton enable_controls_gesture;
    LocationManager locationManager;
    private NativeAd mNativeAd;
    RelativeLayout more_rl;
    PrefManager prefManager;
    RelativeLayout rateus_rl;
    RelativeLayout share_rl;
    TextView textViewBackgroundGallery;
    private ToggleButton toggle_show_on_lock;
    TextView tv_more;
    TextView tv_rateus;
    private TextView tv_remove_ads;
    TextView tv_share;
    Typeface typefaceBold;
    private View viw;

    static /* synthetic */ View access$000(SettingsFragment settingsFragment) {
        return settingsFragment.viw;
    }

    static /* synthetic */ void access$100(SettingsFragment settingsFragment, View view) {
        settingsFragment.refreshNativeAd(view);
    }

    private void disableLockToggle() {
        MySettings.setLockscreen(false, this.context);
    }

    private void enableLockToggle() {
        MySettings.setLockscreen(true, this.context);
    }

    static /* synthetic */ void lambda$onClick$24(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
    }

    static /* synthetic */ void lambda$onClick$26(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
    }

    static /* synthetic */ void lambda$onClick$28(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
    }

    private void refreshNativeAd(final View view) {
        AdLoader.Builder builder = new AdLoader.Builder(this.context, this.getString(2131820588));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener(){

            public void onNativeAdLoaded(NativeAd nativeAd) {
                try {
                    if (SettingsFragment.this.mNativeAd != null) {
                        SettingsFragment.this.mNativeAd.destroy();
                    }
                    SettingsFragment.this.mNativeAd = nativeAd;
                    FrameLayout frameLayout = (FrameLayout)view.findViewById(2131296555);
                    NativeAdView nativeAdView = (NativeAdView)SettingsFragment.this.getLayoutInflater().inflate(2131492901, null);
                    Constants.populateNativeAdView(SettingsFragment.this.mNativeAd, new NativeAdViewHolder((View)nativeAdView).getAdView());
                    frameLayout.removeAllViews();
                    frameLayout.addView((View)nativeAdView);
                    view.findViewById(2131296673).setVisibility(0);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)SettingsFragment.this.context, (CharSequence)((Object)((Object)exception) + ""), (int)1).show();
                    return;
                }
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(videoOptions).build());
        builder.withAdListener(new AdListener(){

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                view.findViewById(2131296555).setVisibility(8);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    private void setEndColor(ColorEnvelope colorEnvelope) {
        ((ImageView)this.viw.findViewById(2131296644)).setColorFilter(colorEnvelope.getColor());
        new PrefManager((Context)this.getActivity()).setGradiantEndColor(colorEnvelope.getColor());
        if (Constants.getRatingDailoge(this.context)) {
            new RatingDialog((Activity)((HomeActivity)this.context)).showDialog();
        }
    }

    private void setLayoutColor(ColorEnvelope colorEnvelope) {
        ((ImageView)this.viw.findViewById(2131296649)).setColorFilter(colorEnvelope.getColor());
        new PrefManager((Context)this.getActivity()).setTitleColor(colorEnvelope.getColor());
        if (Constants.getRatingDailoge(this.context)) {
            new RatingDialog((Activity)((HomeActivity)this.context)).showDialog();
        }
    }

    private void setStartColor(ColorEnvelope colorEnvelope) {
        ((ImageView)this.viw.findViewById(2131296645)).setColorFilter(colorEnvelope.getColor());
        new PrefManager((Context)this.getActivity()).setGradiantStartColor(colorEnvelope.getColor());
        if (Constants.getRatingDailoge(this.context)) {
            new RatingDialog((Activity)((HomeActivity)this.context)).showDialog();
        }
    }

    private void showHelpScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), HelpActivity.class));
    }

    private void showPrivacyScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), PrivacyPolicyActivity.class));
    }

    public void getCustomAppBackground() {
        ImagePicker.with(this).crop().compress(1024).maxResultSize(1080, 1920).start();
    }

    /* synthetic */ void lambda$onClick$23$com-lock-fragment-SettingsFragment(ColorEnvelope colorEnvelope, boolean bl) {
        this.setLayoutColor(colorEnvelope);
    }

    /* synthetic */ void lambda$onClick$25$com-lock-fragment-SettingsFragment(ColorEnvelope colorEnvelope, boolean bl) {
        this.setStartColor(colorEnvelope);
    }

    /* synthetic */ void lambda$onClick$27$com-lock-fragment-SettingsFragment(ColorEnvelope colorEnvelope, boolean bl) {
        this.setEndColor(colorEnvelope);
    }

    /* synthetic */ void lambda$onViewCreated$0$com-lock-fragment-SettingsFragment(View view) {
        this.getCustomAppBackground();
    }

    /* synthetic */ void lambda$onViewCreated$1$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setControlEnabled(bl);
    }

    /* synthetic */ void lambda$onViewCreated$10$com-lock-fragment-SettingsFragment(View view) {
        this.shareLink("https://play.google.com/store/apps/details?id=" + this.context.getApplicationInfo().packageName);
    }

    /* synthetic */ void lambda$onViewCreated$11$com-lock-fragment-SettingsFragment(View view) {
        try {
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.context.getString(2131820583)))));
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.context.getString(2131820583)))));
            return;
        }
    }

    /* synthetic */ void lambda$onViewCreated$12$com-lock-fragment-SettingsFragment(View view) {
        this.startActivity(new Intent(this.context, WallpapersCategoryActivity.class));
    }

    /* synthetic */ void lambda$onViewCreated$13$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131297095) {
            this.prefManager.setCameraCount(0);
        }
        if (n == 2131296786) {
            this.prefManager.setCameraCount(1);
            return;
        }
        if (n == 2131297050) {
            this.prefManager.setCameraCount(2);
            return;
        }
        if (n == 2131296988) {
            this.prefManager.setCameraCount(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$14$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131296660) {
            this.prefManager.setCameraPos(1);
            return;
        }
        if (n == 2131296422) {
            this.prefManager.setCameraPos(2);
            return;
        }
        if (n == 2131296841) {
            this.prefManager.setCameraPos(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$15$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131296572)).getText().toString();
        if (Integer.parseInt((String)string) < 5) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131296572)).setText((CharSequence)(n + ""));
            this.prefManager.setGlowWidth(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$16$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131296572)).getText().toString();
        if (Integer.parseInt((String)string) > 1) {
            int n = Integer.parseInt((String)string) - 1;
            ((TextView)view.findViewById(2131296572)).setText((CharSequence)(n + ""));
            this.prefManager.setGlowWidth(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$17$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131296406)).getText().toString();
        if (Integer.parseInt((String)string) < 75) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131296406)).setText((CharSequence)(n + ""));
            this.prefManager.setCameraMargin(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$18$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131296406)).getText().toString();
        if (Integer.parseInt((String)string) >= 5) {
            int n = -1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131296406)).setText((CharSequence)(n + ""));
            this.prefManager.setCameraMargin(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$19$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131297094)).getText().toString();
        if (Integer.parseInt((String)string) < 20) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131297094)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$2$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setShowOnLock(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$20$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131297094)).getText().toString();
        if (Integer.parseInt((String)string) >= 1) {
            int n = Integer.parseInt((String)string) - 1;
            ((TextView)view.findViewById(2131297094)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$21$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131297091)).getText().toString();
        if (Integer.parseInt((String)string) < 40) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131297091)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$22$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131297091)).getText().toString();
        if (Integer.parseInt((String)string) >= 25) {
            int n = -1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131297091)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$3$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.SetShowInFullScreen(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$4$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.SetShowInLand(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$5$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setAutoCloseNoti(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$6$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setIphoneCall(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$7$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setGlow(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$8$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setMusicAnimation(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$9$com-lock-fragment-SettingsFragment(View view) {
        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("market://details?id=" + this.context.getPackageName()))));
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        String string;
        Uri uri;
        if (intent != null && (uri = intent.getData()) != null && new File(string = uri.getPath()).exists()) {
            Glide.with((Context)this.context).asBitmap().load(string).into((Target)new CustomTarget<Bitmap>(){

                public void onLoadCleared(Drawable drawable) {
                }

                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                    if (bitmap.getWidth() > 300) {
                        try {
                            WallpaperManager.getInstance((Context)SettingsFragment.this.context).setBitmap(bitmap);
                            ((Activity)SettingsFragment.this.context).runOnUiThread(new Runnable(this){
                                final /* synthetic */ 3 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void run() {
                                    Toast.makeText((Context)this.this$1.SettingsFragment.this.context, (CharSequence)this.this$1.SettingsFragment.this.context.getString(2131820906), (int)0).show();
                                }
                            });
                        }
                        catch (Exception exception) {
                            exception.printStackTrace();
                            ((Activity)SettingsFragment.this.context).runOnUiThread(new Runnable(this){
                                final /* synthetic */ 3 this$1;
                                {
                                    this.this$1 = var1_1;
                                }

                                public void run() {
                                    Toast.makeText((Context)this.this$1.SettingsFragment.this.context, (CharSequence)this.this$1.SettingsFragment.this.context.getString(2131820907), (int)0).show();
                                }
                            });
                        }
                        Utils.saveToInternalSorage((Context)SettingsFragment.this.getActivity(), bitmap);
                    }
                }
            });
        }
        if (n == 1133) {
            Uri uri2;
            String string2;
            if (intent != null && (uri2 = intent.getData()) != null && (string2 = Constants.getPathFromUri(this.context, uri2)) != null && new File(string2).exists()) {
                Glide.with((Context)this.context).asBitmap().load(string2).into((Target)new CustomTarget<Bitmap>(){

                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        Utils.saveImage(bitmap);
                    }
                });
                return;
            }
        } else if (n == 9 && Build.VERSION.SDK_INT >= 23) {
            if (Settings.canDrawOverlays((Context)this.context)) {
                this.enableLockToggle();
                return;
            }
            this.disableLockToggle();
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case 2131296846: {
                this.startActivity(new Intent(this.context, AppsListActivity.class));
                return;
            }
            case 2131296845: {
                this.startActivity(new Intent(this.context, AppsFilterListActivity.class));
                return;
            }
            case 2131296814: {
                this.showPrivacyScreen();
                return;
            }
            case 2131296645: {
                AlertDialog.Builder builder = new ColorPickerDialog.Builder(this.context).setTitle("Gradiant start color").setPositiveButton((CharSequence)this.getString(2131820644), (ColorPickerViewListener)new SettingsFragment$$ExternalSyntheticLambda17(this)).setNegativeButton(this.getString(2131820615), (DialogInterface.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda18());
                builder.getColorPickerView().setFlagView(new BubbleFlag(this.context));
                builder.show();
                return;
            }
            case 2131296644: {
                AlertDialog.Builder builder = new ColorPickerDialog.Builder(this.context).setTitle("Gradiant end color").setPositiveButton((CharSequence)this.getString(2131820644), (ColorPickerViewListener)new SettingsFragment$$ExternalSyntheticLambda19(this)).setNegativeButton(this.getString(2131820615), (DialogInterface.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda20());
                builder.getColorPickerView().setFlagView(new BubbleFlag(this.context));
                builder.show();
                return;
            }
            case 2131296594: {
                this.showHelpScreen();
                return;
            }
            case 2131296474: 
        }
        AlertDialog.Builder builder = new ColorPickerDialog.Builder(this.context).setTitle("Pick tiles color").setPositiveButton((CharSequence)this.getString(2131820644), (ColorPickerViewListener)new SettingsFragment$$ExternalSyntheticLambda15(this)).setNegativeButton(this.getString(2131820615), (DialogInterface.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda16());
        builder.getColorPickerView().setFlagView(new BubbleFlag(this.context));
        builder.show();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(2131492933, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        RelativeLayout relativeLayout;
        ToggleButton toggleButton;
        TextView textView;
        RelativeLayout relativeLayout2;
        ToggleButton toggleButton2;
        int n;
        RelativeLayout relativeLayout3;
        super.onViewCreated(view, bundle);
        this.context = this.getActivity();
        this.prefManager = new PrefManager(this.context);
        this.textViewBackgroundGallery = (TextView)view.findViewById(2131296971);
        this.viw = view;
        this.typefaceBold = Typeface.createFromAsset((AssetManager)this.context.getAssets(), (String)"roboto_medium.ttf");
        view.findViewById(2131296594).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131296814).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131296474).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131296846).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131296845).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131296471).setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda0(this));
        this.enable_controls_gesture = toggleButton = (ToggleButton)view.findViewById(2131296530);
        toggleButton.setChecked(this.prefManager.getControlEnabled());
        this.enable_controls_gesture.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda2(this));
        this.toggle_show_on_lock = toggleButton2 = (ToggleButton)view.findViewById(2131297005);
        toggleButton2.setChecked(this.prefManager.getShowOnLock(this.context));
        this.toggle_show_on_lock.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda6(this));
        ToggleButton toggleButton3 = (ToggleButton)view.findViewById(2131297000);
        toggleButton3.setChecked(this.prefManager.getShowInFullScreen(this.context));
        toggleButton3.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda7(this));
        ToggleButton toggleButton4 = (ToggleButton)view.findViewById(2131297001);
        toggleButton4.setChecked(this.prefManager.gethideInLand(this.context));
        toggleButton4.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda8(this));
        ToggleButton toggleButton5 = (ToggleButton)view.findViewById(2131296997);
        toggleButton5.setChecked(this.prefManager.getAutoCloseNoti(this.context));
        toggleButton5.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda9(this));
        ToggleButton toggleButton6 = (ToggleButton)view.findViewById(2131297002);
        toggleButton6.setChecked(this.prefManager.getIphoneCall(this.context));
        toggleButton6.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda10(this));
        ToggleButton toggleButton7 = (ToggleButton)view.findViewById(2131296577);
        toggleButton7.setChecked(this.prefManager.getGlow(this.context));
        toggleButton7.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda12(this));
        ToggleButton toggleButton8 = (ToggleButton)view.findViewById(2131297004);
        toggleButton8.setChecked(this.prefManager.getMusicAnimation(this.context));
        toggleButton8.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda13(this));
        ((ImageView)view.findViewById(2131296649)).setColorFilter(this.prefManager.getTitleColor());
        ((ImageView)view.findViewById(2131296645)).setColorFilter(this.prefManager.getGradiantStartColor());
        view.findViewById(2131296645).setOnClickListener((View.OnClickListener)this);
        ((ImageView)view.findViewById(2131296644)).setColorFilter(this.prefManager.getGradiantEndColor());
        view.findViewById(2131296644).setOnClickListener((View.OnClickListener)this);
        this.locationManager = (LocationManager)this.context.getSystemService("location");
        this.backgroung_rl = view.findViewById(2131296416);
        this.tv_remove_ads = textView = (TextView)view.findViewById(2131297044);
        textView.setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297049)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296472)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296972)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297047)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297036)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296593)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296411)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296412)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297011)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297010)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297094)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297091)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297024)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297045)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297021)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297038)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297037)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296402)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296406)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297035)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297032)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297033)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131297034)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296749)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296573)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131296572)).setTypeface(this.typefaceBold);
        this.tv_rateus = (TextView)view.findViewById(2131297043);
        this.tv_more = (TextView)view.findViewById(2131297040);
        this.tv_share = (TextView)view.findViewById(2131297046);
        this.rateus_rl = relativeLayout2 = (RelativeLayout)view.findViewById(2131296824);
        relativeLayout2.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda14(this));
        this.share_rl = relativeLayout = (RelativeLayout)view.findViewById(2131296890);
        relativeLayout.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda11(this));
        this.more_rl = relativeLayout3 = (RelativeLayout)view.findViewById(2131296722);
        relativeLayout3.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda21(this));
        this.tv_share.setTypeface(this.typefaceBold);
        this.tv_rateus.setTypeface(this.typefaceBold);
        this.tv_more.setTypeface(this.typefaceBold);
        this.textViewBackgroundGallery.setTypeface(this.typefaceBold);
        this.backgroung_rl.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda22(this));
        ((RelativeLayout)view.findViewById(2131296835)).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                ((HomeActivity)this.this$0.context).onRemoveAdButtonClicked();
            }
        });
        this.enable_controls_gesture.postDelayed(new Runnable(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            /*
             * Exception decompiling
             */
            public void run(}
        java.lang.IllegalStateException: Parameters not created
        
        