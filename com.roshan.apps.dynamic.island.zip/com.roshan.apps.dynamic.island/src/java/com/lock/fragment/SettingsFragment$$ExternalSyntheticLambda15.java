/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.lock.fragment;

import com.lock.fragment.SettingsFragment;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.listeners.ColorEnvelopeListener;

public final class SettingsFragment$$ExternalSyntheticLambda15
implements ColorEnvelopeListener {
    public final /* synthetic */ SettingsFragment f$0;

    public /* synthetic */ SettingsFragment$$ExternalSyntheticLambda15(SettingsFragment settingsFragment) {
        this.f$0 = settingsFragment;
    }

    @Override
    public final void onColorSelected(ColorEnvelope colorEnvelope, boolean bl) {
        this.f$0.lambda$onClick$23$com-lock-fragment-SettingsFragment(colorEnvelope, bl);
    }
}

