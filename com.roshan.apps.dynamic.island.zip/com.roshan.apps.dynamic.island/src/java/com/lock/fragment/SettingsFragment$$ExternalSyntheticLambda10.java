/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  com.lock.fragment.SettingsFragment
 *  java.lang.Object
 */
package com.lock.fragment;

import android.widget.CompoundButton;
import com.lock.fragment.SettingsFragment;

public final class SettingsFragment$$ExternalSyntheticLambda10
implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ SettingsFragment f$0;

    public /* synthetic */ SettingsFragment$$ExternalSyntheticLambda10(SettingsFragment settingsFragment) {
        this.f$0 = settingsFragment;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
        this.f$0.lambda$onViewCreated$6$com-lock-fragment-SettingsFragment(compoundButton, bl);
    }
}

