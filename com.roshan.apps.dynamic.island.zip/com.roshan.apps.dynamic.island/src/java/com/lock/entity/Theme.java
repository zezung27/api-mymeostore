/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.lock.entity;

import com.lock.entity.ThemeData;
import java.io.Serializable;
import java.util.ArrayList;

public class Theme
implements Serializable {
    ArrayList<ThemeData> appThems;

    public ArrayList<ThemeData> getAppThems() {
        return this.appThems;
    }

    public void setAppThems(ArrayList<ThemeData> arrayList) {
        this.appThems = arrayList;
    }
}

