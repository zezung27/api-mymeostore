/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class AppDetail
implements Parcelable {
    public static final Parcelable.Creator<AppDetail> CREATOR = new Parcelable.Creator<AppDetail>(){

        public AppDetail createFromParcel(Parcel parcel) {
            return new AppDetail(parcel);
        }

        public AppDetail[] newArray(int n) {
            return new AppDetail[n];
        }
    };
    public String activityInfoName;
    public int image;
    public boolean isCurrentUser;
    public boolean isSelected = false;
    public boolean isSorted;
    public String label;
    public String pkg;

    public AppDetail() {
        this.isCurrentUser = true;
    }

    public AppDetail(long l, String string2, String string3, String string4, String string5, boolean bl, boolean bl2, boolean bl3) {
        this.label = string3;
        this.pkg = string4;
        this.activityInfoName = string5;
        this.isCurrentUser = bl3;
    }

    private AppDetail(Parcel parcel) {
        this.isCurrentUser = true;
        this.label = parcel.readString();
        this.pkg = parcel.readString();
        this.activityInfoName = parcel.readString();
        this.image = parcel.readInt();
        boolean bl = parcel.readByte() != 0;
        this.isSorted = bl;
        boolean bl2 = parcel.readByte() != 0;
        this.isSelected = bl2;
        byte by = parcel.readByte();
        boolean bl3 = false;
        if (by != 0) {
            bl3 = true;
        }
        this.isCurrentUser = bl3;
    }

    public AppDetail(String string2, String string3, String string4, String string5, boolean bl, boolean bl2) {
        this.label = string3;
        this.pkg = string4;
        this.activityInfoName = string5;
        this.isCurrentUser = bl2;
    }

    public AppDetail(String string2, String string3, String string4, String string5, boolean bl, boolean bl2, int n) {
        this.pkg = string2;
        this.label = string3;
        this.activityInfoName = string4;
        this.isCurrentUser = bl;
        this.image = n;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int n) {
        parcel.writeString(this.label);
        parcel.writeString(this.pkg);
        parcel.writeString(this.activityInfoName);
        parcel.writeInt(this.image);
        parcel.writeByte((byte)(this.isSorted ? 1 : 0));
        parcel.writeByte((byte)(this.isSelected ? 1 : 0));
        parcel.writeByte((byte)(this.isCurrentUser ? 1 : 0));
    }

}

