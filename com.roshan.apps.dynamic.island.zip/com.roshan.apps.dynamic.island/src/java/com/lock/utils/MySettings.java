/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.preference.PreferenceManager
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class MySettings {
    public static final String USING = "USING";

    public static boolean getDemo(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(USING, false);
    }

    public static boolean getLockscreen(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean("Lockscreen", false);
    }

    public static SharedPreferences setDemo(Context context, boolean bl) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)context);
        sharedPreferences.edit().putBoolean(USING, bl).apply();
        return sharedPreferences;
    }

    public static void setLockscreen(boolean bl, Context context) {
        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences((Context)context).edit();
        editor.putBoolean("Lockscreen", bl);
        editor.commit();
    }
}

