/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.util.Log
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Type
 *  org.xmlpull.v1.XmlPullParser
 */
package com.lock.utils;

import android.os.Bundle;
import android.util.Log;
import java.lang.reflect.Type;
import org.xmlpull.v1.XmlPullParser;

public class MyStringBuilder {
    public static StringBuilder A(String string2, String string3, String string4) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        return stringBuilder;
    }

    public static StringBuilder B(String string2, String string3, String string4) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        return stringBuilder;
    }

    public static void E(StringBuilder stringBuilder, String string2, char c2, String string3) {
        stringBuilder.append(string2);
        stringBuilder.append(c2);
        stringBuilder.append(string3);
    }

    public static void F(StringBuilder stringBuilder, String string2, long l, String string3) {
        stringBuilder.append(string2);
        stringBuilder.append(l);
        stringBuilder.append(string3);
    }

    public static void G(StringBuilder stringBuilder, String string2, String string3, String string4) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
    }

    public static void H(StringBuilder stringBuilder, String string2, String string3, String string4, String string5) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        stringBuilder.append(string5);
    }

    public static Bundle I(String string2, String string3) {
        Bundle bundle = new Bundle();
        bundle.putString(string2, string3);
        return bundle;
    }

    public static void J(StringBuilder stringBuilder, String string2, String string3, String string4, String string5) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        Log.w((String)string5, (String)stringBuilder.toString());
    }

    public static String O(int n, String string2, int n2) {
        StringBuilder stringBuilder = new StringBuilder(n);
        stringBuilder.append(string2);
        stringBuilder.append(n2);
        return stringBuilder.toString();
    }

    public static String P(int n, String string2, int n2, String string3, int n3) {
        StringBuilder stringBuilder = new StringBuilder(n);
        stringBuilder.append(string2);
        stringBuilder.append(n2);
        stringBuilder.append(string3);
        stringBuilder.append(n3);
        return stringBuilder.toString();
    }

    public static float a(float f, float f2, float f3, float f4) {
        return f4 + f3 * (f - f2);
    }

    public static int b(float f, float f2, float f3) {
        return Math.round((float)(f3 * (f + f2)));
    }

    public static String d(Class class_, StringBuilder stringBuilder, String string2, String string3) {
        stringBuilder.append(class_.getSimpleName());
        stringBuilder.append(string2);
        stringBuilder.append(class_.getSimpleName());
        stringBuilder.append(string3);
        return stringBuilder.toString();
    }

    public static String e(String string2) {
        return string2;
    }

    public static String f(String string2, int n) {
        return string2 + n;
    }

    public static String g(String string2, int n, String string3) {
        return string2 + n + string3;
    }

    public static String i(String string2, Object object) {
        return string2 + object;
    }

    public static String j(String string2, String string3) {
        return string2 + string3;
    }

    public static String k(String string2, String string3, String string4) {
        return string2 + string3 + string4;
    }

    public static String l(String string2, Type type) {
        return string2 + (Object)type;
    }

    public static int m(int n, int n2, int n3, int n4) {
        return n4 + (n3 + (n + n2));
    }

    public static String o(StringBuilder stringBuilder, int n, String string2) {
        stringBuilder.append(n);
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static String p(StringBuilder stringBuilder, long l, String string2) {
        stringBuilder.append(l);
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static String q(StringBuilder stringBuilder, String string2, String string3) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        return stringBuilder.toString();
    }

    public static String r(StringBuilder stringBuilder, String string2, String string3, String string4) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        return stringBuilder.toString();
    }

    public static String s(StringBuilder stringBuilder, String string2, String string3, String string4, String string5) {
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        stringBuilder.append(string4);
        stringBuilder.append(string5);
        return stringBuilder.toString();
    }

    public static String u(XmlPullParser xmlPullParser, StringBuilder stringBuilder, String string2) {
        stringBuilder.append(xmlPullParser.getPositionDescription());
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static StringBuilder v(int n, String string2) {
        StringBuilder stringBuilder = new StringBuilder(n);
        stringBuilder.append(string2);
        return stringBuilder;
    }

    public static StringBuilder w(String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        return stringBuilder;
    }

    public static int x(int n, int n2, int n3, int n4) {
        return n4 + n * n2 / n3;
    }

    public static StringBuilder y(String string2, int n, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(n);
        stringBuilder.append(string3);
        return stringBuilder;
    }

    public static StringBuilder z(String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        return stringBuilder;
    }
}

