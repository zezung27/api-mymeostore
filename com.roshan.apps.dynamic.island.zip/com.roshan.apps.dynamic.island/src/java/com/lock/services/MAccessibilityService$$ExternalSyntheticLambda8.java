/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.services;

import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda8
implements Runnable {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda8(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void run() {
        this.f$0.lambda$closeFullNotificationIsland$8$com-lock-services-MAccessibilityService();
    }
}

