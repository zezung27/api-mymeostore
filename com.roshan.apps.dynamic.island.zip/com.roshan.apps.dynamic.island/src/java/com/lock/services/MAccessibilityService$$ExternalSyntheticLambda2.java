/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.lock.services;

import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda2
implements Runnable {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda2(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void run() {
        this.f$0.lambda$onServiceConnected$0$com-lock-services-MAccessibilityService();
    }
}

