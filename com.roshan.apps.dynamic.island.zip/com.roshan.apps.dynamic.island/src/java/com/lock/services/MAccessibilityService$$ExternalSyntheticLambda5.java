/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.lock.services;

import android.view.View;
import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda5
implements View.OnClickListener {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda5(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void onClick(View view) {
        this.f$0.lambda$onServiceConnected$3$com-lock-services-MAccessibilityService(view);
    }
}

