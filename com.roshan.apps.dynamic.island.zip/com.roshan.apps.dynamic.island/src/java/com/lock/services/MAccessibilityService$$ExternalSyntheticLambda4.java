/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnSystemUiVisibilityChangeListener
 *  java.lang.Object
 */
package com.lock.services;

import android.view.View;
import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda4
implements View.OnSystemUiVisibilityChangeListener {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda4(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void onSystemUiVisibilityChange(int n) {
        this.f$0.lambda$onServiceConnected$2$com-lock-services-MAccessibilityService(n);
    }
}

