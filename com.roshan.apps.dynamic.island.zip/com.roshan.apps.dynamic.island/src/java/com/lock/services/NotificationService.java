/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.PendingIntent
 *  android.app.RemoteInput
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Icon
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.service.notification.NotificationListenerService
 *  android.service.notification.NotificationListenerService$RankingMap
 *  android.service.notification.StatusBarNotification
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.Display
 *  android.view.WindowManager
 *  androidx.core.content.ContextCompat
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  java.io.ByteArrayOutputStream
 *  java.io.OutputStream
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.Runnable
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 */
package com.lock.services;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.lock.services.ActionParsable;
import com.lock.services.NotificationService$$ExternalSyntheticLambda0;
import com.lock.services.NotificationService$$ExternalSyntheticLambda1;
import com.lock.services.NotificationService$$ExternalSyntheticLambda2;
import com.lock.utils.Constants;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class NotificationService
extends NotificationListenerService {
    static NotificationService notificationService;
    Context context;
    Handler handler = new Handler();

    private byte[] getByteArrayFromBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, (OutputStream)byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        }
        return null;
    }

    private byte[] getByteArrayFromBitmap2(Bitmap bitmap) {
        if (bitmap != null) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, (OutputStream)byteArrayOutputStream);
            return byteArrayOutputStream.toByteArray();
        }
        return null;
    }

    private Bitmap getCroppedBitmap(Drawable drawable2) {
        void var2_11;
        try {
            Display display = ((WindowManager)this.getSystemService("window")).getDefaultDisplay();
            DisplayMetrics displayMetrics = new DisplayMetrics();
            display.getRealMetrics(displayMetrics);
            int n = displayMetrics.widthPixels;
            int n2 = displayMetrics.heightPixels;
            Bitmap bitmap = Bitmap.createBitmap((int)drawable2.getIntrinsicWidth(), (int)drawable2.getIntrinsicHeight(), (Bitmap.Config)Bitmap.Config.ARGB_4444);
            Canvas canvas = new Canvas(bitmap);
            drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable2.draw(canvas);
            if (bitmap.getWidth() > n && bitmap.getHeight() > n2) {
                return this.scaleDownImage(bitmap, n, n2);
            }
            Bitmap bitmap2 = this.scaleUpImage(bitmap, n, n2);
            return bitmap2;
        }
        catch (Exception exception) {
        }
        catch (OutOfMemoryError outOfMemoryError) {
            // empty catch block
        }
        var2_11.printStackTrace();
        return null;
    }

    public static NotificationService getInstance() {
        return notificationService;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static ArrayList<ActionParsable> getParsableActions(Notification.Action[] var0) {
        var1_1 = new ArrayList(3);
        var2_2 = var0.length;
        var3_3 = 0;
        var4_4 = false;
        var5_5 = false;
        while (var3_3 < var2_2) {
            block11 : {
                var6_6 = var0[var3_3];
                var7_7 = Build.VERSION.SDK_INT;
                if (var7_7 >= 24 && var6_6 != null) {
                    var4_4 = var6_6.getAllowGeneratedReplies();
                } else if (var6_6 != null) {
                    try {
                        var4_4 = var6_6.getExtras().getBoolean("android.support.allowGeneratedReplies");
                    }
                    catch (Exception var19_17) {
                        var19_17.printStackTrace();
                    }
                } else {
                    var4_4 = false;
                }
                if (var7_7 < 28 || var6_6 == null) break block11;
                var18_16 = var6_6.getSemanticAction();
                ** GOTO lbl26
            }
            if (var6_6 != null) {
                var18_16 = var6_6.getExtras().getInt("android.support.action.semanticAction", 0);
lbl26: // 2 sources:
                var8_8 = var18_16;
            } else {
                var8_8 = 0;
            }
            if (var6_6 != null) {
                var9_9 = var6_6.icon;
                var10_10 = var6_6.title;
                var11_11 = var6_6.actionIntent;
                var12_12 = var6_6.getExtras();
                var13_13 = var6_6.getRemoteInputs();
                if (Build.VERSION.SDK_INT >= 29) {
                    var5_5 = var6_6.isContextual();
                    var16_15 = new ActionParsable(var10_10, var11_11, var12_12, var13_13, var4_4, var8_8, var5_5, var9_9);
                    var1_1.add((Object)var16_15);
                    ++var3_3;
                    continue;
                }
                var14_14 = new ActionParsable(var10_10, var11_11, var12_12, var13_13, var4_4, var8_8, var5_5, var9_9);
                var1_1.add((Object)var14_14);
            }
            ++var3_3;
        }
        return var1_1;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private Bitmap scaleDownImage(Bitmap bitmap, int n, int n2) {
        float f = bitmap.getWidth();
        float f2 = bitmap.getHeight();
        {
            catch (OutOfMemoryError outOfMemoryError) {
                outOfMemoryError.printStackTrace();
                return null;
            }
        }
        float f3 = n;
        if (!(f > f3)) return bitmap;
        float f4 = f / f2;
        float f5 = n2;
        float f6 = f3 / f5;
        if (f2 > f) {
            if (f6 > 1.0f) {
                f3 = (int)(f4 * f5);
                return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)((int)f3), (int)((int)f5), (boolean)true);
            } else {
                f5 = (int)(f3 / f4);
                return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)((int)f3), (int)((int)f5), (boolean)true);
            }
        }
        if (f6 < 1.0f) {
            f5 = (int)(f4 * f3);
        } else {
            f3 = (int)(f5 / f4);
        }
        float f7 = f5;
        f5 = f3;
        f3 = f7;
        return Bitmap.createScaledBitmap((Bitmap)bitmap, (int)((int)f3), (int)((int)f5), (boolean)true);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private Bitmap scaleUpImage(Bitmap bitmap, int n, int n2) {
        block4 : {
            Bitmap bitmap2;
            block3 : {
                try {
                    float f = bitmap.getWidth();
                    if (bitmap.getWidth() > n) {
                        bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)((int)(f / 2.0f - (float)(n / 2))), (int)0, (int)n, (int)bitmap.getHeight());
                        bitmap.recycle();
                        break block3;
                    }
                    if (bitmap.getHeight() <= n2) break block4;
                    bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)bitmap.getWidth(), (int)n2);
                    bitmap.recycle();
                }
                catch (OutOfMemoryError outOfMemoryError) {
                    outOfMemoryError.printStackTrace();
                    return null;
                }
            }
            bitmap = bitmap2;
        }
        Bitmap bitmap3 = null;
        if (bitmap == null) return bitmap3;
        Bitmap bitmap4 = bitmap.getWidth() <= n ? Bitmap.createScaledBitmap((Bitmap)bitmap, (int)n, (int)((int)((float)bitmap.getHeight() / (float)bitmap.getWidth() * (float)n)), (boolean)true) : (bitmap.getHeight() < n2 ? Bitmap.createScaledBitmap((Bitmap)bitmap, (int)((int)((float)bitmap.getHeight() / (float)bitmap.getWidth() * (float)n2)), (int)n2, (boolean)true) : null);
        bitmap.recycle();
        return bitmap4;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private void sendNotification(StatusBarNotification statusBarNotification, boolean bl) {
        Bitmap bitmap;
        Bitmap bitmap2;
        boolean bl4;
        String string10;
        String string4;
        String string7;
        String string6;
        String string5;
        String string8;
        String string9;
        Bitmap bitmap3;
        int n;
        String string2;
        String string11;
        boolean bl3;
        boolean bl2;
        String string14;
        String string12;
        int n2;
        String string15;
        String string3;
        String string13;
        block24 : {
            block26 : {
                void var26_50;
                block25 : {
                    String string16;
                    block23 : {
                        String string18;
                        String string17;
                        try {
                            string17 = (String)this.getPackageManager().getApplicationLabel(this.getPackageManager().getApplicationInfo(statusBarNotification.getPackageName(), 128));
                        }
                        catch (PackageManager.NameNotFoundException nameNotFoundException) {
                            nameNotFoundException.printStackTrace();
                            string17 = "";
                        }
                        if (statusBarNotification.getNotification() == null) return;
                        string4 = statusBarNotification.getPackageName();
                        string8 = statusBarNotification.getNotification().category != null ? statusBarNotification.getNotification().category : "";
                        string13 = statusBarNotification.getNotification().tickerText != null ? statusBarNotification.getNotification().tickerText.toString() : null;
                        bitmap = Build.VERSION.SDK_INT >= 23 && statusBarNotification.getNotification().getLargeIcon() != null ? this.drawableToBmp(this.context, statusBarNotification.getNotification().getLargeIcon().loadDrawable(this.context), 50) : null;
                        if (statusBarNotification.getNotification().extras != null) {
                            Bundle bundle = statusBarNotification.getNotification().extras;
                            if (bundle.containsKey("android.template") && bundle.get("android.template") != null) {
                                string10 = statusBarNotification.getNotification().extras.get("android.template").toString();
                                if (!TextUtils.isEmpty((CharSequence)string10)) {
                                    string10 = string10.substring(1 + string10.indexOf("$"));
                                }
                            } else {
                                string10 = "";
                            }
                            String string19 = bundle.containsKey("android.infoText") && bundle.getString("android.infoText") != null ? bundle.getString("android.infoText", "") : "";
                            String string20 = bundle.containsKey("android.title") && bundle.getCharSequence("android.title") != null ? bundle.getCharSequence("android.title", (CharSequence)"") : "";
                            int n3 = bundle.containsKey("android.progressMax") ? bundle.getInt("android.progressMax", 0) : 0;
                            int n4 = bundle.containsKey("android.progress") ? bundle.getInt("android.progress", 0) : 0;
                            boolean bl5 = bundle.containsKey("android.progressIndeterminate") ? bundle.getBoolean("android.progressIndeterminate", false) : false;
                            boolean bl6 = bundle.containsKey("android.showChronometer") ? bundle.getBoolean("android.showChronometer", false) : false;
                            String string21 = bundle.containsKey("android.summaryText") && bundle.getCharSequence("android.summaryText") != null ? bundle.getCharSequence("android.summaryText", (CharSequence)"") : "";
                            boolean bl7 = bl5;
                            String string22 = bundle.containsKey("android.title.big") && bundle.getCharSequence("android.title.big") != null ? bundle.getCharSequence("android.title.big", (CharSequence)"") : "";
                            String string23 = bundle.containsKey("android.substName") && bundle.getString("android.substName") != null ? bundle.getString("android.substName", "") : "";
                            String string24 = bundle.containsKey("android.subText") && bundle.getCharSequence("android.subText") != null ? bundle.getCharSequence("android.subText", (CharSequence)"") : "";
                            String string25 = bundle.containsKey("android.text") && bundle.getCharSequence("android.text") != null ? bundle.getCharSequence("android.text", (CharSequence)"") : "";
                            String string26 = bundle.containsKey("android.bigText") && bundle.getCharSequence("android.bigText") != null ? bundle.getCharSequence("android.bigText", (CharSequence)"") : "";
                            int n5 = Build.VERSION.SDK_INT;
                            boolean bl8 = bl6;
                            if (n5 >= 24 && bundle.containsKey("android.conversationTitle")) {
                                string17 = string17 + " . " + (Object)bundle.getCharSequence("android.conversationTitle", (CharSequence)"");
                            }
                            if (Build.VERSION.SDK_INT >= 28 && bundle.containsKey("android.isGroupConversation")) {
                                bl3 = bundle.getBoolean("android.isGroupConversation", false);
                                n2 = n3;
                                n = n4;
                                bl4 = bl7;
                                string2 = string23;
                                string12 = string25;
                                string9 = string26;
                                bl2 = bl8;
                                string11 = string17;
                            } else {
                                string11 = string17;
                                bl3 = false;
                                n2 = n3;
                                n = n4;
                                bl4 = bl7;
                                string2 = string23;
                                string12 = string25;
                                string9 = string26;
                                bl2 = bl8;
                            }
                            string18 = string19;
                            string3 = string20;
                            string15 = string22;
                            string16 = string21;
                            string5 = string24;
                        } else {
                            string12 = string3 = (string18 = (string16 = (string15 = (string10 = (string5 = (string2 = (string9 = "")))))));
                            bl3 = false;
                            bl4 = false;
                            bl2 = false;
                            n2 = 0;
                            n = 0;
                            string11 = string17;
                        }
                        string7 = String.valueOf((int)statusBarNotification.getId());
                        string14 = string18;
                        Drawable drawable2 = ContextCompat.getDrawable((Context)this.createPackageContext(string4, 0), (int)statusBarNotification.getNotification().icon);
                        if (drawable2 == null) break block23;
                        string6 = string16;
                        try {
                            Bitmap bitmap4;
                            bitmap2 = bitmap4 = this.drawableToBmp(null, drawable2, 20);
                            break block24;
                        }
                        catch (OutOfMemoryError outOfMemoryError) {
                            break block25;
                        }
                        catch (Exception exception) {
                            break block25;
                        }
                    }
                    string6 = string16;
                    break block26;
                    catch (OutOfMemoryError outOfMemoryError) {
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                    string6 = string16;
                }
                var26_50.printStackTrace();
            }
            bitmap2 = null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        Bitmap bitmap5 = bitmap2;
        Intent intent = new Intent(stringBuilder.append("from_notification_service").append(this.context.getPackageName()).toString());
        intent.putExtra("isGroupConversation", bl3);
        if (Build.VERSION.SDK_INT >= 30) {
            intent.putExtra("isAppGroup", statusBarNotification.isAppGroup());
        }
        if (Build.VERSION.SDK_INT >= 24) {
            intent.putExtra("isGroup", statusBarNotification.isGroup());
        }
        intent.putExtra("isOngoing", statusBarNotification.isOngoing());
        intent.putExtra("tag", statusBarNotification.getTag());
        if (Build.VERSION.SDK_INT >= 29) {
            intent.putExtra("uId", statusBarNotification.getUid());
        }
        intent.putExtra("category", string8);
        intent.putExtra("template", string10);
        intent.putExtra("group_key", statusBarNotification.getGroupKey());
        intent.putExtra("key", statusBarNotification.getKey());
        intent.putExtra("id", string7);
        intent.putExtra("package", string4);
        intent.putExtra("ticker", string13);
        intent.putExtra("appName", string11);
        intent.putExtra("title", (CharSequence)string3);
        intent.putExtra("isAdded", bl);
        intent.putExtra("postTime", statusBarNotification.getNotification().when);
        intent.putExtra("text", (CharSequence)string12);
        intent.putExtra("bigText", (CharSequence)string9);
        intent.putExtra("isClearable", statusBarNotification.isClearable());
        intent.putExtra("color", statusBarNotification.getNotification().color);
        intent.putExtra("largeIcon", this.getByteArrayFromBitmap(bitmap));
        intent.putExtra("substName", (CharSequence)string2);
        intent.putExtra("subText", (CharSequence)string5);
        intent.putExtra("titleBig", (CharSequence)string15);
        intent.putExtra("summaryText", (CharSequence)string6);
        intent.putExtra("info_text", (CharSequence)string14);
        intent.putExtra("progressMax", n2);
        intent.putExtra("progress", n);
        intent.putExtra("progressIndeterminate", bl4);
        intent.putExtra("showChronometer", bl2);
        if (statusBarNotification.getNotification().extras.get("android.picture") != null && (bitmap3 = (Bitmap)statusBarNotification.getNotification().extras.getParcelable("android.picture")) != null) {
            intent.putExtra("picture", this.getByteArrayFromBitmap2(bitmap3));
        }
        if (bitmap5 == null) {
            intent.putExtra("icon", this.getByteArrayFromBitmap(this.drawableToBmp(null, ContextCompat.getDrawable((Context)this.context, (int)2131165301), 20)));
        } else {
            intent.putExtra("icon", this.getByteArrayFromBitmap(bitmap5));
        }
        intent.putExtra("pendingIntent", (Parcelable)statusBarNotification.getNotification().contentIntent);
        if (statusBarNotification.getNotification().actions != null && statusBarNotification.getNotification().actions.length > 0) {
            intent.putExtra("actions", NotificationService.getParsableActions(statusBarNotification.getNotification().actions));
        }
        LocalBroadcastManager.getInstance((Context)this.context).sendBroadcast(intent);
    }

    public void cancelNotificationById(String string2) {
        try {
            this.cancelNotification(string2);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public void cancelNotifications() {
        try {
            this.cancelAllNotifications();
            return;
        }
        catch (SecurityException securityException) {
            securityException.printStackTrace();
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public Bitmap drawableToBmp(Context context, Drawable drawable2, int n) {
        Bitmap bitmap;
        if (drawable2 == null) return null;
        if (drawable2.getIntrinsicWidth() > 0 && drawable2.getIntrinsicHeight() > 0) {
            if (n <= 0) return this.getCroppedBitmap(drawable2);
            int n2 = (int)Constants.convertDpToPixel(n, context);
            bitmap = Bitmap.createBitmap((int)n2, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_4444);
        } else {
            bitmap = Bitmap.createBitmap((int)1, (int)1, (Bitmap.Config)Bitmap.Config.ARGB_4444);
        }
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable2.draw(canvas);
        return bitmap;
    }

    /* synthetic */ void lambda$onNotificationPosted$0$com-lock-services-NotificationService(StatusBarNotification statusBarNotification) {
        this.sendNotification(statusBarNotification, true);
    }

    /* synthetic */ void lambda$onNotificationPosted$1$com-lock-services-NotificationService(StatusBarNotification statusBarNotification) {
        this.sendNotification(statusBarNotification, true);
    }

    /* synthetic */ void lambda$onNotificationRemoved$2$com-lock-services-NotificationService(StatusBarNotification statusBarNotification) {
        this.sendNotification(statusBarNotification, false);
    }

    public void onCreate() {
        super.onCreate();
        this.context = this.getApplicationContext();
        notificationService = this;
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        NotificationListenerService.requestRebind((ComponentName)new ComponentName((Context)this, NotificationListenerService.class));
    }

    public void onNotificationPosted(StatusBarNotification statusBarNotification) {
        super.onNotificationPosted(statusBarNotification);
        this.handler.postDelayed((Runnable)new NotificationService$$ExternalSyntheticLambda2(this, statusBarNotification), 100L);
    }

    public void onNotificationPosted(StatusBarNotification statusBarNotification, NotificationListenerService.RankingMap rankingMap) {
        super.onNotificationPosted(statusBarNotification, rankingMap);
        this.handler.postDelayed((Runnable)new NotificationService$$ExternalSyntheticLambda1(this, statusBarNotification), 100L);
    }

    public void onNotificationRemoved(StatusBarNotification statusBarNotification) {
        Log.i((String)"Msg", (String)"Notification Removed");
        this.handler.postDelayed((Runnable)new NotificationService$$ExternalSyntheticLambda0(this, statusBarNotification), 100L);
    }
}

