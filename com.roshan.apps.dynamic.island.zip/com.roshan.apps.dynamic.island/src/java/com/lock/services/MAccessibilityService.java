/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.accessibilityservice.AccessibilityService
 *  android.accessibilityservice.AccessibilityService$GestureResultCallback
 *  android.accessibilityservice.GestureDescription
 *  android.accessibilityservice.GestureDescription$Builder
 *  android.accessibilityservice.GestureDescription$StrokeDescription
 *  android.app.KeyguardManager
 *  android.app.PendingIntent
 *  android.bluetooth.BluetoothDevice
 *  android.content.BroadcastReceiver
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.database.ContentObserver
 *  android.graphics.Bitmap
 *  android.graphics.Color
 *  android.graphics.Path
 *  android.graphics.drawable.AnimationDrawable
 *  android.graphics.drawable.Drawable
 *  android.media.session.MediaSessionManager
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Parcelable
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.accessibility.AccessibilityEvent
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.Toast
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.res.ResourcesCompat
 *  androidx.core.graphics.ColorUtils
 *  androidx.localbroadcastmanager.content.LocalBroadcastManager
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.PagerSnapHelper
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ItemDecoration
 *  androidx.recyclerview.widget.RecyclerView$LayoutManager
 *  androidx.recyclerview.widget.RecyclerView$OnScrollListener
 *  com.lock.adaptar.CustomNotificationAdapter
 *  com.lock.adaptar.CustomNotificationIconAdapter
 *  com.lock.services.MAccessibilityService$10
 *  com.lock.services.MAccessibilityService$8
 *  com.lock.services.MAccessibilityService$9
 *  com.lock.utils.ItemOffsetDecoration2
 *  com.lock.views.CustomRecyclerView
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package com.lock.services;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.media.session.MediaSessionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.ColorUtils;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.adaptar.CustomNotificationAdapter;
import com.lock.adaptar.CustomNotificationIconAdapter;
import com.lock.background.PrefManager;
import com.lock.entity.AppDetail;
import com.lock.entity.AppPackageList;
import com.lock.entity.Notification;
import com.lock.services.ActionParsable;
import com.lock.services.MAccessibilityService;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda0;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda1;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda2;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda3;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda8;
import com.lock.services.MAccessibilityService$$ExternalSyntheticLambda9;
import com.lock.services.MAccessibilityService$12$$ExternalSyntheticLambda0;
import com.lock.services.MAccessibilityService$7$$ExternalSyntheticLambda0;
import com.lock.services.NotificationListener;
import com.lock.utils.Constants;
import com.lock.utils.ItemOffsetDecoration2;
import com.lock.utils.Utils;
import com.lock.views.CustomRecyclerView;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class MAccessibilityService
extends AccessibilityService {
    public static final Uri ENABLED_ACCESSIBILITY_SERVICES = Settings.Secure.getUriFor((String)"enabled_accessibility_services");
    private static MContentObserver mContentObserver;
    private CustomNotificationAdapter adapter_island_big;
    private CustomNotificationIconAdapter adapter_island_small;
    Handler animationHandler = new Handler();
    Runnable animationRunnable = new Runnable(){

        public void run() {
            MAccessibilityService.this.list_parent_layout.setBackground(ResourcesCompat.getDrawable((Resources)MAccessibilityService.this.mContext.getResources(), (int)2131165586, null));
        }
    };
    public AppPackageList callPKG = new AppPackageList();
    int cameraCount;
    int currentIndex = 0;
    public AppPackageList filterPKG = new AppPackageList();
    int flagKeyBoard = 8913696;
    int flagNormal = 8913704;
    private final Handler handler;
    private boolean isClosingFull;
    boolean isControlEnabled = true;
    private boolean isInFullScreen;
    private boolean isPhoneLocked;
    private RelativeLayout island_top_layout;
    public LinearLayoutManager linearLayoutManager;
    private final ArrayList<Notification> list_big_island = new ArrayList();
    private LinearLayout list_parent_layout;
    private final ArrayList<Notification> list_small_island = new ArrayList();
    SharedPreferences.OnSharedPreferenceChangeListener listener;
    WindowManager.LayoutParams localLayoutParams;
    Context mContext;
    Handler mHandle;
    private BroadcastReceiver mInfoReceiver = new BroadcastReceiver(){

        /* synthetic */ void lambda$onReceive$0$com-lock-services-MAccessibilityService$12() {
            if (MAccessibilityService.this.isPortrait()) {
                MAccessibilityService.this.isInFullScreen = false;
                new Handler().postDelayed(new Runnable(){

                    public void run() {
                        MAccessibilityService.this.showSmallIslandNotification();
                    }
                }, 2000L);
                return;
            }
            MAccessibilityService.this.isInFullScreen = true;
            if (MAccessibilityService.this.utils.prefManager.gethideInLand(MAccessibilityService.this.mContext)) {
                MAccessibilityService.this.closeSmallIslandNotification();
            }
        }

        public void onReceive(Context context, Intent intent) {
            BluetoothDevice bluetoothDevice;
            if (intent != null && intent.getAction() == "android.intent.action.CONFIGURATION_CHANGED") {
                if (MAccessibilityService.this.isShowingFullIsland()) {
                    MAccessibilityService.this.closeFullNotificationIsland();
                }
                new Handler().postDelayed((Runnable)new MAccessibilityService$12$$ExternalSyntheticLambda0(this), 500L);
            }
            if (intent.getAction().matches("android.intent.action.BATTERY_CHANGED")) {
                int n = intent.getIntExtra("status", -1);
                boolean bl = n == 2 || n == 5;
                if (bl) {
                    boolean bl2;
                    Notification notification;
                    block31 : {
                        for (int i = 0; i < MAccessibilityService.this.list_small_island.size(); ++i) {
                            if (!((Notification)MAccessibilityService.access$300((MAccessibilityService)MAccessibilityService.this).get((int)i)).type.equals((Object)"CAT_CHARGING")) continue;
                            notification = (Notification)MAccessibilityService.this.list_small_island.get(i);
                            break block31;
                        }
                        notification = null;
                    }
                    if (notification == null) {
                        notification = new Notification("CAT_CHARGING", 0, 0);
                        MAccessibilityService.this.list_small_island.add((Object)notification);
                        bl2 = true;
                    } else {
                        bl2 = false;
                    }
                    notification.tv_text = MAccessibilityService.this.utils.getBatteryLevel() + "%";
                    notification.color = MAccessibilityService.this.mContext.getColor(2131034352);
                    notification.tv_title = MAccessibilityService.this.utils.getBatteryLevel() < 100 ? MAccessibilityService.this.mContext.getString(2131820622) : MAccessibilityService.this.mContext.getString(2131820684);
                    if (bl2) {
                        MAccessibilityService.this.scrollToLastItem();
                    } else {
                        MAccessibilityService.this.adapter_island_small.notifyDataSetChanged();
                    }
                } else {
                    for (Notification notification : MAccessibilityService.this.list_small_island) {
                        if (!notification.type.equals((Object)"CAT_CHARGING")) continue;
                        MAccessibilityService.this.list_small_island.remove((Object)notification);
                        break;
                    }
                    MAccessibilityService.this.scrollToLastItem();
                }
            }
            if (intent.getAction().matches("android.media.RINGER_MODE_CHANGED")) {
                int n = MAccessibilityService.this.utils.getDndState();
                if (n != 0 && n != 1) {
                    for (Notification notification : MAccessibilityService.this.list_small_island) {
                        if (!notification.type.equals((Object)"CAT_SILENT")) continue;
                        MAccessibilityService.this.list_small_island.remove((Object)notification);
                        break;
                    }
                } else {
                    for (Notification notification : MAccessibilityService.this.list_small_island) {
                        if (!notification.type.equals((Object)"CAT_SILENT")) continue;
                        MAccessibilityService.this.list_small_island.remove((Object)notification);
                        break;
                    }
                    if (n == 0) {
                        Notification notification = new Notification("CAT_SILENT", 2131165599, 0);
                        notification.tv_title = MAccessibilityService.this.mContext.getString(2131820876);
                        notification.color = MAccessibilityService.this.mContext.getColor(2131034981);
                        MAccessibilityService.this.list_small_island.add((Object)notification);
                    }
                    if (n == 1) {
                        Notification notification = new Notification("CAT_SILENT", 2131165632, 0);
                        notification.tv_title = MAccessibilityService.this.mContext.getString(2131820923);
                        notification.color = MAccessibilityService.this.mContext.getColor(2131034964);
                        MAccessibilityService.this.list_small_island.add((Object)notification);
                    }
                }
                MAccessibilityService.this.scrollToLastItem();
            }
            if (intent.getAction() != null && ("android.bluetooth.device.action.ACL_CONNECTED".equals((Object)intent.getAction()) || "android.bluetooth.device.action.ACL_DISCONNECTED".equals((Object)intent.getAction())) && (bluetoothDevice = (BluetoothDevice)intent.getParcelableExtra("android.bluetooth.device.extra.DEVICE")) != null) {
                if (Build.VERSION.SDK_INT >= 31 && ActivityCompat.checkSelfPermission((Context)MAccessibilityService.this.mContext, (String)"android.permission.BLUETOOTH_CONNECT") != 0) {
                    Toast.makeText((Context)MAccessibilityService.this.mContext, (int)2131820605, (int)0).show();
                    return;
                }
                if ("android.bluetooth.device.action.ACL_CONNECTED".equals((Object)intent.getAction()) && bluetoothDevice.getType() == 1) {
                    Notification notification;
                    int n = 0;
                    do {
                        int n2 = MAccessibilityService.this.list_small_island.size();
                        notification = null;
                        if (n >= n2) break;
                        if (((Notification)MAccessibilityService.access$300((MAccessibilityService)MAccessibilityService.this).get((int)n)).type.equals((Object)"TYPE_AIRBUDS")) {
                            notification = (Notification)MAccessibilityService.this.list_small_island.get(n);
                            break;
                        }
                        ++n;
                    } while (true);
                    if (notification == null) {
                        notification = new Notification("TYPE_AIRBUDS", 0, 0);
                    }
                    notification.color = MAccessibilityService.this.mContext.getColor(2131034352);
                    notification.local_right_icon = MAccessibilityService.this.utils.getAirpodsBatteryIcon();
                    MAccessibilityService.this.list_small_island.add((Object)notification);
                    MAccessibilityService.this.scrollToLastItem();
                    new Handler().postDelayed(new Runnable(){

                        public void run() {
                            notification.local_right_icon = MAccessibilityService.this.utils.getAirpodsBatteryIcon();
                            MAccessibilityService.this.adapter_island_small.notifyDataSetChanged();
                        }
                    }, 3000L);
                }
                if ("android.bluetooth.device.action.ACL_DISCONNECTED".equals((Object)intent.getAction())) {
                    if (bluetoothDevice.getType() == 1) {
                        for (Notification notification : MAccessibilityService.this.list_small_island) {
                            if (!notification.type.equals((Object)"TYPE_AIRBUDS")) continue;
                            MAccessibilityService.this.list_small_island.remove((Object)notification);
                            break;
                        }
                    }
                    MAccessibilityService.this.scrollToLastItem();
                }
            }
            KeyguardManager keyguardManager = (KeyguardManager)MAccessibilityService.this.mContext.getSystemService("keyguard");
            if (intent.getAction().equals((Object)"android.intent.action.USER_PRESENT") || intent.getAction().equals((Object)"android.intent.action.SCREEN_OFF") || intent.getAction().equals((Object)"android.intent.action.SCREEN_ON")) {
                if (keyguardManager.inKeyguardRestrictedInputMode()) {
                    MAccessibilityService.this.isPhoneLocked = true;
                    if (!MAccessibilityService.this.utils.prefManager.getShowOnLock(MAccessibilityService.this.mContext)) {
                        MAccessibilityService.this.closeSmallIslandNotification();
                        MAccessibilityService.this.closeFullNotificationIsland();
                        return;
                    }
                } else {
                    MAccessibilityService.this.isPhoneLocked = false;
                }
            }
        }

    };
    Runnable mRunnable = new MAccessibilityService$$ExternalSyntheticLambda1(this);
    WindowManager manager;
    int margin = 0;
    private final int maxIslandHeight = 170;
    private final int maxIslandHeight2 = 110;
    private final int maxIslandHeight3 = 200;
    private final int maxIslandHeight4 = 140;
    private final int maxIslandHeightCall = 90;
    private final int maxIslandWidth = 400;
    Handler mediaHandler = new Handler();
    private MediaSessionManager mediaSessionManager;
    Runnable mediaUpdateRunnable = new Runnable(){

        public void run() {
            long l = MAccessibilityService.this.getMediaDuration();
            long l2 = MAccessibilityService.this.getMediaPosition();
            if (l > 0L) {
                int n = (int)(100.0f * ((float)l2 / (float)l));
                MAccessibilityService.this.adapter_island_big.updateMediaProgress(MAccessibilityService.this.getMediaDuration(), MAccessibilityService.this.getMediaPosition(), n, 100);
            }
            MAccessibilityService.this.mediaHandler.postDelayed(MAccessibilityService.this.mediaUpdateRunnable, 1000L);
        }
    };
    public int minCameIslandWidth = 150;
    private int minIslandHeight = 30;
    public int minOneCameIslandWidth = 150;
    public int minThreeCameIslandWidth = 200;
    public int minTwoCameIslandWidth = 180;
    public int minZeroCameIslandWidth = 120;
    BroadcastReceiver notiReceiver = new BroadcastReceiver(){

        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction().matches("from_notification_service" + context.getPackageName()) && intent.getAction().equals((Object)("from_notification_service" + context.getPackageName()))) {
                MAccessibilityService.this.updateNotificationList(intent);
            }
        }
    };
    int pos = 1;
    SharedPreferences preferences;
    private CustomRecyclerView rv_island_big;
    RecyclerView rv_island_small;
    int startMargin = 20;
    public View statusBarView;
    private boolean useGlow = true;
    private boolean useIphoneCallDesign = false;
    public Utils utils;
    public int zeroHeight = 0;

    public MAccessibilityService() {
        Handler handler;
        this.handler = handler = new Handler();
        mContentObserver = new MContentObserver(handler);
    }

    private void enableControls(boolean bl) {
        this.isControlEnabled = bl;
        if (!bl) {
            this.closeSmallIslandNotification();
            return;
        }
        this.showTempBar();
    }

    private int getIconColor(int n) {
        if (ColorUtils.calculateLuminance((int)n) < 0.15) {
            n = Color.rgb((int)240, (int)240, (int)240);
        }
        return n;
    }

    private int getMinWidth() {
        int n = this.utils.prefManager.getCameraPos();
        if (n != 1 && n != 3) {
            return this.minCameIslandWidth;
        }
        return this.minCameIslandWidth + this.startMargin;
    }

    private RelativeLayout.LayoutParams getTopLayoutParams() {
        return (RelativeLayout.LayoutParams)this.list_parent_layout.getLayoutParams();
    }

    private void initNotifications() {
        CustomNotificationAdapter customNotificationAdapter;
        LinearLayoutManager linearLayoutManager;
        CustomNotificationIconAdapter customNotificationIconAdapter;
        this.rv_island_big = (CustomRecyclerView)this.statusBarView.findViewById(2131296855);
        this.rv_island_small = (RecyclerView)this.statusBarView.findViewById(2131296856);
        this.adapter_island_small = customNotificationIconAdapter = new CustomNotificationIconAdapter((Context)this, this.list_small_island, (NotificationListener)new 8(this));
        this.rv_island_small.setAdapter((RecyclerView.Adapter)customNotificationIconAdapter);
        this.rv_island_small.setHasFixedSize(true);
        this.rv_island_small.addItemDecoration((RecyclerView.ItemDecoration)new ItemOffsetDecoration2((Context)this, 2131100269));
        new PagerSnapHelper().attachToRecyclerView(this.rv_island_small);
        this.adapter_island_big = customNotificationAdapter = new CustomNotificationAdapter((Context)this, this.list_big_island, (NotificationListener)new 9(this));
        this.rv_island_big.setAdapter((RecyclerView.Adapter)customNotificationAdapter);
        this.rv_island_big.setHasFixedSize(true);
        this.linearLayoutManager = linearLayoutManager = new LinearLayoutManager(this.mContext);
        linearLayoutManager.setOrientation(0);
        this.rv_island_big.setLayoutManager((RecyclerView.LayoutManager)this.linearLayoutManager);
        this.rv_island_big.addItemDecoration((RecyclerView.ItemDecoration)new ItemOffsetDecoration2((Context)this, 2131100269));
        this.rv_island_big.addOnScrollListener((RecyclerView.OnScrollListener)new 10(this));
        new PagerSnapHelper().attachToRecyclerView((RecyclerView)this.rv_island_big);
    }

    private boolean isPortrait() {
        int n = ((WindowManager)this.getSystemService("window")).getDefaultDisplay().getRotation();
        return n == 0 || 2 == n;
        {
        }
    }

    private boolean isSameItem(Notification notification) {
        if (notification.pack.equals((Object)"com.whatsapp") && notification.template.equals((Object)"")) {
            return true;
        }
        return notification.pack.equals((Object)"com.google.android.gm") && notification.id.equals((Object)"0");
    }

    private boolean isShowingFullIsland() {
        return this.localLayoutParams.height == -1 && this.island_top_layout.getVisibility() == 0;
    }

    private boolean isShowingSmall() {
        return this.localLayoutParams.width == this.getMinWidth() && this.localLayoutParams.height == (int)((float)this.utils.prefManager.getMinHeight() * this.getResources().getDisplayMetrics().scaledDensity) && this.island_top_layout.getVisibility() == 0;
    }

    private void onUpdatePreference(String string2) {
        if (string2.equals((Object)"default_color1")) {
            this.adapter_island_small.notifyDataSetChanged();
        }
        if (string2.equals((Object)"SHOW_IN_FULL_SCREEN1")) {
            this.showTempBar();
        }
        if (string2.equals((Object)"CONTROL_ENABLE")) {
            this.enableControls(this.utils.prefManager.getControlEnabled());
        }
        if (string2.equals((Object)"SHOW_IN_LOCK1")) {
            this.showTempBar();
        }
        if (string2.equals((Object)"ENABLE_MUSIC_ANIM1")) {
            this.adapter_island_small.notifyDataSetChanged();
        }
        if (string2.equals((Object)"CAM_COUNT1") || string2.equals((Object)"CAM_POS1") || string2.equals((Object)"CAM_MARGIN1")) {
            this.setIslandPosition();
            this.showTempBar();
        }
        if (string2.equals((Object)"Y_POS1")) {
            this.setYPosIsland();
            this.showTempBar();
        }
        if (string2.equals((Object)"Y_HEIGHT1")) {
            int n;
            this.minIslandHeight = n = this.utils.prefManager.getMinHeight();
            this.localLayoutParams.height = (int)((float)n * this.getResources().getDisplayMetrics().scaledDensity);
            this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
            this.list_parent_layout.requestLayout();
            this.showTempBar();
            this.updateSmallIconSize();
        }
        if (string2.equals((Object)"SELECTED_PKG1")) {
            this.callPKG = this.utils.prefManager.getCallPkg(this.mContext);
        }
        if (string2.equals((Object)"FILTER_PKG1")) {
            this.filterPKG = this.utils.prefManager.getFilterPkg(this.mContext);
        }
        if (string2.equals((Object)"IPHONE_CALL1")) {
            this.useIphoneCallDesign = this.utils.prefManager.getIphoneCall(this.mContext);
        }
        if (string2.equals((Object)"ENABLE_GLOW1")) {
            this.useGlow = this.utils.prefManager.getGlow(this.mContext);
        }
    }

    private void removeMediaCallBacks() {
        this.mediaHandler.removeCallbacks(this.mediaUpdateRunnable);
    }

    private void scrollToLastItem() {
        this.adapter_island_small.notifyDataSetChanged();
        if (this.adapter_island_small.getItemCount() > 0) {
            this.rv_island_small.scrollToPosition(-1 + this.adapter_island_small.getItemCount());
        }
        this.showSmallIslandNotification();
    }

    private void setCenterCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 49;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    MAccessibilityService mAccessibilityService = MAccessibilityService.this;
                    mAccessibilityService.setLayoutGravity(17, (View)mAccessibilityService.list_parent_layout);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setFullIslandMargin(boolean bl) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.rv_island_small.getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams)this.island_top_layout.getLayoutParams();
        if (bl) {
            layoutParams2.leftMargin = 0;
            layoutParams2.rightMargin = 0;
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
            this.island_top_layout.requestLayout();
            return;
        }
        if (this.pos == 1) {
            layoutParams2.leftMargin = this.startMargin;
            layoutParams2.rightMargin = 0;
            layoutParams.leftMargin = this.margin;
            layoutParams.rightMargin = 0;
        }
        if (this.pos == 2) {
            layoutParams2.leftMargin = 0;
            layoutParams2.rightMargin = 0;
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = 0;
        }
        if (this.pos == 3) {
            layoutParams2.leftMargin = 0;
            layoutParams2.rightMargin = this.startMargin;
            layoutParams.leftMargin = 0;
            layoutParams.rightMargin = this.margin;
        }
        this.island_top_layout.requestLayout();
    }

    private void setIslandPosition() {
        int n;
        this.minIslandHeight = this.utils.prefManager.getMinHeight();
        this.statusBarView.findViewById(2131296887).setVisibility(8);
        this.statusBarView.findViewById(2131296888).setVisibility(8);
        this.startMargin = (int)((float)this.utils.prefManager.getCameraMargin() * this.getResources().getDisplayMetrics().scaledDensity);
        this.pos = this.utils.prefManager.getCameraPos();
        this.cameraCount = n = this.utils.prefManager.getCameraCount();
        if (n == 0) {
            this.localLayoutParams.width = (int)((float)this.minZeroCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
            this.margin = 0;
        }
        if (this.cameraCount == 1) {
            this.localLayoutParams.width = (int)((float)this.minOneCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
            this.margin = (int)(25.0f * this.getResources().getDisplayMetrics().scaledDensity);
        }
        if (this.cameraCount == 2) {
            this.margin = (int)(50.0f * this.getResources().getDisplayMetrics().scaledDensity);
            this.localLayoutParams.width = (int)((float)this.minTwoCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
        }
        if (this.cameraCount == 3) {
            this.localLayoutParams.width = (int)((float)this.minThreeCameIslandWidth * this.getResources().getDisplayMetrics().scaledDensity);
            this.margin = (int)(75.0f * this.getResources().getDisplayMetrics().scaledDensity);
        }
        this.minCameIslandWidth = this.localLayoutParams.width;
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.rv_island_small.getLayoutParams();
        LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams)this.island_top_layout.getLayoutParams();
        int n2 = this.pos;
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 == 3) {
                    this.setRightCamera();
                    layoutParams.leftMargin = 0;
                    layoutParams2.rightMargin = this.startMargin;
                    layoutParams2.leftMargin = 0;
                    layoutParams2.gravity = 8388613;
                    layoutParams.rightMargin = this.margin;
                }
            } else {
                this.setCenterCamera();
                layoutParams.leftMargin = 0;
                layoutParams.rightMargin = 0;
                layoutParams2.leftMargin = 0;
                layoutParams2.rightMargin = 0;
                layoutParams2.gravity = 17;
            }
        } else {
            this.setLeftCamera();
            layoutParams.leftMargin = this.margin;
            layoutParams2.leftMargin = this.startMargin;
            layoutParams2.rightMargin = 0;
            layoutParams.rightMargin = 0;
            layoutParams2.gravity = 8388611;
        }
        this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
        this.island_top_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
        this.rv_island_small.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.list_parent_layout.requestLayout();
        this.island_top_layout.requestLayout();
    }

    private void setLeftCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 8388659;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    MAccessibilityService mAccessibilityService = MAccessibilityService.this;
                    mAccessibilityService.setLayoutGravity(8388611, (View)mAccessibilityService.list_parent_layout);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setMediaUpdateHandler() {
        this.removeMediaCallBacks();
        this.mediaHandler.postDelayed(this.mediaUpdateRunnable, 1000L);
    }

    private void setRightCamera() {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                try {
                    MAccessibilityService.this.localLayoutParams.gravity = 8388661;
                    MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                    MAccessibilityService mAccessibilityService = MAccessibilityService.this;
                    mAccessibilityService.setLayoutGravity(8388613, (View)mAccessibilityService.list_parent_layout);
                    return;
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
            }
        }, 100L);
    }

    private void setYPosIsland() {
        this.localLayoutParams.y = (int)((float)this.utils.prefManager.getYPosOfIsland() * this.getResources().getDisplayMetrics().scaledDensity);
        this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
    }

    private void showFullIslandNotification(Notification notification) {
        int n;
        block9 : {
            if (this.isClosingFull) {
                return;
            }
            for (n = 0; n < this.list_big_island.size(); ++n) {
                if (!((Notification)this.list_big_island.get((int)n)).key.equals((Object)notification.key)) {
                    continue;
                }
                break block9;
            }
            n = -1;
        }
        if (notification.isLocal) {
            if (notification.type.equals((Object)"TYPE_AIRBUDS")) {
                notification.local_right_icon = this.utils.getAirpodsBatteryIcon();
            }
            this.adapter_island_small.notifyDataSetChanged();
            return;
        }
        if (n == -1) {
            return;
        }
        this.statusBarView.findViewById(2131296888).setVisibility(8);
        this.statusBarView.findViewById(2131296887).setVisibility(8);
        this.adapter_island_small.setHalfMode(false);
        this.island_top_layout.setVisibility(0);
        this.rv_island_small.setVisibility(8);
        if (this.isShowingFullIsland()) {
            this.rv_island_big.setVisibility(0);
            this.rv_island_big.scrollToPosition(n);
            return;
        }
        if (notification.template.equals((Object)"MediaStyle")) {
            this.setMediaUpdateHandler();
        }
        this.setFullIslandMargin(true);
        this.localLayoutParams.height = -1;
        this.localLayoutParams.width = this.isPortrait() ? -1 : (int)(400.0f * this.getResources().getDisplayMetrics().scaledDensity);
        if (!notification.category.equalsIgnoreCase("call")) {
            this.localLayoutParams.flags = this.flagKeyBoard;
        }
        this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
        RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
        layoutParams.width = this.isPortrait() ? -1 : (int)(350.0f * this.getResources().getDisplayMetrics().scaledDensity);
        layoutParams.setMarginStart(50);
        layoutParams.setMarginEnd(50);
        layoutParams.height = -2;
        this.list_parent_layout.setPivotX(300.0f);
        this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.rv_island_big.setVisibility(0);
        this.rv_island_big.scrollToPosition(n);
    }

    private void showGlowAnimation() {
        if (this.useGlow) {
            this.animationHandler.removeCallbacks(this.animationRunnable);
            AnimationDrawable animationDrawable = this.utils.getAnimationDrawable();
            this.list_parent_layout.setBackground((Drawable)animationDrawable);
            animationDrawable.start();
            this.animationHandler.postDelayed(this.animationRunnable, 3000L);
        }
    }

    private void showHideSmallIcon() {
        if (this.pos == 3) {
            if (this.statusBarView.findViewById(2131296887).getVisibility() == 8) {
                this.statusBarView.findViewById(2131296887).setVisibility(0);
                this.adapter_island_small.setHalfMode(true);
            } else {
                this.statusBarView.findViewById(2131296887).setVisibility(8);
                this.adapter_island_small.setHalfMode(false);
            }
        } else if (this.statusBarView.findViewById(2131296888).getVisibility() == 8) {
            this.statusBarView.findViewById(2131296888).setVisibility(0);
            this.adapter_island_small.setHalfMode(true);
        } else {
            this.statusBarView.findViewById(2131296888).setVisibility(8);
            this.adapter_island_small.setHalfMode(false);
        }
        this.adapter_island_small.notifyDataSetChanged();
    }

    private void updateNotificationItem(Notification notification, Notification notification2) {
        notification.senderIcon = notification2.senderIcon;
        notification.isPlaying = notification2.isPlaying;
        notification.icon = notification2.icon;
        notification.actions = notification2.actions;
        notification.pendingIntent = notification2.pendingIntent;
        notification.tv_title = notification2.tv_title;
        notification.tv_text = notification2.tv_text;
        notification.pack = notification2.pack;
        notification.postTime = notification2.postTime;
        notification.count = notification2.count;
        notification.bigText = notification2.bigText;
        notification.app_name = notification2.app_name;
        notification.isClearable = notification2.isClearable;
        notification.color = notification2.color;
        notification.picture = notification2.picture;
        notification.id = notification2.id;
        notification.template = notification2.template;
        notification.key = notification2.key;
        notification.groupKey = notification2.groupKey;
        notification.isAppGroup = notification2.isAppGroup;
        notification.isGroup = notification2.isGroup;
        notification.isOngoing = notification2.isOngoing;
        notification.isGroupConversation = notification2.isGroupConversation;
        notification.showChronometer = notification2.showChronometer;
        notification.progress = notification2.progress;
        notification.progressMax = notification2.progressMax;
        notification.progressIndeterminate = notification2.progressIndeterminate;
        notification.category = notification2.category;
    }

    private void updateSmallIconSize() {
        int n = (int)((float)this.minIslandHeight * this.getResources().getDisplayMetrics().scaledDensity);
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams)this.statusBarView.findViewById(2131296888).getLayoutParams();
        layoutParams.height = n;
        layoutParams.width = n;
        this.statusBarView.findViewById(2131296888).setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams)this.statusBarView.findViewById(2131296887).getLayoutParams();
        layoutParams2.height = n;
        layoutParams2.width = n;
        this.statusBarView.findViewById(2131296887).setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
    }

    public final void cleanUp() {
        this.handler.removeCallbacksAndMessages(null);
        try {
            this.getContentResolver().unregisterContentObserver((ContentObserver)mContentObserver);
        }
        catch (Throwable throwable) {}
    }

    public void closeFullNotificationIsland() {
        this.isClosingFull = true;
        new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda8(this), 1500L);
        this.removeMediaCallBacks();
        this.setFullIslandMargin(false);
        this.localLayoutParams.height = (int)(170.0f * this.getResources().getDisplayMetrics().scaledDensity);
        this.localLayoutParams.flags = this.flagNormal;
        this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
        RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
        int n = this.pos;
        layoutParams.width = n != 1 && n != 3 ? (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity) : (int)((float)(25 * this.cameraCount) * this.getResources().getDisplayMetrics().scaledDensity);
        layoutParams.height = (int)((float)this.minIslandHeight * this.getResources().getDisplayMetrics().scaledDensity);
        layoutParams.setMarginStart(0);
        layoutParams.setMarginEnd(0);
        this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.rv_island_big.setVisibility(8);
        new Handler().postDelayed(new Runnable(){

            /* synthetic */ void lambda$run$0$com-lock-services-MAccessibilityService$7() {
                RelativeLayout.LayoutParams layoutParams = MAccessibilityService.this.getTopLayoutParams();
                layoutParams.width = -1;
                layoutParams.height = -1;
                MAccessibilityService.this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                if (MAccessibilityService.this.adapter_island_small.getItemCount() > MAccessibilityService.this.currentIndex) {
                    MAccessibilityService.this.rv_island_small.scrollToPosition(MAccessibilityService.this.currentIndex);
                }
                new Handler().postDelayed(new Runnable(){

                    public void run() {
                        MAccessibilityService.this.rv_island_small.setVisibility(0);
                    }
                }, 500L);
            }

            public void run() {
                if (MAccessibilityService.this.list_small_island.size() == 0) {
                    MAccessibilityService.this.closeSmallIslandNotification();
                    return;
                }
                MAccessibilityService.this.localLayoutParams.height = (int)((float)MAccessibilityService.this.minIslandHeight * MAccessibilityService.this.getResources().getDisplayMetrics().scaledDensity);
                MAccessibilityService.this.localLayoutParams.width = MAccessibilityService.this.getMinWidth();
                MAccessibilityService.this.manager.updateViewLayout(MAccessibilityService.this.statusBarView, (ViewGroup.LayoutParams)MAccessibilityService.this.localLayoutParams);
                new Handler().postDelayed((Runnable)new MAccessibilityService$7$$ExternalSyntheticLambda0(this), 100L);
            }

        }, 500L);
    }

    public void closeHeadsUpNotification(final Notification notification) {
        new Handler().postDelayed(new Runnable(){

            public void run() {
                DisplayMetrics displayMetrics = MAccessibilityService.this.getResources().getDisplayMetrics();
                GestureDescription.Builder builder = new GestureDescription.Builder();
                Path path = new Path();
                double d = displayMetrics.heightPixels;
                double d2 = 0.01 * d;
                double d3 = d * 0.1;
                float f = displayMetrics.widthPixels / 2 + displayMetrics.widthPixels / 4;
                path.moveTo(f, (float)d3);
                path.lineTo(f, (float)d2);
                GestureDescription.StrokeDescription strokeDescription = new GestureDescription.StrokeDescription(path, 100L, 50L);
                builder.addStroke(strokeDescription);
                MAccessibilityService.this.dispatchGesture(builder.build(), new AccessibilityService.GestureResultCallback(){

                    public void onCompleted(GestureDescription gestureDescription) {
                        super.onCompleted(gestureDescription);
                        MAccessibilityService.this.showFullIslandNotification(notification);
                    }
                }, null);
            }

        }, 700L);
    }

    public void closeSmallIslandNotification() {
        try {
            RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
            layoutParams.width = (int)(this.utils.convertDpToPixel(3.0f, this.mContext) * this.getResources().getDisplayMetrics().scaledDensity);
            layoutParams.height = (int)(this.utils.convertDpToPixel(3.0f, this.mContext) * this.getResources().getDisplayMetrics().scaledDensity);
            this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            this.statusBarView.findViewById(2131296888).setVisibility(8);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda0(this), 500L);
    }

    /*
     * Exception decompiling
     */
    public long getMediaDuration() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl46.1 : LCONST_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public long getMediaPosition() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl45.1 : LCONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public boolean isCallPkgFound(String string2) {
        AppPackageList appPackageList;
        if (this.callPKG == null) {
            this.callPKG = this.utils.prefManager.getCallPkg(this.mContext);
        }
        if ((appPackageList = this.callPKG) != null) {
            Iterator iterator = appPackageList.appDetailList.iterator();
            while (iterator.hasNext()) {
                if (!((AppDetail)iterator.next()).pkg.equalsIgnoreCase(string2)) continue;
                return true;
            }
        }
        return false;
    }

    public boolean isFilterPkgFound(String string2) {
        AppPackageList appPackageList;
        if (this.filterPKG == null) {
            this.filterPKG = this.utils.prefManager.getFilterPkg(this.mContext);
        }
        if ((appPackageList = this.filterPKG) != null) {
            Iterator iterator = appPackageList.appDetailList.iterator();
            while (iterator.hasNext()) {
                if (!((AppDetail)iterator.next()).pkg.contains((CharSequence)string2)) continue;
                return true;
            }
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    public boolean isMediaPlaying(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl48.1 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /* synthetic */ void lambda$closeFullNotificationIsland$8$com-lock-services-MAccessibilityService() {
        this.isClosingFull = false;
    }

    /* synthetic */ void lambda$closeSmallIslandNotification$6$com-lock-services-MAccessibilityService() {
        try {
            this.localLayoutParams.height = (int)(this.utils.convertDpToPixel(3.0f, this.mContext) * this.getResources().getDisplayMetrics().scaledDensity);
            this.localLayoutParams.width = (int)(this.utils.convertDpToPixel(3.0f, this.mContext) * this.getResources().getDisplayMetrics().scaledDensity);
            this.localLayoutParams.flags = this.flagNormal;
            this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
            this.island_top_layout.setVisibility(8);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /* synthetic */ void lambda$new$7$com-lock-services-MAccessibilityService() {
        if (this.list_small_island.size() == 0) {
            this.closeSmallIslandNotification();
        }
    }

    /* synthetic */ void lambda$onServiceConnected$0$com-lock-services-MAccessibilityService() {
        this.showSmallIslandNotification();
    }

    /* synthetic */ void lambda$onServiceConnected$1$com-lock-services-MAccessibilityService() {
        this.closeSmallIslandNotification();
    }

    /* synthetic */ void lambda$onServiceConnected$2$com-lock-services-MAccessibilityService(int n) {
        if ((n & 4) == 0) {
            this.isInFullScreen = false;
            new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda2(this), 1000L);
            return;
        }
        this.isInFullScreen = true;
        if (!this.utils.prefManager.getShowInFullScreen(this.mContext)) {
            new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda3(this), 500L);
        }
    }

    /* synthetic */ void lambda$onServiceConnected$3$com-lock-services-MAccessibilityService(View view) {
        if (this.isShowingFullIsland()) {
            this.closeFullNotificationIsland();
        }
    }

    /* synthetic */ void lambda$onServiceConnected$4$com-lock-services-MAccessibilityService(SharedPreferences sharedPreferences, String string2) {
        this.onUpdatePreference(string2);
    }

    /* synthetic */ void lambda$onServiceConnected$5$com-lock-services-MAccessibilityService() {
        this.setIslandPosition();
        new Handler().postDelayed((Runnable)new MAccessibilityService$$ExternalSyntheticLambda9(this), 500L);
    }

    public void onAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        try {
            if (accessibilityEvent.getPackageName() != null) {
                accessibilityEvent.getEventType();
                return;
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.updateFontSize(configuration);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void onDestroy() {
        try {
            SharedPreferences sharedPreferences;
            Context context;
            SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener;
            BroadcastReceiver broadcastReceiver;
            Context context2;
            View view;
            WindowManager windowManager = this.manager;
            if (windowManager != null && (view = this.statusBarView) != null) {
                windowManager.removeView(view);
            }
            if ((sharedPreferences = this.preferences) != null && (onSharedPreferenceChangeListener = this.listener) != null) {
                sharedPreferences.unregisterOnSharedPreferenceChangeListener(onSharedPreferenceChangeListener);
            }
            if (this.notiReceiver != null && (context = this.mContext) != null) {
                LocalBroadcastManager.getInstance((Context)context).unregisterReceiver(this.notiReceiver);
            }
            if ((broadcastReceiver = this.mInfoReceiver) != null && (context2 = this.mContext) != null) {
                context2.unregisterReceiver(broadcastReceiver);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        super.onDestroy();
    }

    public void onInterrupt() {
    }

    /*
     * Exception decompiling
     */
    protected void onServiceConnected() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl185 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public int onStartCommand(Intent var1, int var2, int var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void setLayoutGravity(int n, View view) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        layoutParams.gravity = n;
        view.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        view.requestLayout();
    }

    public void showSmallIslandNotification() {
        if (this.list_small_island.size() == 0) {
            if (this.isShowingFullIsland()) {
                this.closeFullNotificationIsland();
            }
            if (this.isShowingSmall()) {
                this.closeSmallIslandNotification();
            }
        }
        if (this.adapter_island_small.getItemCount() >= 1) {
            this.rv_island_small.scrollToPosition(this.adapter_island_small.getItemCount() - 1);
        }
        if (this.isShowingSmall()) {
            this.island_top_layout.setVisibility(0);
            this.rv_island_small.setVisibility(0);
            this.showGlowAnimation();
            return;
        }
        if (this.isControlEnabled && (!this.isPhoneLocked || this.utils.prefManager.getShowOnLock(this.mContext)) && !this.isShowingFullIsland()) {
            if (this.isInFullScreen && !this.utils.prefManager.getShowInFullScreen(this.mContext)) {
                return;
            }
            this.showGlowAnimation();
            this.island_top_layout.setVisibility(0);
            this.rv_island_small.setVisibility(0);
            this.rv_island_big.setVisibility(8);
            if (this.list_small_island.size() == 0) {
                RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
                layoutParams.width = (int)(0.0f * this.getResources().getDisplayMetrics().scaledDensity);
                this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
                return;
            }
            this.localLayoutParams.height = (int)((float)this.utils.prefManager.getMinHeight() * this.getResources().getDisplayMetrics().scaledDensity);
            this.localLayoutParams.width = this.getMinWidth();
            this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
            RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -1;
            this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            if (this.adapter_island_small.getItemCount() >= 1) {
                this.rv_island_small.scrollToPosition(this.adapter_island_small.getItemCount() - 1);
            }
        }
    }

    public void showTempBar() {
        this.island_top_layout.setVisibility(0);
        this.localLayoutParams.height = (int)((float)this.utils.prefManager.getMinHeight() * this.getResources().getDisplayMetrics().scaledDensity);
        this.localLayoutParams.width = this.getMinWidth();
        this.manager.updateViewLayout(this.statusBarView, (ViewGroup.LayoutParams)this.localLayoutParams);
        RelativeLayout.LayoutParams layoutParams = this.getTopLayoutParams();
        layoutParams.width = -1;
        layoutParams.height = -1;
        this.list_parent_layout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        this.mHandle.removeCallbacks(this.mRunnable);
        this.mHandle.postDelayed(this.mRunnable, 3000L);
        this.showGlowAnimation();
    }

    public final void updateFontSize(Configuration configuration) {
        if (configuration.fontScale > 1.3f) {
            configuration.fontScale = 1.3f;
            DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
            ((WindowManager)this.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
            displayMetrics.scaledDensity = configuration.fontScale * displayMetrics.density;
            this.getResources().updateConfiguration(configuration, displayMetrics);
        }
    }

    /*
     * Exception decompiling
     */
    public void updateNotificationList(Intent var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl222 : ILOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public class MContentObserver
    extends ContentObserver {
        public MContentObserver(Handler handler) {
            super(handler);
        }

        public void onChange(boolean bl, Uri uri) {
            if (MAccessibilityService.ENABLED_ACCESSIBILITY_SERVICES.equals((Object)uri) && !Constants.checkAccessibilityEnabled((Context)MAccessibilityService.this)) {
                MAccessibilityService.this.cleanUp();
            }
        }
    }

}

