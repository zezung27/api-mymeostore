/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.accessibility.AccessibilityNodeInfo
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Objects
 */
package com.lock.services;

import android.view.accessibility.AccessibilityNodeInfo;
import com.lock.services.AccessibilityNodeUtil;
import java.util.Objects;

public final class NodeCheckerForSwitch
implements AccessibilityNodeUtil.performActionListener {
    public final AccessibilityNodeUtil accessibilityNodeUtil;

    public NodeCheckerForSwitch(AccessibilityNodeUtil accessibilityNodeUtil) {
        this.accessibilityNodeUtil = accessibilityNodeUtil;
    }

    public final boolean performActionOnButton(Object object, String string) {
        AccessibilityNodeInfo accessibilityNodeInfo = (AccessibilityNodeInfo)object;
        Objects.requireNonNull((Object)this.accessibilityNodeUtil);
        if ((String)accessibilityNodeInfo.getClassName() == null) {
            return false;
        }
        CharSequence charSequence = accessibilityNodeInfo.getContentDescription();
        if (charSequence == null) {
            return false;
        }
        String[] arrstring = string.split(",");
        boolean bl = false;
        for (int i = 0; i < arrstring.length; ++i) {
            if (!charSequence.toString().toLowerCase().contains((CharSequence)arrstring[i].toLowerCase())) continue;
            bl = true;
        }
        if (!bl) {
            return false;
        }
        if (accessibilityNodeInfo.isClickable()) {
            AccessibilityNodeUtil.performButtonClick(accessibilityNodeInfo);
            return true;
        }
        if (accessibilityNodeInfo.getParent().isClickable()) {
            AccessibilityNodeUtil.performButtonClick(accessibilityNodeInfo.getParent());
            return true;
        }
        return false;
    }
}

