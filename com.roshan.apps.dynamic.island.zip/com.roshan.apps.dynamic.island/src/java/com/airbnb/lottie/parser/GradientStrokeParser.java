/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableGradientColorValue;
import com.airbnb.lottie.model.animatable.AnimatableIntegerValue;
import com.airbnb.lottie.model.animatable.AnimatablePointValue;
import com.airbnb.lottie.model.content.GradientStroke;
import com.airbnb.lottie.model.content.GradientType;
import com.airbnb.lottie.model.content.ShapeStroke;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.value.Keyframe;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class GradientStrokeParser {
    private static final JsonReader.Options DASH_PATTERN_NAMES;
    private static final JsonReader.Options GRADIENT_NAMES;
    private static final JsonReader.Options NAMES;

    static {
        NAMES = JsonReader.Options.of("nm", "g", "o", "t", "s", "e", "w", "lc", "lj", "ml", "hd", "d");
        GRADIENT_NAMES = JsonReader.Options.of("p", "k");
        DASH_PATTERN_NAMES = JsonReader.Options.of("n", "v");
    }

    private GradientStrokeParser() {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    static GradientStroke parse(JsonReader var0, LottieComposition var1_1) throws IOException {
        block27 : {
            block26 : {
                var2_2 = new ArrayList();
                var3_3 = 0.0f;
                var4_4 = null;
                var5_5 = null;
                var6_6 = null;
                var7_7 = null;
                var8_8 = null;
                var9_9 = null;
                var10_10 = null;
                var11_11 = null;
                var12_12 = null;
                var13_13 = false;
                var14_14 = null;
                while (var0.hasNext()) {
                    block0 : switch (var0.selectName(GradientStrokeParser.NAMES)) {
                        default: {
                            var0.skipName();
                            var0.skipValue();
                            break;
                        }
                        case 11: {
                            var0.beginArray();
lbl22: // 3 sources:
                            do {
                                if (var0.hasNext()) {
                                    var0.beginObject();
                                    var23_20 = null;
                                    var24_21 = null;
                                    break block26;
                                }
                                var21_19 = var12_12;
                                var0.endArray();
                                if (var2_2.size() == 1) {
                                    var2_2.add((Object)((AnimatableFloatValue)var2_2.get(0)));
                                }
                                var12_12 = var21_19;
                                break block0;
                                break;
                            } while (true);
                        }
                        case 10: {
                            var13_13 = var0.nextBoolean();
                            break;
                        }
                        case 9: {
                            var3_3 = (float)var0.nextDouble();
                            break;
                        }
                        case 8: {
                            var11_11 = ShapeStroke.LineJoinType.values()[var0.nextInt() - 1];
                            break;
                        }
                        case 7: {
                            var10_10 = ShapeStroke.LineCapType.values()[var0.nextInt() - 1];
                            break;
                        }
                        case 6: {
                            var9_9 = AnimatableValueParser.parseFloat(var0, var1_1);
                            break;
                        }
                        case 5: {
                            var8_8 = AnimatableValueParser.parsePoint(var0, var1_1);
                            break;
                        }
                        case 4: {
                            var7_7 = AnimatableValueParser.parsePoint(var0, var1_1);
                            break;
                        }
                        case 3: {
                            var20_18 = var0.nextInt() == 1 ? GradientType.LINEAR : GradientType.RADIAL;
                            var5_5 = var20_18;
                            break;
                        }
                        case 2: {
                            var14_14 = AnimatableValueParser.parseInteger(var0, var1_1);
                            break;
                        }
                        case 1: {
                            var16_15 = -1;
                            var0.beginObject();
                            while (var0.hasNext()) {
                                var18_16 = var0.selectName(GradientStrokeParser.GRADIENT_NAMES);
                                if (var18_16 == 0) ** GOTO lbl75
                                var19_17 = var6_6;
                                if (var18_16 != 1) {
                                    var0.skipName();
                                    var0.skipValue();
                                } else {
                                    var6_6 = AnimatableValueParser.parseGradientColor(var0, var1_1, var16_15);
                                    continue;
lbl75: // 1 sources:
                                    var19_17 = var6_6;
                                    var16_15 = var0.nextInt();
                                }
                                var6_6 = var19_17;
                            }
                            var0.endObject();
                            break;
                        }
                        case 0: {
                            var4_4 = var0.nextString();
                            break;
                        }
                    }
                }
                if (var14_14 != null) return new GradientStroke(var4_4, var5_5, var6_6, var14_14, var7_7, var8_8, var9_9, var10_10, var11_11, var3_3, (List<AnimatableFloatValue>)var2_2, var12_12, var13_13);
                var14_14 = new AnimatableIntegerValue((List<Keyframe<Integer>>)Collections.singletonList(new Keyframe<Integer>((int)100)));
                return new GradientStroke(var4_4, var5_5, var6_6, var14_14, var7_7, var8_8, var9_9, var10_10, var11_11, var3_3, (List<AnimatableFloatValue>)var2_2, var12_12, var13_13);
            }
            while (var0.hasNext()) {
                var27_23 = var0.selectName(GradientStrokeParser.DASH_PATTERN_NAMES);
                if (var27_23 != 0) {
                    var29_24 = var12_12;
                    if (var27_23 != 1) {
                        var0.skipName();
                        var0.skipValue();
                    } else {
                        var24_21 = AnimatableValueParser.parseFloat(var0, var1_1);
                    }
                    var12_12 = var29_24;
                    continue;
                }
                var23_20 = var0.nextString();
            }
            var25_22 = var12_12;
            var0.endObject();
            if (!var23_20.equals((Object)"o")) break block27;
            var12_12 = var24_21;
            ** GOTO lbl22
        }
        if (var23_20.equals((Object)"d") || var23_20.equals((Object)"g")) {
            var1_1.setHasDashPattern(true);
            var2_2.add((Object)var24_21);
        }
        var12_12 = var25_22;
        ** while (true)
    }
}

