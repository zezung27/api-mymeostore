/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.parser;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.model.animatable.AnimatableColorValue;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.parser.AnimatableValueParser;
import com.airbnb.lottie.parser.DropShadowEffect;
import com.airbnb.lottie.parser.moshi.JsonReader;
import java.io.IOException;

public class DropShadowEffectParser {
    private static final JsonReader.Options DROP_SHADOW_EFFECT_NAMES = JsonReader.Options.of("ef");
    private static final JsonReader.Options INNER_EFFECT_NAMES = JsonReader.Options.of("nm", "v");
    private AnimatableColorValue color;
    private AnimatableFloatValue direction;
    private AnimatableFloatValue distance;
    private AnimatableFloatValue opacity;
    private AnimatableFloatValue radius;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void maybeParseInnerEffect(JsonReader var1_1, LottieComposition var2_2) throws IOException {
        var1_1.beginObject();
        var3_3 = "";
        block14 : do {
            block18 : {
                block19 : {
                    block20 : {
                        if (!var1_1.hasNext()) {
                            var1_1.endObject();
                            return;
                        }
                        var4_4 = var1_1.selectName(DropShadowEffectParser.INNER_EFFECT_NAMES);
                        if (var4_4 == 0) break block18;
                        var5_5 = 1;
                        if (var4_4 != var5_5) {
                            var1_1.skipName();
                            var1_1.skipValue();
                            continue;
                        }
                        var3_3.hashCode();
                        switch (var3_3.hashCode()) {
                            case 1383710113: {
                                if (!var3_3.equals((Object)"Softness")) break;
                                var5_5 = 4;
                                ** break;
                            }
                            case 1379387491: {
                                if (!var3_3.equals((Object)"Shadow Color")) break;
                                var5_5 = 3;
                                ** break;
                            }
                            case 1041377119: {
                                if (!var3_3.equals((Object)"Direction")) break;
                                var5_5 = 2;
                                ** break;
                            }
                            case 397447147: {
                                if (!var3_3.equals((Object)"Opacity")) {
                                    break;
                                }
                                break block19;
                            }
                            case 353103893: {
                                if (var3_3.equals((Object)"Distance")) break block20;
                            }
                        }
                        var5_5 = -1;
                        ** break;
                    }
                    var5_5 = 0;
                }
                switch (var5_5) {
                    default: {
                        var1_1.skipValue();
                        continue block14;
                    }
                    case 4: {
                        this.radius = AnimatableValueParser.parseFloat(var1_1, var2_2);
                        continue block14;
                    }
                    case 3: {
                        this.color = AnimatableValueParser.parseColor(var1_1, var2_2);
                        continue block14;
                    }
                    case 2: {
                        this.direction = AnimatableValueParser.parseFloat(var1_1, var2_2, false);
                        continue block14;
                    }
                    case 1: {
                        this.opacity = AnimatableValueParser.parseFloat(var1_1, var2_2, false);
                        continue block14;
                    }
                    case 0: 
                }
                this.distance = AnimatableValueParser.parseFloat(var1_1, var2_2);
                continue;
            }
            var3_3 = var1_1.nextString();
        } while (true);
    }

    DropShadowEffect parse(JsonReader jsonReader, LottieComposition lottieComposition) throws IOException {
        while (jsonReader.hasNext()) {
            if (jsonReader.selectName(DROP_SHADOW_EFFECT_NAMES) != 0) {
                jsonReader.skipName();
                jsonReader.skipValue();
                continue;
            }
            jsonReader.beginArray();
            while (jsonReader.hasNext()) {
                this.maybeParseInnerEffect(jsonReader, lottieComposition);
            }
            jsonReader.endArray();
        }
        if (this.color != null && this.opacity != null && this.direction != null && this.distance != null && this.radius != null) {
            DropShadowEffect dropShadowEffect = new DropShadowEffect(this.color, this.opacity, this.direction, this.distance, this.radius);
            return dropShadowEffect;
        }
        return null;
    }
}

