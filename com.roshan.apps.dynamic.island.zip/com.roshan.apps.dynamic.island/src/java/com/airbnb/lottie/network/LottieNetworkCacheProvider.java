/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Object
 */
package com.airbnb.lottie.network;

import java.io.File;

public interface LottieNetworkCacheProvider {
    public File getCacheDir();
}

