/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import com.airbnb.lottie.animation.keyframe.KeyframeAnimation;
import com.airbnb.lottie.model.DocumentData;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class TextKeyframeAnimation
extends KeyframeAnimation<DocumentData> {
    public TextKeyframeAnimation(List<Keyframe<DocumentData>> list) {
        super(list);
    }

    @Override
    DocumentData getValue(Keyframe<DocumentData> keyframe, float f) {
        if (this.valueCallback != null) {
            LottieValueCallback lottieValueCallback = this.valueCallback;
            float f2 = keyframe.startFrame;
            float f3 = keyframe.endFrame == null ? Float.MAX_VALUE : keyframe.endFrame.floatValue();
            float f4 = f3;
            DocumentData documentData = (DocumentData)keyframe.startValue;
            Object t = keyframe.endValue == null ? keyframe.startValue : keyframe.endValue;
            return lottieValueCallback.getValueInternal(f2, f4, documentData, (DocumentData)t, f, this.getInterpolatedCurrentKeyframeProgress(), this.getProgress());
        }
        if (f == 1.0f && keyframe.endValue != null) {
            return (DocumentData)keyframe.endValue;
        }
        return (DocumentData)keyframe.startValue;
    }

    public void setStringValueCallback(LottieValueCallback<String> lottieValueCallback) {
        super.setValueCallback(new LottieValueCallback<DocumentData>(new LottieFrameInfo(), lottieValueCallback, new DocumentData()){
            final /* synthetic */ DocumentData val$documentData;
            final /* synthetic */ LottieFrameInfo val$stringFrameInfo;
            final /* synthetic */ LottieValueCallback val$valueCallback;
            {
                this.val$stringFrameInfo = lottieFrameInfo;
                this.val$valueCallback = lottieValueCallback;
                this.val$documentData = documentData;
            }

            @Override
            public DocumentData getValue(LottieFrameInfo<DocumentData> lottieFrameInfo) {
                this.val$stringFrameInfo.set(lottieFrameInfo.getStartFrame(), lottieFrameInfo.getEndFrame(), lottieFrameInfo.getStartValue().text, lottieFrameInfo.getEndValue().text, lottieFrameInfo.getLinearKeyframeProgress(), lottieFrameInfo.getInterpolatedKeyframeProgress(), lottieFrameInfo.getOverallProgress());
                String string2 = (String)this.val$valueCallback.getValue(this.val$stringFrameInfo);
                DocumentData documentData = lottieFrameInfo.getInterpolatedKeyframeProgress() == 1.0f ? lottieFrameInfo.getEndValue() : lottieFrameInfo.getStartValue();
                DocumentData documentData2 = documentData;
                this.val$documentData.set(string2, documentData2.fontName, documentData2.size, documentData2.justification, documentData2.tracking, documentData2.lineHeight, documentData2.baselineShift, documentData2.color, documentData2.strokeColor, documentData2.strokeWidth, documentData2.strokeOverFill);
                return this.val$documentData;
            }
        });
    }

}

