/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Path
 *  android.graphics.PointF
 *  android.graphics.RectF
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package com.airbnb.lottie.animation.content;

import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.animation.content.CompoundTrimPathContent;
import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.animation.content.KeyPathElementContent;
import com.airbnb.lottie.animation.content.PathContent;
import com.airbnb.lottie.animation.content.RoundedCornersContent;
import com.airbnb.lottie.animation.content.TrimPathContent;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.animation.keyframe.FloatKeyframeAnimation;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.model.animatable.AnimatableFloatValue;
import com.airbnb.lottie.model.animatable.AnimatableValue;
import com.airbnb.lottie.model.content.RectangleShape;
import com.airbnb.lottie.model.content.ShapeTrimPath;
import com.airbnb.lottie.model.layer.BaseLayer;
import com.airbnb.lottie.utils.MiscUtils;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.List;

public class RectangleContent
implements BaseKeyframeAnimation.AnimationListener,
KeyPathElementContent,
PathContent {
    private final BaseKeyframeAnimation<?, Float> cornerRadiusAnimation;
    private final boolean hidden;
    private boolean isPathValid;
    private final LottieDrawable lottieDrawable;
    private final String name;
    private final Path path = new Path();
    private final BaseKeyframeAnimation<?, PointF> positionAnimation;
    private final RectF rect = new RectF();
    private BaseKeyframeAnimation<Float, Float> roundedCornersAnimation = null;
    private final BaseKeyframeAnimation<?, PointF> sizeAnimation;
    private final CompoundTrimPathContent trimPaths = new CompoundTrimPathContent();

    public RectangleContent(LottieDrawable lottieDrawable, BaseLayer baseLayer, RectangleShape rectangleShape) {
        this.name = rectangleShape.getName();
        this.hidden = rectangleShape.isHidden();
        this.lottieDrawable = lottieDrawable;
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation = rectangleShape.getPosition().createAnimation();
        this.positionAnimation = baseKeyframeAnimation;
        BaseKeyframeAnimation<PointF, PointF> baseKeyframeAnimation2 = rectangleShape.getSize().createAnimation();
        this.sizeAnimation = baseKeyframeAnimation2;
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation3 = rectangleShape.getCornerRadius().createAnimation();
        this.cornerRadiusAnimation = baseKeyframeAnimation3;
        baseLayer.addAnimation(baseKeyframeAnimation);
        baseLayer.addAnimation(baseKeyframeAnimation2);
        baseLayer.addAnimation(baseKeyframeAnimation3);
        baseKeyframeAnimation.addUpdateListener(this);
        baseKeyframeAnimation2.addUpdateListener(this);
        baseKeyframeAnimation3.addUpdateListener(this);
    }

    private void invalidate() {
        this.isPathValid = false;
        this.lottieDrawable.invalidateSelf();
    }

    @Override
    public <T> void addValueCallback(T t, LottieValueCallback<T> lottieValueCallback) {
        if (t == LottieProperty.RECTANGLE_SIZE) {
            this.sizeAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.POSITION) {
            this.positionAnimation.setValueCallback(lottieValueCallback);
            return;
        }
        if (t == LottieProperty.CORNER_RADIUS) {
            this.cornerRadiusAnimation.setValueCallback(lottieValueCallback);
        }
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public Path getPath() {
        BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation;
        float f;
        if (this.isPathValid) {
            return this.path;
        }
        this.path.reset();
        if (this.hidden) {
            this.isPathValid = true;
            return this.path;
        }
        PointF pointF = this.sizeAnimation.getValue();
        float f2 = pointF.x / 2.0f;
        float f3 = pointF.y / 2.0f;
        BaseKeyframeAnimation<?, Float> baseKeyframeAnimation2 = this.cornerRadiusAnimation;
        float f4 = baseKeyframeAnimation2 == null ? 0.0f : ((FloatKeyframeAnimation)baseKeyframeAnimation2).getFloatValue();
        if (f4 == 0.0f && (baseKeyframeAnimation = this.roundedCornersAnimation) != null) {
            f4 = Math.min((float)baseKeyframeAnimation.getValue().floatValue(), (float)Math.min((float)f2, (float)f3));
        }
        if (f4 > (f = Math.min((float)f2, (float)f3))) {
            f4 = f;
        }
        PointF pointF2 = this.positionAnimation.getValue();
        this.path.moveTo(f2 + pointF2.x, f4 + (pointF2.y - f3));
        this.path.lineTo(f2 + pointF2.x, f3 + pointF2.y - f4);
        float f5 = f4 FCMPL 0.0f;
        if (f5 > 0) {
            RectF rectF = this.rect;
            float f6 = f2 + pointF2.x;
            float f7 = f4 * 2.0f;
            rectF.set(f6 - f7, f3 + pointF2.y - f7, f2 + pointF2.x, f3 + pointF2.y);
            this.path.arcTo(this.rect, 0.0f, 90.0f, false);
        }
        this.path.lineTo(f4 + (pointF2.x - f2), f3 + pointF2.y);
        if (f5 > 0) {
            RectF rectF = this.rect;
            float f8 = pointF2.x - f2;
            float f9 = f3 + pointF2.y;
            float f10 = f4 * 2.0f;
            rectF.set(f8, f9 - f10, f10 + (pointF2.x - f2), f3 + pointF2.y);
            this.path.arcTo(this.rect, 90.0f, 90.0f, false);
        }
        this.path.lineTo(pointF2.x - f2, f4 + (pointF2.y - f3));
        if (f5 > 0) {
            RectF rectF = this.rect;
            float f11 = pointF2.x - f2;
            float f12 = pointF2.y - f3;
            float f13 = pointF2.x - f2;
            float f14 = f4 * 2.0f;
            rectF.set(f11, f12, f13 + f14, f14 + (pointF2.y - f3));
            this.path.arcTo(this.rect, 180.0f, 90.0f, false);
        }
        this.path.lineTo(f2 + pointF2.x - f4, pointF2.y - f3);
        if (f5 > 0) {
            RectF rectF = this.rect;
            float f15 = f2 + pointF2.x;
            float f16 = f4 * 2.0f;
            rectF.set(f15 - f16, pointF2.y - f3, f2 + pointF2.x, f16 + (pointF2.y - f3));
            this.path.arcTo(this.rect, 270.0f, 90.0f, false);
        }
        this.path.close();
        this.trimPaths.apply(this.path);
        this.isPathValid = true;
        return this.path;
    }

    @Override
    public void onValueChanged() {
        this.invalidate();
    }

    @Override
    public void resolveKeyPath(KeyPath keyPath, int n, List<KeyPath> list, KeyPath keyPath2) {
        MiscUtils.resolveKeyPath(keyPath, n, list, keyPath2, this);
    }

    @Override
    public void setContents(List<Content> list, List<Content> list2) {
        for (int i = 0; i < list.size(); ++i) {
            TrimPathContent trimPathContent;
            Content content = (Content)list.get(i);
            if (content instanceof TrimPathContent && (trimPathContent = (TrimPathContent)content).getType() == ShapeTrimPath.Type.SIMULTANEOUSLY) {
                this.trimPaths.addTrimPath(trimPathContent);
                trimPathContent.addListener(this);
                continue;
            }
            if (!(content instanceof RoundedCornersContent)) continue;
            this.roundedCornersAnimation = ((RoundedCornersContent)content).getRoundedCorners();
        }
    }
}

