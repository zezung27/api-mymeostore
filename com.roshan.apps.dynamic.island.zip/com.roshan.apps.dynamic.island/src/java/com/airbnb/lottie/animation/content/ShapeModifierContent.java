/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie.animation.content;

import com.airbnb.lottie.animation.content.Content;
import com.airbnb.lottie.model.content.ShapeData;

public interface ShapeModifierContent
extends Content {
    public ShapeData modifyShape(ShapeData var1);
}

