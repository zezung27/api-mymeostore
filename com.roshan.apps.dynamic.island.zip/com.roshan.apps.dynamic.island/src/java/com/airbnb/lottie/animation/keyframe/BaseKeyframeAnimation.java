/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.view.animation.Interpolator;
import com.airbnb.lottie.L;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseKeyframeAnimation<K, A> {
    private float cachedEndProgress = -1.0f;
    private A cachedGetValue = null;
    private float cachedStartDelayProgress = -1.0f;
    private boolean isDiscrete = false;
    private final KeyframesWrapper<K> keyframesWrapper;
    final List<AnimationListener> listeners = new ArrayList(1);
    protected float progress = 0.0f;
    protected LottieValueCallback<A> valueCallback;

    BaseKeyframeAnimation(List<? extends Keyframe<K>> list) {
        this.keyframesWrapper = BaseKeyframeAnimation.wrap(list);
    }

    private float getStartDelayProgress() {
        if (this.cachedStartDelayProgress == -1.0f) {
            this.cachedStartDelayProgress = this.keyframesWrapper.getStartDelayProgress();
        }
        return this.cachedStartDelayProgress;
    }

    private static <T> KeyframesWrapper<T> wrap(List<? extends Keyframe<T>> list) {
        if (list.isEmpty()) {
            return new EmptyKeyframeWrapper();
        }
        if (list.size() == 1) {
            return new SingleKeyframeWrapper(list);
        }
        return new KeyframesWrapperImpl(list);
    }

    public void addUpdateListener(AnimationListener animationListener) {
        this.listeners.add((Object)animationListener);
    }

    protected Keyframe<K> getCurrentKeyframe() {
        L.beginSection("BaseKeyframeAnimation#getCurrentKeyframe");
        Keyframe<K> keyframe = this.keyframesWrapper.getCurrentKeyframe();
        L.endSection("BaseKeyframeAnimation#getCurrentKeyframe");
        return keyframe;
    }

    float getEndProgress() {
        if (this.cachedEndProgress == -1.0f) {
            this.cachedEndProgress = this.keyframesWrapper.getEndProgress();
        }
        return this.cachedEndProgress;
    }

    protected float getInterpolatedCurrentKeyframeProgress() {
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        if (keyframe != null && !keyframe.isStatic()) {
            return keyframe.interpolator.getInterpolation(this.getLinearCurrentKeyframeProgress());
        }
        return 0.0f;
    }

    float getLinearCurrentKeyframeProgress() {
        if (this.isDiscrete) {
            return 0.0f;
        }
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        if (keyframe.isStatic()) {
            return 0.0f;
        }
        return (this.progress - keyframe.getStartProgress()) / (keyframe.getEndProgress() - keyframe.getStartProgress());
    }

    public float getProgress() {
        return this.progress;
    }

    public A getValue() {
        float f = this.getLinearCurrentKeyframeProgress();
        if (this.valueCallback == null && this.keyframesWrapper.isCachedValueEnabled(f)) {
            return this.cachedGetValue;
        }
        Keyframe<K> keyframe = this.getCurrentKeyframe();
        A a = keyframe.xInterpolator != null && keyframe.yInterpolator != null ? this.getValue(keyframe, f, keyframe.xInterpolator.getInterpolation(f), keyframe.yInterpolator.getInterpolation(f)) : this.getValue(keyframe, this.getInterpolatedCurrentKeyframeProgress());
        this.cachedGetValue = a;
        return a;
    }

    abstract A getValue(Keyframe<K> var1, float var2);

    protected A getValue(Keyframe<K> keyframe, float f, float f2, float f3) {
        throw new UnsupportedOperationException("This animation does not support split dimensions!");
    }

    public void notifyListeners() {
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((AnimationListener)this.listeners.get(i)).onValueChanged();
        }
    }

    public void setIsDiscrete() {
        this.isDiscrete = true;
    }

    public void setProgress(float f) {
        if (this.keyframesWrapper.isEmpty()) {
            return;
        }
        if (f < this.getStartDelayProgress()) {
            f = this.getStartDelayProgress();
        } else if (f > this.getEndProgress()) {
            f = this.getEndProgress();
        }
        if (f == this.progress) {
            return;
        }
        this.progress = f;
        if (this.keyframesWrapper.isValueChanged(f)) {
            this.notifyListeners();
        }
    }

    public void setValueCallback(LottieValueCallback<A> lottieValueCallback) {
        LottieValueCallback<A> lottieValueCallback2 = this.valueCallback;
        if (lottieValueCallback2 != null) {
            lottieValueCallback2.setAnimation(null);
        }
        this.valueCallback = lottieValueCallback;
        if (lottieValueCallback != null) {
            lottieValueCallback.setAnimation(this);
        }
    }

    public static interface AnimationListener {
        public void onValueChanged();
    }

    private static final class EmptyKeyframeWrapper<T>
    implements KeyframesWrapper<T> {
        private EmptyKeyframeWrapper() {
        }

        @Override
        public Keyframe<T> getCurrentKeyframe() {
            throw new IllegalStateException("not implemented");
        }

        @Override
        public float getEndProgress() {
            return 1.0f;
        }

        @Override
        public float getStartDelayProgress() {
            return 0.0f;
        }

        @Override
        public boolean isCachedValueEnabled(float f) {
            throw new IllegalStateException("not implemented");
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public boolean isValueChanged(float f) {
            return false;
        }
    }

    private static interface KeyframesWrapper<T> {
        public Keyframe<T> getCurrentKeyframe();

        public float getEndProgress();

        public float getStartDelayProgress();

        public boolean isCachedValueEnabled(float var1);

        public boolean isEmpty();

        public boolean isValueChanged(float var1);
    }

    private static final class KeyframesWrapperImpl<T>
    implements KeyframesWrapper<T> {
        private Keyframe<T> cachedCurrentKeyframe = null;
        private float cachedInterpolatedProgress = -1.0f;
        private Keyframe<T> currentKeyframe;
        private final List<? extends Keyframe<T>> keyframes;

        KeyframesWrapperImpl(List<? extends Keyframe<T>> list) {
            this.keyframes = list;
            this.currentKeyframe = this.findKeyframe(0.0f);
        }

        private Keyframe<T> findKeyframe(float f) {
            List<? extends Keyframe<T>> list = this.keyframes;
            Keyframe keyframe = (Keyframe)list.get(list.size() - 1);
            if (f >= keyframe.getStartProgress()) {
                return keyframe;
            }
            for (int i = -2 + this.keyframes.size(); i >= 1; --i) {
                Keyframe keyframe2 = (Keyframe)this.keyframes.get(i);
                if (this.currentKeyframe == keyframe2 || !keyframe2.containsProgress(f)) continue;
                return keyframe2;
            }
            return (Keyframe)this.keyframes.get(0);
        }

        @Override
        public Keyframe<T> getCurrentKeyframe() {
            return this.currentKeyframe;
        }

        @Override
        public float getEndProgress() {
            List<? extends Keyframe<T>> list = this.keyframes;
            return ((Keyframe)list.get(-1 + list.size())).getEndProgress();
        }

        @Override
        public float getStartDelayProgress() {
            return ((Keyframe)this.keyframes.get(0)).getStartProgress();
        }

        @Override
        public boolean isCachedValueEnabled(float f) {
            Keyframe<T> keyframe = this.cachedCurrentKeyframe;
            Keyframe<T> keyframe2 = this.currentKeyframe;
            if (keyframe == keyframe2 && this.cachedInterpolatedProgress == f) {
                return true;
            }
            this.cachedCurrentKeyframe = keyframe2;
            this.cachedInterpolatedProgress = f;
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isValueChanged(float f) {
            if (this.currentKeyframe.containsProgress(f)) {
                return true ^ this.currentKeyframe.isStatic();
            }
            this.currentKeyframe = this.findKeyframe(f);
            return true;
        }
    }

    private static final class SingleKeyframeWrapper<T>
    implements KeyframesWrapper<T> {
        private float cachedInterpolatedProgress = -1.0f;
        private final Keyframe<T> keyframe;

        SingleKeyframeWrapper(List<? extends Keyframe<T>> list) {
            this.keyframe = (Keyframe)list.get(0);
        }

        @Override
        public Keyframe<T> getCurrentKeyframe() {
            return this.keyframe;
        }

        @Override
        public float getEndProgress() {
            return this.keyframe.getEndProgress();
        }

        @Override
        public float getStartDelayProgress() {
            return this.keyframe.getStartProgress();
        }

        @Override
        public boolean isCachedValueEnabled(float f) {
            if (this.cachedInterpolatedProgress == f) {
                return true;
            }
            this.cachedInterpolatedProgress = f;
            return false;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isValueChanged(float f) {
            return true ^ this.keyframe.isStatic();
        }
    }

}

