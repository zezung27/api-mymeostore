/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.nordan.dialog;

public final class Animation
extends Enum<Animation> {
    private static final /* synthetic */ Animation[] $VALUES;
    public static final /* enum */ Animation POP;
    public static final /* enum */ Animation SIDE;
    public static final /* enum */ Animation SLIDE;

    static {
        Animation animation;
        Animation animation2;
        Animation animation3;
        POP = animation3 = new Animation();
        SIDE = animation2 = new Animation();
        SLIDE = animation = new Animation();
        $VALUES = new Animation[]{animation3, animation2, animation};
    }

    public static Animation valueOf(String string2) {
        return (Animation)Enum.valueOf(Animation.class, (String)string2);
    }

    public static Animation[] values() {
        return (Animation[])$VALUES.clone();
    }
}

