/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.nordan.dialog;

public final class DialogType
extends Enum<DialogType> {
    private static final /* synthetic */ DialogType[] $VALUES;
    public static final /* enum */ DialogType ERROR;
    public static final /* enum */ DialogType INFORMATION;
    public static final /* enum */ DialogType QUESTION;
    public static final /* enum */ DialogType SUCCESS;
    public static final /* enum */ DialogType WARNING;

    static {
        DialogType dialogType;
        DialogType dialogType2;
        DialogType dialogType3;
        DialogType dialogType4;
        DialogType dialogType5;
        WARNING = dialogType4 = new DialogType();
        ERROR = dialogType = new DialogType();
        INFORMATION = dialogType5 = new DialogType();
        QUESTION = dialogType3 = new DialogType();
        SUCCESS = dialogType2 = new DialogType();
        $VALUES = new DialogType[]{dialogType4, dialogType, dialogType5, dialogType3, dialogType2};
    }

    public static DialogType valueOf(String string2) {
        return (DialogType)Enum.valueOf(DialogType.class, (String)string2);
    }

    public static DialogType[] values() {
        return (DialogType[])$VALUES.clone();
    }
}

