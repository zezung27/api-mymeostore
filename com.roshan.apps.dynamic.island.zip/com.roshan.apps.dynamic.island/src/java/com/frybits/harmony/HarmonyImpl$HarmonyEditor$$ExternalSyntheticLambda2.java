/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.ArrayList
 *  java.util.Set
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;
import com.frybits.harmony.HarmonyTransaction;
import java.util.ArrayList;
import java.util.Set;

public final class HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda2
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;
    public final /* synthetic */ HarmonyTransaction f$1;
    public final /* synthetic */ Set f$2;
    public final /* synthetic */ ArrayList f$3;

    public /* synthetic */ HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda2(HarmonyImpl harmonyImpl, HarmonyTransaction harmonyTransaction, Set set, ArrayList arrayList) {
        this.f$0 = harmonyImpl;
        this.f$1 = harmonyTransaction;
        this.f$2 = set;
        this.f$3 = arrayList;
    }

    public final void run() {
        HarmonyImpl.HarmonyEditor.$r8$lambda$BrDg2Ity3INnj_N_Et7iIZG3fqE(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

