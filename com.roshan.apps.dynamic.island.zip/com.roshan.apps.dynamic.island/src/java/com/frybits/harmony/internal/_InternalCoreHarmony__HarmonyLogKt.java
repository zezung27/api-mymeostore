/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package com.frybits.harmony.internal;

import kotlin.Metadata;

@Metadata(d1={"\u0000\b\n\u0000\n\u0002\u0010\u000b\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082D\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0002"}, d2={"LOG", "", "harmony_release"}, k=5, mv={1, 7, 1}, xi=48, xs="com/frybits/harmony/internal/_InternalCoreHarmony")
final class _InternalCoreHarmony__HarmonyLogKt {
    private static final boolean LOG;

    public static final /* synthetic */ boolean access$getLOG$p() {
        return LOG;
    }
}

