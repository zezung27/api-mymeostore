/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.FileObserver
 *  java.io.File
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Intrinsics
 */
package com.frybits.harmony.internal;

import android.os.FileObserver;
import java.io.File;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u0001BO\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00128\u0010\u0006\u001a4\u0012\u0013\u0012\u00110\u0005\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u00010\u000b\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\r0\u0007\u00a2\u0006\u0002\u0010\u000eJ\u001a\u0010\u000f\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\u00052\b\u0010\f\u001a\u0004\u0018\u00010\u000bH\u0016R@\u0010\u0006\u001a4\u0012\u0013\u0012\u00110\u0005\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u00010\u000b\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\r0\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0010"}, d2={"Lcom/frybits/harmony/internal/HarmonyFileObserverImpl;", "Landroid/os/FileObserver;", "file", "Ljava/io/File;", "eventFilter", "", "block", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "event", "", "path", "", "(Ljava/io/File;ILkotlin/jvm/functions/Function2;)V", "onEvent", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
final class HarmonyFileObserverImpl
extends FileObserver {
    private final Function2<Integer, String, Unit> block;

    public HarmonyFileObserverImpl(File file, int n, Function2<? super Integer, ? super String, Unit> function2) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        Intrinsics.checkNotNullParameter(function2, (String)"block");
        super(file.getPath(), n);
        this.block = function2;
    }

    public void onEvent(int n, String string2) {
        this.block.invoke((Object)n, (Object)string2);
    }
}

