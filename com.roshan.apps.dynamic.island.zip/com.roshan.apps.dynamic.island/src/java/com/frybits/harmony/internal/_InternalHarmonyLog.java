/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.frybits.harmony.internal;

import android.util.Log;
import com.frybits.harmony.HarmonyLog;
import com.frybits.harmony.LoggerKt;
import com.frybits.harmony.internal._InternalCoreHarmony__HarmonyLogKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\b\b\u00c1\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J)\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0000\u00a2\u0006\u0002\b\nJ)\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0000\u00a2\u0006\u0002\b\fJ\u001c\u0010\r\u001a\u00020\u00062\b\u0010\u0005\u001a\u0004\u0018\u00010\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006H\u0002J)\u0010\u000e\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0000\u00a2\u0006\u0002\b\u000fJ \u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0006H\u0002J\u0015\u0010\u0013\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\tH\u0000\u00a2\u0006\u0002\b\u0014J)\u0010\u0015\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0000\u00a2\u0006\u0002\b\u0016J$\u0010\u0017\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0001J)\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u00062\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\tH\u0000\u00a2\u0006\u0002\b\u0019\u00a8\u0006\u001a"}, d2={"Lcom/frybits/harmony/internal/_InternalHarmonyLog;", "", "()V", "d", "", "tag", "", "msg", "throwable", "", "d$harmony_release", "e", "e$harmony_release", "getMessage", "i", "i$harmony_release", "log", "priority", "", "recordException", "recordException$harmony_release", "v", "v$harmony_release", "w", "wtf", "wtf$harmony_release", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
public final class _InternalHarmonyLog {
    public static final _InternalHarmonyLog INSTANCE = new _InternalHarmonyLog();

    private _InternalHarmonyLog() {
    }

    public static /* synthetic */ void d$harmony_release$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.d$harmony_release(string2, string3, throwable);
    }

    public static /* synthetic */ void e$harmony_release$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.e$harmony_release(string2, string3, throwable);
    }

    private final String getMessage(String string2, String string3) {
        return string2 + ": " + string3;
    }

    public static /* synthetic */ void i$harmony_release$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.i$harmony_release(string2, string3, throwable);
    }

    private final void log(int n, String string2, String string3) {
        HarmonyLog harmonyLog = LoggerKt.get_harmonyLog();
        if (harmonyLog != null) {
            harmonyLog.log(n, this.getMessage(string2, string3));
        }
        if (_InternalCoreHarmony__HarmonyLogKt.access$getLOG$p()) {
            Log.println((int)n, (String)string2, (String)string3);
        }
    }

    public static /* synthetic */ void v$harmony_release$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.v$harmony_release(string2, string3, throwable);
    }

    public static /* synthetic */ void w$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.w(string2, string3, throwable);
    }

    public static /* synthetic */ void wtf$harmony_release$default(_InternalHarmonyLog _InternalHarmonyLog2, String string2, String string3, Throwable throwable, int n, Object object) {
        if ((n & 4) != 0) {
            throwable = null;
        }
        _InternalHarmonyLog2.wtf$harmony_release(string2, string3, throwable);
    }

    public final /* synthetic */ void d$harmony_release(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(3, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(3, string2, string4);
        }
    }

    public final /* synthetic */ void e$harmony_release(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(6, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(6, string2, string4);
        }
    }

    public final /* synthetic */ void i$harmony_release(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(4, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(4, string2, string4);
        }
    }

    public final /* synthetic */ void recordException$harmony_release(Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)throwable, (String)"throwable");
        HarmonyLog harmonyLog = LoggerKt.get_harmonyLog();
        if (harmonyLog != null) {
            harmonyLog.recordException(throwable);
        }
    }

    public final /* synthetic */ void v$harmony_release(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(2, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(2, string2, string4);
        }
    }

    public final /* synthetic */ void w(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(5, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(5, string2, string4);
        }
    }

    public final /* synthetic */ void wtf$harmony_release(String string2, String string3, Throwable throwable) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"tag");
        Intrinsics.checkNotNullParameter((Object)string3, (String)"msg");
        this.log(7, string2, string3);
        if (throwable != null) {
            _InternalHarmonyLog _InternalHarmonyLog2 = INSTANCE;
            String string4 = Log.getStackTraceString((Throwable)throwable);
            Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"getStackTraceString(it)");
            _InternalHarmonyLog2.log(7, string2, string4);
        }
    }
}

