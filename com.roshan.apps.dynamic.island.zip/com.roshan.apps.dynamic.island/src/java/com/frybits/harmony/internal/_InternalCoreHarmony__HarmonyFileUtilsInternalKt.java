/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileLock
 *  kotlin.Metadata
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.InlineMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.frybits.harmony.internal;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import kotlin.Metadata;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000\u001e\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a1\u0010\u0004\u001a\u0002H\u0005\"\u0004\b\u0000\u0010\u0005*\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\f\u0010\t\u001a\b\u0012\u0004\u0012\u0002H\u00050\nH\u0081\b\u00f8\u0001\u0000\u00a2\u0006\u0002\u0010\u000b\"\u0016\u0010\u0000\u001a\u00020\u00018\u0000X\u0081T\u00a2\u0006\b\n\u0000\u0012\u0004\b\u0002\u0010\u0003\u0082\u0002\u0007\n\u0005\b\u009920\u0001\u00a8\u0006\f"}, d2={"FILE_UTILS_LOG_TAG", "", "getFILE_UTILS_LOG_TAG$annotations", "()V", "withFileLock", "T", "Ljava/io/RandomAccessFile;", "shared", "", "block", "Lkotlin/Function0;", "(Ljava/io/RandomAccessFile;ZLkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "harmony_release"}, k=5, mv={1, 7, 1}, xi=48, xs="com/frybits/harmony/internal/_InternalCoreHarmony")
final class _InternalCoreHarmony__HarmonyFileUtilsInternalKt {
    public static /* synthetic */ void getFILE_UTILS_LOG_TAG$annotations() {
    }

    public static final /* synthetic */ <T> T withFileLock(RandomAccessFile randomAccessFile, boolean bl, Function0<? extends T> function0) throws IOException {
        Intrinsics.checkNotNullParameter((Object)randomAccessFile, (String)"<this>");
        Intrinsics.checkNotNullParameter(function0, (String)"block");
        FileLock fileLock = null;
        try {
            fileLock = randomAccessFile.getChannel().lock(0L, Long.MAX_VALUE, bl);
            Object object = function0.invoke();
            return (T)object;
        }
        finally {
            InlineMarker.finallyStart((int)1);
            if (fileLock != null) {
                try {
                    fileLock.release();
                }
                catch (IOException iOException) {
                    throw new IOException("Unable to release FileLock!", (Throwable)iOException);
                }
            }
            InlineMarker.finallyEnd((int)1);
        }
    }
}

