/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.JsonReader
 *  android.util.JsonToken
 *  android.util.JsonWriter
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.IOException
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.jvm.internal.Intrinsics
 */
package com.frybits.harmony.internal;

import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;
import dalvik.annotation.SourceDebugExtension;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nHarmonyJsonUtils.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HarmonyJsonUtils.kt\ncom/frybits/harmony/internal/_InternalCoreHarmony__HarmonyJsonUtilsKt\n+ 2 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,187:1\n211#2:188\n212#2:191\n1851#3,2:189\n*S KotlinDebug\n*F\n+ 1 HarmonyJsonUtils.kt\ncom/frybits/harmony/internal/_InternalCoreHarmony__HarmonyJsonUtilsKt\n*L\n139#1:188\n139#1:191\n173#1:189,2\n*E\n")
@Metadata(d1={"\u00002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a;\u0010\r\u001a\u0002H\u000e\"\b\b\u0000\u0010\u000e*\u00020\u000f*\u0002H\u000e2\u0006\u0010\u0010\u001a\u00020\u00012\u0016\u0010\u0011\u001a\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u0012H\u0000\u00a2\u0006\u0002\u0010\u0014\u001aM\u0010\u0015\u001a4\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0012(\u0012&\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u0017j\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u0013`\u00180\u0016\"\b\b\u0000\u0010\u000e*\u00020\u0019*\u0002H\u000eH\u0000\u00a2\u0006\u0002\u0010\u001a\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0003\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0005\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0007\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\t\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\n\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u000b\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\f\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001b"}, d2={"BOOLEAN", "", "DATA", "FLOAT", "INT", "KEY", "LONG", "METADATA", "NAME_KEY", "SET", "STRING", "TYPE", "VALUE", "putHarmony", "T", "Ljava/io/Writer;", "prefsName", "data", "", "", "(Ljava/io/Writer;Ljava/lang/String;Ljava/util/Map;)Ljava/io/Writer;", "readHarmony", "Lkotlin/Pair;", "Ljava/util/HashMap;", "Lkotlin/collections/HashMap;", "Ljava/io/Reader;", "(Ljava/io/Reader;)Lkotlin/Pair;", "harmony_release"}, k=5, mv={1, 7, 1}, xi=48, xs="com/frybits/harmony/internal/_InternalCoreHarmony")
final class _InternalCoreHarmony__HarmonyJsonUtilsKt {
    private static final String BOOLEAN = "boolean";
    private static final String DATA = "data";
    private static final String FLOAT = "float";
    private static final String INT = "int";
    private static final String KEY = "key";
    private static final String LONG = "long";
    private static final String METADATA = "metaData";
    private static final String NAME_KEY = "name";
    private static final String SET = "set";
    private static final String STRING = "string";
    private static final String TYPE = "type";
    private static final String VALUE = "value";

    public static final /* synthetic */ Writer putHarmony(Writer writer, String string2, Map map) {
        Intrinsics.checkNotNullParameter((Object)writer, (String)"<this>");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"prefsName");
        Intrinsics.checkNotNullParameter((Object)map, (String)DATA);
        JsonWriter jsonWriter = new JsonWriter(writer);
        jsonWriter.beginObject();
        jsonWriter.name(METADATA);
        jsonWriter.beginObject();
        jsonWriter.name(NAME_KEY).value(string2);
        jsonWriter.endObject();
        jsonWriter.name(DATA);
        jsonWriter.beginArray();
        for (Map.Entry entry : map.entrySet()) {
            String string3 = (String)entry.getKey();
            Object object = entry.getValue();
            jsonWriter.beginObject();
            if (object instanceof Integer) {
                jsonWriter.name(TYPE).value(INT);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE).value((Number)object);
            } else if (object instanceof Long) {
                jsonWriter.name(TYPE).value(LONG);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE).value(((Number)object).longValue());
            } else if (object instanceof Float) {
                jsonWriter.name(TYPE).value(FLOAT);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE).value((Number)object);
            } else if (object instanceof Boolean) {
                jsonWriter.name(TYPE).value(BOOLEAN);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE).value(((Boolean)object).booleanValue());
            } else if (object instanceof String) {
                jsonWriter.name(TYPE).value(STRING);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE).value((String)object);
            } else if (object instanceof Set) {
                jsonWriter.name(TYPE).value(SET);
                jsonWriter.name(KEY).value(string3);
                jsonWriter.name(VALUE);
                jsonWriter.beginArray();
                Intrinsics.checkNotNull((Object)object, (String)"null cannot be cast to non-null type kotlin.collections.Set<kotlin.String>");
                Iterator iterator = ((Iterable)((Set)object)).iterator();
                while (iterator.hasNext()) {
                    jsonWriter.value((String)iterator.next());
                }
                jsonWriter.endArray();
            }
            jsonWriter.endObject();
        }
        jsonWriter.endArray();
        jsonWriter.endObject();
        return writer;
    }

    public static final /* synthetic */ Pair readHarmony(Reader reader) throws IOException {
        Intrinsics.checkNotNullParameter((Object)reader, (String)"<this>");
        HashMap hashMap = new HashMap();
        JsonReader jsonReader = new JsonReader(reader);
        if (jsonReader.peek() == JsonToken.END_DOCUMENT) {
            return TuplesKt.to(null, (Object)hashMap);
        }
        jsonReader.beginObject();
        String string2 = null;
        String string3 = null;
        while (jsonReader.hasNext()) {
            JsonToken jsonToken = jsonReader.peek();
            int n = jsonToken == null ? -1 : WhenMappings.$EnumSwitchMapping$0[jsonToken.ordinal()];
            if (n != 1) {
                if (n != 2) {
                    if (n != 3) {
                        jsonReader.skipValue();
                        continue;
                    }
                    if (Intrinsics.areEqual((Object)string3, (Object)DATA)) {
                        jsonReader.beginArray();
                        while (jsonReader.hasNext()) {
                            jsonReader.beginObject();
                            String string4 = null;
                            String string5 = null;
                            block10 : while (jsonReader.hasNext()) {
                                String string6 = jsonReader.nextName();
                                if (string6 == null) continue;
                                int n2 = string6.hashCode();
                                if (n2 != 106079) {
                                    if (n2 != 3575610) {
                                        if (n2 != 111972721 || !string6.equals((Object)VALUE) || string4 == null) continue;
                                        switch (string4.hashCode()) {
                                            default: {
                                                continue block10;
                                            }
                                            case 97526364: {
                                                if (!string4.equals((Object)FLOAT)) continue block10;
                                                ((Map)hashMap).put((Object)string5, (Object)Float.valueOf((float)((float)jsonReader.nextDouble())));
                                                continue block10;
                                            }
                                            case 64711720: {
                                                if (!string4.equals((Object)BOOLEAN)) continue block10;
                                                ((Map)hashMap).put((Object)string5, (Object)jsonReader.nextBoolean());
                                                continue block10;
                                            }
                                            case 3327612: {
                                                if (!string4.equals((Object)LONG)) continue block10;
                                                ((Map)hashMap).put((Object)string5, (Object)jsonReader.nextLong());
                                                continue block10;
                                            }
                                            case 113762: {
                                                if (!string4.equals((Object)SET)) continue block10;
                                                Set set = (Set)new LinkedHashSet();
                                                jsonReader.beginArray();
                                                while (jsonReader.hasNext()) {
                                                    String string7 = jsonReader.nextString();
                                                    Intrinsics.checkNotNullExpressionValue((Object)string7, (String)"nextString()");
                                                    set.add((Object)string7);
                                                }
                                                jsonReader.endArray();
                                                ((Map)hashMap).put((Object)string5, (Object)set);
                                                continue block10;
                                            }
                                            case 104431: {
                                                if (!string4.equals((Object)INT)) continue block10;
                                                ((Map)hashMap).put((Object)string5, (Object)jsonReader.nextInt());
                                                continue block10;
                                            }
                                            case -891985903: 
                                        }
                                        if (!string4.equals((Object)STRING)) continue;
                                        ((Map)hashMap).put((Object)string5, (Object)jsonReader.nextString());
                                        continue;
                                    }
                                    if (!string6.equals((Object)TYPE)) continue;
                                    string4 = jsonReader.nextString();
                                    continue;
                                }
                                if (!string6.equals((Object)KEY)) continue;
                                if (jsonReader.peek() == JsonToken.NULL) {
                                    jsonReader.nextNull();
                                    (String)null;
                                    string5 = null;
                                    continue;
                                }
                                string5 = jsonReader.nextString();
                            }
                            jsonReader.endObject();
                        }
                        jsonReader.endArray();
                        continue;
                    }
                    jsonReader.skipValue();
                    continue;
                }
                if (Intrinsics.areEqual((Object)string3, (Object)METADATA)) {
                    jsonReader.beginObject();
                    if (Intrinsics.areEqual((Object)jsonReader.nextName(), (Object)NAME_KEY)) {
                        string2 = jsonReader.nextString();
                    }
                    jsonReader.endObject();
                    continue;
                }
                jsonReader.skipValue();
                continue;
            }
            string3 = jsonReader.nextName();
        }
        jsonReader.endObject();
        return TuplesKt.to(string2, (Object)hashMap);
    }

    @Metadata(k=3, mv={1, 7, 1}, xi=48)
    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] arrn = new int[JsonToken.values().length];
            arrn[JsonToken.NAME.ordinal()] = 1;
            arrn[JsonToken.BEGIN_OBJECT.ordinal()] = 2;
            arrn[JsonToken.BEGIN_ARRAY.ordinal()] = 3;
            $EnumSwitchMapping$0 = arrn;
        }
    }

}

