/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.FileObserver
 *  java.io.File
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Intrinsics
 */
package com.frybits.harmony.internal;

import android.os.FileObserver;
import com.frybits.harmony.internal.HarmonyFileObserverImpl;
import java.io.File;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000,\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\u001aR\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u000528\u0010\u0006\u001a4\u0012\u0013\u0012\u00110\u0005\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\n\u0012\u0015\u0012\u0013\u0018\u00010\u000b\u00a2\u0006\f\b\b\u0012\b\b\t\u0012\u0004\b\b(\f\u0012\u0004\u0012\u00020\r0\u0007H\u0000\u00a8\u0006\u000e"}, d2={"HarmonyFileObserver", "Landroid/os/FileObserver;", "file", "Ljava/io/File;", "eventFilter", "", "block", "Lkotlin/Function2;", "Lkotlin/ParameterName;", "name", "event", "", "path", "", "harmony_release"}, k=5, mv={1, 7, 1}, xi=48, xs="com/frybits/harmony/internal/_InternalCoreHarmony")
final class _InternalCoreHarmony__HarmonyFileObserverKt {
    public static final /* synthetic */ FileObserver HarmonyFileObserver(File file, int n, Function2 function2) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        Intrinsics.checkNotNullParameter((Object)function2, (String)"block");
        return new HarmonyFileObserverImpl(file, n, (Function2<? super Integer, ? super String, Unit>)function2);
    }
}

