/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.FileObserver
 *  java.io.File
 *  java.io.IOException
 *  java.io.RandomAccessFile
 *  java.io.Reader
 *  java.io.Writer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function2
 */
package com.frybits.harmony.internal;

import android.os.FileObserver;
import com.frybits.harmony.internal._InternalCoreHarmony__HarmonyFileObserverKt;
import com.frybits.harmony.internal._InternalCoreHarmony__HarmonyFileUtilsInternalKt;
import com.frybits.harmony.internal._InternalCoreHarmony__HarmonyJsonUtilsKt;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.Writer;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;

@Metadata(d1={"com/frybits/harmony/internal/_InternalCoreHarmony__HarmonyFileObserverKt", "com/frybits/harmony/internal/_InternalCoreHarmony__HarmonyFileUtilsInternalKt", "com/frybits/harmony/internal/_InternalCoreHarmony__HarmonyJsonUtilsKt", "com/frybits/harmony/internal/_InternalCoreHarmony__HarmonyLogKt"}, k=4, mv={1, 7, 1}, xi=48)
public final class _InternalCoreHarmony {
    public static final String FILE_UTILS_LOG_TAG = "HarmonyFileUtils";

    public static final /* synthetic */ FileObserver HarmonyFileObserver(File file, int n, Function2 function2) {
        return _InternalCoreHarmony__HarmonyFileObserverKt.HarmonyFileObserver(file, n, function2);
    }

    public static /* synthetic */ void getFILE_UTILS_LOG_TAG$annotations() {
        _InternalCoreHarmony__HarmonyFileUtilsInternalKt.getFILE_UTILS_LOG_TAG$annotations();
    }

    public static final /* synthetic */ Writer putHarmony(Writer writer, String string2, Map map) {
        return _InternalCoreHarmony__HarmonyJsonUtilsKt.putHarmony(writer, string2, map);
    }

    public static final /* synthetic */ Pair readHarmony(Reader reader) throws IOException {
        return _InternalCoreHarmony__HarmonyJsonUtilsKt.readHarmony(reader);
    }

    public static final /* synthetic */ <T> T withFileLock(RandomAccessFile randomAccessFile, boolean bl, Function0<? extends T> function0) throws IOException {
        return _InternalCoreHarmony__HarmonyFileUtilsInternalKt.withFileLock(randomAccessFile, bl, function0);
    }
}

