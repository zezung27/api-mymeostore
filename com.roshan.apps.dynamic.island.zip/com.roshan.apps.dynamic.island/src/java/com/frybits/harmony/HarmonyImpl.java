/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.FileObserver
 *  android.os.Handler
 *  android.os.HandlerThread
 *  android.os.Looper
 *  android.os.SystemClock
 *  com.frybits.harmony.HarmonyImpl$harmonyFileObserver
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.BufferedReader
 *  java.io.Closeable
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Comparable
 *  java.lang.Exception
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeSet
 *  java.util.UUID
 *  java.util.WeakHashMap
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  java.util.concurrent.FutureTask
 *  java.util.concurrent.LinkedBlockingQueue
 *  java.util.concurrent.locks.ReentrantReadWriteLock
 *  java.util.concurrent.locks.ReentrantReadWriteLock$ReadLock
 *  java.util.concurrent.locks.ReentrantReadWriteLock$WriteLock
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.MapsKt
 *  kotlin.collections.SetsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.io.CloseableKt
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 *  kotlin.text.Charsets
 *  kotlin.text.StringsKt
 *  org.json.JSONException
 */
package com.frybits.harmony;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.FileObserver;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import com.frybits.harmony.EmptyContent;
import com.frybits.harmony.Harmony;
import com.frybits.harmony.HarmonyImpl;
import com.frybits.harmony.HarmonyImpl$$ExternalSyntheticLambda3;
import com.frybits.harmony.HarmonyImpl$$ExternalSyntheticLambda4;
import com.frybits.harmony.HarmonyImpl$$ExternalSyntheticLambda5;
import com.frybits.harmony.HarmonyImpl$$ExternalSyntheticLambda6;
import com.frybits.harmony.HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda0;
import com.frybits.harmony.HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda1;
import com.frybits.harmony.HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda2;
import com.frybits.harmony.HarmonyTransaction;
import com.frybits.harmony.OnHarmonySharedPreferenceChangedListener;
import com.frybits.harmony.internal._InternalCoreHarmony;
import com.frybits.harmony.internal._InternalHarmonyLog;
import dalvik.annotation.SourceDebugExtension;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.collections.SetsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import org.json.JSONException;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@SourceDebugExtension(value="SMAP\nHarmony.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 FileUtils.kt\ncom/frybits/harmony/FileUtilsKt\n+ 4 HarmonyFileUtilsInternal.kt\ncom/frybits/harmony/internal/_InternalCoreHarmony__HarmonyFileUtilsInternalKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 6 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,1295:1\n1#2:1296\n38#3,6:1297\n50#3,4:1315\n44#3,13:1319\n39#3,5:1332\n50#3,4:1349\n44#3,13:1353\n39#3,5:1366\n50#3,4:1382\n44#3,13:1386\n38#3,6:1405\n50#3,4:1422\n44#3,13:1426\n38#3,6:1441\n50#3,4:1458\n44#3,13:1462\n40#4,6:1303\n47#4,4:1311\n40#4,6:1337\n47#4,4:1345\n40#4,11:1371\n40#4,11:1411\n40#4,11:1447\n1851#5,2:1309\n1851#5,2:1343\n1851#5,2:1399\n1851#5,2:1403\n1851#5,2:1439\n1851#5,2:1475\n1851#5:1477\n1851#5,2:1478\n1852#5:1480\n1851#5,2:1481\n1851#5:1483\n1851#5,2:1484\n1852#5:1486\n211#6,2:1401\n*S KotlinDebug\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyImpl\n*L\n304#1:1297,6\n304#1:1315,4\n304#1:1319,13\n390#1:1332,5\n390#1:1349,4\n390#1:1353,13\n511#1:1366,5\n511#1:1382,4\n511#1:1386,13\n621#1:1405,6\n621#1:1422,4\n621#1:1426,13\n431#1:1441,6\n431#1:1458,4\n431#1:1462,13\n304#1:1303,6\n304#1:1311,4\n390#1:1337,6\n390#1:1345,4\n511#1:1371,11\n621#1:1411,11\n431#1:1447,11\n349#1:1309,2\n470#1:1343,2\n553#1:1399,2\n582#1:1403,2\n720#1:1439,2\n489#1:1475,2\n497#1:1477\n498#1:1478,2\n497#1:1480\n600#1:1481,2\n608#1:1483\n609#1:1484,2\n608#1:1486\n568#1:1401,2\n*E\n")
@Metadata(d1={"\u0000\u00ca\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010%\n\u0002\b\u0003\n\u0002\u0010\u0007\n\u0002\b\u0004\n\u0002\u0010#\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\"\n\u0002\b\u0002\b\u0002\u0018\u00002\u00020\u0001:\u0001WB%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u00a2\u0006\u0002\u0010\nJ\b\u00104\u001a\u00020\u001dH\u0002J\b\u00105\u001a\u00020\u001dH\u0002J\b\u00106\u001a\u00020-H\u0002J\b\u00107\u001a\u00020-H\u0003J\u0013\u00108\u001a\u00020-2\b\u00109\u001a\u0004\u0018\u00010\u0005H\u0096\u0002J\b\u0010:\u001a\u00020;H\u0016J\u0014\u0010<\u001a\u000e\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0002\b\u00030=H\u0016J\u001a\u0010>\u001a\u00020-2\b\u00109\u001a\u0004\u0018\u00010\u00052\u0006\u0010?\u001a\u00020-H\u0016J\u001a\u0010@\u001a\u00020A2\b\u00109\u001a\u0004\u0018\u00010\u00052\u0006\u0010?\u001a\u00020AH\u0016J\u001a\u0010B\u001a\u00020\t2\b\u00109\u001a\u0004\u0018\u00010\u00052\u0006\u0010?\u001a\u00020\tH\u0016J\u001a\u0010C\u001a\u00020\u00072\b\u00109\u001a\u0004\u0018\u00010\u00052\u0006\u0010?\u001a\u00020\u0007H\u0016J\u001e\u0010D\u001a\u0004\u0018\u00010\u00052\b\u00109\u001a\u0004\u0018\u00010\u00052\b\u0010?\u001a\u0004\u0018\u00010\u0005H\u0016J.\u0010E\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010F2\b\u00109\u001a\u0004\u0018\u00010\u00052\u0010\u0010G\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0018\u00010FH\u0016J\b\u0010H\u001a\u00020\u001dH\u0003J\b\u0010I\u001a\u00020\u001dH\u0002J\b\u0010J\u001a\u00020\u001dH\u0002J\b\u0010K\u001a\u00020\u001dH\u0002J.\u0010L\u001a \u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0014\u0012\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00170N0M2\u0006\u0010O\u001a\u00020PH\u0002J\u0010\u0010Q\u001a\u00020\u001d2\u0006\u0010R\u001a\u00020&H\u0016J\b\u0010S\u001a\u00020\u001dH\u0002J\u0010\u0010T\u001a\u00020\u001d2\u0006\u0010R\u001a\u00020&H\u0016J\u001e\u0010U\u001a\n\u0012\u0004\u0012\u00020&\u0018\u00010V*\f\u0012\u0004\u0012\u00020&\u0012\u0002\b\u00030%H\u0002R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R6\u0010\u0015\u001a&\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0016j\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0017`\u00188\u0002@\u0002X\u0083\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u001b\u001a\u0010\u0012\f\u0012\n \u001e*\u0004\u0018\u00010\u001d0\u001d0\u001cX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020!0 X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\"\u001a\u00020!X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010#\u001a\u00020\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010$\u001a\u000e\u0012\u0004\u0012\u00020&\u0012\u0004\u0012\u00020\u00170%8\u0002X\u0083\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010'\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R2\u0010(\u001a&\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0016j\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0005\u0012\u0006\u0012\u0004\u0018\u00010\u0017`\u0018X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010)\u001a\u00020*X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020\u0012X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010,\u001a\u00020-X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010.\u001a\u00020-X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010/\u001a\b\u0012\u0004\u0012\u00020!00X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0016\u00101\u001a\b\u0012\u0004\u0012\u00020!0 8\u0002X\u0083\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u00102\u001a\u000203X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006X"}, d2={"Lcom/frybits/harmony/HarmonyImpl;", "Landroid/content/SharedPreferences;", "context", "Landroid/content/Context;", "prefsName", "", "transactionMaxByteSize", "", "transactionMaxBatchCount", "", "(Landroid/content/Context;Ljava/lang/String;JI)V", "harmonyFileObserver", "Landroid/os/FileObserver;", "harmonyHandler", "Landroid/os/Handler;", "harmonyHandlerThread", "Landroid/os/HandlerThread;", "harmonyMainBackupFile", "Ljava/io/File;", "harmonyMainFile", "harmonyMainLockFile", "harmonyMap", "Ljava/util/HashMap;", "", "Lkotlin/collections/HashMap;", "harmonyPrefsFolder", "harmonyTransactionsFile", "isLoadedTask", "Ljava/util/concurrent/FutureTask;", "", "kotlin.jvm.PlatformType", "lastReadTransactions", "Ljava/util/TreeSet;", "Lcom/frybits/harmony/HarmonyTransaction;", "lastTransaction", "lastTransactionPosition", "listenerMap", "Ljava/util/WeakHashMap;", "Landroid/content/SharedPreferences$OnSharedPreferenceChangeListener;", "mainHandler", "mainSnapshot", "mapReentrantReadWriteLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;", "oldHarmonyTransactionsFile", "shouldNotifyClearToListeners", "", "shouldSynchronizeFileObserver", "transactionQueue", "Ljava/util/concurrent/LinkedBlockingQueue;", "transactionSet", "transactionUpdateJob", "Ljava/lang/Runnable;", "awaitForLoad", "checkForRequiredFiles", "commitTransactionToDisk", "commitTransactionsToMain", "contains", "key", "edit", "Landroid/content/SharedPreferences$Editor;", "getAll", "", "getBoolean", "defValue", "getFloat", "", "getInt", "getLong", "getString", "getStringSet", "", "defValues", "handleMainUpdate", "handleMainUpdateWithFileLock", "handleTransactionUpdate", "initialLoad", "readHarmonyMapFromStream", "Lkotlin/Pair;", "", "prefsReader", "Ljava/io/Reader;", "registerOnSharedPreferenceChangeListener", "listener", "startFileObserver", "unregisterOnSharedPreferenceChangeListener", "toSafeSet", "", "HarmonyEditor", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
final class HarmonyImpl
implements SharedPreferences {
    private final FileObserver harmonyFileObserver;
    private final Handler harmonyHandler;
    private final HandlerThread harmonyHandlerThread;
    private final File harmonyMainBackupFile;
    private final File harmonyMainFile;
    private final File harmonyMainLockFile;
    private HashMap<String, Object> harmonyMap;
    private final File harmonyPrefsFolder;
    private final File harmonyTransactionsFile;
    private final FutureTask<Unit> isLoadedTask;
    private TreeSet<HarmonyTransaction> lastReadTransactions;
    private HarmonyTransaction lastTransaction;
    private long lastTransactionPosition;
    private final WeakHashMap<SharedPreferences.OnSharedPreferenceChangeListener, Object> listenerMap;
    private final Handler mainHandler;
    private HashMap<String, Object> mainSnapshot;
    private final ReentrantReadWriteLock mapReentrantReadWriteLock;
    private final File oldHarmonyTransactionsFile;
    private final String prefsName;
    private final boolean shouldNotifyClearToListeners;
    private final boolean shouldSynchronizeFileObserver;
    private final int transactionMaxBatchCount;
    private final long transactionMaxByteSize;
    private final LinkedBlockingQueue<HarmonyTransaction> transactionQueue;
    private final TreeSet<HarmonyTransaction> transactionSet;
    private Runnable transactionUpdateJob;

    public static /* synthetic */ void $r8$lambda$3HEFQMNEiowFIEm_wV9FdxF54_4(HarmonyImpl harmonyImpl) {
        HarmonyImpl.transactionUpdateJob$lambda-2(harmonyImpl);
    }

    public static /* synthetic */ Pair $r8$lambda$734rayo6TpDKKMzVLabndgPkG70(HarmonyImpl harmonyImpl) {
        return HarmonyImpl.initialLoad$lambda-21$lambda-16(harmonyImpl);
    }

    public static /* synthetic */ void $r8$lambda$HV7F5LOlEGAMzHOTRxHhzi9jEvY(HarmonyImpl harmonyImpl, Ref.BooleanRef booleanRef, Set set, ArrayList arrayList) {
        HarmonyImpl.handleTransactionUpdate$lambda-37$lambda-36$lambda-35(harmonyImpl, booleanRef, set, arrayList);
    }

    public static /* synthetic */ Unit $r8$lambda$JbZx2xhqu5H8w8MY6-eFqA-6GOI(HarmonyImpl harmonyImpl) {
        return HarmonyImpl.isLoadedTask$lambda-4(harmonyImpl);
    }

    public static /* synthetic */ void $r8$lambda$PacUEhhrhT0kAJ8hBjpg8f7UvhA(HarmonyImpl harmonyImpl) {
        HarmonyImpl.handleTransactionUpdate$lambda-37$lambda-29(harmonyImpl);
    }

    public static /* synthetic */ void $r8$lambda$eQDSMWLAj7Ed0ZIq2QLYQUvtep4(HarmonyImpl harmonyImpl, Ref.BooleanRef booleanRef, Set set, ArrayList arrayList) {
        HarmonyImpl.handleMainUpdate$lambda-50$lambda-49(harmonyImpl, booleanRef, set, arrayList);
    }

    public static /* synthetic */ Pair $r8$lambda$nsLa4beEnHOqP_dMlcDWh9jNb6I(HarmonyImpl harmonyImpl) {
        return HarmonyImpl.handleMainUpdate$lambda-40(harmonyImpl);
    }

    public HarmonyImpl(Context context, String string2, long l, int n) {
        Handler handler;
        FutureTask futureTask;
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"prefsName");
        this.prefsName = string2;
        this.transactionMaxByteSize = l;
        this.transactionMaxBatchCount = n;
        HandlerThread handlerThread = new HandlerThread("Harmony-" + string2);
        handlerThread.start();
        this.harmonyHandlerThread = handlerThread;
        File file = new File(Harmony.access$harmonyPrefsFolder(context), string2);
        if (!file.exists()) {
            file.mkdirs();
        }
        this.harmonyPrefsFolder = file;
        this.harmonyMainFile = new File(file, "prefs.data");
        this.harmonyMainLockFile = new File(file, "prefs.data.lock");
        this.harmonyTransactionsFile = new File(file, "prefs.transaction.data");
        this.oldHarmonyTransactionsFile = new File(file, "prefs.transaction.old");
        this.harmonyMainBackupFile = new File(file, "prefs.backup");
        this.harmonyHandler = handler = new Handler(handlerThread.getLooper());
        this.mainHandler = new Handler(context.getMainLooper());
        this.mapReentrantReadWriteLock = new ReentrantReadWriteLock();
        this.lastReadTransactions = SetsKt.sortedSetOf((Object[])new HarmonyTransaction[0]);
        this.lastTransaction = Harmony.access$getEMPTY_TRANSACTION$p();
        boolean bl = context.getApplicationContext().getApplicationInfo().targetSdkVersion >= 30;
        this.shouldNotifyClearToListeners = bl;
        String string3 = Build.MANUFACTURER;
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"MANUFACTURER");
        boolean bl2 = StringsKt.contains((CharSequence)string3, (CharSequence)"lge", (boolean)true) && Build.VERSION.SDK_INT <= 28;
        this.shouldSynchronizeFileObserver = bl2;
        this.transactionUpdateJob = new HarmonyImpl$$ExternalSyntheticLambda5(this);
        this.harmonyFileObserver = _InternalCoreHarmony.HarmonyFileObserver(file, 520, (Function2)new Function2<Integer, String, Unit>(this){
            final /* synthetic */ HarmonyImpl this$0;

            public static /* synthetic */ void $r8$lambda$giyZ-vvTfM4ImtXnZGQzIYJk92o(HarmonyImpl harmonyImpl) {
                harmonyFileObserver.1.invoke$lambda-1(harmonyImpl);
            }

            public static /* synthetic */ void $r8$lambda$kBb3xOdGsS4BoV0vyAWkTuP28RY(HarmonyImpl harmonyImpl) {
                harmonyFileObserver.1.invoke$lambda-0(harmonyImpl);
            }
            {
                this.this$0 = harmonyImpl;
                super(2);
            }

            private static final void invoke$lambda-0(HarmonyImpl harmonyImpl) {
                Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
                HarmonyImpl.access$handleMainUpdateWithFileLock(harmonyImpl);
            }

            private static final void invoke$lambda-1(HarmonyImpl harmonyImpl) {
                Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
                HarmonyImpl.access$setLastReadTransactions$p(harmonyImpl, SetsKt.sortedSetOf((Object[])new HarmonyTransaction[0]));
                HarmonyImpl.access$setLastTransactionPosition$p(harmonyImpl, 0L);
            }

            public final void invoke(int n, String string2) {
                CharSequence charSequence = string2;
                boolean bl = charSequence == null || StringsKt.isBlank((CharSequence)charSequence);
                if (bl) {
                    return;
                }
                if (n == 8) {
                    if (StringsKt.endsWith$default((String)string2, (String)"prefs.transaction.data", (boolean)false, (int)2, null)) {
                        HarmonyImpl.access$getHarmonyHandler$p(this.this$0).removeCallbacks(HarmonyImpl.access$getTransactionUpdateJob$p(this.this$0));
                        HarmonyImpl.access$getHarmonyHandler$p(this.this$0).post(HarmonyImpl.access$getTransactionUpdateJob$p(this.this$0));
                        return;
                    }
                    if (StringsKt.endsWith$default((String)string2, (String)"prefs.data", (boolean)false, (int)2, null)) {
                        HarmonyImpl.access$getHarmonyHandler$p(this.this$0).removeCallbacks(HarmonyImpl.access$getTransactionUpdateJob$p(this.this$0));
                        HarmonyImpl.access$getHarmonyHandler$p(this.this$0).post((Runnable)new com.frybits.harmony.HarmonyImpl$harmonyFileObserver$1$$ExternalSyntheticLambda0(this.this$0));
                        return;
                    }
                } else if (n == 512 && StringsKt.endsWith$default((String)string2, (String)"prefs.transaction.old", (boolean)false, (int)2, null)) {
                    HarmonyImpl.access$getHarmonyHandler$p(this.this$0).removeCallbacks(HarmonyImpl.access$getTransactionUpdateJob$p(this.this$0));
                    HarmonyImpl.access$getHarmonyHandler$p(this.this$0).post((Runnable)new com.frybits.harmony.HarmonyImpl$harmonyFileObserver$1$$ExternalSyntheticLambda1(this.this$0));
                }
            }
        });
        this.harmonyMap = new HashMap();
        this.mainSnapshot = new HashMap();
        this.transactionSet = SetsKt.sortedSetOf((Object[])new HarmonyTransaction[0]);
        this.transactionQueue = new LinkedBlockingQueue();
        this.listenerMap = new WeakHashMap();
        this.isLoadedTask = futureTask = new FutureTask((Callable)new HarmonyImpl$$ExternalSyntheticLambda6(this));
        int n2 = ((CharSequence)string2).length();
        boolean bl3 = false;
        if (n2 == 0) {
            bl3 = true;
        }
        if (!bl3 && !Harmony.access$getPosixRegex$p().containsMatchIn((CharSequence)string2)) {
            handler.post((Runnable)futureTask);
            return;
        }
        throw new IllegalArgumentException("Preference name is not valid: " + string2);
    }

    public static final /* synthetic */ Runnable access$getTransactionUpdateJob$p(HarmonyImpl harmonyImpl) {
        return harmonyImpl.transactionUpdateJob;
    }

    public static final /* synthetic */ void access$handleMainUpdateWithFileLock(HarmonyImpl harmonyImpl) {
        harmonyImpl.handleMainUpdateWithFileLock();
    }

    public static final /* synthetic */ void access$setLastReadTransactions$p(HarmonyImpl harmonyImpl, TreeSet treeSet) {
        harmonyImpl.lastReadTransactions = treeSet;
    }

    public static final /* synthetic */ void access$setLastTransaction$p(HarmonyImpl harmonyImpl, HarmonyTransaction harmonyTransaction) {
        harmonyImpl.lastTransaction = harmonyTransaction;
    }

    public static final /* synthetic */ void access$setLastTransactionPosition$p(HarmonyImpl harmonyImpl, long l) {
        harmonyImpl.lastTransactionPosition = l;
    }

    private final void awaitForLoad() {
        if (!this.isLoadedTask.isDone()) {
            this.isLoadedTask.get();
        }
    }

    private final void checkForRequiredFiles() {
        if (!this.harmonyPrefsFolder.exists()) {
            _InternalHarmonyLog.e$harmony_release$default(_InternalHarmonyLog.INSTANCE, "Harmony", "Harmony folder does not exist! Creating...", null, 4, null);
            if (this.harmonyPrefsFolder.mkdirs()) {
                this.harmonyMainLockFile.createNewFile();
                return;
            }
            throw new IOException("Unable to create harmony prefs directories");
        }
        if (!this.harmonyMainLockFile.exists()) {
            _InternalHarmonyLog.e$harmony_release$default(_InternalHarmonyLog.INSTANCE, "Harmony", "Harmony main lock file does not exist! Creating...", null, 4, null);
            this.harmonyMainLockFile.createNewFile();
        }
    }

    /*
     * Exception decompiling
     */
    private final boolean commitTransactionToDisk() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private final boolean commitTransactionsToMain() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private final void handleMainUpdate() {
        Closeable closeable;
        int n;
        int n2;
        ReentrantReadWriteLock.WriteLock writeLock;
        ReentrantReadWriteLock.ReadLock readLock;
        block22 : {
            Future future = Harmony.access$getIO_THREAD_POOL$p().submit((Callable)new HarmonyImpl$$ExternalSyntheticLambda3(this));
            File file = this.harmonyMainFile;
            Charset charset = Charsets.UTF_8;
            Reader reader = (Reader)new InputStreamReader((InputStream)new FileInputStream(file), charset);
            BufferedReader bufferedReader = reader instanceof BufferedReader ? (BufferedReader)reader : new BufferedReader(reader, 8192);
            closeable = (Closeable)bufferedReader;
            Pair<String, Map<String, Object>> pair = this.readHarmonyMapFromStream((Reader)((BufferedReader)closeable));
            CloseableKt.closeFinally((Closeable)closeable, null);
            Map map = (Map)pair.component2();
            ReentrantReadWriteLock reentrantReadWriteLock = this.mapReentrantReadWriteLock;
            readLock = reentrantReadWriteLock.readLock();
            int n3 = reentrantReadWriteLock.getWriteHoldCount();
            n = 0;
            n2 = n3 == 0 ? reentrantReadWriteLock.getReadHoldCount() : 0;
            for (int i = 0; i < n2; ++i) {
                readLock.unlock();
            }
            writeLock = reentrantReadWriteLock.writeLock();
            writeLock.lock();
            try {
                Set<SharedPreferences.OnSharedPreferenceChangeListener> set;
                ArrayList arrayList;
                Ref.BooleanRef booleanRef;
                boolean bl;
                block24 : {
                    Set set2;
                    HashMap<String, Object> hashMap;
                    block23 : {
                        hashMap = this.mainSnapshot;
                        this.mainSnapshot = new HashMap(map);
                        HashMap hashMap2 = new HashMap((Map)this.mainSnapshot);
                        Pair pair2 = (Pair)future.get();
                        set2 = (Set)pair2.component1();
                        boolean bl2 = (Boolean)pair2.component2();
                        this.transactionSet.removeAll((Collection)set2);
                        Iterator iterator = ((Iterable)this.transactionSet).iterator();
                        while (iterator.hasNext()) {
                            HarmonyTransaction.commitTransaction$default((HarmonyTransaction)iterator.next(), hashMap2, null, 2, null);
                        }
                        bl = true ^ ((Map)this.listenerMap).isEmpty();
                        arrayList = bl ? new ArrayList() : null;
                        set = bl ? this.toSafeSet(this.listenerMap) : null;
                        HashMap<String, Object> hashMap3 = this.harmonyMap;
                        this.harmonyMap = hashMap2;
                        booleanRef = new Ref.BooleanRef();
                        if (!bl2) break block23;
                        _InternalHarmonyLog.e$harmony_release$default(_InternalHarmonyLog.INSTANCE, "Harmony", "Old transaction file was corrupted", null, 4, null);
                        if (arrayList != null) {
                            arrayList.clear();
                        }
                        if (!(true ^ ((Map)this.harmonyMap).isEmpty())) break block24;
                        for (Map.Entry entry : ((Map)this.harmonyMap).entrySet()) {
                            String string2 = (String)entry.getKey();
                            Object object = entry.getValue();
                            if (!(hashMap3.containsKey((Object)string2) && Intrinsics.areEqual((Object)hashMap3.get((Object)string2), (Object)object) || arrayList == null)) {
                                arrayList.add((Object)string2);
                            }
                            hashMap3.remove((Object)string2);
                        }
                        if (arrayList == null) break block24;
                        arrayList.addAll((Collection)hashMap3.keySet());
                        break block24;
                    }
                    TreeSet treeSet = SetsKt.sortedSetOf((Object[])new HarmonyTransaction[0]);
                    treeSet.addAll((Collection)set2);
                    treeSet.addAll((Collection)this.transactionSet);
                    for (HarmonyTransaction harmonyTransaction : (Iterable)treeSet) {
                        if (this.lastTransaction.compareTo(harmonyTransaction) < 0) {
                            if (harmonyTransaction.getCleared()) {
                                booleanRef.element = true;
                            }
                            harmonyTransaction.commitTransaction(hashMap, (List<String>)((List)arrayList));
                            this.lastTransaction = harmonyTransaction;
                            continue;
                        }
                        HarmonyTransaction.commitTransaction$default(harmonyTransaction, hashMap, null, 2, null);
                    }
                }
                if (!bl) break block22;
                if (arrayList == null) throw new IllegalArgumentException("Required value was null.".toString());
                this.mainHandler.post((Runnable)new HarmonyImpl$$ExternalSyntheticLambda4(this, booleanRef, set, arrayList));
            }
            catch (Throwable throwable) {
                do {
                    if (n >= n2) {
                        writeLock.unlock();
                        throw throwable;
                    }
                    readLock.lock();
                    ++n;
                } while (true);
            }
        }
        do {
            if (n >= n2) {
                writeLock.unlock();
                return;
            }
            readLock.lock();
            ++n;
        } while (true);
        catch (Throwable throwable) {
            try {
                throw throwable;
            }
            catch (Throwable throwable2) {
                try {
                    CloseableKt.closeFinally((Closeable)closeable, (Throwable)throwable);
                    throw throwable2;
                }
                catch (IOException iOException) {
                    _InternalHarmonyLog.INSTANCE.e$harmony_release("Harmony", "Unable to get main file.", iOException);
                    return;
                }
            }
        }
    }

    /*
     * Exception decompiling
     */
    private static final Pair handleMainUpdate$lambda-40(HarmonyImpl var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static final void handleMainUpdate$lambda-50$lambda-49(HarmonyImpl harmonyImpl, Ref.BooleanRef booleanRef, Set set, ArrayList arrayList) {
        Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
        Intrinsics.checkNotNullParameter((Object)booleanRef, (String)"$wasCleared");
        if (harmonyImpl.shouldNotifyClearToListeners && booleanRef.element && set != null) {
            for (SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener : (Iterable)set) {
                if (onSharedPreferenceChangeListener instanceof OnHarmonySharedPreferenceChangedListener) {
                    ((OnHarmonySharedPreferenceChangedListener)onSharedPreferenceChangeListener).onSharedPreferencesCleared(harmonyImpl);
                    continue;
                }
                onSharedPreferenceChangeListener.onSharedPreferenceChanged((SharedPreferences)harmonyImpl, null);
            }
        }
        for (String string2 : (Iterable)CollectionsKt.asReversedMutable((List)((List)arrayList))) {
            if (set == null) continue;
            Iterator iterator = ((Iterable)set).iterator();
            while (iterator.hasNext()) {
                ((SharedPreferences.OnSharedPreferenceChangeListener)iterator.next()).onSharedPreferenceChanged((SharedPreferences)harmonyImpl, string2);
            }
        }
    }

    /*
     * Exception decompiling
     */
    private final void handleMainUpdateWithFileLock() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 18[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private final void handleTransactionUpdate() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl333 : FAKE_TRY : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private static final void handleTransactionUpdate$lambda-37$lambda-29(HarmonyImpl var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[TRYBLOCK]], but top level block is 23[CATCHBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static final void handleTransactionUpdate$lambda-37$lambda-36$lambda-35(HarmonyImpl harmonyImpl, Ref.BooleanRef booleanRef, Set set, ArrayList arrayList) {
        Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
        Intrinsics.checkNotNullParameter((Object)booleanRef, (String)"$wasCleared");
        if (harmonyImpl.shouldNotifyClearToListeners && booleanRef.element && set != null) {
            for (SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener : (Iterable)set) {
                if (onSharedPreferenceChangeListener instanceof OnHarmonySharedPreferenceChangedListener) {
                    ((OnHarmonySharedPreferenceChangedListener)onSharedPreferenceChangeListener).onSharedPreferencesCleared(harmonyImpl);
                    continue;
                }
                onSharedPreferenceChangeListener.onSharedPreferenceChanged((SharedPreferences)harmonyImpl, null);
            }
        }
        for (String string2 : (Iterable)CollectionsKt.asReversedMutable((List)((List)arrayList))) {
            if (set == null) continue;
            Iterator iterator = ((Iterable)set).iterator();
            while (iterator.hasNext()) {
                ((SharedPreferences.OnSharedPreferenceChangeListener)iterator.next()).onSharedPreferenceChanged((SharedPreferences)harmonyImpl, string2);
            }
        }
    }

    /*
     * Exception decompiling
     */
    private final void initialLoad() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 7[TRYBLOCK]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    private static final Pair initialLoad$lambda-21$lambda-16(HarmonyImpl var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl83 : INVOKESTATIC : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static final Unit isLoadedTask$lambda-4(HarmonyImpl harmonyImpl) {
        Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
        harmonyImpl.initialLoad();
        if (harmonyImpl.shouldSynchronizeFileObserver) {
            Object object;
            Object object2 = object = Harmony.access$getFILE_OBSERVER_SYNC_OBJECT$p();
            synchronized (object2) {
                harmonyImpl.startFileObserver();
            }
        } else {
            harmonyImpl.startFileObserver();
        }
        return Unit.INSTANCE;
    }

    private final Pair<String, Map<String, Object>> readHarmonyMapFromStream(Reader reader) {
        try {
            Pair pair = _InternalCoreHarmony.readHarmony(reader);
            return pair;
        }
        catch (IOException iOException) {
            _InternalHarmonyLog.INSTANCE.e$harmony_release("Harmony", "IOException occurred while reading json", iOException);
            return TuplesKt.to(null, (Object)MapsKt.emptyMap());
        }
        catch (JSONException jSONException) {
            _InternalHarmonyLog.INSTANCE.e$harmony_release("Harmony", "JSONException while reading data file", jSONException);
            return TuplesKt.to(null, (Object)MapsKt.emptyMap());
        }
        catch (IllegalStateException illegalStateException) {
            _InternalHarmonyLog.INSTANCE.e$harmony_release("Harmony", "IllegalStateException while reading data file", illegalStateException);
            return TuplesKt.to(null, (Object)MapsKt.emptyMap());
        }
    }

    private final void startFileObserver() {
        this.harmonyFileObserver.startWatching();
    }

    /*
     * Exception decompiling
     */
    private final Set<SharedPreferences.OnSharedPreferenceChangeListener> toSafeSet(WeakHashMap<SharedPreferences.OnSharedPreferenceChangeListener, ?> var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl71 : ALOAD : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    private static final void transactionUpdateJob$lambda-2(HarmonyImpl harmonyImpl) {
        Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
        harmonyImpl.handleTransactionUpdate();
    }

    public boolean contains(String string2) {
        this.awaitForLoad();
        ReentrantReadWriteLock.ReadLock readLock = this.mapReentrantReadWriteLock.readLock();
        readLock.lock();
        try {
            boolean bl = this.harmonyMap.containsKey((Object)string2);
            return bl;
        }
        finally {
            readLock.unlock();
        }
    }

    public SharedPreferences.Editor edit() {
        this.awaitForLoad();
        return new HarmonyEditor();
    }

    public Map<String, ?> getAll() {
        this.awaitForLoad();
        ReentrantReadWriteLock.ReadLock readLock = this.mapReentrantReadWriteLock.readLock();
        readLock.lock();
        try {
            Map map = MapsKt.toMutableMap((Map)((Map)this.harmonyMap));
            return map;
        }
        finally {
            readLock.unlock();
        }
    }

    public boolean getBoolean(String string2, boolean bl) {
        ReentrantReadWriteLock.ReadLock readLock;
        block3 : {
            this.awaitForLoad();
            readLock = this.mapReentrantReadWriteLock.readLock();
            readLock.lock();
            Object object = this.harmonyMap.get((Object)string2);
            Boolean bl2 = (Boolean)object;
            if (bl2 == null) break block3;
            bl = bl2;
        }
        return bl;
        finally {
            readLock.unlock();
        }
    }

    public float getFloat(String string2, float f) {
        ReentrantReadWriteLock.ReadLock readLock;
        block3 : {
            this.awaitForLoad();
            readLock = this.mapReentrantReadWriteLock.readLock();
            readLock.lock();
            Object object = this.harmonyMap.get((Object)string2);
            Float f2 = (Float)object;
            if (f2 == null) break block3;
            f = f2.floatValue();
        }
        return f;
        finally {
            readLock.unlock();
        }
    }

    public int getInt(String string2, int n) {
        ReentrantReadWriteLock.ReadLock readLock;
        block3 : {
            this.awaitForLoad();
            readLock = this.mapReentrantReadWriteLock.readLock();
            readLock.lock();
            Object object = this.harmonyMap.get((Object)string2);
            Integer n2 = (Integer)object;
            if (n2 == null) break block3;
            n = n2;
        }
        return n;
        finally {
            readLock.unlock();
        }
    }

    public long getLong(String string2, long l) {
        ReentrantReadWriteLock.ReadLock readLock;
        block3 : {
            this.awaitForLoad();
            readLock = this.mapReentrantReadWriteLock.readLock();
            readLock.lock();
            Object object = this.harmonyMap.get((Object)string2);
            Long l2 = (Long)object;
            if (l2 == null) break block3;
            l = l2;
        }
        return l;
        finally {
            readLock.unlock();
        }
    }

    public String getString(String string2, String string3) {
        this.awaitForLoad();
        ReentrantReadWriteLock.ReadLock readLock = this.mapReentrantReadWriteLock.readLock();
        readLock.lock();
        try {
            Object object = this.harmonyMap.get((Object)string2);
            String string4 = (String)object;
            if (string4 == null) {
                return string3;
            }
            return string4;
        }
        finally {
            readLock.unlock();
        }
    }

    public Set<String> getStringSet(String string2, Set<String> set) {
        Set set2;
        this.awaitForLoad();
        ReentrantReadWriteLock.ReadLock readLock = this.mapReentrantReadWriteLock.readLock();
        readLock.lock();
        Object object = this.harmonyMap.get((Object)string2);
        Set set3 = (Set)object;
        if (set3 == null || (set2 = CollectionsKt.toMutableSet((Iterable)((Iterable)set3))) == null) {
            set2 = (Set)new HashSet();
        }
        if (set2.size() > 0) {
            set = set2;
        }
        return set;
        finally {
            readLock.unlock();
        }
    }

    public void registerOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener) {
        Intrinsics.checkNotNullParameter((Object)onSharedPreferenceChangeListener, (String)"listener");
        ReentrantReadWriteLock reentrantReadWriteLock = this.mapReentrantReadWriteLock;
        ReentrantReadWriteLock.ReadLock readLock = reentrantReadWriteLock.readLock();
        int n = reentrantReadWriteLock.getWriteHoldCount();
        int n2 = 0;
        int n3 = n == 0 ? reentrantReadWriteLock.getReadHoldCount() : 0;
        for (int i = 0; i < n3; ++i) {
            readLock.unlock();
        }
        ReentrantReadWriteLock.WriteLock writeLock = reentrantReadWriteLock.writeLock();
        writeLock.lock();
        try {
            ((Map)this.listenerMap).put((Object)onSharedPreferenceChangeListener, (Object)EmptyContent.INSTANCE);
            return;
        }
        finally {
            while (n2 < n3) {
                readLock.lock();
                ++n2;
            }
            writeLock.unlock();
        }
    }

    public void unregisterOnSharedPreferenceChangeListener(SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener) {
        Intrinsics.checkNotNullParameter((Object)onSharedPreferenceChangeListener, (String)"listener");
        ReentrantReadWriteLock reentrantReadWriteLock = this.mapReentrantReadWriteLock;
        ReentrantReadWriteLock.ReadLock readLock = reentrantReadWriteLock.readLock();
        int n = reentrantReadWriteLock.getWriteHoldCount();
        int n2 = 0;
        int n3 = n == 0 ? reentrantReadWriteLock.getReadHoldCount() : 0;
        for (int i = 0; i < n3; ++i) {
            readLock.unlock();
        }
        ReentrantReadWriteLock.WriteLock writeLock = reentrantReadWriteLock.writeLock();
        writeLock.lock();
        try {
            this.listenerMap.remove((Object)onSharedPreferenceChangeListener);
            return;
        }
        finally {
            while (n2 < n3) {
                readLock.lock();
                ++n2;
            }
            writeLock.unlock();
        }
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    @SourceDebugExtension(value="SMAP\nHarmony.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyImpl$HarmonyEditor\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1295:1\n1851#2,2:1296\n1851#2:1298\n1851#2,2:1299\n1852#2:1301\n*S KotlinDebug\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyImpl$HarmonyEditor\n*L\n881#1:1296,2\n889#1:1298\n890#1:1299,2\n889#1:1301\n*E\n")
    @Metadata(d1={"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010#\n\u0002\b\u0002\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0005\u001a\u00020\u0006H\u0016J\b\u0010\u0007\u001a\u00020\u0001H\u0016J\b\u0010\b\u001a\u00020\tH\u0016J\b\u0010\n\u001a\u00020\u0006H\u0002J\u001a\u0010\u000b\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\tH\u0016J\u001a\u0010\u000f\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u0010H\u0016J\u001a\u0010\u0011\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u0012H\u0016J\u001a\u0010\u0013\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\u0006\u0010\u000e\u001a\u00020\u0014H\u0016J\u001c\u0010\u0015\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\rH\u0016J$\u0010\u0016\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\r2\u0010\u0010\u0017\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\r\u0018\u00010\u0018H\u0016J\u0012\u0010\u0019\u001a\u00020\u00012\b\u0010\f\u001a\u0004\u0018\u00010\rH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001a"}, d2={"Lcom/frybits/harmony/HarmonyImpl$HarmonyEditor;", "Landroid/content/SharedPreferences$Editor;", "(Lcom/frybits/harmony/HarmonyImpl;)V", "harmonyTransaction", "Lcom/frybits/harmony/HarmonyTransaction;", "apply", "", "clear", "commit", "", "commitToMemory", "putBoolean", "key", "", "value", "putFloat", "", "putInt", "", "putLong", "", "putString", "putStringSet", "values", "", "remove", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
    private final class HarmonyEditor
    implements SharedPreferences.Editor {
        private HarmonyTransaction harmonyTransaction = new HarmonyTransaction(null, 1, null);

        public static /* synthetic */ Boolean $r8$lambda$4I7RR90CnZIkljiiDAinEU_qaoY(HarmonyImpl harmonyImpl) {
            return HarmonyEditor.commit$lambda-9(harmonyImpl);
        }

        public static /* synthetic */ void $r8$lambda$BrDg2Ity3INnj_N_Et7iIZG3fqE(HarmonyImpl harmonyImpl, HarmonyTransaction harmonyTransaction, Set set, ArrayList arrayList) {
            HarmonyEditor.commitToMemory$lambda-15$lambda-14(harmonyImpl, harmonyTransaction, set, arrayList);
        }

        public static /* synthetic */ void $r8$lambda$xourV67xvj-3QspvJlNL-yNvr34(HarmonyImpl harmonyImpl) {
            HarmonyEditor.apply$lambda-8(harmonyImpl);
        }

        private static final void apply$lambda-8(HarmonyImpl harmonyImpl) {
            Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
            if (true ^ ((Collection)harmonyImpl.transactionQueue).isEmpty()) {
                harmonyImpl.commitTransactionToDisk();
            }
        }

        private static final Boolean commit$lambda-9(HarmonyImpl harmonyImpl) {
            Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
            return harmonyImpl.commitTransactionToDisk();
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        private final void commitToMemory() {
            HarmonyTransaction harmonyTransaction;
            ReentrantReadWriteLock reentrantReadWriteLock = HarmonyImpl.this.mapReentrantReadWriteLock;
            HarmonyImpl harmonyImpl = HarmonyImpl.this;
            ReentrantReadWriteLock.ReadLock readLock = reentrantReadWriteLock.readLock();
            int n = reentrantReadWriteLock.getWriteHoldCount();
            int n2 = 0;
            int n3 = n == 0 ? reentrantReadWriteLock.getReadHoldCount() : 0;
            for (int i = 0; i < n3; ++i) {
                readLock.unlock();
            }
            ReentrantReadWriteLock.WriteLock writeLock = reentrantReadWriteLock.writeLock();
            writeLock.lock();
            boolean bl = true ^ ((Map)harmonyImpl.listenerMap).isEmpty();
            ArrayList arrayList = bl ? new ArrayList() : null;
            Set set = bl ? harmonyImpl.toSafeSet(harmonyImpl.listenerMap) : null;
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                harmonyTransaction = this.harmonyTransaction;
            }
            {
                harmonyTransaction.setMemoryCommitTime(SystemClock.elapsedRealtimeNanos());
                harmonyImpl.transactionSet.add((Object)harmonyTransaction);
                harmonyImpl.transactionQueue.put((Object)harmonyTransaction);
                HarmonyImpl.access$setLastTransaction$p(harmonyImpl, (HarmonyTransaction)ComparisonsKt.maxOf((Comparable)harmonyTransaction, (Comparable)harmonyImpl.lastTransaction));
                this.harmonyTransaction = new HarmonyTransaction(null, 1, null);
                harmonyTransaction.commitTransaction((HashMap<String, Object>)harmonyImpl.harmonyMap, (List<String>)((List)arrayList));
            }
            if (!bl) return;
            if (arrayList == null) throw new IllegalArgumentException("Required value was null.".toString());
            try {
                harmonyImpl.mainHandler.post((Runnable)new HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda2(harmonyImpl, harmonyTransaction, set, arrayList));
                return;
            }
            finally {
                do {
                    if (n2 >= n3) {
                        writeLock.unlock();
                    }
                    readLock.lock();
                    ++n2;
                } while (true);
            }
        }

        private static final void commitToMemory$lambda-15$lambda-14(HarmonyImpl harmonyImpl, HarmonyTransaction harmonyTransaction, Set set, ArrayList arrayList) {
            Intrinsics.checkNotNullParameter((Object)harmonyImpl, (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)harmonyTransaction, (String)"$transaction");
            if (harmonyImpl.shouldNotifyClearToListeners && harmonyTransaction.getCleared() && set != null) {
                for (SharedPreferences.OnSharedPreferenceChangeListener onSharedPreferenceChangeListener : (Iterable)set) {
                    if (onSharedPreferenceChangeListener instanceof OnHarmonySharedPreferenceChangedListener) {
                        ((OnHarmonySharedPreferenceChangedListener)onSharedPreferenceChangeListener).onSharedPreferencesCleared(harmonyImpl);
                        continue;
                    }
                    onSharedPreferenceChangeListener.onSharedPreferenceChanged((SharedPreferences)harmonyImpl, null);
                }
            }
            for (String string2 : (Iterable)CollectionsKt.asReversedMutable((List)((List)arrayList))) {
                if (set == null) continue;
                Iterator iterator = ((Iterable)set).iterator();
                while (iterator.hasNext()) {
                    ((SharedPreferences.OnSharedPreferenceChangeListener)iterator.next()).onSharedPreferenceChanged((SharedPreferences)harmonyImpl, string2);
                }
            }
        }

        public void apply() {
            this.commitToMemory();
            HarmonyImpl.this.harmonyHandler.post((Runnable)new HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda0(HarmonyImpl.this));
        }

        public SharedPreferences.Editor clear() {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.clear();
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        public boolean commit() {
            this.commitToMemory();
            FutureTask futureTask = new FutureTask((Callable)new HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda1(HarmonyImpl.this));
            HarmonyImpl.this.harmonyHandler.post((Runnable)futureTask);
            try {
                Object object = futureTask.get();
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"{\n                runnab\u2026 the commit\n            }");
                boolean bl = (Boolean)object;
                return bl;
            }
            catch (Exception exception) {
                return false;
            }
        }

        public SharedPreferences.Editor putBoolean(String string2, boolean bl) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.update(string2, bl);
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        public SharedPreferences.Editor putFloat(String string2, float f) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.update(string2, (Object)Float.valueOf((float)f));
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        public SharedPreferences.Editor putInt(String string2, int n) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.update(string2, n);
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        public SharedPreferences.Editor putLong(String string2, long l) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.update(string2, l);
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        public SharedPreferences.Editor putString(String string2, String string3) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.update(string2, string3);
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public SharedPreferences.Editor putStringSet(String string2, Set<String> set) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                HarmonyTransaction harmonyTransaction = this.harmonyTransaction;
                HashSet hashSet = set != null ? CollectionsKt.toHashSet((Iterable)((Iterable)set)) : null;
                harmonyTransaction.update(string2, (Object)hashSet);
                return this;
            }
        }

        public SharedPreferences.Editor remove(String string2) {
            HarmonyEditor harmonyEditor = this;
            synchronized (harmonyEditor) {
                this.harmonyTransaction.delete(string2);
                SharedPreferences.Editor editor = this;
                return editor;
            }
        }
    }

}

