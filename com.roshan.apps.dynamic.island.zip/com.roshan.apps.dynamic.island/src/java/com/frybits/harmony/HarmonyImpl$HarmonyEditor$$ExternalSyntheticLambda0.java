/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;

public final class HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda0(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final void run() {
        HarmonyImpl.HarmonyEditor.$r8$lambda$xourV67xvj-3QspvJlNL-yNvr34(this.f$0);
    }
}

