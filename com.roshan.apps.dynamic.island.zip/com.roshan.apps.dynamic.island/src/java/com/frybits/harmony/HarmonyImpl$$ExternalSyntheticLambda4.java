/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.ArrayList
 *  java.util.Set
 *  kotlin.jvm.internal.Ref
 *  kotlin.jvm.internal.Ref$BooleanRef
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;
import java.util.ArrayList;
import java.util.Set;
import kotlin.jvm.internal.Ref;

public final class HarmonyImpl$$ExternalSyntheticLambda4
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;
    public final /* synthetic */ Ref.BooleanRef f$1;
    public final /* synthetic */ Set f$2;
    public final /* synthetic */ ArrayList f$3;

    public /* synthetic */ HarmonyImpl$$ExternalSyntheticLambda4(HarmonyImpl harmonyImpl, Ref.BooleanRef booleanRef, Set set, ArrayList arrayList) {
        this.f$0 = harmonyImpl;
        this.f$1 = booleanRef;
        this.f$2 = set;
        this.f$3 = arrayList;
    }

    public final void run() {
        HarmonyImpl.$r8$lambda$eQDSMWLAj7Ed0ZIq2QLYQUvtep4(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

