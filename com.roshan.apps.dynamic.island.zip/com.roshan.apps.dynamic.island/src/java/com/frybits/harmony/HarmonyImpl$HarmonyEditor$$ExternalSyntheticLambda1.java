/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;
import java.util.concurrent.Callable;

public final class HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda1
implements Callable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$HarmonyEditor$$ExternalSyntheticLambda1(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final Object call() {
        return HarmonyImpl.HarmonyEditor.$r8$lambda$4I7RR90CnZIkljiiDAinEU_qaoY(this.f$0);
    }
}

