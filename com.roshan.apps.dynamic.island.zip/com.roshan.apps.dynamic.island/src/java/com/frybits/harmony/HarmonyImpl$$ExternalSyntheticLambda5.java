/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;

public final class HarmonyImpl$$ExternalSyntheticLambda5
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$$ExternalSyntheticLambda5(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final void run() {
        HarmonyImpl.$r8$lambda$3HEFQMNEiowFIEm_wV9FdxF54_4(this.f$0);
    }
}

