/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;

public final class HarmonyImpl$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$$ExternalSyntheticLambda0(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final void run() {
        HarmonyImpl.$r8$lambda$PacUEhhrhT0kAJ8hBjpg8f7UvhA(this.f$0);
    }
}

