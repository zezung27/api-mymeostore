/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyLog;
import kotlin.Metadata;

@Metadata(d1={"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\"\u001c\u0010\u0000\u001a\u0004\u0018\u00010\u0001X\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u0002\u0010\u0003\"\u0004\b\u0004\u0010\u0005\u00a8\u0006\u0006"}, d2={"_harmonyLog", "Lcom/frybits/harmony/HarmonyLog;", "get_harmonyLog", "()Lcom/frybits/harmony/HarmonyLog;", "set_harmonyLog", "(Lcom/frybits/harmony/HarmonyLog;)V", "harmony_release"}, k=2, mv={1, 7, 1}, xi=48)
public final class LoggerKt {
    private static volatile /* synthetic */ HarmonyLog _harmonyLog;

    public static final HarmonyLog get_harmonyLog() {
        return _harmonyLog;
    }

    public static final void set_harmonyLog(HarmonyLog harmonyLog) {
        _harmonyLog = harmonyLog;
    }
}

