/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.DataOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Comparable
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.UUID
 *  java.util.zip.Adler32
 *  java.util.zip.CheckedOutputStream
 *  java.util.zip.Checksum
 *  kotlin.Metadata
 *  kotlin.NoWhenBranchMatchedException
 *  kotlin.Pair
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Charsets
 */
package com.frybits.harmony;

import com.frybits.harmony.Harmony;
import dalvik.annotation.SourceDebugExtension;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.zip.Adler32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.Checksum;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

@SourceDebugExtension(value="SMAP\nHarmony.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyTransaction\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1295:1\n1#2:1296\n211#3,2:1297\n211#3:1299\n212#3:1302\n1851#4,2:1300\n*S KotlinDebug\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyTransaction\n*L\n957#1:1297,2\n983#1:1299\n983#1:1302\n1016#1:1300,2\n*E\n")
@Metadata(d1={"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u000b\b\u0002\u0018\u0000 )2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0002)*B\u000f\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0006\u0010\u0015\u001a\u00020\u0016JF\u0010\u0017\u001a\u00020\u00162*\u0010\u0018\u001a&\u0012\u0006\u0012\u0004\u0018\u00010\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u00190\u0011j\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0012\u0012\u0006\u0012\u0004\u0018\u00010\u0019`\u00142\u0012\b\u0002\u0010\u001a\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0012\u0018\u00010\u001bJ\u000e\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\u001eJ\u0011\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u0000H\u0096\u0002J\u0010\u0010\"\u001a\u00020\u00162\b\u0010#\u001a\u0004\u0018\u00010\u0012J\u0013\u0010$\u001a\u00020\u00062\b\u0010!\u001a\u0004\u0018\u00010\u0019H\u0096\u0002J\b\u0010%\u001a\u00020 H\u0016J\b\u0010&\u001a\u00020\u0012H\u0016J\u001a\u0010'\u001a\u00020\u00162\b\u0010#\u001a\u0004\u0018\u00010\u00122\b\u0010(\u001a\u0004\u0018\u00010\u0019R\u001e\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0006@BX\u0086\u000e\u00a2\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u001a\u0010\n\u001a\u00020\u000bX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\f\u0010\r\"\u0004\b\u000e\u0010\u000fR.\u0010\u0010\u001a\"\u0012\u0006\u0012\u0004\u0018\u00010\u0012\u0012\u0004\u0012\u00020\u00130\u0011j\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0012\u0012\u0004\u0012\u00020\u0013`\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006+"}, d2={"Lcom/frybits/harmony/HarmonyTransaction;", "", "uuid", "Ljava/util/UUID;", "(Ljava/util/UUID;)V", "<set-?>", "", "cleared", "getCleared", "()Z", "memoryCommitTime", "", "getMemoryCommitTime", "()J", "setMemoryCommitTime", "(J)V", "transactionMap", "Ljava/util/HashMap;", "", "Lcom/frybits/harmony/HarmonyTransaction$Operation;", "Lkotlin/collections/HashMap;", "clear", "", "commitTransaction", "dataMap", "", "keysModified", "", "commitTransactionToOutputStream", "outputStream", "Ljava/io/OutputStream;", "compareTo", "", "other", "delete", "key", "equals", "hashCode", "toString", "update", "value", "Companion", "Operation", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
final class HarmonyTransaction
implements Comparable<HarmonyTransaction> {
    public static final Companion Companion = new Companion(null);
    private boolean cleared;
    private long memoryCommitTime;
    private final HashMap<String, Operation> transactionMap;
    private final UUID uuid;

    public HarmonyTransaction() {
        this(null, 1, null);
    }

    public HarmonyTransaction(UUID uUID) {
        Intrinsics.checkNotNullParameter((Object)uUID, (String)"uuid");
        this.uuid = uUID;
        this.transactionMap = new HashMap();
    }

    public /* synthetic */ HarmonyTransaction(UUID uUID, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 1) != 0) {
            uUID = UUID.randomUUID();
            Intrinsics.checkNotNullExpressionValue((Object)uUID, (String)"randomUUID()");
        }
        this(uUID);
    }

    public static final /* synthetic */ HashMap access$getTransactionMap$p(HarmonyTransaction harmonyTransaction) {
        return harmonyTransaction.transactionMap;
    }

    public static final /* synthetic */ UUID access$getUuid$p(HarmonyTransaction harmonyTransaction) {
        return harmonyTransaction.uuid;
    }

    public static final /* synthetic */ void access$setCleared$p(HarmonyTransaction harmonyTransaction, boolean bl) {
        harmonyTransaction.cleared = bl;
    }

    public static /* synthetic */ void commitTransaction$default(HarmonyTransaction harmonyTransaction, HashMap hashMap, List list, int n, Object object) {
        if ((n & 2) != 0) {
            list = null;
        }
        harmonyTransaction.commitTransaction((HashMap<String, Object>)hashMap, (List<String>)list);
    }

    public final void clear() {
        this.cleared = true;
    }

    public final void commitTransaction(HashMap<String, Object> hashMap, List<String> list) {
        Intrinsics.checkNotNullParameter(hashMap, (String)"dataMap");
        if (this.cleared && true ^ ((Map)hashMap).isEmpty()) {
            hashMap.clear();
        }
        for (Map.Entry entry : ((Map)this.transactionMap).entrySet()) {
            String string2 = (String)entry.getKey();
            Operation operation = (Operation)entry.getValue();
            if (Intrinsics.areEqual((Object)operation, (Object)Operation.Delete.INSTANCE)) {
                if (!hashMap.containsKey((Object)string2)) continue;
                hashMap.remove((Object)string2);
            } else {
                Object object;
                if (hashMap.containsKey((Object)string2) && (object = hashMap.get((Object)string2)) != null && Intrinsics.areEqual((Object)object, (Object)operation.getData())) continue;
                ((Map)hashMap).put((Object)string2, operation.getData());
            }
            if (list == null) continue;
            list.add((Object)string2);
        }
    }

    public final void commitTransactionToOutputStream(OutputStream outputStream) throws IOException {
        Intrinsics.checkNotNullParameter((Object)outputStream, (String)"outputStream");
        Adler32 adler32 = new Adler32();
        DataOutputStream dataOutputStream = new DataOutputStream((OutputStream)new CheckedOutputStream(outputStream, (Checksum)adler32));
        dataOutputStream.writeByte(126);
        dataOutputStream.writeLong(this.uuid.getMostSignificantBits());
        dataOutputStream.writeLong(this.uuid.getLeastSignificantBits());
        dataOutputStream.writeBoolean(this.cleared);
        dataOutputStream.writeLong(this.memoryCommitTime);
        for (Map.Entry entry : ((Map)this.transactionMap).entrySet()) {
            block29 : {
                int n;
                block28 : {
                    Operation operation;
                    block27 : {
                        byte[] arrby;
                        String string2 = (String)entry.getKey();
                        operation = (Operation)entry.getValue();
                        dataOutputStream.writeBoolean(true);
                        if (string2 != null) {
                            arrby = string2.getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue((Object)arrby, (String)"this as java.lang.String).getBytes(charset)");
                        } else {
                            arrby = null;
                        }
                        int n2 = arrby != null ? arrby.length : 0;
                        dataOutputStream.writeInt(n2);
                        if (arrby == null) {
                            arrby = Harmony.access$getEMPTY_BYTE_ARRAY$p();
                        }
                        dataOutputStream.write(arrby);
                        Object object = operation.getData();
                        if (object instanceof Integer) {
                            dataOutputStream.writeByte(0);
                            dataOutputStream.writeInt(((Number)object).intValue());
                        } else if (object instanceof Long) {
                            dataOutputStream.writeByte(1);
                            dataOutputStream.writeLong(((Number)object).longValue());
                        } else if (object instanceof Float) {
                            dataOutputStream.writeByte(2);
                            dataOutputStream.writeFloat(((Number)object).floatValue());
                        } else if (object instanceof Boolean) {
                            dataOutputStream.writeByte(3);
                            dataOutputStream.writeBoolean(((Boolean)object).booleanValue());
                        } else if (object instanceof String) {
                            dataOutputStream.writeByte(4);
                            byte[] arrby2 = ((String)object).getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue((Object)arrby2, (String)"this as java.lang.String).getBytes(charset)");
                            dataOutputStream.writeInt(arrby2.length);
                            dataOutputStream.write(arrby2);
                        } else {
                            boolean bl = object instanceof Set;
                            if (bl) {
                                dataOutputStream.writeByte(5);
                                Set set = (Set)object;
                                dataOutputStream.writeInt(set.size());
                                if (!bl) {
                                    set = null;
                                }
                                if (set != null) {
                                    for (String string3 : (Iterable)set) {
                                        byte[] arrby3;
                                        if (string3 != null) {
                                            arrby3 = string3.getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue((Object)arrby3, (String)"this as java.lang.String).getBytes(charset)");
                                        } else {
                                            arrby3 = null;
                                        }
                                        int n3 = arrby3 != null ? arrby3.length : 0;
                                        dataOutputStream.writeInt(n3);
                                        if (arrby3 == null) {
                                            arrby3 = Harmony.access$getEMPTY_BYTE_ARRAY$p();
                                        }
                                        dataOutputStream.write(arrby3);
                                    }
                                }
                            } else if (object == null) {
                                dataOutputStream.writeByte(6);
                            }
                        }
                        if (!(operation instanceof Operation.Update)) break block27;
                        n = 0;
                        break block28;
                    }
                    if (!(operation instanceof Operation.Delete)) break block29;
                    n = 1;
                }
                dataOutputStream.writeByte(n);
                continue;
            }
            throw new NoWhenBranchMatchedException();
        }
        dataOutputStream.writeBoolean(false);
        dataOutputStream.writeLong(adler32.getValue());
    }

    public int compareTo(HarmonyTransaction harmonyTransaction) {
        Intrinsics.checkNotNullParameter((Object)harmonyTransaction, (String)"other");
        return Intrinsics.compare((long)this.memoryCommitTime, (long)harmonyTransaction.memoryCommitTime);
    }

    public final void delete(String string2) {
        ((Map)this.transactionMap).put((Object)string2, (Object)Operation.Delete.INSTANCE);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof HarmonyTransaction)) {
            return false;
        }
        return Intrinsics.areEqual((Object)this.uuid, (Object)((HarmonyTransaction)object).uuid);
    }

    public final boolean getCleared() {
        return this.cleared;
    }

    public final long getMemoryCommitTime() {
        return this.memoryCommitTime;
    }

    public int hashCode() {
        return this.uuid.hashCode();
    }

    public final void setMemoryCommitTime(long l) {
        this.memoryCommitTime = l;
    }

    public String toString() {
        UUID uUID = this.uuid;
        HashMap<String, Operation> hashMap = this.transactionMap;
        boolean bl = this.cleared;
        long l = this.memoryCommitTime;
        return "HarmonyTransaction(uuid=" + (Object)uUID + ", transactionMap=" + hashMap + ", cleared=" + bl + ", memoryCommitTime=" + l + ")";
    }

    public final void update(String string2, Object object) {
        Map map = (Map)this.transactionMap;
        Operation operation = object != null ? (Operation)new Operation.Update(object) : (Operation)Operation.Delete.INSTANCE;
        map.put((Object)string2, (Object)operation);
    }

    @SourceDebugExtension(value="SMAP\nHarmony.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyTransaction$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,1295:1\n1#2:1296\n125#3:1297\n152#3,3:1298\n*S KotlinDebug\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/HarmonyTransaction$Companion\n*L\n1197#1:1297\n1197#1:1298,3\n*E\n")
    @Metadata(d1={"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J \u0010\u0003\u001a\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u0004\u0012\u00020\u00070\u00042\u0006\u0010\b\u001a\u00020\tJ\f\u0010\n\u001a\u00020\u000b*\u00020\fH\u0002\u00a8\u0006\r"}, d2={"Lcom/frybits/harmony/HarmonyTransaction$Companion;", "", "()V", "generateHarmonyTransactions", "Lkotlin/Pair;", "", "Lcom/frybits/harmony/HarmonyTransaction;", "", "inputStream", "Ljava/io/InputStream;", "type", "", "Lcom/frybits/harmony/HarmonyTransaction$Operation;", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final String type(Operation operation) {
            if (operation instanceof Operation.Update) {
                return "Update";
            }
            if (operation instanceof Operation.Delete) {
                return "Delete";
            }
            throw new NoWhenBranchMatchedException();
        }

        /*
         * Exception decompiling
         */
        public final Pair<Set<HarmonyTransaction>, Boolean> generateHarmonyTransactions(InputStream var1_1) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
            // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
            // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
            // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:923)
            throw new IllegalStateException("Decompilation failed");
        }
    }

    @Metadata(d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b2\u0018\u00002\u00020\u0001:\u0002\r\u000eB\u0011\b\u0004\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0001\u00a2\u0006\u0002\u0010\u0003J\u0013\u0010\u0006\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\u0001H\u0096\u0002J\b\u0010\t\u001a\u00020\nH\u0016J\b\u0010\u000b\u001a\u00020\fH\u0016R\u0013\u0010\u0002\u001a\u0004\u0018\u00010\u0001\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0004\u0010\u0005\u0082\u0001\u0002\u000f\u0010\u00a8\u0006\u0011"}, d2={"Lcom/frybits/harmony/HarmonyTransaction$Operation;", "", "data", "(Ljava/lang/Object;)V", "getData", "()Ljava/lang/Object;", "equals", "", "other", "hashCode", "", "toString", "", "Delete", "Update", "Lcom/frybits/harmony/HarmonyTransaction$Operation$Delete;", "Lcom/frybits/harmony/HarmonyTransaction$Operation$Update;", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
    private static abstract class Operation {
        private final Object data;

        private Operation(Object object) {
            this.data = object;
        }

        public /* synthetic */ Operation(Object object, DefaultConstructorMarker defaultConstructorMarker) {
            this(object);
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof Update)) {
                return false;
            }
            if (this instanceof Update) {
                return Intrinsics.areEqual((Object)this.data, (Object)((Update)object).getData());
            }
            return false;
        }

        public final Object getData() {
            return this.data;
        }

        public int hashCode() {
            Object object = this.data;
            if (object != null) {
                return object.hashCode();
            }
            return 0;
        }

        public String toString() {
            String string2 = this.getClass().getSimpleName();
            Object object = this.data;
            return string2 + "(data=" + object + ")";
        }

        @Metadata(d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lcom/frybits/harmony/HarmonyTransaction$Operation$Delete;", "Lcom/frybits/harmony/HarmonyTransaction$Operation;", "()V", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
        public static final class Delete
        extends Operation {
            public static final Delete INSTANCE = new Delete();

            private Delete() {
                super(null, null);
            }
        }

        @Metadata(d1={"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004\u00a8\u0006\u0005"}, d2={"Lcom/frybits/harmony/HarmonyTransaction$Operation$Update;", "Lcom/frybits/harmony/HarmonyTransaction$Operation;", "data", "", "(Ljava/lang/Object;)V", "harmony_release"}, k=1, mv={1, 7, 1}, xi=48)
        public static final class Update
        extends Operation {
            public Update(Object object) {
                Intrinsics.checkNotNullParameter((Object)object, (String)"data");
                super(object, null);
            }
        }

    }

}

