/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.os.FileObserver
 *  dalvik.annotation.SourceDebugExtension
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.UUID
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Regex
 */
package com.frybits.harmony;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.FileObserver;
import com.frybits.harmony.HarmonyImpl;
import com.frybits.harmony.HarmonyLog;
import com.frybits.harmony.HarmonyTransaction;
import com.frybits.harmony.LoggerKt;
import com.frybits.harmony.SingletonLockObj;
import dalvik.annotation.SourceDebugExtension;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;

@SourceDebugExtension(value="SMAP\nHarmony.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/Harmony\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Maps.kt\nkotlin/collections/MapsKt__MapsKt\n*L\n1#1,1295:1\n1#2:1296\n357#3,7:1297\n*S KotlinDebug\n*F\n+ 1 Harmony.kt\ncom/frybits/harmony/Harmony\n*L\n1259#1:1297,7\n*E\n")
@Metadata(d1={"\u0000l\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\u001a\u0015\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020!H\u0007\u00a2\u0006\u0002\b\"\u001a\u0019\u0010#\u001a\u00020$*\u00020%2\u0006\u0010&\u001a\u00020\tH\u0007\u00a2\u0006\u0002\b'\u001a$\u0010#\u001a\u00020$*\u00020%2\u0006\u0010(\u001a\u00020\t2\u0006\u0010)\u001a\u00020\u000e2\u0006\u0010*\u001a\u00020\u0001H\u0001\u001a\f\u0010+\u001a\u00020,*\u00020%H\u0002\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\b\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u0016\u0010\n\u001a\n \f*\u0004\u0018\u00010\u000b0\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\r\u001a\u00020\u000eX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u000f\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0010\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0011\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0012\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0013\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0014\u001a\u00020\tX\u0082T\u00a2\u0006\u0002\n\u0000\"*\u0010\u0015\u001a\u001e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u00170\u0016j\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\u0017`\u0018X\u0082\u0004\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u0019\u001a\u00020\u001aX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u001b\u001a\u00020\u001aX\u0082T\u00a2\u0006\u0002\n\u0000\"\u000e\u0010\u001c\u001a\u00020\u001dX\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006-"}, d2={"CURR_TRANSACTION_FILE_VERSION", "", "EMPTY_BYTE_ARRAY", "", "EMPTY_TRANSACTION", "Lcom/frybits/harmony/HarmonyTransaction;", "FILE_OBSERVER_SYNC_OBJECT", "", "HARMONY_PREFS_FOLDER", "", "IO_THREAD_POOL", "Ljava/util/concurrent/ExecutorService;", "kotlin.jvm.PlatformType", "KILOBYTE", "", "LOG_TAG", "PREFS_BACKUP", "PREFS_DATA", "PREFS_DATA_LOCK", "PREFS_TRANSACTIONS", "PREFS_TRANSACTIONS_OLD", "SINGLETON_MAP", "Ljava/util/HashMap;", "Lcom/frybits/harmony/HarmonyImpl;", "Lkotlin/collections/HashMap;", "TRANSACTION_FILE_VERSION_1", "", "TRANSACTION_FILE_VERSION_2", "posixRegex", "Lkotlin/text/Regex;", "setHarmonyLog", "", "harmonyLog", "Lcom/frybits/harmony/HarmonyLog;", "setLogger", "getHarmonySharedPreferences", "Landroid/content/SharedPreferences;", "Landroid/content/Context;", "fileName", "getSharedPreferences", "name", "maxTransactionSize", "maxTransactionBatchCount", "harmonyPrefsFolder", "Ljava/io/File;", "harmony_release"}, k=2, mv={1, 7, 1}, xi=48)
public final class Harmony {
    private static final int CURR_TRANSACTION_FILE_VERSION = 126;
    private static final byte[] EMPTY_BYTE_ARRAY;
    private static final HarmonyTransaction EMPTY_TRANSACTION;
    private static final Object FILE_OBSERVER_SYNC_OBJECT;
    private static final String HARMONY_PREFS_FOLDER = "harmony_prefs";
    private static final ExecutorService IO_THREAD_POOL;
    private static final long KILOBYTE = 1024L;
    private static final String LOG_TAG = "Harmony";
    private static final String PREFS_BACKUP = "prefs.backup";
    private static final String PREFS_DATA = "prefs.data";
    private static final String PREFS_DATA_LOCK = "prefs.data.lock";
    private static final String PREFS_TRANSACTIONS = "prefs.transaction.data";
    private static final String PREFS_TRANSACTIONS_OLD = "prefs.transaction.old";
    private static final HashMap<String, HarmonyImpl> SINGLETON_MAP;
    private static final byte TRANSACTION_FILE_VERSION_1 = 127;
    private static final byte TRANSACTION_FILE_VERSION_2 = 126;
    private static final Regex posixRegex;

    static {
        posixRegex = new Regex("[^-_.A-Za-z0-9]");
        EMPTY_BYTE_ARRAY = new byte[0];
        Class class_ = Class.forName((String)FileObserver.class.getName());
        Intrinsics.checkNotNullExpressionValue((Object)class_, (String)"forName(FileObserver::class.java.name)");
        FILE_OBSERVER_SYNC_OBJECT = class_;
        SINGLETON_MAP = new HashMap();
        HarmonyTransaction harmonyTransaction = new HarmonyTransaction(null, 1, null);
        harmonyTransaction.setMemoryCommitTime(Long.MIN_VALUE);
        EMPTY_TRANSACTION = harmonyTransaction;
        IO_THREAD_POOL = Executors.newCachedThreadPool();
    }

    public static final /* synthetic */ byte[] access$getEMPTY_BYTE_ARRAY$p() {
        return EMPTY_BYTE_ARRAY;
    }

    public static final /* synthetic */ HarmonyTransaction access$getEMPTY_TRANSACTION$p() {
        return EMPTY_TRANSACTION;
    }

    public static final /* synthetic */ Object access$getFILE_OBSERVER_SYNC_OBJECT$p() {
        return FILE_OBSERVER_SYNC_OBJECT;
    }

    public static final /* synthetic */ ExecutorService access$getIO_THREAD_POOL$p() {
        return IO_THREAD_POOL;
    }

    public static final /* synthetic */ Regex access$getPosixRegex$p() {
        return posixRegex;
    }

    public static final /* synthetic */ File access$harmonyPrefsFolder(Context context) {
        return Harmony.harmonyPrefsFolder(context);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static final /* synthetic */ SharedPreferences getHarmonySharedPreferences(Context context, String string2, long l, int n) {
        SingletonLockObj singletonLockObj;
        Intrinsics.checkNotNullParameter((Object)context, (String)"<this>");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"name");
        HashMap<String, HarmonyImpl> hashMap = SINGLETON_MAP;
        HarmonyImpl harmonyImpl = (HarmonyImpl)hashMap.get((Object)string2);
        if (harmonyImpl != null) {
            return harmonyImpl;
        }
        SingletonLockObj singletonLockObj2 = singletonLockObj = SingletonLockObj.INSTANCE;
        synchronized (singletonLockObj2) {
            Map map = (Map)hashMap;
            Object object = map.get((Object)string2);
            if (object == null) {
                Context context2 = context.getApplicationContext();
                Intrinsics.checkNotNullExpressionValue((Object)context2, (String)"applicationContext");
                object = new HarmonyImpl(context2, string2, l, n);
                map.put((Object)string2, object);
            }
            HarmonyImpl harmonyImpl2 = (HarmonyImpl)object;
            return harmonyImpl2;
        }
    }

    public static final SharedPreferences getSharedPreferences(Context context, String string2) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"<this>");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"fileName");
        return Harmony.getHarmonySharedPreferences(context, string2, 131072L, 250);
    }

    private static final File harmonyPrefsFolder(Context context) {
        File file = new File(context.getFilesDir(), HARMONY_PREFS_FOLDER);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    public static final void setLogger(HarmonyLog harmonyLog) {
        SingletonLockObj singletonLockObj;
        Intrinsics.checkNotNullParameter((Object)harmonyLog, (String)"harmonyLog");
        SingletonLockObj singletonLockObj2 = singletonLockObj = SingletonLockObj.INSTANCE;
        synchronized (singletonLockObj2) {
            if (LoggerKt.get_harmonyLog() == null) {
                LoggerKt.set_harmonyLog(harmonyLog);
            }
            return;
        }
    }
}

