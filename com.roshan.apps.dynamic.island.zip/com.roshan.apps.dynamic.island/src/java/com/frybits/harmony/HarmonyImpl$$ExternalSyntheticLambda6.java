/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.Callable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;
import java.util.concurrent.Callable;

public final class HarmonyImpl$$ExternalSyntheticLambda6
implements Callable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$$ExternalSyntheticLambda6(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final Object call() {
        return HarmonyImpl.$r8$lambda$JbZx2xhqu5H8w8MY6-eFqA-6GOI(this.f$0);
    }
}

