/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.frybits.harmony.HarmonyImpl$harmonyFileObserver
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.frybits.harmony;

import com.frybits.harmony.HarmonyImpl;

public final class HarmonyImpl$harmonyFileObserver$1$$ExternalSyntheticLambda0
implements Runnable {
    public final /* synthetic */ HarmonyImpl f$0;

    public /* synthetic */ HarmonyImpl$harmonyFileObserver$1$$ExternalSyntheticLambda0(HarmonyImpl harmonyImpl) {
        this.f$0 = harmonyImpl;
    }

    public final void run() {
        HarmonyImpl.harmonyFileObserver.1.$r8$lambda$kBb3xOdGsS4BoV0vyAWkTuP28RY(this.f$0);
    }
}

