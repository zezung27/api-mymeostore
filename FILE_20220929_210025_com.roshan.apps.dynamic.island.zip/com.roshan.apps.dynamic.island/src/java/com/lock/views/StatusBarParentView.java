/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.MotionEvent
 *  android.widget.FrameLayout
 */
package com.lock.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class StatusBarParentView
extends FrameLayout {
    public StatusBarParentView(Context context) {
        super(context);
    }

    public StatusBarParentView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public StatusBarParentView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
    }

    public StatusBarParentView(Context context, AttributeSet attributeSet, int n, int n2) {
        super(context, attributeSet, n, n2);
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return super.onInterceptTouchEvent(motionEvent);
    }
}

