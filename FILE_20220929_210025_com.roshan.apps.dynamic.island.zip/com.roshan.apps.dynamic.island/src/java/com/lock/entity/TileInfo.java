/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.entity;

import android.content.Intent;
import android.graphics.drawable.Drawable;

public class TileInfo {
    public Drawable drawable;
    public Intent intent;
    public boolean isEnabled;
    public String label;

    public TileInfo(String string2, Intent intent, Drawable drawable2, boolean bl) {
        this.label = string2;
        this.intent = intent;
        this.drawable = drawable2;
        this.isEnabled = bl;
    }
}

