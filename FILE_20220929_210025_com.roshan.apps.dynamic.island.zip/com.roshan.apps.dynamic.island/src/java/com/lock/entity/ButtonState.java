/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.graphics.drawable.Drawable
 *  android.widget.TextView
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.entity;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;

public abstract class ButtonState {
    Context context;
    public Drawable iconOff;
    public Drawable iconOn;
    public Boolean isStateOn;
    public Intent launchIntent;
    public String title;

    public ButtonState(Context context) {
        this.context = context;
    }

    public abstract Intent getIntent();

    public abstract String getName();

    public abstract boolean getState();

    public abstract boolean hasSystemFeature();

    public abstract void setState(boolean var1, LottieAnimationView var2, TextView var3, TextView var4);
}

