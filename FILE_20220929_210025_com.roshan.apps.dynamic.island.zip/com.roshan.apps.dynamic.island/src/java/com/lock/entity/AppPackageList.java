/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.lock.entity;

import com.lock.entity.AppDetail;
import java.util.ArrayList;

public class AppPackageList {
    public ArrayList<AppDetail> appDetailList = new ArrayList();
}

