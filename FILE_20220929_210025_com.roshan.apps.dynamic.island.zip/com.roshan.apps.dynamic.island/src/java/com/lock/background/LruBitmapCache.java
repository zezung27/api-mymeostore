/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  androidx.collection.LruCache
 *  com.android.volley.toolbox.ImageLoader
 *  com.android.volley.toolbox.ImageLoader$ImageCache
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.lang.String
 */
package com.lock.background;

import android.graphics.Bitmap;
import androidx.collection.LruCache;
import com.android.volley.toolbox.ImageLoader;

public class LruBitmapCache
extends LruCache<String, Bitmap>
implements ImageLoader.ImageCache {
    public LruBitmapCache() {
        this(LruBitmapCache.getDefaultLruCacheSize());
    }

    public LruBitmapCache(int n) {
        super(n);
    }

    public static int getDefaultLruCacheSize() {
        return (int)(Runtime.getRuntime().maxMemory() / 1024L) / 8;
    }

    public Bitmap getBitmap(String string2) {
        return (Bitmap)this.get((Object)string2);
    }

    public void putBitmap(String string2, Bitmap bitmap) {
        this.put((Object)string2, (Object)bitmap);
    }

    protected int sizeOf(String string2, Bitmap bitmap) {
        return bitmap.getRowBytes() * bitmap.getHeight() / 1024;
    }
}

