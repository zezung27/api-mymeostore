/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.WallpaperManager
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.Color
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.location.LocationManager
 *  android.os.AsyncTask
 *  android.os.Environment
 *  android.util.Log
 *  android.widget.ImageView
 *  android.widget.Toast
 *  androidx.palette.graphics.Palette
 *  androidx.palette.graphics.Palette$PaletteAsyncListener
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.OutputStream
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.Random
 */
package com.lock.background;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.palette.graphics.Palette;
import com.lock.background.PrefManager;
import com.lock.utils.Constants;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Random;
import jp.wasabeef.blurry.Blurry;

public class Utils {
    public static final int PERMISSIONS_REQUEST_READ_EXT = 300;
    public static final int PERMISSIONS_REQUEST_SET_WALLPAPER = 200;
    public static final int PERMISSIONS_REQUEST_WRITE_EXT = 100;
    private String TAG = "Utils";
    private Context _context;
    private PrefManager pref;

    public Utils(Context context) {
        this._context = context;
        this.pref = new PrefManager(this._context);
    }

    public static boolean isAdsRemoved(Context context) {
        return context.getSharedPreferences("ads", 0).getBoolean("isAdRemoved", false);
    }

    public static boolean isLocationEnabled(Context context) {
        LocationManager locationManager = (LocationManager)context.getSystemService("location");
        boolean bl = locationManager.isProviderEnabled("gps");
        boolean bl2 = locationManager.isProviderEnabled("network");
        return bl || bl2;
    }

    public static String saveImage(Bitmap bitmap) {
        File file = new File((Object)Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_PICTURES) + "/complockwallpaper.jpg");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return file.getPath();
    }

    public static String saveToInternalSorage(Context context, Bitmap bitmap) {
        Palette.from((Bitmap)bitmap).generate(new Palette.PaletteAsyncListener(){

            public void onGenerated(Palette palette) {
                Context context = Context.this;
                Constants.setWallpaperColor(context, palette.getVibrantColor(context.getResources().getColor(2131100531)));
            }
        });
        File file = new File(context.getDir("imageDir", 0), context.getString(2131886135));
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            ImageView imageView = new ImageView(context);
            Blurry.with(context).radius(25).sampling(4).color(Color.argb((int)66, (int)150, (int)150, (int)150)).from(bitmap).into(imageView);
            ((BitmapDrawable)imageView.getDrawable()).getBitmap().compress(Bitmap.CompressFormat.JPEG, 100, (OutputStream)fileOutputStream);
            fileOutputStream.close();
            Constants.setWallpaperUpdated(context, true);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return file.getAbsolutePath();
    }

    /*
     * Exception decompiling
     */
    public int getScreenWidth() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl24 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:923)
        throw new IllegalStateException("Decompilation failed");
    }

    public void saveImageToSDCard(Bitmap bitmap) {
        File file = new File(Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_PICTURES), this.pref.getGalleryName());
        file.mkdirs();
        int n = new Random().nextInt(10000);
        final File file2 = new File(file, "Wallpaper-" + n + ".jpg");
        if (file2.exists()) {
            file2.delete();
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, (OutputStream)fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            ((Activity)this._context).runOnUiThread(new Runnable(){

                public void run() {
                    Toast.makeText((Context)Utils.this._context, (CharSequence)"Wallpaper Set", (int)0).show();
                    Log.d((String)Utils.this.TAG, (String)("Wallpaper saved to: " + file2.getAbsolutePath()));
                }
            });
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            ((Activity)this._context).runOnUiThread(new Runnable(){

                public void run() {
                    Toast.makeText((Context)Utils.this._context, (CharSequence)Utils.this._context.getString(2131886532), (int)0).show();
                }
            });
            return;
        }
    }

    public void setAsWallpaper(Bitmap bitmap) {
        Utils.saveToInternalSorage(this._context, bitmap);
        try {
            WallpaperManager.getInstance((Context)this._context).setBitmap(bitmap);
            ((Activity)this._context).runOnUiThread(new Runnable(){

                public void run() {
                    Toast.makeText((Context)Utils.this._context, (CharSequence)Utils.this._context.getString(2131886533), (int)0).show();
                }
            });
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            ((Activity)this._context).runOnUiThread(new Runnable(){

                public void run() {
                    Toast.makeText((Context)Utils.this._context, (CharSequence)Utils.this._context.getString(2131886534), (int)0).show();
                }
            });
            return;
        }
    }

}

