/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$OnSharedPreferenceChangeListener
 *  java.lang.Object
 *  java.lang.String
 */
package com.lock.services;

import android.content.SharedPreferences;
import com.lock.services.MAccessibilityService;

public final class MAccessibilityService$$ExternalSyntheticLambda2
implements SharedPreferences.OnSharedPreferenceChangeListener {
    public final /* synthetic */ MAccessibilityService f$0;

    public /* synthetic */ MAccessibilityService$$ExternalSyntheticLambda2(MAccessibilityService mAccessibilityService) {
        this.f$0 = mAccessibilityService;
    }

    public final void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String string2) {
        this.f$0.lambda$onServiceConnected$0$com-lock-services-MAccessibilityService(sharedPreferences, string2);
    }
}

