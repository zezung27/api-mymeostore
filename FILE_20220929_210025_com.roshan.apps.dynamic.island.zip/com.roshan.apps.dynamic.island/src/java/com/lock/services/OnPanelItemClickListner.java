/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 */
package com.lock.services;

public interface OnPanelItemClickListner {
    public void onItemClicked(boolean var1, Boolean var2);
}

