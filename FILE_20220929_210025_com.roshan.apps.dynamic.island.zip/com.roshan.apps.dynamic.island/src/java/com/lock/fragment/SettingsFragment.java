/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.WallpaperManager
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Typeface
 *  android.graphics.drawable.Drawable
 *  android.location.LocationManager
 *  android.net.Uri
 *  android.net.wifi.WifiManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.provider.Settings
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.ImageView
 *  android.widget.RadioButton
 *  android.widget.RadioGroup
 *  android.widget.RadioGroup$OnCheckedChangeListener
 *  android.widget.RelativeLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  android.widget.ToggleButton
 *  androidx.appcompat.app.AlertDialog
 *  androidx.appcompat.app.AlertDialog$Builder
 *  androidx.core.content.ContextCompat
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.request.target.CustomTarget
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.transition.Transition
 *  com.google.android.gms.ads.AdListener
 *  com.google.android.gms.ads.AdLoader
 *  com.google.android.gms.ads.AdLoader$Builder
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.VideoOptions
 *  com.google.android.gms.ads.VideoOptions$Builder
 *  com.google.android.gms.ads.nativead.NativeAd
 *  com.google.android.gms.ads.nativead.NativeAd$OnNativeAdLoadedListener
 *  com.google.android.gms.ads.nativead.NativeAdOptions
 *  com.google.android.gms.ads.nativead.NativeAdOptions$Builder
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package com.lock.fragment;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.lock.Controllers.LocationSettingController;
import com.lock.activites.AppsFilterListActivity;
import com.lock.activites.AppsListActivity;
import com.lock.activites.HelpActivity;
import com.lock.activites.HomeActivity;
import com.lock.activites.PrivacyPolicyActivity;
import com.lock.background.PrefManager;
import com.lock.background.Utils;
import com.lock.background.WallpapersCategoryActivity;
import com.lock.fragment.SettingsFragment;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda0;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda1;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda10;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda11;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda12;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda13;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda14;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda15;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda16;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda17;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda18;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda2;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda3;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda4;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda5;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda6;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda7;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda8;
import com.lock.fragment.SettingsFragment$$ExternalSyntheticLambda9;
import com.lock.utils.Constants;
import com.lock.utils.MySettings;
import com.lock.utils.RatingDialog;
import com.skydoves.colorpickerview.ColorEnvelope;
import com.skydoves.colorpickerview.ColorPickerDialog;
import com.skydoves.colorpickerview.ColorPickerView;
import com.skydoves.colorpickerview.flag.BubbleFlag;
import com.skydoves.colorpickerview.flag.FlagView;
import com.skydoves.colorpickerview.listeners.ColorPickerViewListener;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SettingsFragment
extends Fragment
implements View.OnClickListener {
    View backgroung_rl;
    Context context;
    private ToggleButton enable_controls_gesture;
    LocationManager locationManager;
    private NativeAd mNativeAd;
    RelativeLayout more_rl;
    PrefManager prefManager;
    RelativeLayout rateus_rl;
    RelativeLayout share_rl;
    TextView textViewBackgroundGallery;
    private ToggleButton toggle_show_on_lock;
    TextView tv_more;
    TextView tv_rateus;
    private TextView tv_remove_ads;
    TextView tv_share;
    Typeface typefaceBold;
    private View viw;

    static /* synthetic */ View access$000(SettingsFragment settingsFragment) {
        return settingsFragment.viw;
    }

    static /* synthetic */ void access$100(SettingsFragment settingsFragment, View view) {
        settingsFragment.refreshNativeAd(view);
    }

    static /* synthetic */ NativeAd access$200(SettingsFragment settingsFragment) {
        return settingsFragment.mNativeAd;
    }

    static /* synthetic */ NativeAd access$202(SettingsFragment settingsFragment, NativeAd nativeAd) {
        settingsFragment.mNativeAd = nativeAd;
        return nativeAd;
    }

    private void checkMethod() {
        LocationSettingController locationSettingController = new LocationSettingController((Context)this.getActivity());
        Toast.makeText((Context)this.getActivity(), (CharSequence)("Name: " + locationSettingController.getName()), (int)0).show();
    }

    private void disableLockToggle() {
        MySettings.setLockscreen(false, this.context);
    }

    private void enableLockToggle() {
        MySettings.setLockscreen(true, this.context);
    }

    private void getPrivateFunc(boolean bl) {
        void var4_10;
        WallpaperManager.getInstance((Context)this.getActivity());
        WifiManager wifiManager = (WifiManager)this.getActivity().getApplicationContext().getSystemService("wifi");
        try {
            Class class_ = wifiManager.getClass();
            Class[] arrclass = new Class[]{Boolean.TYPE};
            Method method = class_.getMethod("setWifiEnabled", arrclass);
            Object[] arrobject = new Object[]{bl};
            method.invoke((Object)wifiManager, arrobject);
            return;
        }
        catch (InvocationTargetException invocationTargetException) {
        }
        catch (IllegalAccessException illegalAccessException) {
        }
        catch (NoSuchMethodException noSuchMethodException) {
            // empty catch block
        }
        var4_10.printStackTrace();
    }

    static /* synthetic */ void lambda$onClick$18(DialogInterface dialogInterface, int n) {
        dialogInterface.dismiss();
    }

    private void refreshNativeAd(View view) {
        AdLoader.Builder builder = new AdLoader.Builder(this.context, this.getString(2131886121));
        builder.forNativeAd(new NativeAd.OnNativeAdLoadedListener(this, view){
            final /* synthetic */ SettingsFragment this$0;
            final /* synthetic */ View val$view;
            {
                this.this$0 = settingsFragment;
                this.val$view = view;
            }

            public void onNativeAdLoaded(NativeAd nativeAd) {
                try {
                    if (SettingsFragment.access$200(this.this$0) != null) {
                        SettingsFragment.access$200(this.this$0).destroy();
                    }
                    SettingsFragment.access$202(this.this$0, nativeAd);
                    android.widget.FrameLayout frameLayout = (android.widget.FrameLayout)this.val$view.findViewById(2131362081);
                    com.google.android.gms.ads.nativead.NativeAdView nativeAdView = (com.google.android.gms.ads.nativead.NativeAdView)this.this$0.getLayoutInflater().inflate(2131558436, null);
                    Constants.populateNativeAdView(SettingsFragment.access$200(this.this$0), new com.lock.adaptar.NativeAdViewHolder((View)nativeAdView).getAdView());
                    frameLayout.removeAllViews();
                    frameLayout.addView((View)nativeAdView);
                    this.val$view.findViewById(2131362184).setVisibility(0);
                    return;
                }
                catch (Exception exception) {
                    Toast.makeText((Context)this.this$0.context, (CharSequence)((Object)((Object)exception) + ""), (int)1).show();
                    return;
                }
            }
        });
        VideoOptions videoOptions = new VideoOptions.Builder().setStartMuted(true).build();
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(videoOptions).build());
        builder.withAdListener(new AdListener(this, view){
            final /* synthetic */ SettingsFragment this$0;
            final /* synthetic */ View val$view;
            {
                this.this$0 = settingsFragment;
                this.val$view = view;
            }

            public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                this.val$view.findViewById(2131362081).setVisibility(8);
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    private void setLayoutColor(ColorEnvelope colorEnvelope) {
        ((ImageView)this.viw.findViewById(2131362162)).setColorFilter(colorEnvelope.getColor());
        new PrefManager((Context)this.getActivity()).setKeyDefaultColor(colorEnvelope.getColor());
        if (Constants.getRatingDailoge(this.context)) {
            new RatingDialog((Activity)((HomeActivity)this.context)).showDialog();
        }
    }

    private void showHelpScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), HelpActivity.class));
    }

    private void showPrivacyScreen() {
        this.startActivity(new Intent((Context)this.getActivity(), PrivacyPolicyActivity.class));
    }

    public void askForPermission() {
        if (ContextCompat.checkSelfPermission((Context)this.getActivity(), (String)"android.permission.MODIFY_PHONE_STATE") == 0) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            String[] arrstring = new String[]{"android.permission.MODIFY_PHONE_STATE"};
            this.getActivity().requestPermissions(arrstring, 69);
        }
    }

    public void getCustomAppBackground() {
        ImagePicker.with(this).crop().compress(1024).maxResultSize(1080, 1920).start();
    }

    /* synthetic */ void lambda$onClick$17$com-lock-fragment-SettingsFragment(ColorEnvelope colorEnvelope, boolean bl) {
        this.setLayoutColor(colorEnvelope);
    }

    /* synthetic */ void lambda$onViewCreated$0$com-lock-fragment-SettingsFragment(View view) {
        this.getCustomAppBackground();
    }

    /* synthetic */ void lambda$onViewCreated$1$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.setControlEnabled(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$10$com-lock-fragment-SettingsFragment(View view) {
        this.startActivity(new Intent(this.context, WallpapersCategoryActivity.class));
    }

    /* synthetic */ void lambda$onViewCreated$11$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131362597) {
            this.prefManager.setCameraCount(0);
        }
        if (n == 2131362295) {
            this.prefManager.setCameraCount(1);
            return;
        }
        if (n == 2131362552) {
            this.prefManager.setCameraCount(2);
            return;
        }
        if (n == 2131362494) {
            this.prefManager.setCameraCount(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$12$com-lock-fragment-SettingsFragment(RadioGroup radioGroup, int n) {
        if (n == 2131362173) {
            this.prefManager.setCameraPos(1);
            return;
        }
        if (n == 2131361949) {
            this.prefManager.setCameraPos(2);
            return;
        }
        if (n == 2131362350) {
            this.prefManager.setCameraPos(3);
        }
    }

    /* synthetic */ void lambda$onViewCreated$13$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362596)).getText().toString();
        if (Integer.parseInt((String)string) < 20) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362596)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$14$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362596)).getText().toString();
        if (Integer.parseInt((String)string) >= 1) {
            int n = Integer.parseInt((String)string) - 1;
            ((TextView)view.findViewById(2131362596)).setText((CharSequence)(n + ""));
            this.prefManager.setYPosOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$15$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362593)).getText().toString();
        if (Integer.parseInt((String)string) < 40) {
            int n = 1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362593)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$16$com-lock-fragment-SettingsFragment(View view, View view2) {
        String string = ((TextView)view.findViewById(2131362593)).getText().toString();
        if (Integer.parseInt((String)string) >= 25) {
            int n = -1 + Integer.parseInt((String)string);
            ((TextView)view.findViewById(2131362593)).setText((CharSequence)(n + ""));
            this.prefManager.setHeightOfIsland(n);
        }
    }

    /* synthetic */ void lambda$onViewCreated$2$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.setShowOnLock(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$3$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.SetShowInFullScreen(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$4$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.SetShowInLand(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$5$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        Constants.setAutoCloseNoti(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$6$com-lock-fragment-SettingsFragment(CompoundButton compoundButton, boolean bl) {
        this.prefManager.setIphoneCall(this.context, bl);
    }

    /* synthetic */ void lambda$onViewCreated$7$com-lock-fragment-SettingsFragment(View view) {
        this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("market://details?id=" + this.context.getPackageName()))));
    }

    /* synthetic */ void lambda$onViewCreated$8$com-lock-fragment-SettingsFragment(View view) {
        this.shareLink("https://play.google.com/store/apps/details?id=" + this.context.getApplicationInfo().packageName);
    }

    /* synthetic */ void lambda$onViewCreated$9$com-lock-fragment-SettingsFragment(View view) {
        try {
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.context.getString(2131886117)))));
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/developer?id=" + this.context.getString(2131886117)))));
            return;
        }
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        String string;
        Uri uri;
        if (intent != null && (uri = intent.getData()) != null && new File(string = uri.getPath()).exists()) {
            Glide.with((Context)this.context).asBitmap().load(string).into((Target)new CustomTarget<Bitmap>(){

                public void onLoadCleared(Drawable drawable) {
                }

                public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                    if (bitmap.getWidth() > 300) {
                        Utils.saveToInternalSorage((Context)SettingsFragment.this.getActivity(), bitmap);
                    }
                }
            });
        }
        if (n == 1133) {
            Uri uri2;
            String string2;
            if (intent != null && (uri2 = intent.getData()) != null && (string2 = Constants.getPathFromUri(this.context, uri2)) != null && new File(string2).exists()) {
                Glide.with((Context)this.context).asBitmap().load(string2).into((Target)new CustomTarget<Bitmap>(){

                    public void onLoadCleared(Drawable drawable) {
                    }

                    public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                        Utils.saveImage(bitmap);
                    }
                });
                return;
            }
        } else if (n == 9 && Build.VERSION.SDK_INT >= 23) {
            if (Settings.canDrawOverlays((Context)this.context)) {
                this.enableLockToggle();
                return;
            }
            this.disableLockToggle();
        }
    }

    public void onClick(View view) {
        switch (view.getId()) {
            default: {
                return;
            }
            case 2131362355: {
                this.startActivity(new Intent(this.context, AppsListActivity.class));
                return;
            }
            case 2131362354: {
                this.startActivity(new Intent(this.context, AppsFilterListActivity.class));
                return;
            }
            case 2131362323: {
                this.showPrivacyScreen();
                return;
            }
            case 2131362108: {
                this.showHelpScreen();
                return;
            }
            case 2131362000: 
        }
        AlertDialog.Builder builder = new ColorPickerDialog.Builder(this.context).setTitle("Pick tiles color").setPositiveButton((CharSequence)this.getString(2131886177), (ColorPickerViewListener)new SettingsFragment$$ExternalSyntheticLambda8(this)).setNegativeButton(this.getString(2131886148), (DialogInterface.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda9());
        builder.getColorPickerView().setFlagView(new BubbleFlag(this.context));
        builder.show();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(2131558468, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        ToggleButton toggleButton;
        RelativeLayout relativeLayout;
        RelativeLayout relativeLayout2;
        TextView textView;
        ToggleButton toggleButton2;
        RelativeLayout relativeLayout3;
        int n;
        super.onViewCreated(view, bundle);
        this.context = this.getActivity();
        this.prefManager = new PrefManager(this.context);
        this.textViewBackgroundGallery = (TextView)view.findViewById(2131362477);
        this.viw = view;
        this.typefaceBold = Typeface.createFromAsset((AssetManager)this.context.getAssets(), (String)"roboto_medium.ttf");
        view.findViewById(2131362108).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131362323).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131362000).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131362355).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131362354).setOnClickListener((View.OnClickListener)this);
        view.findViewById(2131361997).setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda0(this));
        this.enable_controls_gesture = toggleButton = (ToggleButton)view.findViewById(2131362056);
        toggleButton.setChecked(Constants.getControlEnabled(this.context));
        this.enable_controls_gesture.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda17(this));
        this.toggle_show_on_lock = toggleButton2 = (ToggleButton)view.findViewById(2131362510);
        toggleButton2.setChecked(Constants.getShowOnLock(this.context));
        this.toggle_show_on_lock.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda18(this));
        ToggleButton toggleButton3 = (ToggleButton)view.findViewById(2131362506);
        toggleButton3.setChecked(Constants.getShowInFullScreen(this.context));
        toggleButton3.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda1(this));
        ToggleButton toggleButton4 = (ToggleButton)view.findViewById(2131362507);
        toggleButton4.setChecked(Constants.gethideInLand(this.context));
        toggleButton4.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda2(this));
        ToggleButton toggleButton5 = (ToggleButton)view.findViewById(2131362503);
        toggleButton5.setChecked(Constants.getAutoCloseNoti(this.context));
        toggleButton5.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda3(this));
        ToggleButton toggleButton6 = (ToggleButton)view.findViewById(2131362508);
        toggleButton6.setChecked(this.prefManager.getIphoneCall(this.context));
        toggleButton6.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener)new SettingsFragment$$ExternalSyntheticLambda4(this));
        ((ImageView)view.findViewById(2131362162)).setColorFilter(this.prefManager.getDefaultColor());
        this.locationManager = (LocationManager)this.context.getSystemService("location");
        this.backgroung_rl = view.findViewById(2131361943);
        this.tv_remove_ads = textView = (TextView)view.findViewById(2131362546);
        textView.setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362551)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361998)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362478)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362549)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362538)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362107)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361938)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131361939)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362517)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362516)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362596)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362593)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362530)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362547)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362527)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362540)).setTypeface(this.typefaceBold);
        ((TextView)view.findViewById(2131362539)).setTypeface(this.typefaceBold);
        this.tv_rateus = (TextView)view.findViewById(2131362545);
        this.tv_more = (TextView)view.findViewById(2131362542);
        this.tv_share = (TextView)view.findViewById(2131362548);
        this.rateus_rl = relativeLayout3 = (RelativeLayout)view.findViewById(2131362333);
        relativeLayout3.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda5(this));
        this.share_rl = relativeLayout2 = (RelativeLayout)view.findViewById(2131362396);
        relativeLayout2.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda6(this));
        this.more_rl = relativeLayout = (RelativeLayout)view.findViewById(2131362233);
        relativeLayout.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda7(this));
        this.tv_share.setTypeface(this.typefaceBold);
        this.tv_rateus.setTypeface(this.typefaceBold);
        this.tv_more.setTypeface(this.typefaceBold);
        this.textViewBackgroundGallery.setTypeface(this.typefaceBold);
        this.backgroung_rl.setOnClickListener((View.OnClickListener)new SettingsFragment$$ExternalSyntheticLambda10(this));
        ((RelativeLayout)view.findViewById(2131362344)).setOnClickListener(new View.OnClickListener(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            public void onClick(View view) {
                ((HomeActivity)this.this$0.context).onRemoveAdButtonClicked();
            }
        });
        this.enable_controls_gesture.postDelayed(new Runnable(this){
            final /* synthetic */ SettingsFragment this$0;
            {
                this.this$0 = settingsFragment;
            }

            /*
             * Exception decompiling
             */
            public void run(}
        java.lang.IllegalStateException: Parameters not created
        
        