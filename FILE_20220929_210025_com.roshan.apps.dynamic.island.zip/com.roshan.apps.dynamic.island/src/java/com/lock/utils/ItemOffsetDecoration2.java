/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Rect
 *  android.view.View
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$ItemDecoration
 *  androidx.recyclerview.widget.RecyclerView$State
 */
package com.lock.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public class ItemOffsetDecoration2
extends RecyclerView.ItemDecoration {
    private int mItemOffset;

    public ItemOffsetDecoration2(int n) {
        this.mItemOffset = n;
    }

    public ItemOffsetDecoration2(Context context, int n) {
        this(context.getResources().getDimensionPixelSize(n));
    }

    public void getItemOffsets(Rect rect, View view, RecyclerView recyclerView, RecyclerView.State state) {
        super.getItemOffsets(rect, view, recyclerView, state);
        int n = this.mItemOffset;
        rect.set(n, n, n, n);
    }
}

