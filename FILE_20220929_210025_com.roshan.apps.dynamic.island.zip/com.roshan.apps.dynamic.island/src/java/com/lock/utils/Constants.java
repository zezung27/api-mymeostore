/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.Resources
 *  android.database.Cursor
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.preference.PreferenceManager
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.provider.Settings$System
 *  android.text.TextUtils
 *  android.text.TextUtils$SimpleStringSplitter
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.widget.ImageView
 *  android.widget.RatingBar
 *  android.widget.TextView
 *  com.google.android.gms.ads.nativead.NativeAd
 *  com.google.android.gms.ads.nativead.NativeAd$Image
 *  com.google.android.gms.ads.nativead.NativeAdView
 *  java.lang.CharSequence
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  pub.devrel.easypermissions.EasyPermissions
 */
package com.lock.utils;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.lock.services.MAccessibilityService;
import pub.devrel.easypermissions.EasyPermissions;

public class Constants {
    public static final String APP_ICON_URL = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/small_image/";
    public static final String APP_IMG_URL = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/big_image/";
    private static final String AUTO_CLOSE_NOTI = "AUTO_CLOSE_NOTI";
    public static final String BACKGROUND_TIME = "BACKGROUND_TIME";
    public static String[] BLUETOOTH_PERMISSION;
    public static final int BLUETOOTH_PERMISSION_REQUEST = 16;
    public static final String CAMERA_PKG = "CAMERA_PKG";
    public static final String CONTROL_GESTURE = "CONTROL_GESTURE";
    public static final String CREDENTIALS = "ali:uraan1234";
    public static final int DrawOverlay_REQUEST_CODE = 9;
    public static final String GETTING_APP = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/get_computer_launcher_app.php";
    public static final String GETTING_LOCK = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/get_computer_launcher_lock.php";
    public static final String GETTING_THEME = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/get_computer_launcher_themes.php";
    private static final String IS_FIRST_TIME = "IS_FIRST_TIME";
    public static final String LOCK_ICON_URL = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/small_image/";
    public static final String LOCK_IMG_URL = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/big_image/";
    public static final String LOCK_SCREEN = "com.system.request.lock.screen";
    public static final int MAX_RETRY = 2;
    public static final int MY_SOCKET_TIMEOUT_MS = 10000;
    public static final String NOTIFICATION = "NOTIFICATION";
    public static final String NOTIFICATION_GESTURE = "NOTIFICATION_GESTURE";
    public static final String ONETIME = "ONETIME";
    public static final String PAGE_COUNT = "page_count";
    public static final String PHONE_PKG = "PHONE_PKG";
    public static String[] PHONE_STATE_PERMISSION;
    public static final String POWER_DIALOG = "com.system.request.power.dialog";
    public static final String RATING_DIALOUGE_ONETIME = "RATING_DIALOUGE_ONETIME";
    public static final int RC_LOCATION_PERMISSION_REQUEST = 10;
    public static final int RC_PHONE_STATE_PERMISSION_REQUEST = 15;
    public static final String SCREEN_SHOT = "com.system.request.screen.shot";
    public static final String SHOW_IN_FULL_SCREEN = "SHOW_IN_FULL_SCREEN";
    private static final String SHOW_IN_LAND = "SHOW_IN_LAND";
    public static final String SHOW_IN_LOCK = "SHOW_IN_LOCK";
    public static final int STORAGE_PERMISSION_REQUEST = 2252;
    public static final String TAG = "LOCKSCREEN";
    public static final String THEME_ICON_URL = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/small_image/";
    public static final String THEME_IMG_URL = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/big_image/";
    public static final String TILE_I_PKG = "TILE_I_PKG";
    public static final String TILE_J_PKG = "TILE_J_PKG";
    public static final String TILE_K_PKG = "TILE_K_PKG";
    public static final String TILE_L_PKG = "TILE_L_PKG";
    public static final String TYPE_AIRBUDS = "TYPE_AIRBUDS";
    public static final String TYPE_CHARGING = "CAT_CHARGING";
    public static final String TYPE_SILENT = "CAT_SILENT";
    public static final String USE_MATERIAL_COLOR = "USE_MATERIAL_COLOR";
    private static final String WALLPAPER_COLOR = "WALLPAPER_COLOR";
    public static final String WALLPAPER_UPDATED = "WALLPAPER_UPDATED";
    public static final int WRITE_SETTINGS_REQUEST = 11;

    static {
        PHONE_STATE_PERMISSION = new String[]{"android.permission.READ_PHONE_STATE"};
        BLUETOOTH_PERMISSION = new String[]{"android.permission.BLUETOOTH_CONNECT"};
    }

    public static void SetShowInFullScreen(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(SHOW_IN_FULL_SCREEN, bl).apply();
    }

    public static void SetShowInLand(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(SHOW_IN_LAND, bl).apply();
    }

    public static boolean checkAccessibilityEnabled(Context context) {
        String string2 = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"enabled_accessibility_services");
        if (string2 == null) {
            return false;
        }
        TextUtils.SimpleStringSplitter simpleStringSplitter = new TextUtils.SimpleStringSplitter(':');
        simpleStringSplitter.setString(string2);
        while (simpleStringSplitter.hasNext()) {
            if (!simpleStringSplitter.next().equalsIgnoreCase(context.getPackageName() + "/" + MAccessibilityService.class.getName())) continue;
            return true;
        }
        return false;
    }

    public static boolean checkSystemWritePermission(Context context) {
        if (Build.VERSION.SDK_INT >= 23) {
            return Settings.System.canWrite((Context)context);
        }
        return true;
    }

    public static float convertDpToPixel(float f, Context context) {
        Resources resources = context == null ? Resources.getSystem() : context.getResources();
        return f * ((float)resources.getDisplayMetrics().densityDpi / 160.0f);
    }

    public static Bitmap drawableToBmp(Activity activity, Drawable drawable2, int n) {
        if (drawable2 != null) {
            Bitmap bitmap;
            if (drawable2.getIntrinsicWidth() > 0 && drawable2.getIntrinsicHeight() > 0) {
                int n2 = (int)Constants.convertDpToPixel(n, (Context)activity);
                bitmap = Bitmap.createBitmap((int)n2, (int)n2, (Bitmap.Config)Bitmap.Config.ARGB_4444);
            } else {
                bitmap = Bitmap.createBitmap((int)1, (int)1, (Bitmap.Config)Bitmap.Config.ARGB_4444);
            }
            Canvas canvas = new Canvas(bitmap);
            drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable2.draw(canvas);
            return bitmap;
        }
        return null;
    }

    public static Bitmap drawableToBmp(Context context, Drawable drawable2) {
        int n = (int)Constants.convertDpToPixel(20.0f, context);
        Bitmap bitmap = drawable2.getIntrinsicWidth() > 0 && drawable2.getIntrinsicHeight() > 0 ? Bitmap.createBitmap((int)n, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888) : Bitmap.createBitmap((int)1, (int)1, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable2.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable2.draw(canvas);
        return bitmap;
    }

    public static boolean getAutoCloseNoti(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(AUTO_CLOSE_NOTI, false);
    }

    public static String getCameraPkg(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(CAMERA_PKG, "");
    }

    public static boolean getControlEnabled(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(CONTROL_GESTURE, true);
    }

    public static boolean getEnable(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(ONETIME, true);
    }

    public static boolean getNotif(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(NOTIFICATION, false);
    }

    public static String getPathFromUri(Context context, Uri uri) {
        String string2;
        block3 : {
            Cursor cursor;
            String[] arrstring = new String[]{"_data"};
            try {
                cursor = context.getContentResolver().query(uri, arrstring, null, null, null);
                string2 = null;
                if (cursor == null) break block3;
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return null;
            }
            cursor.moveToFirst();
            String string3 = cursor.getString(cursor.getColumnIndex(arrstring[0]));
            cursor.close();
            string2 = string3;
        }
        return string2;
    }

    public static String getPhonePkg(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(PHONE_PKG, "");
    }

    public static boolean getRatingDailoge(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(RATING_DIALOUGE_ONETIME, true);
    }

    public static boolean getShowInFullScreen(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(SHOW_IN_FULL_SCREEN, false);
    }

    public static boolean getShowOnLock(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(SHOW_IN_LOCK, true);
    }

    public static String getTileIPackage(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(TILE_I_PKG, "com.google.android.gm");
    }

    public static String getTileJPackage(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(TILE_J_PKG, "com.facebook.katana");
    }

    public static String getTileKPackage(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(TILE_K_PKG, "com.zhiliaoapp.musically");
    }

    public static String getTileLPackage(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getString(TILE_L_PKG, "com.twitter.android");
    }

    public static int getWallpaperColor(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getInt(WALLPAPER_COLOR, context.getResources().getColor(2131100531));
    }

    public static boolean gethideInLand(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(SHOW_IN_LAND, true);
    }

    public static /* varargs */ boolean hasPermissions(Context context, String ... arrstring) {
        return EasyPermissions.hasPermissions((Context)context, (String[])arrstring);
    }

    public static boolean isAppInstalled(Context context, String string2) {
        try {
            context.getPackageManager().getApplicationInfo(string2, 0);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    public static boolean isFirstTimeLoad(Context context) {
        boolean bl = PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(IS_FIRST_TIME, true);
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(IS_FIRST_TIME, false).apply();
        return bl;
    }

    public static boolean isRotationOn(Context context) {
        int n = Settings.System.getInt((ContentResolver)context.getContentResolver(), (String)"accelerometer_rotation", (int)0);
        boolean bl = false;
        if (n == 1) {
            bl = true;
        }
        return bl;
    }

    public static boolean isUseMaterialColor(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(USE_MATERIAL_COLOR, false);
    }

    public static boolean isWallpaperUpdated(Context context) {
        return PreferenceManager.getDefaultSharedPreferences((Context)context).getBoolean(WALLPAPER_UPDATED, false);
    }

    public static void populateNativeAdView(NativeAd nativeAd, NativeAdView nativeAdView) {
        ((TextView)nativeAdView.getHeadlineView()).setText((CharSequence)nativeAd.getHeadline());
        ((TextView)nativeAdView.getCallToActionView()).setText((CharSequence)nativeAd.getCallToAction());
        if (nativeAd.getBody() != null && !nativeAd.getBody().isEmpty()) {
            nativeAdView.getBodyView().setVisibility(0);
            ((TextView)nativeAdView.getBodyView()).setText((CharSequence)nativeAd.getBody());
        } else {
            nativeAdView.getBodyView().setVisibility(4);
        }
        NativeAd.Image image = nativeAd.getIcon();
        if (image == null) {
            nativeAdView.getIconView().setVisibility(4);
        } else {
            ((ImageView)nativeAdView.getIconView()).setImageDrawable(image.getDrawable());
            nativeAdView.getIconView().setVisibility(0);
        }
        if (nativeAd.getPrice() == null) {
            nativeAdView.getPriceView().setVisibility(4);
        } else {
            nativeAdView.getPriceView().setVisibility(0);
            ((TextView)nativeAdView.getPriceView()).setText((CharSequence)nativeAd.getPrice());
        }
        if (nativeAd.getStore() == null) {
            nativeAdView.getStoreView().setVisibility(4);
        } else {
            nativeAdView.getStoreView().setVisibility(0);
            ((TextView)nativeAdView.getStoreView()).setText((CharSequence)nativeAd.getStore());
        }
        if (nativeAd.getStarRating() == null) {
            nativeAdView.getStarRatingView().setVisibility(4);
        } else {
            ((RatingBar)nativeAdView.getStarRatingView()).setRating(nativeAd.getStarRating().floatValue());
            nativeAdView.getStarRatingView().setVisibility(0);
        }
        if (nativeAd.getAdvertiser() == null) {
            nativeAdView.getAdvertiserView().setVisibility(4);
        } else {
            ((TextView)nativeAdView.getAdvertiserView()).setText((CharSequence)nativeAd.getAdvertiser());
            nativeAdView.getAdvertiserView().setVisibility(0);
        }
        nativeAdView.setNativeAd(nativeAd);
    }

    public static void setAutoCloseNoti(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(AUTO_CLOSE_NOTI, bl).apply();
    }

    public static void setAutoOrientationEnabled(Context context, boolean bl) {
        Settings.System.putInt((ContentResolver)context.getContentResolver(), (String)"accelerometer_rotation", (int)bl);
    }

    public static void setCameraPkg(Context context, String string2) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putString(CAMERA_PKG, string2).apply();
    }

    public static SharedPreferences setControlEnabled(Context context, boolean bl) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)context);
        sharedPreferences.edit().putBoolean(CONTROL_GESTURE, bl).apply();
        return sharedPreferences;
    }

    public static void setEnable(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(ONETIME, bl).apply();
    }

    public static SharedPreferences setNotif(Context context, boolean bl) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context)context);
        sharedPreferences.edit().putBoolean(NOTIFICATION, bl).apply();
        return sharedPreferences;
    }

    public static void setPhonePkg(Context context, String string2) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putString(PHONE_PKG, string2).apply();
    }

    public static void setRatingDailoge(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(RATING_DIALOUGE_ONETIME, bl).apply();
    }

    public static void setShowOnLock(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(SHOW_IN_LOCK, bl).apply();
    }

    public static boolean setUseMaterialColor(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(USE_MATERIAL_COLOR, bl).apply();
        return bl;
    }

    public static void setWallpaperColor(Context context, int n) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putInt(WALLPAPER_COLOR, n).apply();
    }

    public static void setWallpaperUpdated(Context context, boolean bl) {
        PreferenceManager.getDefaultSharedPreferences((Context)context).edit().putBoolean(WALLPAPER_UPDATED, bl).apply();
    }
}

