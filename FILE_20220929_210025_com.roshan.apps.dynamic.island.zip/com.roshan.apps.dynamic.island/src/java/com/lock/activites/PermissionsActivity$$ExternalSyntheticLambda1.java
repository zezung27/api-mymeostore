/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  com.lock.activites.PermissionsActivity
 *  java.lang.Object
 */
package com.lock.activites;

import android.widget.CompoundButton;
import com.lock.activites.PermissionsActivity;

public final class PermissionsActivity$$ExternalSyntheticLambda1
implements CompoundButton.OnCheckedChangeListener {
    public final /* synthetic */ PermissionsActivity f$0;

    public /* synthetic */ PermissionsActivity$$ExternalSyntheticLambda1(PermissionsActivity permissionsActivity) {
        this.f$0 = permissionsActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
        this.f$0.lambda$onCreate$1$com-lock-activites-PermissionsActivity(compoundButton, bl);
    }
}

