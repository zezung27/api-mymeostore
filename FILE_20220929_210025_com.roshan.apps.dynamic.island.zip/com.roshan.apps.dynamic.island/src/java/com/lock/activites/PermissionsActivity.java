/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ActivityOptions
 *  android.app.NotificationManager
 *  android.content.ComponentName
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.content.res.AssetManager
 *  android.graphics.Typeface
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.TextView
 *  android.widget.Toast
 *  android.widget.ToggleButton
 *  androidx.appcompat.app.AppCompatActivity
 *  androidx.core.app.ActivityCompat
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.List
 *  pub.devrel.easypermissions.AfterPermissionGranted
 *  pub.devrel.easypermissions.AppSettingsDialog
 *  pub.devrel.easypermissions.AppSettingsDialog$Builder
 *  pub.devrel.easypermissions.EasyPermissions
 *  pub.devrel.easypermissions.EasyPermissions$PermissionCallbacks
 *  pub.devrel.easypermissions.EasyPermissions$RationaleCallbacks
 */
package com.lock.activites;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.lock.activites.HomeActivity;
import com.lock.activites.PermissionsActivity;
import com.lock.activites.PermissionsActivity$$ExternalSyntheticLambda0;
import com.lock.activites.PermissionsActivity$$ExternalSyntheticLambda1;
import com.lock.services.MAccessibilityService;
import com.lock.utils.Constants;
import java.util.List;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class PermissionsActivity
extends AppCompatActivity
implements EasyPermissions.PermissionCallbacks,
EasyPermissions.RationaleCallbacks {
    private boolean bluetoothPermissionGranted;
    TextView lockScreen;
    Context mContxt;
    private Button next_btn;
    NotificationManager notificationManager;
    private ToggleButton toggle_enable;
    private ToggleButton toggle_notification;
    TextView tv_enable_notification;
    Typeface typefaceBold;

    static /* synthetic */ Button access$000(PermissionsActivity permissionsActivity) {
        return permissionsActivity.next_btn;
    }

    static /* synthetic */ void access$100(PermissionsActivity permissionsActivity) {
        permissionsActivity.enableLock();
    }

    private void enableLock() {
        Intent intent = new Intent("com.samsung.accessibility.installed_service");
        if (intent.resolveActivity(this.mContxt.getPackageManager()) == null) {
            intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
        }
        Bundle bundle = new Bundle();
        String string = this.mContxt.getPackageName() + "/" + MAccessibilityService.class.getName();
        bundle.putString(":settings:fragment_args_key", string);
        intent.putExtra(":settings:fragment_args_key", string);
        intent.putExtra(":settings:show_fragment_args", bundle);
        this.StartPermissionActivity(this.mContxt, intent);
    }

    private void setFullScreen() {
        this.getWindow().getDecorView().setSystemUiVisibility(8192);
    }

    public static void stopService(Context context, int n) {
        try {
            context.startService(new Intent(context, MAccessibilityService.class).putExtra("com.control.center.intent.MESSAGE", n));
        }
        catch (Throwable throwable) {}
    }

    public void StartPermissionActivity(Context context, Intent intent) {
        context.startActivity(intent, ActivityOptions.makeCustomAnimation((Context)context, (int)2130772000, (int)2130772003).toBundle());
    }

    @AfterPermissionGranted(value=15)
    public void accessPhoneStatePermision() {
        if (!Constants.hasPermissions(this.mContxt, Constants.PHONE_STATE_PERMISSION)) {
            EasyPermissions.requestPermissions((Activity)this, (String)this.getString(2131886339), (int)15, (String[])Constants.PHONE_STATE_PERMISSION);
        }
    }

    public boolean checkNotificationEnabled(Context context) {
        try {
            boolean bl = Settings.Secure.getString((ContentResolver)context.getContentResolver(), (String)"enabled_notification_listeners").contains((CharSequence)context.getPackageName());
            return bl;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    /* synthetic */ void lambda$onCreate$0$com-lock-activites-PermissionsActivity(View view) {
        this.startActivity(new Intent(this.mContxt, HomeActivity.class));
        this.overridePendingTransition(2130771980, 2130771981);
        this.finish();
    }

    /* synthetic */ void lambda$onCreate$1$com-lock-activites-PermissionsActivity(CompoundButton compoundButton, boolean bl) {
        EasyPermissions.requestPermissions((Activity)this, (String)this.getString(2131886141), (int)16, (String[])Constants.BLUETOOTH_PERMISSION);
    }

    protected void onCreate(Bundle bundle) {
        Typeface typeface;
        super.onCreate(bundle);
        this.setContentView(2131558433);
        this.mContxt = this;
        this.setFullScreen();
        this.notificationManager = (NotificationManager)this.mContxt.getSystemService("notification");
        this.lockScreen = (TextView)this.findViewById(2131362479);
        this.tv_enable_notification = (TextView)this.findViewById(2131362536);
        this.next_btn = (Button)this.findViewById(2131362276);
        this.toggle_enable = (ToggleButton)this.findViewById(2131362505);
        this.toggle_notification = (ToggleButton)this.findViewById(2131362509);
        this.typefaceBold = typeface = Typeface.createFromAsset((AssetManager)this.mContxt.getAssets(), (String)"roboto_medium.ttf");
        this.lockScreen.setTypeface(typeface);
        this.tv_enable_notification.setTypeface(this.typefaceBold);
        ((TextView)this.findViewById(2131362535)).setTypeface(this.typefaceBold);
        if (Constants.checkAccessibilityEnabled(this.mContxt)) {
            this.toggle_enable.setChecked(true);
        } else {
            this.toggle_enable.setChecked(false);
        }
        this.toggle_enable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ PermissionsActivity this$0;
            {
                this.this$0 = permissionsActivity;
            }

            /* synthetic */ void lambda$onCheckedChanged$0$com-lock-activites-PermissionsActivity$1() {
                PermissionsActivity.access$100(this.this$0);
            }

            /* synthetic */ void lambda$onCheckedChanged$1$com-lock-activites-PermissionsActivity$1() {
                this.this$0.finish();
            }

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                if (bl) {
                    new com.nordan.dialog.NordanAlertDialog$Builder((Activity)this.this$0).setAnimation(com.nordan.dialog.Animation.SLIDE).isCancellable(false).setTitle("Accessibility Permission Disclosure & Consent").setMessage("This app needs to be activated in accessibility service to show dynamic island view on top of mobile screen.\n\n1- This application do not collect or share any user data.\n\n2- This application do not store any sort of user data.").setPositiveBtnText("Agree").setNegativeBtnText("Cancel").setIcon(2131230836, false).onPositiveClicked(new com.lock.activites.PermissionsActivity$1$$ExternalSyntheticLambda0(this)).onNegativeClicked(new com.lock.activites.PermissionsActivity$1$$ExternalSyntheticLambda1(this)).build().show();
                    return;
                }
                PermissionsActivity.stopService(this.this$0.mContxt, 0);
                PermissionsActivity.access$000(this.this$0).setVisibility(8);
            }
        });
        if (Constants.getNotif(this.mContxt)) {
            this.toggle_notification.setChecked(true);
        } else {
            this.toggle_notification.setChecked(false);
        }
        this.toggle_notification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(this){
            final /* synthetic */ PermissionsActivity this$0;
            {
                this.this$0 = permissionsActivity;
            }

            /*
             * Exception decompiling
             */
            /* synthetic */ void lambda$onCheckedChanged$0$com-lock-activites-PermissionsActivity$2(}
        java.lang.IllegalStateException: Parameters not created
        
        