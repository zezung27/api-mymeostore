/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentProvider
 *  android.content.ContentResolver
 *  android.content.ContentUris
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.UriMatcher
 *  android.database.ContentObserver
 *  android.database.Cursor
 *  android.database.SQLException
 *  android.database.sqlite.SQLiteDatabase
 *  android.database.sqlite.SQLiteDatabase$CursorFactory
 *  android.database.sqlite.SQLiteOpenHelper
 *  android.database.sqlite.SQLiteQueryBuilder
 *  android.net.Uri
 *  android.util.Log
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package com.lock.providers;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;
import java.util.HashMap;
import java.util.Map;

public class InAppPurchaseProvider
extends ContentProvider {
    private static HashMap<String, String> BirthMap;
    public static final Uri CONTENT_URI;
    static final String CREATE_TABLE = " CREATE TABLE purchaseTable (id INTEGER);";
    static final String DATABASE_NAME = "BirthdayReminder";
    static final int DATABASE_VERSION = 1;
    public static final String ID = "id";
    static final String PROVIDER_NAME = "com.jalan.control.center.android12";
    static final int PURCHASE = 1;
    static final String TABLE_NAME = "purchaseTable";
    public static final String URL = "content://com.jalan.control.center.android12/purchase";
    static final UriMatcher uriMatcher;
    private SQLiteDatabase database;
    DBHelper dbHelper;

    static {
        UriMatcher uriMatcher;
        CONTENT_URI = Uri.parse((String)URL);
        BirthMap = new HashMap();
        InAppPurchaseProvider.uriMatcher = uriMatcher = new UriMatcher(-1);
        uriMatcher.addURI(PROVIDER_NAME, "purchase", 1);
        BirthMap.put((Object)ID, (Object)ID);
    }

    public int delete(Uri uri, String string2, String[] arrstring) {
        return 0;
    }

    public String getType(Uri uri) {
        if (uriMatcher.match(uri) == 1) {
            return "vnd.android.cursor.dir/vnd.example.friends";
        }
        throw new IllegalArgumentException("Unsupported URI: " + (Object)uri);
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        long l = this.database.insert(TABLE_NAME, "", contentValues);
        if (l > 0L) {
            Uri uri2 = ContentUris.withAppendedId((Uri)CONTENT_URI, (long)l);
            this.getContext().getContentResolver().notifyChange(uri2, null);
            return uri2;
        }
        throw new SQLException("Fail to add a new record into " + (Object)uri);
    }

    public boolean onCreate() {
        DBHelper dBHelper;
        SQLiteDatabase sQLiteDatabase;
        this.dbHelper = dBHelper = new DBHelper(this.getContext());
        this.database = sQLiteDatabase = dBHelper.getWritableDatabase();
        return sQLiteDatabase != null;
    }

    public Cursor query(Uri uri, String[] arrstring, String string2, String[] arrstring2, String string3) {
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        sQLiteQueryBuilder.setStrict(true);
        sQLiteQueryBuilder.setTables(TABLE_NAME);
        if (uriMatcher.match(uri) == 1) {
            sQLiteQueryBuilder.setProjectionMap(BirthMap);
            Cursor cursor = sQLiteQueryBuilder.query(this.database, arrstring, string2, arrstring2, null, null, string3);
            cursor.setNotificationUri(this.getContext().getContentResolver(), uri);
            return cursor;
        }
        throw new IllegalArgumentException("Unknown URI " + (Object)uri);
    }

    public int update(Uri uri, ContentValues contentValues, String string2, String[] arrstring) {
        return 0;
    }

    private static class DBHelper
    extends SQLiteOpenHelper {
        public DBHelper(Context context) {
            super(context, InAppPurchaseProvider.DATABASE_NAME, null, 1);
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL(InAppPurchaseProvider.CREATE_TABLE);
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int n, int n2) {
            Log.w((String)DBHelper.class.getName(), (String)("Upgrading database from version " + n + " to " + n2 + ". Old data will be destroyed"));
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS purchaseTable");
            this.onCreate(sQLiteDatabase);
        }
    }

}

