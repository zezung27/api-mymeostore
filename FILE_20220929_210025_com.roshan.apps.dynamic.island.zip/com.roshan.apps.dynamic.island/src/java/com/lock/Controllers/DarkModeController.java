/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.util.DisplayMetrics
 *  android.widget.TextView
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class DarkModeController
extends ButtonState {
    private final Context context;
    private final Intent intent;
    private String name;

    public DarkModeController(Context context) {
        super(context);
        this.context = context;
        this.intent = new Intent("android.settings.DISPLAY_SETTINGS");
        this.name = context.getString(2131886370);
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public boolean getState() {
        this.context.getApplicationContext().getResources().updateConfiguration(this.context.getApplicationContext().getResources().getConfiguration(), this.context.getApplicationContext().getResources().getDisplayMetrics());
        return (48 & this.context.getApplicationContext().getResources().getConfiguration().uiMode) == 32;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }
}

