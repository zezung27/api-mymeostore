/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Runnable
 *  java.lang.String
 */
package com.lock.Controllers;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Handler;
import android.widget.TextView;
import android.widget.Toast;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.Controllers.ScreenShotController;
import com.lock.activites.ScreenshotCaptureActivity;
import com.lock.entity.ButtonState;
import com.lock.services.MAccessibilityService;

public class ScreenShotController
extends ButtonState {
    private Context context;
    Handler handler = new Handler();

    public ScreenShotController(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public Intent getIntent() {
        return null;
    }

    @Override
    public String getName() {
        return this.context.getResources().getString(2131886398);
    }

    @Override
    public boolean getState() {
        return false;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
    }

    public boolean startScreenCapture() {
        try {
            Intent intent = new Intent(this.context, ScreenshotCaptureActivity.class);
            intent.addFlags(335544320);
            PendingIntent.getActivity((Context)this.context, (int)0, (Intent)intent, (int)0).send();
            return true;
        }
        catch (Exception exception) {
            Toast.makeText((Context)this.context, (CharSequence)"No Activity found to handle this feature", (int)0).show();
            return false;
        }
    }

    public boolean takeScreenShot(MAccessibilityService mAccessibilityService) {
        if (Build.VERSION.SDK_INT >= 28) {
            this.context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
            this.handler.postDelayed(new Runnable(this, mAccessibilityService){
                final /* synthetic */ ScreenShotController this$0;
                final /* synthetic */ MAccessibilityService val$accessibilityService;
                {
                    this.this$0 = screenShotController;
                    this.val$accessibilityService = mAccessibilityService;
                }

                public void run() {
                    this.val$accessibilityService.performGlobalAction(9);
                }
            }, 500L);
            return true;
        }
        return false;
    }
}

