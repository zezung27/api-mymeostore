/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  android.widget.TextView
 *  java.lang.Exception
 *  java.lang.String
 */
package com.lock.Controllers;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.provider.Settings;
import android.widget.TextView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.ButtonState;

public class AirPlaneModeController
extends ButtonState {
    private final Context context;
    private final Intent intent;
    private String name;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public AirPlaneModeController(Context context) {
        int n;
        super(context);
        this.context = context;
        this.intent = Build.VERSION.SDK_INT >= 29 ? new Intent("android.settings.panel.action.INTERNET_CONNECTIVITY") : new Intent("android.settings.AIRPLANE_MODE_SETTINGS");
        try {
            n = Build.MANUFACTURER.equalsIgnoreCase("samsung") ? context.getResources().getIdentifier("com.android.systemui:string/airplane_mode_plmn", null, null) : 0;
        }
        catch (Exception exception) {
            this.name = null;
            return;
        }
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/airplane_mode", null, null);
        }
        Resources resources = context.getResources();
        if (n == 0) {
            n = context.getResources().getIdentifier("com.android.systemui:string/accessibility_airplane_mode", null, null);
        }
        this.name = resources.getString(n);
    }

    @Override
    public Intent getIntent() {
        return this.intent;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public boolean getState() {
        return Settings.Global.getInt((ContentResolver)this.context.getContentResolver(), (String)"airplane_mode_on", (int)0) != 0;
    }

    @Override
    public boolean hasSystemFeature() {
        return true;
    }

    @Override
    public void setState(boolean bl, LottieAnimationView lottieAnimationView, TextView textView, TextView textView2) {
        if (bl) {
            lottieAnimationView.setImageResource(2131231049);
            return;
        }
        lottieAnimationView.setImageResource(2131231048);
    }
}

