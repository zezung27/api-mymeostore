/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.os.SystemClock
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnLongClickListener
 *  android.view.ViewGroup
 *  android.widget.Chronometer
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.airbnb.lottie.LottieAnimationView;
import com.lock.entity.Notification;
import com.lock.services.MAccessibilityService;
import com.lock.services.NotificationListener;
import com.lock.utils.Constants;
import com.lock.utils.Utils;
import java.util.ArrayList;

public class CustomNotificationIconAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private final Context mContext;
    private final NotificationListener notificationListener;
    private final ArrayList<Notification> notifications;
    ViewGroup viewGroup;

    public CustomNotificationIconAdapter(Context context, ArrayList<Notification> arrayList, NotificationListener notificationListener) {
        this.mContext = context;
        this.notifications = arrayList;
        this.notificationListener = notificationListener;
    }

    public int getItemCount() {
        ArrayList<Notification> arrayList = this.notifications;
        if (arrayList != null) {
            return arrayList.size();
        }
        return 0;
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        boolean bl;
        Notification notification = (Notification)this.notifications.get(viewHolder.getAbsoluteAdapterPosition());
        viewHolder.mChronometer.setVisibility(8);
        if (!notification.isChronometerRunning) {
            viewHolder.mChronometer.setBase(SystemClock.elapsedRealtime());
            viewHolder.mChronometer.stop();
        }
        viewHolder.itemView.setOnLongClickListener(null);
        viewHolder.itemView.setLongClickable(false);
        viewHolder.mLottieAnimationView.setVisibility(8);
        viewHolder.mLottieAnimationView.pauseAnimation();
        viewHolder.island_small_image_left.clearColorFilter();
        viewHolder.island_small_image_right.clearColorFilter();
        viewHolder.island_small_image_left.setImageResource(0);
        viewHolder.island_small_image_right.setImageResource(0);
        viewHolder.island_small_image_left.setVisibility(0);
        viewHolder.island_small_image_right.setVisibility(0);
        viewHolder.island_small_text_left.setVisibility(0);
        viewHolder.island_small_text_right.setVisibility(0);
        viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        viewHolder.island_small_text_left.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        viewHolder.island_small_text_left.setTextColor(((MAccessibilityService)this.mContext).utils.getTileColor());
        viewHolder.island_small_text_right.setTextColor(((MAccessibilityService)this.mContext).utils.getTileColor());
        if (notification.type.equalsIgnoreCase("TYPE_AIRBUDS")) {
            viewHolder.island_small_image_left.setImageResource(2131230927);
            viewHolder.island_small_text_right.setTextColor(notification.color);
            int n2 = ((MAccessibilityService)this.mContext).utils.getAirpodsBattery();
            if (n2 != -1) {
                viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, n2, 0);
                viewHolder.island_small_text_right.setCompoundDrawablePadding((int)Constants.convertDpToPixel(5.0f, this.mContext));
                String string2 = ((MAccessibilityService)this.mContext).utils.getAirPodLevel() + this.mContext.getString(2131886337);
                viewHolder.island_small_text_right.setText((CharSequence)string2);
            } else {
                viewHolder.island_small_text_right.setText(2131886124);
            }
            viewHolder.island_small_text_left.setVisibility(8);
            viewHolder.island_small_image_right.setVisibility(8);
            bl = false;
        } else {
            bl = true;
        }
        if (notification.type.equalsIgnoreCase("CAT_CHARGING")) {
            viewHolder.island_small_image_left.setVisibility(8);
            viewHolder.island_small_text_right.setTextColor(notification.color);
            viewHolder.island_small_text_right.setText(notification.tv_text);
            int n3 = ((MAccessibilityService)this.mContext).utils.getBatteryImage();
            viewHolder.island_small_text_right.setCompoundDrawablesWithIntrinsicBounds(0, 0, n3, 0);
            viewHolder.island_small_text_right.setCompoundDrawablePadding((int)Constants.convertDpToPixel(5.0f, this.mContext));
            viewHolder.island_small_text_left.setTextColor(notification.color);
            viewHolder.island_small_text_left.setText(notification.tv_title);
            viewHolder.island_small_image_right.setVisibility(8);
            bl = false;
        }
        if (notification.type.equalsIgnoreCase("CAT_SILENT")) {
            viewHolder.island_small_image_left.clearColorFilter();
            viewHolder.island_small_image_left.setImageResource(notification.local_left_icon);
            viewHolder.island_small_text_left.setText((CharSequence)"");
            viewHolder.island_small_text_right.setText(notification.tv_title);
            viewHolder.island_small_text_right.setTextColor(notification.color);
            viewHolder.island_small_image_right.setImageResource(0);
            viewHolder.island_small_image_right.setVisibility(8);
            bl = false;
        }
        if (bl) {
            if (notification.icon != null) {
                viewHolder.island_small_image_left.setImageBitmap(notification.icon);
                viewHolder.island_small_image_left.setColorFilter(-1);
                if (notification.showChronometer) {
                    viewHolder.mChronometer.setVisibility(0);
                    viewHolder.mChronometer.start();
                    notification.isChronometerRunning = true;
                    viewHolder.island_small_text_left.setText((CharSequence)"");
                    viewHolder.island_small_image_left.setColorFilter(this.mContext.getColor(2131099886));
                } else {
                    viewHolder.island_small_text_left.setText((CharSequence)((MAccessibilityService)this.mContext).utils.getFormatedDate(notification.postTime));
                }
            } else {
                viewHolder.island_small_image_left.setImageBitmap(null);
            }
            if (notification.senderIcon != null) {
                if (notification.showChronometer && notification.category.equalsIgnoreCase("call") && notification.isOngoing) {
                    viewHolder.island_small_text_right.setVisibility(8);
                    viewHolder.island_small_image_right.setVisibility(8);
                    viewHolder.island_small_text_right.setText((CharSequence)"");
                    viewHolder.mLottieAnimationView.setAnimation(2131820546);
                    viewHolder.mLottieAnimationView.setVisibility(0);
                    if (!viewHolder.mLottieAnimationView.isAnimating()) {
                        viewHolder.mLottieAnimationView.playAnimation();
                    }
                } else if (notification.template.equals((Object)"MediaStyle") && !notification.isClearable) {
                    viewHolder.mLottieAnimationView.setAnimation(2131820544);
                    viewHolder.mLottieAnimationView.setVisibility(0);
                    if (!viewHolder.mLottieAnimationView.isAnimating()) {
                        viewHolder.mLottieAnimationView.playAnimation();
                    }
                    viewHolder.island_small_text_right.setVisibility(8);
                    viewHolder.island_small_image_right.setVisibility(8);
                } else {
                    viewHolder.island_small_text_right.setVisibility(8);
                    viewHolder.island_small_image_right.setImageBitmap(notification.senderIcon);
                }
            } else {
                viewHolder.island_small_image_right.setImageResource(0);
                viewHolder.island_small_image_right.setVisibility(8);
                if (notification.tv_title != null && notification.tv_title.length() > 0) {
                    viewHolder.island_small_text_right.setVisibility(0);
                    String[] arrstring = notification.tv_title.toString().split(" ");
                    if (arrstring.length > 0) {
                        viewHolder.island_small_text_right.setText((CharSequence)arrstring[0]);
                    } else {
                        viewHolder.island_small_text_right.setText((CharSequence)"");
                    }
                } else {
                    viewHolder.island_small_text_right.setVisibility(8);
                }
            }
            viewHolder.itemView.setOnClickListener(new View.OnClickListener(){

                public void onClick(View view) {
                    int n = viewHolder.getAbsoluteAdapterPosition();
                    if (n >= 0 && n < CustomNotificationIconAdapter.this.notifications.size()) {
                        CustomNotificationIconAdapter.this.notificationListener.onItemClicked((Notification)CustomNotificationIconAdapter.this.notifications.get(n));
                        CustomNotificationIconAdapter.this.notificationListener.onItemClicked((Notification)CustomNotificationIconAdapter.this.notifications.get(n), n);
                    }
                }
            });
        }
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        LayoutInflater layoutInflater = LayoutInflater.from((Context)this.mContext);
        this.viewGroup = viewGroup;
        return new ViewHolder(layoutInflater.inflate(2131558530, viewGroup, false));
    }

    public void onViewDetachedFromWindow(ViewHolder viewHolder) {
        super.onViewDetachedFromWindow((RecyclerView.ViewHolder)viewHolder);
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        private final ImageView island_small_image_left;
        private final ImageView island_small_image_right;
        private final TextView island_small_text_left;
        private final TextView island_small_text_right;
        private final Chronometer mChronometer;
        private final LottieAnimationView mLottieAnimationView;
        private final View mRootLayout;

        public ViewHolder(View view) {
            super(view);
            this.mRootLayout = view;
            this.island_small_image_left = (ImageView)view.findViewById(2131362145);
            this.island_small_text_left = (TextView)view.findViewById(2131362146);
            this.mLottieAnimationView = (LottieAnimationView)view.findViewById(2131362352);
            this.island_small_image_right = (ImageView)view.findViewById(2131362144);
            this.island_small_text_right = (TextView)view.findViewById(2131362147);
            this.mChronometer = (Chronometer)view.findViewById(2131361963);
        }
    }

}

