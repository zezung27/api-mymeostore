/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.pm.PackageManager
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.view.ContextThemeWrapper
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.TextView
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.bumptech.glide.Glide
 *  com.bumptech.glide.RequestBuilder
 *  com.bumptech.glide.load.DataSource
 *  com.bumptech.glide.load.engine.GlideException
 *  com.bumptech.glide.request.RequestListener
 *  com.bumptech.glide.request.target.Target
 *  com.bumptech.glide.request.target.ViewTarget
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.lock.adaptar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.target.ViewTarget;
import com.lock.entity.ThemeData;
import com.lock.utils.Constants;
import java.util.ArrayList;

public class ThemeListAdaptr
extends RecyclerView.Adapter<ViewHolder> {
    int index;
    private Activity mContext;
    String nameTittle;
    public ArrayList<ThemeData> themeData;

    public ThemeListAdaptr(Activity activity, ArrayList<ThemeData> arrayList, int n) {
        this.mContext = activity;
        this.themeData = arrayList;
        this.index = n;
    }

    public int getItemCount() {
        return this.themeData.size();
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        String string2;
        String string3;
        final ThemeData themeData = (ThemeData)this.themeData.get(n);
        viewHolder.rating.setText((CharSequence)(themeData.getRating() + ""));
        viewHolder.name.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.rating.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.rating_image.setColorFilter(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.cardView.setCardBackgroundColor(Color.parseColor((String)themeData.bgColor));
        viewHolder.downloadTxt.setText((CharSequence)themeData.getDownloads());
        viewHolder.downloadTxt.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        viewHolder.intallBtn.setTextColor(Color.parseColor((String)themeData.getTxtColor()));
        if (themeData.txtColor.equalsIgnoreCase("#FFFFFF")) {
            viewHolder.intallBtn.setBackgroundResource(2131230868);
        } else {
            viewHolder.intallBtn.setBackgroundResource(2131230867);
        }
        if (this.index == 1) {
            this.nameTittle = themeData.getName() + " Theme";
            string2 = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/big_image/";
            string3 = "http://centsolapps.com/api/AppThemes/2021_themes/computer_launcher/small_image/";
        } else {
            string3 = string2 = "";
        }
        if (this.index == 2) {
            this.nameTittle = themeData.getName() + " Lock";
            string2 = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/big_image/";
            string3 = "http://centsolapps.com/api/AppThemes/2021_lock/compuer_launcher/small_image/";
        }
        if (this.index == 3) {
            this.nameTittle = themeData.getName() + "";
            string2 = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/big_image/";
            string3 = "http://centsolapps.com/api/AppThemes/2021_app/computer_launcher/small_image/";
        }
        Glide.with((Activity)this.mContext).load(string2 + themeData.getImage() + ".jpg").listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                viewHolder.progressBar.setVisibility(8);
                return false;
            }

            public boolean onResourceReady(Drawable drawable2, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                viewHolder.progressBar.setVisibility(8);
                return false;
            }
        }).into(viewHolder.banner);
        Glide.with((Activity)this.mContext).load(string3 + themeData.getIcon() + ".png").listener((RequestListener)new RequestListener<Drawable>(){

            public boolean onLoadFailed(GlideException glideException, Object object, Target<Drawable> target, boolean bl) {
                return false;
            }

            public boolean onResourceReady(Drawable drawable2, Object object, Target<Drawable> target, DataSource dataSource, boolean bl) {
                return false;
            }
        }).into(viewHolder.image);
        viewHolder.name.setText((CharSequence)this.nameTittle);
        viewHolder.intallBtn.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if (ThemeListAdaptr.this.index == 1) {
                    ThemeListAdaptr.this.nameTittle = themeData.getName() + " Theme";
                }
                if (ThemeListAdaptr.this.index == 2) {
                    ThemeListAdaptr.this.nameTittle = themeData.getName() + " Lock";
                }
                if (ThemeListAdaptr.this.index == 3) {
                    ThemeListAdaptr.this.nameTittle = themeData.getName() + "";
                }
                if (Constants.isAppInstalled((Context)ThemeListAdaptr.this.mContext, themeData.getPkg())) {
                    Intent intent = ThemeListAdaptr.this.mContext.getPackageManager().getLaunchIntentForPackage(themeData.getPkg());
                    if (ThemeListAdaptr.this.mContext != null) {
                        ThemeListAdaptr.this.mContext.startActivity(intent);
                        return;
                    }
                } else {
                    new AlertDialog.Builder((Context)new ContextThemeWrapper((Context)ThemeListAdaptr.this.mContext, 2131951618)).setTitle((CharSequence)ThemeListAdaptr.this.nameTittle).setMessage((CharSequence)"Do You Want To Install It From PlayStore.....!!!").setPositiveButton((CharSequence)"Yes", new DialogInterface.OnClickListener(){

                        public void onClick(DialogInterface dialogInterface, int n) {
                            try {
                                ThemeListAdaptr.this.mContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String)("https://play.google.com/store/apps/details?id=" + themeData.getPkg()))));
                            }
                            catch (Exception exception) {}
                        }
                    }).setNegativeButton((CharSequence)"No", null).show();
                }
            }

        });
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(LayoutInflater.from((Context)viewGroup.getContext()).inflate(2131558472, viewGroup, false));
    }

    public static class ViewHolder
    extends RecyclerView.ViewHolder {
        ImageView banner;
        CardView cardView;
        TextView downloadTxt;
        ImageView image;
        TextView intallBtn;
        TextView name;
        ProgressBar progressBar;
        TextView rating;
        ImageView rating_image;

        public ViewHolder(View view) {
            super(view);
            this.progressBar = (ProgressBar)view.findViewById(2131362324);
            this.image = (ImageView)view.findViewById(2131361897);
            this.rating_image = (ImageView)view.findViewById(2131362334);
            this.cardView = (CardView)view.findViewById(2131361942);
            this.banner = (ImageView)view.findViewById(2131361896);
            this.name = (TextView)view.findViewById(2131361898);
            this.downloadTxt = (TextView)view.findViewById(2131362027);
            this.intallBtn = (TextView)view.findViewById(2131362138);
            this.rating = (TextView)view.findViewById(2131361899);
        }
    }

}

