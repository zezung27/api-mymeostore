/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.net.Uri
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.CheckBox
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  com.squareup.picasso.Picasso
 *  com.squareup.picasso.Picasso$Builder
 *  com.squareup.picasso.RequestCreator
 *  com.squareup.picasso.RequestHandler
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.List
 */
package com.lock.adaptar;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.lock.entity.AppDetail;
import com.lock.handler.ChangeAppIconRequestHandler;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.RequestHandler;
import java.util.HashMap;
import java.util.List;

public class AppsRecyclerViewAdapter
extends RecyclerView.Adapter<ViewHolder> {
    private final List<AppDetail> apps;
    private Picasso.Builder builder;
    private ItemClickListener mClickListener;
    private final LayoutInflater mInflater;
    private Picasso mPicasso;

    public AppsRecyclerViewAdapter(Activity activity, List<AppDetail> list, HashMap<String, AppDetail> hashMap) {
        this.mInflater = LayoutInflater.from((Context)activity);
        this.apps = list;
        if (this.builder == null) {
            Picasso.Builder builder;
            this.builder = builder = new Picasso.Builder((Context)activity);
            builder.addRequestHandler((RequestHandler)new ChangeAppIconRequestHandler(activity, hashMap));
        }
        if (this.mPicasso == null) {
            this.mPicasso = this.builder.build();
        }
    }

    static /* synthetic */ List access$000(AppsRecyclerViewAdapter appsRecyclerViewAdapter) {
        return appsRecyclerViewAdapter.apps;
    }

    public int getItemCount() {
        return this.apps.size();
    }

    public long getItemId(int n) {
        return n;
    }

    public void onBindViewHolder(final ViewHolder viewHolder, int n) {
        viewHolder.cb_apps.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

            public void onCheckedChanged(CompoundButton compoundButton, boolean bl) {
                ((AppDetail)AppsRecyclerViewAdapter.access$000((AppsRecyclerViewAdapter)AppsRecyclerViewAdapter.this).get((int)viewHolder.getAbsoluteAdapterPosition())).isSelected = bl;
            }
        });
        viewHolder.cb_apps.setChecked(((AppDetail)this.apps.get((int)n)).isSelected);
        this.mPicasso.load(ChangeAppIconRequestHandler.getUri(((AppDetail)this.apps.get((int)n)).label + ((AppDetail)this.apps.get((int)n)).activityInfoName + ((AppDetail)this.apps.get((int)n)).pkg)).into(viewHolder.iv_icon);
        viewHolder.tv_app_name.setText((CharSequence)((AppDetail)this.apps.get((int)n)).label);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        return new ViewHolder(this.mInflater.inflate(2131558439, viewGroup, false));
    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    public static interface ItemClickListener {
        public void onItemClick(View var1, int var2);
    }

    public class ViewHolder
    extends RecyclerView.ViewHolder
    implements View.OnClickListener {
        CheckBox cb_apps;
        ImageView iv_icon;
        TextView tv_app_name;

        ViewHolder(View view) {
            super(view);
            this.tv_app_name = (TextView)view.findViewById(2131362528);
            this.iv_icon = (ImageView)view.findViewById(2131362159);
            this.cb_apps = (CheckBox)view.findViewById(2131361945);
            this.tv_app_name.setOnClickListener((View.OnClickListener)this);
        }

        public void onClick(View view) {
            if (AppsRecyclerViewAdapter.this.mClickListener != null) {
                AppsRecyclerViewAdapter.this.mClickListener.onItemClick(view, this.getAbsoluteAdapterPosition());
            }
        }
    }

}

