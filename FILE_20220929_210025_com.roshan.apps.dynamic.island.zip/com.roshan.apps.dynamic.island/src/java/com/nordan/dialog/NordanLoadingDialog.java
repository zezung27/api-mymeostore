/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Dialog
 *  android.content.Context
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.view.View
 *  android.view.Window
 *  android.widget.ProgressBar
 *  com.google.android.material.textview.MaterialTextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Optional
 *  java.util.function.Consumer
 */
package com.nordan.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.Window;
import android.widget.ProgressBar;
import com.google.android.material.textview.MaterialTextView;
import com.nordan.dialog.NordanLoadingDialog$$ExternalSyntheticLambda0;
import com.nordan.dialog.R;
import java.util.Optional;
import java.util.function.Consumer;

public class NordanLoadingDialog {
    private NordanLoadingDialog() {
    }

    public static Dialog createLoadingDialog(Activity activity, String string2) {
        return NordanLoadingDialog.createLoadingDialog(activity, string2, 0, -1);
    }

    public static Dialog createLoadingDialog(Activity activity, String string2, int n) {
        return NordanLoadingDialog.createLoadingDialog(activity, string2, n, -1);
    }

    public static Dialog createLoadingDialog(Activity activity, String string2, int n, int n2) {
        Dialog dialog = new Dialog((Context)activity);
        dialog.requestWindowFeature(1);
        Optional.ofNullable((Object)dialog.getWindow()).ifPresent((Consumer)new NordanLoadingDialog$$ExternalSyntheticLambda0());
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.nordan_loading_dialog);
        ((MaterialTextView)dialog.findViewById(R.id.loading_text)).setText((CharSequence)string2);
        ProgressBar progressBar = (ProgressBar)dialog.findViewById(R.id.progress_bar);
        if (n > 0) {
            progressBar.getIndeterminateDrawable().setColorFilter(activity.getColor(n), PorterDuff.Mode.MULTIPLY);
        }
        if (n2 > -1) {
            progressBar.setIndeterminate(false);
            progressBar.setProgress(n2);
        }
        return dialog;
    }

    static /* synthetic */ void lambda$createLoadingDialog$0(Window window) {
        window.setBackgroundDrawable((Drawable)new ColorDrawable(0));
    }
}

