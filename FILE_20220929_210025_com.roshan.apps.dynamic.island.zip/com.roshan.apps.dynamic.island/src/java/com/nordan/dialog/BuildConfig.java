/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.nordan.dialog;

public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "com.nordan.dialog";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "Nordan Material Dialog v1.0.7";
}

