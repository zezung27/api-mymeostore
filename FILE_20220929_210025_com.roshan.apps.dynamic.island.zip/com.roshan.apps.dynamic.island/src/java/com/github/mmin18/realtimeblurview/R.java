/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.github.mmin18.realtimeblurview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int realtimeBlurRadius = 2130969532;
        public static final int realtimeDownsampleFactor = 2130969533;
        public static final int realtimeOverlayColor = 2130969534;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] RealtimeBlurView = new int[]{2130969532, 2130969533, 2130969534};
        public static final int RealtimeBlurView_realtimeBlurRadius = 0;
        public static final int RealtimeBlurView_realtimeDownsampleFactor = 1;
        public static final int RealtimeBlurView_realtimeOverlayColor = 2;

        private styleable() {
        }
    }

}

