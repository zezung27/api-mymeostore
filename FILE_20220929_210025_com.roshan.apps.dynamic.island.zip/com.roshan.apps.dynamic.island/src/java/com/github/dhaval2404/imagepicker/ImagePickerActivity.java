/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  android.os.Bundle
 *  android.util.Log
 *  androidx.appcompat.app.AppCompatActivity
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.github.dhaval2404.imagepicker.ImagePickerActivity$WhenMappings;
import com.github.dhaval2404.imagepicker.R;
import com.github.dhaval2404.imagepicker.constant.ImageProvider;
import com.github.dhaval2404.imagepicker.provider.CameraProvider;
import com.github.dhaval2404.imagepicker.provider.CompressionProvider;
import com.github.dhaval2404.imagepicker.provider.CropProvider;
import com.github.dhaval2404.imagepicker.provider.GalleryProvider;
import com.github.dhaval2404.imagepicker.util.FileUriUtils;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0015\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u0000 )2\u00020\u0001:\u0001)B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0012\u0010\u000b\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0002J\"\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00112\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014H\u0014J\b\u0010\u0015\u001a\u00020\fH\u0016J\u0012\u0010\u0016\u001a\u00020\f2\b\u0010\r\u001a\u0004\u0018\u00010\u000eH\u0014J+\u0010\u0017\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\u00112\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u001a0\u00192\u0006\u0010\u001b\u001a\u00020\u001cH\u0016\u00a2\u0006\u0002\u0010\u001dJ\u0010\u0010\u001e\u001a\u00020\f2\u0006\u0010\u001f\u001a\u00020\u000eH\u0016J\u000e\u0010 \u001a\u00020\f2\u0006\u0010!\u001a\u00020\"J\u000e\u0010#\u001a\u00020\f2\u0006\u0010!\u001a\u00020\"J\u000e\u0010$\u001a\u00020\f2\u0006\u0010%\u001a\u00020\u001aJ\u000e\u0010&\u001a\u00020\f2\u0006\u0010!\u001a\u00020\"J\u0010\u0010'\u001a\u00020\f2\u0006\u0010!\u001a\u00020\"H\u0002J\u0006\u0010(\u001a\u00020\fR\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082.\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006*"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePickerActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "()V", "mCameraProvider", "Lcom/github/dhaval2404/imagepicker/provider/CameraProvider;", "mCompressionProvider", "Lcom/github/dhaval2404/imagepicker/provider/CompressionProvider;", "mCropProvider", "Lcom/github/dhaval2404/imagepicker/provider/CropProvider;", "mGalleryProvider", "Lcom/github/dhaval2404/imagepicker/provider/GalleryProvider;", "loadBundle", "", "savedInstanceState", "Landroid/os/Bundle;", "onActivityResult", "requestCode", "", "resultCode", "data", "Landroid/content/Intent;", "onBackPressed", "onCreate", "onRequestPermissionsResult", "permissions", "", "", "grantResults", "", "(I[Ljava/lang/String;[I)V", "onSaveInstanceState", "outState", "setCompressedImage", "uri", "Landroid/net/Uri;", "setCropImage", "setError", "message", "setImage", "setResult", "setResultCancel", "Companion", "imagepicker_release"}, k=1, mv={1, 4, 0})
public final class ImagePickerActivity
extends AppCompatActivity {
    public static final Companion Companion = new Companion(null);
    private static final String TAG = "image_picker";
    private CameraProvider mCameraProvider;
    private CompressionProvider mCompressionProvider;
    private CropProvider mCropProvider;
    private GalleryProvider mGalleryProvider;

    private final void loadBundle(Bundle bundle) {
        block10 : {
            GalleryProvider galleryProvider;
            block8 : {
                CameraProvider cameraProvider;
                block9 : {
                    block7 : {
                        CropProvider cropProvider;
                        this.mCropProvider = cropProvider = new CropProvider(this);
                        cropProvider.onRestoreInstanceState(bundle);
                        this.mCompressionProvider = new CompressionProvider(this);
                        Intent intent = this.getIntent();
                        Serializable serializable = intent != null ? intent.getSerializableExtra("extra.image_provider") : null;
                        ImageProvider imageProvider = (ImageProvider)serializable;
                        if (imageProvider == null) break block7;
                        int n = ImagePickerActivity$WhenMappings.$EnumSwitchMapping$0[imageProvider.ordinal()];
                        if (n == 1) break block8;
                        if (n == 2) break block9;
                    }
                    Log.e((String)TAG, (String)"Image provider can not be null");
                    String string2 = this.getString(R.string.error_task_cancelled);
                    Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"getString(R.string.error_task_cancelled)");
                    this.setError(string2);
                    return;
                }
                this.mCameraProvider = cameraProvider = new CameraProvider(this);
                cameraProvider.onRestoreInstanceState(bundle);
                if (bundle != null) {
                    return;
                }
                CameraProvider cameraProvider2 = this.mCameraProvider;
                if (cameraProvider2 != null) {
                    cameraProvider2.startIntent();
                    return;
                }
                break block10;
            }
            this.mGalleryProvider = galleryProvider = new GalleryProvider(this);
            if (bundle != null) {
                return;
            }
            galleryProvider.startIntent();
        }
    }

    private final void setResult(Uri uri) {
        Intent intent = new Intent();
        intent.setData(uri);
        intent.putExtra("extra.file_path", FileUriUtils.INSTANCE.getRealPath((Context)this, uri));
        this.setResult(-1, intent);
        this.finish();
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        CropProvider cropProvider;
        GalleryProvider galleryProvider;
        super.onActivityResult(n, n2, intent);
        CameraProvider cameraProvider = this.mCameraProvider;
        if (cameraProvider != null) {
            cameraProvider.onActivityResult(n, n2, intent);
        }
        if ((galleryProvider = this.mGalleryProvider) != null) {
            galleryProvider.onActivityResult(n, n2, intent);
        }
        if ((cropProvider = this.mCropProvider) == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCropProvider");
        }
        cropProvider.onActivityResult(n, n2, intent);
    }

    public void onBackPressed() {
        this.setResultCancel();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.loadBundle(bundle);
    }

    public void onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
        Intrinsics.checkNotNullParameter((Object)arrstring, (String)"permissions");
        Intrinsics.checkNotNullParameter((Object)arrn, (String)"grantResults");
        super.onRequestPermissionsResult(n, arrstring, arrn);
        CameraProvider cameraProvider = this.mCameraProvider;
        if (cameraProvider != null) {
            cameraProvider.onRequestPermissionsResult(n);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        CropProvider cropProvider;
        Intrinsics.checkNotNullParameter((Object)bundle, (String)"outState");
        CameraProvider cameraProvider = this.mCameraProvider;
        if (cameraProvider != null) {
            cameraProvider.onSaveInstanceState(bundle);
        }
        if ((cropProvider = this.mCropProvider) == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCropProvider");
        }
        cropProvider.onSaveInstanceState(bundle);
        super.onSaveInstanceState(bundle);
    }

    public final void setCompressedImage(Uri uri) {
        CropProvider cropProvider;
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        CameraProvider cameraProvider = this.mCameraProvider;
        if (cameraProvider != null) {
            cameraProvider.delete();
        }
        if ((cropProvider = this.mCropProvider) == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCropProvider");
        }
        cropProvider.delete();
        this.setResult(uri);
    }

    public final void setCropImage(Uri uri) {
        CompressionProvider compressionProvider;
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        CameraProvider cameraProvider = this.mCameraProvider;
        if (cameraProvider != null) {
            cameraProvider.delete();
        }
        if ((compressionProvider = this.mCompressionProvider) == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCompressionProvider");
        }
        if (compressionProvider.isCompressionRequired(uri)) {
            CompressionProvider compressionProvider2 = this.mCompressionProvider;
            if (compressionProvider2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mCompressionProvider");
            }
            compressionProvider2.compress(uri);
            return;
        }
        this.setResult(uri);
    }

    public final void setError(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"message");
        Intent intent = new Intent();
        intent.putExtra("extra.error", string2);
        this.setResult(64, intent);
        this.finish();
    }

    public final void setImage(Uri uri) {
        Intrinsics.checkNotNullParameter((Object)uri, (String)"uri");
        CropProvider cropProvider = this.mCropProvider;
        if (cropProvider == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCropProvider");
        }
        if (cropProvider.isCropEnabled()) {
            CropProvider cropProvider2 = this.mCropProvider;
            if (cropProvider2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mCropProvider");
            }
            cropProvider2.startIntent(uri);
            return;
        }
        CompressionProvider compressionProvider = this.mCompressionProvider;
        if (compressionProvider == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mCompressionProvider");
        }
        if (compressionProvider.isCompressionRequired(uri)) {
            CompressionProvider compressionProvider2 = this.mCompressionProvider;
            if (compressionProvider2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mCompressionProvider");
            }
            compressionProvider2.compress(uri);
            return;
        }
        this.setResult(uri);
    }

    public final void setResultCancel() {
        this.setResult(0, Companion.getCancelledIntent$imagepicker_release((Context)this));
        this.finish();
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0015\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0000\u00a2\u0006\u0002\b\tR\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\n"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePickerActivity$Companion;", "", "()V", "TAG", "", "getCancelledIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "getCancelledIntent$imagepicker_release", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Intent getCancelledIntent$imagepicker_release(Context context) {
            Intrinsics.checkNotNullParameter((Object)context, (String)"context");
            Intent intent = new Intent();
            String string2 = context.getString(R.string.error_task_cancelled);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"context.getString(R.string.error_task_cancelled)");
            intent.putExtra("extra.error", string2);
            return intent;
        }
    }

}

