/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  androidx.fragment.app.Fragment
 *  androidx.fragment.app.FragmentActivity
 *  com.github.dhaval2404.imagepicker.ImagePicker$Builder$createIntent
 *  com.github.dhaval2404.imagepicker.ImagePicker$Builder$setDismissListener
 *  com.github.dhaval2404.imagepicker.ImagePicker$Builder$showImageProviderDialog
 *  java.io.File
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.imagepicker;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.github.dhaval2404.imagepicker.ImagePickerActivity;
import com.github.dhaval2404.imagepicker.constant.ImageProvider;
import com.github.dhaval2404.imagepicker.listener.DismissListener;
import com.github.dhaval2404.imagepicker.listener.ResultListener;
import com.github.dhaval2404.imagepicker.util.DialogHelper;
import java.io.File;
import java.io.Serializable;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\b\u0016\u0018\u0000 \u00042\u00020\u0001:\u0002\u0003\u0004B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0005"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePicker;", "", "()V", "Builder", "Companion", "imagepicker_release"}, k=1, mv={1, 4, 0})
public class ImagePicker {
    public static final Companion Companion = new Companion(null);
    public static final String EXTRA_CAMERA_DEVICE = "extra.camera_device";
    public static final String EXTRA_CROP = "extra.crop";
    public static final String EXTRA_CROP_X = "extra.crop_x";
    public static final String EXTRA_CROP_Y = "extra.crop_y";
    public static final String EXTRA_ERROR = "extra.error";
    public static final String EXTRA_FILE_PATH = "extra.file_path";
    public static final String EXTRA_IMAGE_MAX_SIZE = "extra.image_max_size";
    public static final String EXTRA_IMAGE_PROVIDER = "extra.image_provider";
    public static final String EXTRA_MAX_HEIGHT = "extra.max_height";
    public static final String EXTRA_MAX_WIDTH = "extra.max_width";
    public static final String EXTRA_MIME_TYPES = "extra.mime_types";
    public static final String EXTRA_SAVE_DIRECTORY = "extra.save_directory";
    public static final int REQUEST_CODE = 2404;
    public static final int RESULT_ERROR = 64;

    @JvmStatic
    public static final String getError(Intent intent) {
        return Companion.getError(intent);
    }

    @JvmStatic
    public static final Builder with(Activity activity) {
        return Companion.with(activity);
    }

    @JvmStatic
    public static final Builder with(Fragment fragment) {
        return Companion.with(fragment);
    }

    @Metadata(bv={1, 0, 3}, d1={"\u0000x\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0007\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u000f\b\u0016\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004B\r\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\u0002\u0010\u0007J\u0006\u0010\u001e\u001a\u00020\u0000J\u000e\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u0016\u001a\u00020\u0015J\b\u0010 \u001a\u00020!H\u0002J\u001a\u0010 \u001a\u00020\u00132\u0012\u0010\"\u001a\u000e\u0012\u0004\u0012\u00020!\u0012\u0004\u0012\u00020\u00130\u0012J\u0006\u0010\b\u001a\u00020\u0000J\u0016\u0010\b\u001a\u00020\u00002\u0006\u0010#\u001a\u00020\u000b2\u0006\u0010$\u001a\u00020\u000bJ\u0006\u0010%\u001a\u00020\u0000J\u0019\u0010&\u001a\u00020\u00002\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a\u00a2\u0006\u0002\u0010'J\u0006\u0010(\u001a\u00020\u0000J\b\u0010)\u001a\u00020*H\u0002J\u0016\u0010+\u001a\u00020\u00002\u0006\u0010,\u001a\u00020\u00152\u0006\u0010-\u001a\u00020\u0015J\u000e\u0010.\u001a\u00020\u00002\u0006\u0010\u000f\u001a\u00020\u0010J\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u0010/\u001a\u000200J\u000e\u0010\u001d\u001a\u00020\u00002\u0006\u00101\u001a\u00020\u001bJ\u0014\u00102\u001a\u00020\u00002\f\u00103\u001a\b\u0012\u0004\u0012\u00020\u001304J\u000e\u00102\u001a\u00020\u00002\u0006\u00103\u001a\u00020\u000eJ\u001a\u00105\u001a\u00020\u00002\u0012\u00106\u001a\u000e\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u00130\u0012J\u0010\u00107\u001a\u00020\u00132\u0006\u00108\u001a\u00020\u0015H\u0002J\u0006\u00109\u001a\u00020\u0013J\u000e\u00109\u001a\u00020\u00132\u0006\u00108\u001a\u00020\u0015J\u0010\u0010:\u001a\u00020\u00132\u0006\u00108\u001a\u00020\u0015H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0002\u001a\u0004\u0018\u00010\u0003X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0011\u001a\u0010\u0012\u0004\u0012\u00020\u0010\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\u0015X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001aX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u001cR\u0010\u0010\u001d\u001a\u0004\u0018\u00010\u001bX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006;"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePicker$Builder;", "", "fragment", "Landroidx/fragment/app/Fragment;", "(Landroidx/fragment/app/Fragment;)V", "activity", "Landroid/app/Activity;", "(Landroid/app/Activity;)V", "crop", "", "cropX", "", "cropY", "dismissListener", "Lcom/github/dhaval2404/imagepicker/listener/DismissListener;", "imageProvider", "Lcom/github/dhaval2404/imagepicker/constant/ImageProvider;", "imageProviderInterceptor", "Lkotlin/Function1;", "", "maxHeight", "", "maxSize", "", "maxWidth", "mimeTypes", "", "", "[Ljava/lang/String;", "saveDir", "cameraOnly", "compress", "createIntent", "Landroid/content/Intent;", "onResult", "x", "y", "cropSquare", "galleryMimeTypes", "([Ljava/lang/String;)Lcom/github/dhaval2404/imagepicker/ImagePicker$Builder;", "galleryOnly", "getBundle", "Landroid/os/Bundle;", "maxResultSize", "width", "height", "provider", "file", "Ljava/io/File;", "path", "setDismissListener", "listener", "Lkotlin/Function0;", "setImageProviderInterceptor", "interceptor", "showImageProviderDialog", "reqCode", "start", "startActivity", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Builder {
        private final Activity activity;
        private boolean crop;
        private float cropX;
        private float cropY;
        private DismissListener dismissListener;
        private Fragment fragment;
        private ImageProvider imageProvider;
        private Function1<? super ImageProvider, Unit> imageProviderInterceptor;
        private int maxHeight;
        private long maxSize;
        private int maxWidth;
        private String[] mimeTypes;
        private String saveDir;

        public Builder(Activity activity) {
            Intrinsics.checkNotNullParameter((Object)activity, (String)"activity");
            this.activity = activity;
            this.imageProvider = ImageProvider.BOTH;
            this.mimeTypes = new String[0];
        }

        public Builder(Fragment fragment) {
            Intrinsics.checkNotNullParameter((Object)fragment, (String)"fragment");
            FragmentActivity fragmentActivity = fragment.requireActivity();
            Intrinsics.checkNotNullExpressionValue((Object)fragmentActivity, (String)"fragment.requireActivity()");
            this((Activity)fragmentActivity);
            this.fragment = fragment;
        }

        public static final /* synthetic */ Intent access$createIntent(Builder builder) {
            return builder.createIntent();
        }

        public static final /* synthetic */ ImageProvider access$getImageProvider$p(Builder builder) {
            return builder.imageProvider;
        }

        public static final /* synthetic */ Function1 access$getImageProviderInterceptor$p(Builder builder) {
            return builder.imageProviderInterceptor;
        }

        public static final /* synthetic */ void access$setImageProvider$p(Builder builder, ImageProvider imageProvider) {
            builder.imageProvider = imageProvider;
        }

        public static final /* synthetic */ void access$setImageProviderInterceptor$p(Builder builder, Function1 function1) {
            builder.imageProviderInterceptor = function1;
        }

        public static final /* synthetic */ void access$startActivity(Builder builder, int n) {
            builder.startActivity(n);
        }

        private final Intent createIntent() {
            Intent intent = new Intent((Context)this.activity, ImagePickerActivity.class);
            intent.putExtras(this.getBundle());
            return intent;
        }

        private final Bundle getBundle() {
            Bundle bundle = new Bundle();
            bundle.putSerializable(ImagePicker.EXTRA_IMAGE_PROVIDER, (Serializable)this.imageProvider);
            bundle.putStringArray(ImagePicker.EXTRA_MIME_TYPES, this.mimeTypes);
            bundle.putBoolean(ImagePicker.EXTRA_CROP, this.crop);
            bundle.putFloat(ImagePicker.EXTRA_CROP_X, this.cropX);
            bundle.putFloat(ImagePicker.EXTRA_CROP_Y, this.cropY);
            bundle.putInt(ImagePicker.EXTRA_MAX_WIDTH, this.maxWidth);
            bundle.putInt(ImagePicker.EXTRA_MAX_HEIGHT, this.maxHeight);
            bundle.putLong(ImagePicker.EXTRA_IMAGE_MAX_SIZE, this.maxSize);
            bundle.putString(ImagePicker.EXTRA_SAVE_DIRECTORY, this.saveDir);
            return bundle;
        }

        private final void showImageProviderDialog(int n) {
            DialogHelper.INSTANCE.showChooseAppDialog((Context)this.activity, new ResultListener<ImageProvider>(this, n){
                final /* synthetic */ int $reqCode;
                final /* synthetic */ Builder this$0;
                {
                    this.this$0 = builder;
                    this.$reqCode = n;
                }

                public void onResult(ImageProvider imageProvider) {
                    if (imageProvider != null) {
                        Builder.access$setImageProvider$p(this.this$0, imageProvider);
                        Function1 function1 = Builder.access$getImageProviderInterceptor$p(this.this$0);
                        if (function1 != null) {
                            (Unit)function1.invoke((Object)((Object)Builder.access$getImageProvider$p(this.this$0)));
                        }
                        Builder.access$startActivity(this.this$0, this.$reqCode);
                    }
                }
            }, this.dismissListener);
        }

        private final void startActivity(int n) {
            Intent intent = new Intent((Context)this.activity, ImagePickerActivity.class);
            intent.putExtras(this.getBundle());
            Fragment fragment = this.fragment;
            if (fragment != null) {
                if (fragment != null) {
                    fragment.startActivityForResult(intent, n);
                    return;
                }
            } else {
                this.activity.startActivityForResult(intent, n);
            }
        }

        public final Builder cameraOnly() {
            this.imageProvider = ImageProvider.CAMERA;
            return this;
        }

        public final Builder compress(int n) {
            this.maxSize = 1024L * (long)n;
            return this;
        }

        public final void createIntent(Function1<? super Intent, Unit> function1) {
            Intrinsics.checkNotNullParameter(function1, (String)"onResult");
            if (this.imageProvider == ImageProvider.BOTH) {
                DialogHelper.INSTANCE.showChooseAppDialog((Context)this.activity, new ResultListener<ImageProvider>(this, function1){
                    final /* synthetic */ Function1 $onResult;
                    final /* synthetic */ Builder this$0;
                    {
                        this.this$0 = builder;
                        this.$onResult = function1;
                    }

                    public void onResult(ImageProvider imageProvider) {
                        if (imageProvider != null) {
                            Builder.access$setImageProvider$p(this.this$0, imageProvider);
                            Function1 function1 = Builder.access$getImageProviderInterceptor$p(this.this$0);
                            if (function1 != null) {
                                (Unit)function1.invoke((Object)((Object)Builder.access$getImageProvider$p(this.this$0)));
                            }
                            this.$onResult.invoke((Object)Builder.access$createIntent(this.this$0));
                        }
                    }
                }, this.dismissListener);
                return;
            }
            function1.invoke((Object)this.createIntent());
        }

        public final Builder crop() {
            this.crop = true;
            return this;
        }

        public final Builder crop(float f, float f2) {
            this.cropX = f;
            this.cropY = f2;
            return this.crop();
        }

        public final Builder cropSquare() {
            return this.crop(1.0f, 1.0f);
        }

        public final Builder galleryMimeTypes(String[] arrstring) {
            Intrinsics.checkNotNullParameter((Object)arrstring, (String)"mimeTypes");
            this.mimeTypes = arrstring;
            return this;
        }

        public final Builder galleryOnly() {
            this.imageProvider = ImageProvider.GALLERY;
            return this;
        }

        public final Builder maxResultSize(int n, int n2) {
            this.maxWidth = n;
            this.maxHeight = n2;
            return this;
        }

        public final Builder provider(ImageProvider imageProvider) {
            Intrinsics.checkNotNullParameter((Object)((Object)imageProvider), (String)"imageProvider");
            this.imageProvider = imageProvider;
            return this;
        }

        public final Builder saveDir(File file) {
            Intrinsics.checkNotNullParameter((Object)file, (String)"file");
            this.saveDir = file.getAbsolutePath();
            return this;
        }

        public final Builder saveDir(String string2) {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"path");
            this.saveDir = string2;
            return this;
        }

        public final Builder setDismissListener(DismissListener dismissListener) {
            Intrinsics.checkNotNullParameter((Object)dismissListener, (String)"listener");
            this.dismissListener = dismissListener;
            return this;
        }

        public final Builder setDismissListener(Function0<Unit> function0) {
            Intrinsics.checkNotNullParameter(function0, (String)"listener");
            this.dismissListener = new DismissListener(function0){
                final /* synthetic */ Function0 $listener;
                {
                    this.$listener = function0;
                }

                public void onDismiss() {
                    this.$listener.invoke();
                }
            };
            return this;
        }

        public final Builder setImageProviderInterceptor(Function1<? super ImageProvider, Unit> function1) {
            Intrinsics.checkNotNullParameter(function1, (String)"interceptor");
            this.imageProviderInterceptor = function1;
            return this;
        }

        public final void start() {
            this.start(2404);
        }

        public final void start(int n) {
            if (this.imageProvider == ImageProvider.BOTH) {
                this.showImageProviderDialog(n);
                return;
            }
            this.startActivity(n);
        }
    }

    @Metadata(bv={1, 0, 3}, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0012\u0010\u0013\u001a\u00020\u00042\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015H\u0007J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u0019H\u0007J\u0010\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u001a\u001a\u00020\u001bH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\u0004XT\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0011X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001c"}, d2={"Lcom/github/dhaval2404/imagepicker/ImagePicker$Companion;", "", "()V", "EXTRA_CAMERA_DEVICE", "", "EXTRA_CROP", "EXTRA_CROP_X", "EXTRA_CROP_Y", "EXTRA_ERROR", "EXTRA_FILE_PATH", "EXTRA_IMAGE_MAX_SIZE", "EXTRA_IMAGE_PROVIDER", "EXTRA_MAX_HEIGHT", "EXTRA_MAX_WIDTH", "EXTRA_MIME_TYPES", "EXTRA_SAVE_DIRECTORY", "REQUEST_CODE", "", "RESULT_ERROR", "getError", "data", "Landroid/content/Intent;", "with", "Lcom/github/dhaval2404/imagepicker/ImagePicker$Builder;", "activity", "Landroid/app/Activity;", "fragment", "Landroidx/fragment/app/Fragment;", "imagepicker_release"}, k=1, mv={1, 4, 0})
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @JvmStatic
        public final String getError(Intent intent) {
            String string2 = intent != null ? intent.getStringExtra(ImagePicker.EXTRA_ERROR) : null;
            if (string2 != null) {
                return string2;
            }
            return "Unknown Error!";
        }

        @JvmStatic
        public final Builder with(Activity activity) {
            Intrinsics.checkNotNullParameter((Object)activity, (String)"activity");
            return new Builder(activity);
        }

        @JvmStatic
        public final Builder with(Fragment fragment) {
            Intrinsics.checkNotNullParameter((Object)fragment, (String)"fragment");
            return new Builder(fragment);
        }
    }

}

