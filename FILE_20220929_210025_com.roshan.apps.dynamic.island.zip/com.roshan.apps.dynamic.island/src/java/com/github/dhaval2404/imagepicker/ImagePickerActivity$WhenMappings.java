/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package com.github.dhaval2404.imagepicker;

import com.github.dhaval2404.imagepicker.constant.ImageProvider;
import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, k=3, mv={1, 4, 0})
public final class ImagePickerActivity$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static /* synthetic */ {
        int[] arrn = new int[ImageProvider.values().length];
        $EnumSwitchMapping$0 = arrn;
        arrn[ImageProvider.GALLERY.ordinal()] = 1;
        arrn[ImageProvider.CAMERA.ordinal()] = 2;
    }
}

