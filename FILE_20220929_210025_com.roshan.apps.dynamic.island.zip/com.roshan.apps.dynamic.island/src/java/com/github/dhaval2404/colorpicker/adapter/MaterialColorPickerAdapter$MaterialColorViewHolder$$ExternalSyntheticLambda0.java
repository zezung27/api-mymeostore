/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker.adapter;

import android.view.View;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter;

public final class MaterialColorPickerAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0
implements View.OnClickListener {
    public final /* synthetic */ MaterialColorPickerAdapter f$0;

    public /* synthetic */ MaterialColorPickerAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0(MaterialColorPickerAdapter materialColorPickerAdapter) {
        this.f$0 = materialColorPickerAdapter;
    }

    public final void onClick(View view) {
        MaterialColorPickerAdapter.MaterialColorViewHolder.$r8$lambda$3IzHiaQC3ObNpnPQDkY2Nymqkic(this.f$0, view);
    }
}

