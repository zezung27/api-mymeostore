/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  java.io.BufferedReader
 *  java.io.Closeable
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.Reader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  kotlin.Metadata
 *  kotlin.io.CloseableKt
 *  kotlin.io.TextStreamsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Charsets
 */
package com.github.dhaval2404.colorpicker.util;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.io.CloseableKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

@Metadata(d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0016\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\u0004\u00a8\u0006\b"}, d2={"Lcom/github/dhaval2404/colorpicker/util/AssetUtil;", "", "()V", "readAssetFile", "", "context", "Landroid/content/Context;", "fileName", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class AssetUtil {
    public static final AssetUtil INSTANCE = new AssetUtil();

    private AssetUtil() {
    }

    public final String readAssetFile(Context context, String string2) {
        String string3;
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        Intrinsics.checkNotNullParameter((Object)string2, (String)"fileName");
        InputStream inputStream = context.getAssets().open(string2);
        Intrinsics.checkNotNullExpressionValue((Object)inputStream, (String)"context.assets.open(fileName)");
        Reader reader = (Reader)new InputStreamReader(inputStream, Charsets.UTF_8);
        BufferedReader bufferedReader = reader instanceof BufferedReader ? (BufferedReader)reader : new BufferedReader(reader, 8192);
        Closeable closeable = (Closeable)bufferedReader;
        (Throwable)null;
        try {
            string3 = TextStreamsKt.readText((Reader)((Reader)((BufferedReader)closeable)));
        }
        catch (Throwable throwable) {
            try {
                throw throwable;
            }
            catch (Throwable throwable2) {
                CloseableKt.closeFinally((Closeable)closeable, (Throwable)throwable);
                throw throwable2;
            }
        }
        CloseableKt.closeFinally((Closeable)closeable, null);
        return string3;
    }
}

