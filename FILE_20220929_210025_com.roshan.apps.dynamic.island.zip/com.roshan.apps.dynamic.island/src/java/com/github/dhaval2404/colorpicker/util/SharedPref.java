/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.json.JSONArray
 */
package com.github.dhaval2404.colorpicker.util;

import android.content.Context;
import android.content.SharedPreferences;
import com.github.dhaval2404.colorpicker.util.ColorUtil;
import dalvik.annotation.SourceDebugExtension;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.json.JSONArray;

@SourceDebugExtension(value="SMAP\nSharedPref.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SharedPref.kt\ncom/github/dhaval2404/colorpicker/util/SharedPref\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,108:1\n348#2,7:109\n*S KotlinDebug\n*F\n+ 1 SharedPref.kt\ncom/github/dhaval2404/colorpicker/util/SharedPref\n*L\n59#1:109,7\n*E\n")
@Metadata(d1={"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u0000 \u00182\u00020\u0001:\u0001\u0018B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\nJ\u001e\u0010\u000b\u001a\u0004\u0018\u00010\n2\u0006\u0010\f\u001a\u00020\n2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\nH\u0002J\u000e\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u000fJ\u000e\u0010\u000e\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\nJ\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\n0\u0012J\u0016\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\n0\u00122\u0006\u0010\u0014\u001a\u00020\u0015H\u0002J\u001a\u0010\u0016\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\n2\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001H\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0019"}, d2={"Lcom/github/dhaval2404/colorpicker/util/SharedPref;", "", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "manager", "Landroid/content/SharedPreferences;", "addColor", "", "color", "", "get", "key", "default", "getRecentColor", "", "defaultColor", "getRecentColors", "", "jsonArrayToArrayList", "jsonArray", "Lorg/json/JSONArray;", "put", "value", "Companion", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class SharedPref {
    public static final Companion Companion = new Companion(null);
    private static final String KEY_RECENT_COLORS = "recent_colors";
    public static final int RECENT_COLORS_LIMIT = 10;
    private static final String SHARED_PREF_NAME = "com.github.dhaval2404.colorpicker";
    private final SharedPreferences manager;

    public SharedPref(Context context) {
        Intrinsics.checkNotNullParameter((Object)context, (String)"context");
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        Intrinsics.checkNotNullExpressionValue((Object)sharedPreferences, (String)"context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)");
        this.manager = sharedPreferences;
    }

    private final String get(String string2, String string3) {
        return this.manager.getString(string2, string3);
    }

    static /* synthetic */ String get$default(SharedPref sharedPref, String string2, String string3, int n, Object object) {
        if ((n & 2) != 0) {
            string3 = null;
        }
        return sharedPref.get(string2, string3);
    }

    private final List<String> jsonArrayToArrayList(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        int n = jSONArray.length();
        if (n > 0) {
            int n2 = 0;
            do {
                int n3 = n2 + 1;
                arrayList.add((Object)jSONArray.getString(n2));
                if (n3 >= n) break;
                n2 = n3;
            } while (true);
        }
        return (List)arrayList;
    }

    private final void put(String string2, Object object) {
        block9 : {
            SharedPreferences.Editor editor;
            block3 : {
                block8 : {
                    block7 : {
                        block6 : {
                            block5 : {
                                block4 : {
                                    block2 : {
                                        editor = this.manager.edit();
                                        if (!(object instanceof Boolean)) break block2;
                                        editor.putBoolean(string2, ((Boolean)object).booleanValue());
                                        break block3;
                                    }
                                    if (!(object instanceof Integer)) break block4;
                                    editor.putInt(string2, ((Number)object).intValue());
                                    break block3;
                                }
                                if (!(object instanceof Float)) break block5;
                                editor.putFloat(string2, ((Number)object).floatValue());
                                break block3;
                            }
                            if (!(object instanceof Long)) break block6;
                            editor.putLong(string2, ((Number)object).longValue());
                            break block3;
                        }
                        if (!(object instanceof String)) break block7;
                        editor.putString(string2, (String)object);
                        break block3;
                    }
                    if (!(object instanceof Enum)) break block8;
                    editor.putString(string2, ((Enum)object).toString());
                    break block3;
                }
                if (object != null) break block9;
                editor.remove(string2);
            }
            editor.apply();
            return;
        }
        throw new RuntimeException("Attempting to save non-supported preference");
    }

    public final void addColor(String string2) {
        int n;
        List list;
        block4 : {
            Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
            list = CollectionsKt.toMutableList((Collection)((Collection)this.getRecentColors()));
            Iterator iterator = list.iterator();
            n = 0;
            while (iterator.hasNext()) {
                String string3 = (String)iterator.next();
                if (!ColorUtil.isEqualColor$default(string2, string3, 0, 4, null)) {
                    ++n;
                    continue;
                }
                break block4;
            }
            n = -1;
        }
        if (n >= 0) {
            list.remove(n);
        }
        if (list.size() >= 10) {
            list.remove(-1 + list.size());
        }
        list.add(0, (Object)string2);
        String string4 = new JSONArray((Collection)list).toString();
        Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"JSONArray(colors).toString()");
        this.put(KEY_RECENT_COLORS, string4);
    }

    public final int getRecentColor(int n) {
        String string2 = this.getRecentColor(ColorUtil.formatColor(n));
        return ColorUtil.parseColor(string2);
    }

    public final String getRecentColor(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"defaultColor");
        List<String> list = this.getRecentColors();
        if (true ^ ((Collection)list).isEmpty()) {
            string2 = (String)CollectionsKt.first(list);
        }
        return string2;
    }

    public final List<String> getRecentColors() {
        String string2 = SharedPref.get$default(this, KEY_RECENT_COLORS, null, 2, null);
        CharSequence charSequence = string2;
        boolean bl = charSequence == null || StringsKt.isBlank((CharSequence)charSequence);
        if (bl) {
            List list = Collections.emptyList();
            Intrinsics.checkNotNullExpressionValue((Object)list, (String)"emptyList()");
            return list;
        }
        return this.jsonArrayToArrayList(new JSONArray(string2));
    }

    @Metadata(d1={"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\b"}, d2={"Lcom/github/dhaval2404/colorpicker/util/SharedPref$Companion;", "", "()V", "KEY_RECENT_COLORS", "", "RECENT_COLORS_LIMIT", "", "SHARED_PREF_NAME", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }
    }

}

