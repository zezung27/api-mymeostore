/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  androidx.cardview.widget.CardView
 *  androidx.recyclerview.widget.RecyclerView
 *  androidx.recyclerview.widget.RecyclerView$Adapter
 *  androidx.recyclerview.widget.RecyclerView$ViewHolder
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package com.github.dhaval2404.colorpicker.adapter;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.github.dhaval2404.colorpicker.R;
import com.github.dhaval2404.colorpicker.adapter.ColorViewBinding;
import com.github.dhaval2404.colorpicker.adapter.RecentColorAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0;
import com.github.dhaval2404.colorpicker.listener.ColorListener;
import com.github.dhaval2404.colorpicker.model.ColorShape;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1={"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00000\u0001:\u0001\u001cB\u0013\u0012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\u0002\u0010\u0006J\u000e\u0010\f\u001a\u00020\u00052\u0006\u0010\r\u001a\u00020\u000eJ\b\u0010\u000f\u001a\u00020\u000eH\u0016J\u001c\u0010\u0010\u001a\u00020\u00112\n\u0010\u0012\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u001c\u0010\u0013\u001a\u00060\u0002R\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u000eH\u0016J\u000e\u0010\u0017\u001a\u00020\u00112\u0006\u0010\u0018\u001a\u00020\bJ\u000e\u0010\u0019\u001a\u00020\u00112\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u001a\u001a\u00020\u00112\u0006\u0010\u001b\u001a\u00020\u0005R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001d"}, d2={"Lcom/github/dhaval2404/colorpicker/adapter/RecentColorAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/github/dhaval2404/colorpicker/adapter/RecentColorAdapter$MaterialColorViewHolder;", "colors", "", "", "(Ljava/util/List;)V", "colorListener", "Lcom/github/dhaval2404/colorpicker/listener/ColorListener;", "colorShape", "Lcom/github/dhaval2404/colorpicker/model/ColorShape;", "emptyColor", "getItem", "position", "", "getItemCount", "onBindViewHolder", "", "holder", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "setColorListener", "listener", "setColorShape", "setEmptyColor", "color", "MaterialColorViewHolder", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
public final class RecentColorAdapter
extends RecyclerView.Adapter<MaterialColorViewHolder> {
    private ColorListener colorListener;
    private ColorShape colorShape;
    private final List<String> colors;
    private String emptyColor;

    public RecentColorAdapter(List<String> list) {
        Intrinsics.checkNotNullParameter(list, (String)"colors");
        this.colors = list;
        this.colorShape = ColorShape.CIRCLE;
        this.emptyColor = "#E0E0E0";
    }

    public final String getItem(int n) {
        if (n < this.colors.size()) {
            return (String)this.colors.get(n);
        }
        return this.emptyColor;
    }

    public int getItemCount() {
        return 10;
    }

    public void onBindViewHolder(MaterialColorViewHolder materialColorViewHolder, int n) {
        Intrinsics.checkNotNullParameter((Object)((Object)materialColorViewHolder), (String)"holder");
        materialColorViewHolder.bind(n);
    }

    public MaterialColorViewHolder onCreateViewHolder(ViewGroup viewGroup, int n) {
        Intrinsics.checkNotNullParameter((Object)viewGroup, (String)"parent");
        return new MaterialColorViewHolder(ColorViewBinding.INSTANCE.inflateAdapterItemView(viewGroup));
    }

    public final void setColorListener(ColorListener colorListener) {
        Intrinsics.checkNotNullParameter((Object)colorListener, (String)"listener");
        this.colorListener = colorListener;
    }

    public final void setColorShape(ColorShape colorShape) {
        Intrinsics.checkNotNullParameter((Object)((Object)colorShape), (String)"colorShape");
        this.colorShape = colorShape;
    }

    public final void setEmptyColor(String string2) {
        Intrinsics.checkNotNullParameter((Object)string2, (String)"color");
        this.emptyColor = string2;
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    @Metadata(d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0004\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bR\u0016\u0010\u0005\u001a\n \u0007*\u0004\u0018\u00010\u00060\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2={"Lcom/github/dhaval2404/colorpicker/adapter/RecentColorAdapter$MaterialColorViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "rootView", "Landroid/view/View;", "(Lcom/github/dhaval2404/colorpicker/adapter/RecentColorAdapter;Landroid/view/View;)V", "colorView", "Landroidx/cardview/widget/CardView;", "kotlin.jvm.PlatformType", "bind", "", "position", "", "colorpicker_release"}, k=1, mv={1, 5, 1}, xi=48)
    public final class MaterialColorViewHolder
    extends RecyclerView.ViewHolder {
        private final CardView colorView;
        private final View rootView;

        public static /* synthetic */ void $r8$lambda$p3HHvRbNqY_UhT1oaiT60Iz-k1w(RecentColorAdapter recentColorAdapter, View view) {
            MaterialColorViewHolder._init_$lambda-0(recentColorAdapter, view);
        }

        public MaterialColorViewHolder(View view) {
            Intrinsics.checkNotNullParameter((Object)((Object)RecentColorAdapter.this), (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)view, (String)"rootView");
            super(view);
            this.rootView = view;
            this.colorView = (CardView)view.findViewById(R.id.colorView);
            view.setOnClickListener((View.OnClickListener)new RecentColorAdapter$MaterialColorViewHolder$$ExternalSyntheticLambda0(RecentColorAdapter.this));
        }

        private static final void _init_$lambda-0(RecentColorAdapter recentColorAdapter, View view) {
            Intrinsics.checkNotNullParameter((Object)((Object)recentColorAdapter), (String)"this$0");
            Object object = view.getTag();
            if (object != null) {
                int n = (Integer)object;
                if (n < recentColorAdapter.colors.size()) {
                    String string2 = recentColorAdapter.getItem(n);
                    ColorListener colorListener = recentColorAdapter.colorListener;
                    if (colorListener == null) {
                        return;
                    }
                    colorListener.onColorSelected(Color.parseColor((String)string2), string2);
                }
                return;
            }
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
        }

        public final void bind(int n) {
            String string2 = RecentColorAdapter.this.getItem(n);
            this.rootView.setTag((Object)n);
            ColorViewBinding colorViewBinding = ColorViewBinding.INSTANCE;
            CardView cardView = this.colorView;
            Intrinsics.checkNotNullExpressionValue((Object)cardView, (String)"colorView");
            colorViewBinding.setBackgroundColor(cardView, string2);
            ColorViewBinding colorViewBinding2 = ColorViewBinding.INSTANCE;
            CardView cardView2 = this.colorView;
            Intrinsics.checkNotNullExpressionValue((Object)cardView2, (String)"colorView");
            colorViewBinding2.setCardRadius(cardView2, RecentColorAdapter.this.colorShape);
        }
    }

}

