/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  java.lang.Object
 */
package com.github.dhaval2404.colorpicker;

import android.content.DialogInterface;
import com.github.dhaval2404.colorpicker.MaterialColorPickerDialog;
import com.github.dhaval2404.colorpicker.adapter.MaterialColorPickerAdapter;

public final class MaterialColorPickerDialog$$ExternalSyntheticLambda0
implements DialogInterface.OnClickListener {
    public final /* synthetic */ MaterialColorPickerAdapter f$0;
    public final /* synthetic */ MaterialColorPickerDialog f$1;

    public /* synthetic */ MaterialColorPickerDialog$$ExternalSyntheticLambda0(MaterialColorPickerAdapter materialColorPickerAdapter, MaterialColorPickerDialog materialColorPickerDialog) {
        this.f$0 = materialColorPickerAdapter;
        this.f$1 = materialColorPickerDialog;
    }

    public final void onClick(DialogInterface dialogInterface, int n) {
        MaterialColorPickerDialog.$r8$lambda$xAhmCZAlSyJRZLc8BJXQa1TkN1s(this.f$0, this.f$1, dialogInterface, n);
    }
}

