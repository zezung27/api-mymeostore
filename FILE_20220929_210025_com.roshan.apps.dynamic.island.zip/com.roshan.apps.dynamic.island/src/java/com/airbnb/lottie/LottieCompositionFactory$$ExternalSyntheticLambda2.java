/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import android.content.Context;
import com.airbnb.lottie.LottieCompositionFactory;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda2
implements Callable {
    public final /* synthetic */ Context f$0;
    public final /* synthetic */ String f$1;
    public final /* synthetic */ String f$2;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda2(Context context, String string2, String string3) {
        this.f$0 = context;
        this.f$1 = string2;
        this.f$2 = string3;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromUrl$0(this.f$0, this.f$1, this.f$2);
    }
}

