/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.String
 */
package com.airbnb.lottie.parser.moshi;

import java.io.IOException;

final class JsonEncodingException
extends IOException {
    JsonEncodingException(String string2) {
        super(string2);
    }
}

