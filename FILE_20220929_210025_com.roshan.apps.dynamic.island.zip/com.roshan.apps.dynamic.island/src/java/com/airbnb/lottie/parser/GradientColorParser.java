/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  java.io.IOException
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.List
 */
package com.airbnb.lottie.parser;

import android.graphics.Color;
import com.airbnb.lottie.model.content.GradientColor;
import com.airbnb.lottie.parser.ValueParser;
import com.airbnb.lottie.parser.moshi.JsonReader;
import com.airbnb.lottie.utils.MiscUtils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GradientColorParser
implements ValueParser<GradientColor> {
    private int colorPoints;

    public GradientColorParser(int n) {
        this.colorPoints = n;
    }

    private GradientColor addOpacityStopsToGradientIfNeeded(GradientColor gradientColor, List<Float> list) {
        int n;
        if (list.size() <= n) {
            return gradientColor;
        }
        float[] arrf = gradientColor.getPositions();
        int[] arrn = gradientColor.getColors();
        int n2 = (list.size() - n) / 2;
        float[] arrf2 = new float[n2];
        float[] arrf3 = new float[n2];
        int n3 = 0;
        int n4 = 0;
        for (n = 4 * this.colorPoints; n < list.size(); ++n) {
            if (n % 2 == 0) {
                arrf2[n4] = ((Float)list.get(n)).floatValue();
                continue;
            }
            arrf3[n4] = ((Float)list.get(n)).floatValue();
            ++n4;
        }
        float[] arrf4 = GradientColorParser.mergeUniqueElements(gradientColor.getPositions(), arrf2);
        int n5 = arrf4.length;
        int[] arrn2 = new int[n5];
        while (n3 < n5) {
            float f = arrf4[n3];
            int n6 = Arrays.binarySearch((float[])arrf, (float)f);
            int n7 = Arrays.binarySearch((float[])arrf2, (float)f);
            if (n6 >= 0 && n7 <= 0) {
                arrn2[n3] = this.getColorInBetweenOpacityStops(f, arrn[n6], arrf2, arrf3);
            } else {
                if (n7 < 0) {
                    n7 = -(n7 + 1);
                }
                arrn2[n3] = this.getColorInBetweenColorStops(f, arrf3[n7], arrf, arrn);
            }
            ++n3;
        }
        return new GradientColor(arrf4, arrn2);
    }

    private int getColorInBetweenColorStops(float f, float f2, float[] arrf, int[] arrn) {
        if (arrn.length >= 2 && f != arrf[0]) {
            for (int i = 1; i < arrf.length; ++i) {
                float f3 = arrf[i];
                if (f3 < f && i != arrf.length - 1) {
                    continue;
                }
                int n = i - 1;
                float f4 = arrf[n];
                float f5 = f3 - f4;
                float f6 = (f - f4) / f5;
                int n2 = arrn[i];
                int n3 = arrn[n];
                return Color.argb((int)((int)(f2 * 255.0f)), (int)MiscUtils.lerp(Color.red((int)n3), Color.red((int)n2), f6), (int)MiscUtils.lerp(Color.green((int)n3), Color.green((int)n2), f6), (int)MiscUtils.lerp(Color.blue((int)n3), Color.blue((int)n2), f6));
            }
            throw new IllegalArgumentException("Unreachable code.");
        }
        return arrn[0];
    }

    private int getColorInBetweenOpacityStops(float f, int n, float[] arrf, float[] arrf2) {
        if (arrf2.length >= 2 && !(f <= arrf[0])) {
            for (int i = 1; i < arrf.length; ++i) {
                float f2;
                float f3 = arrf[i];
                float f4 = f3 FCMPG f;
                if (f4 < 0 && i != arrf.length - 1) {
                    continue;
                }
                if (f4 <= 0) {
                    f2 = arrf2[i];
                } else {
                    int n2 = i - 1;
                    float f5 = arrf[n2];
                    float f6 = f3 - f5;
                    float f7 = (f - f5) / f6;
                    f2 = MiscUtils.lerp(arrf2[n2], arrf2[i], f7);
                }
                return Color.argb((int)((int)(f2 * 255.0f)), (int)Color.red((int)n), (int)Color.green((int)n), (int)Color.blue((int)n));
            }
            throw new IllegalArgumentException("Unreachable code.");
        }
        return Color.argb((int)((int)(255.0f * arrf2[0])), (int)Color.red((int)n), (int)Color.green((int)n), (int)Color.blue((int)n));
    }

    protected static float[] mergeUniqueElements(float[] arrf, float[] arrf2) {
        if (arrf.length == 0) {
            return arrf2;
        }
        if (arrf2.length == 0) {
            return arrf;
        }
        int n = arrf.length + arrf2.length;
        float[] arrf3 = new float[n];
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        for (int i = 0; i < n; ++i) {
            int n5 = arrf.length;
            float f = Float.NaN;
            float f2 = n3 < n5 ? arrf[n3] : f;
            if (n4 < arrf2.length) {
                f = arrf2[n4];
            }
            if (!Float.isNaN((float)f) && !(f2 < f)) {
                if (!Float.isNaN((float)f2) && !(f < f2)) {
                    arrf3[i] = f2;
                    ++n3;
                    ++n4;
                    ++n2;
                    continue;
                }
                arrf3[i] = f;
                ++n4;
                continue;
            }
            arrf3[i] = f2;
            ++n3;
        }
        if (n2 == 0) {
            return arrf3;
        }
        return Arrays.copyOf((float[])arrf3, (int)(n - n2));
    }

    @Override
    public GradientColor parse(JsonReader jsonReader, float f) throws IOException {
        ArrayList arrayList = new ArrayList();
        JsonReader.Token token = jsonReader.peek();
        JsonReader.Token token2 = JsonReader.Token.BEGIN_ARRAY;
        int n = 0;
        boolean bl = token == token2;
        if (bl) {
            jsonReader.beginArray();
        }
        while (jsonReader.hasNext()) {
            arrayList.add((Object)Float.valueOf((float)((float)jsonReader.nextDouble())));
        }
        if (arrayList.size() == 4 && ((Float)arrayList.get(0)).floatValue() == 1.0f) {
            arrayList.set(0, (Object)Float.valueOf((float)0.0f));
            arrayList.add((Object)Float.valueOf((float)1.0f));
            arrayList.add((Object)((Float)arrayList.get(1)));
            arrayList.add((Object)((Float)arrayList.get(2)));
            arrayList.add((Object)((Float)arrayList.get(3)));
            this.colorPoints = 2;
        }
        if (bl) {
            jsonReader.endArray();
        }
        if (this.colorPoints == -1) {
            this.colorPoints = arrayList.size() / 4;
        }
        int n2 = this.colorPoints;
        float[] arrf = new float[n2];
        int[] arrn = new int[n2];
        int n3 = 0;
        int n4 = 0;
        while (n < 4 * this.colorPoints) {
            int n5 = n / 4;
            double d = ((Float)arrayList.get(n)).floatValue();
            int n6 = n % 4;
            if (n6 != 0) {
                if (n6 != 1) {
                    if (n6 != 2) {
                        if (n6 == 3) {
                            arrn[n5] = Color.argb((int)255, (int)n3, (int)n4, (int)((int)(d * 255.0)));
                        }
                    } else {
                        n4 = (int)(d * 255.0);
                    }
                } else {
                    n3 = (int)(d * 255.0);
                }
            } else {
                float f2;
                float f3;
                arrf[n5] = n5 > 0 && (f3 = arrf[n5 - 1]) >= (f2 = (float)d) ? f2 + 0.01f : (float)d;
            }
            ++n;
        }
        return this.addOpacityStopsToGradientIfNeeded(new GradientColor(arrf, arrn), (List<Float>)arrayList);
    }
}

