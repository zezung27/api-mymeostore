/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.PointF
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Collections
 *  java.util.List
 */
package com.airbnb.lottie.animation.keyframe;

import android.graphics.PointF;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.airbnb.lottie.value.Keyframe;
import com.airbnb.lottie.value.LottieValueCallback;
import java.util.Collections;
import java.util.List;

public class SplitDimensionPathKeyframeAnimation
extends BaseKeyframeAnimation<PointF, PointF> {
    private final PointF point = new PointF();
    private final PointF pointWithCallbackValues = new PointF();
    private final BaseKeyframeAnimation<Float, Float> xAnimation;
    protected LottieValueCallback<Float> xValueCallback;
    private final BaseKeyframeAnimation<Float, Float> yAnimation;
    protected LottieValueCallback<Float> yValueCallback;

    public SplitDimensionPathKeyframeAnimation(BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation, BaseKeyframeAnimation<Float, Float> baseKeyframeAnimation2) {
        super(Collections.emptyList());
        this.xAnimation = baseKeyframeAnimation;
        this.yAnimation = baseKeyframeAnimation2;
        this.setProgress(this.getProgress());
    }

    @Override
    public PointF getValue() {
        return this.getValue(null, 0.0f);
    }

    @Override
    PointF getValue(Keyframe<PointF> keyframe, float f) {
        Float f2;
        Keyframe<Float> keyframe2;
        if (this.xValueCallback != null && (keyframe2 = this.xAnimation.getCurrentKeyframe()) != null) {
            float f3 = this.xAnimation.getInterpolatedCurrentKeyframeProgress();
            Float f4 = keyframe2.endFrame;
            LottieValueCallback<Float> lottieValueCallback = this.xValueCallback;
            float f5 = keyframe2.startFrame;
            float f6 = f4 == null ? keyframe2.startFrame : f4.floatValue();
            f2 = lottieValueCallback.getValueInternal(f5, f6, (Float)keyframe2.startValue, (Float)keyframe2.endValue, f, f, f3);
        } else {
            f2 = null;
        }
        LottieValueCallback<Float> lottieValueCallback = this.yValueCallback;
        Float f7 = null;
        if (lottieValueCallback != null) {
            Keyframe<Float> keyframe3 = this.yAnimation.getCurrentKeyframe();
            f7 = null;
            if (keyframe3 != null) {
                float f8 = this.yAnimation.getInterpolatedCurrentKeyframeProgress();
                Float f9 = keyframe3.endFrame;
                LottieValueCallback<Float> lottieValueCallback2 = this.yValueCallback;
                float f10 = keyframe3.startFrame;
                float f11 = f9 == null ? keyframe3.startFrame : f9.floatValue();
                f7 = lottieValueCallback2.getValueInternal(f10, f11, (Float)keyframe3.startValue, (Float)keyframe3.endValue, f, f, f8);
            }
        }
        if (f2 == null) {
            this.pointWithCallbackValues.set(this.point.x, 0.0f);
        } else {
            this.pointWithCallbackValues.set(f2.floatValue(), 0.0f);
        }
        if (f7 == null) {
            PointF pointF = this.pointWithCallbackValues;
            pointF.set(pointF.x, this.point.y);
        } else {
            PointF pointF = this.pointWithCallbackValues;
            pointF.set(pointF.x, f7.floatValue());
        }
        return this.pointWithCallbackValues;
    }

    @Override
    public void setProgress(float f) {
        this.xAnimation.setProgress(f);
        this.yAnimation.setProgress(f);
        this.point.set(this.xAnimation.getValue().floatValue(), this.yAnimation.getValue().floatValue());
        for (int i = 0; i < this.listeners.size(); ++i) {
            ((BaseKeyframeAnimation.AnimationListener)this.listeners.get(i)).onValueChanged();
        }
    }

    public void setXValueCallback(LottieValueCallback<Float> lottieValueCallback) {
        LottieValueCallback<Float> lottieValueCallback2 = this.xValueCallback;
        if (lottieValueCallback2 != null) {
            lottieValueCallback2.setAnimation(null);
        }
        this.xValueCallback = lottieValueCallback;
        if (lottieValueCallback != null) {
            lottieValueCallback.setAnimation(this);
        }
    }

    public void setYValueCallback(LottieValueCallback<Float> lottieValueCallback) {
        LottieValueCallback<Float> lottieValueCallback2 = this.yValueCallback;
        if (lottieValueCallback2 != null) {
            lottieValueCallback2.setAnimation(null);
        }
        this.yValueCallback = lottieValueCallback;
        if (lottieValueCallback != null) {
            lottieValueCallback.setAnimation(this);
        }
    }
}

