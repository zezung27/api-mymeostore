/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.animation.Animator$AnimatorPauseListener
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.ColorFilter
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$Callback
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.Log
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  androidx.appcompat.content.res.AppCompatResources
 *  androidx.appcompat.widget.AppCompatImageView
 *  java.io.ByteArrayInputStream
 *  java.io.InputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.widget.AppCompatImageView;
import com.airbnb.lottie.FontAssetDelegate;
import com.airbnb.lottie.ImageAssetDelegate;
import com.airbnb.lottie.L;
import com.airbnb.lottie.LottieAnimationView$$ExternalSyntheticLambda0;
import com.airbnb.lottie.LottieAnimationView$$ExternalSyntheticLambda1;
import com.airbnb.lottie.LottieAnimationView$$ExternalSyntheticLambda2;
import com.airbnb.lottie.LottieAnimationView$$ExternalSyntheticLambda3;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieListener;
import com.airbnb.lottie.LottieOnCompositionLoadedListener;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.LottieResult;
import com.airbnb.lottie.LottieTask;
import com.airbnb.lottie.PerformanceTracker;
import com.airbnb.lottie.R;
import com.airbnb.lottie.RenderMode;
import com.airbnb.lottie.SimpleColorFilter;
import com.airbnb.lottie.TextDelegate;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.utils.Logger;
import com.airbnb.lottie.utils.Utils;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.LottieValueCallback;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class LottieAnimationView
extends AppCompatImageView {
    private static final LottieListener<Throwable> DEFAULT_FAILURE_LISTENER = new LottieAnimationView$$ExternalSyntheticLambda2();
    private static final String TAG = "LottieAnimationView";
    private String animationName;
    private int animationResId;
    private boolean autoPlay = false;
    private boolean cacheComposition = true;
    private LottieComposition composition;
    private LottieTask<LottieComposition> compositionTask;
    private LottieListener<Throwable> failureListener;
    private int fallbackResource = 0;
    private boolean ignoreUnschedule = false;
    private final LottieListener<LottieComposition> loadedListener = new LottieAnimationView$$ExternalSyntheticLambda1(this);
    private final LottieDrawable lottieDrawable = new LottieDrawable();
    private final Set<LottieOnCompositionLoadedListener> lottieOnCompositionLoadedListeners = new HashSet();
    private final Set<UserActionTaken> userActionsTaken = new HashSet();
    private final LottieListener<Throwable> wrappedFailureListener = new LottieListener<Throwable>(){

        @Override
        public void onResult(Throwable throwable) {
            if (LottieAnimationView.this.fallbackResource != 0) {
                LottieAnimationView lottieAnimationView = LottieAnimationView.this;
                lottieAnimationView.setImageResource(lottieAnimationView.fallbackResource);
            }
            LottieListener lottieListener = LottieAnimationView.this.failureListener == null ? DEFAULT_FAILURE_LISTENER : LottieAnimationView.this.failureListener;
            lottieListener.onResult(throwable);
        }
    };

    public LottieAnimationView(Context context) {
        super(context);
        this.init(null, R.attr.lottieAnimationViewStyle);
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(attributeSet, R.attr.lottieAnimationViewStyle);
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet, int n) {
        super(context, attributeSet, n);
        this.init(attributeSet, n);
    }

    private void cancelLoaderTask() {
        LottieTask<LottieComposition> lottieTask = this.compositionTask;
        if (lottieTask != null) {
            lottieTask.removeListener(this.loadedListener);
            this.compositionTask.removeFailureListener(this.wrappedFailureListener);
        }
    }

    private void clearComposition() {
        this.composition = null;
        this.lottieDrawable.clearComposition();
    }

    private LottieTask<LottieComposition> fromAssets(String string2) {
        if (this.isInEditMode()) {
            return new LottieTask<LottieComposition>(new LottieAnimationView$$ExternalSyntheticLambda3(this, string2), true);
        }
        if (this.cacheComposition) {
            return LottieCompositionFactory.fromAsset(this.getContext(), string2);
        }
        return LottieCompositionFactory.fromAsset(this.getContext(), string2, null);
    }

    private LottieTask<LottieComposition> fromRawRes(int n) {
        if (this.isInEditMode()) {
            return new LottieTask<LottieComposition>(new LottieAnimationView$$ExternalSyntheticLambda0(this, n), true);
        }
        if (this.cacheComposition) {
            return LottieCompositionFactory.fromRawRes(this.getContext(), n);
        }
        return LottieCompositionFactory.fromRawRes(this.getContext(), n, null);
    }

    private void init(AttributeSet attributeSet, int n) {
        String string2;
        TypedArray typedArray = this.getContext().obtainStyledAttributes(attributeSet, R.styleable.LottieAnimationView, n, 0);
        this.cacheComposition = typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_cacheComposition, true);
        boolean bl = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_rawRes);
        boolean bl2 = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_fileName);
        boolean bl3 = typedArray.hasValue(R.styleable.LottieAnimationView_lottie_url);
        if (bl && bl2) {
            throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
        }
        if (bl) {
            int n2 = typedArray.getResourceId(R.styleable.LottieAnimationView_lottie_rawRes, 0);
            if (n2 != 0) {
                this.setAnimation(n2);
            }
        } else if (bl2) {
            String string3 = typedArray.getString(R.styleable.LottieAnimationView_lottie_fileName);
            if (string3 != null) {
                this.setAnimation(string3);
            }
        } else if (bl3 && (string2 = typedArray.getString(R.styleable.LottieAnimationView_lottie_url)) != null) {
            this.setAnimationFromUrl(string2);
        }
        this.setFallbackResource(typedArray.getResourceId(R.styleable.LottieAnimationView_lottie_fallbackRes, 0));
        if (typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_autoPlay, false)) {
            this.autoPlay = true;
        }
        if (typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_loop, false)) {
            this.lottieDrawable.setRepeatCount(-1);
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_repeatMode)) {
            this.setRepeatMode(typedArray.getInt(R.styleable.LottieAnimationView_lottie_repeatMode, 1));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_repeatCount)) {
            this.setRepeatCount(typedArray.getInt(R.styleable.LottieAnimationView_lottie_repeatCount, -1));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_speed)) {
            this.setSpeed(typedArray.getFloat(R.styleable.LottieAnimationView_lottie_speed, 1.0f));
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_clipToCompositionBounds)) {
            this.setClipToCompositionBounds(typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_clipToCompositionBounds, true));
        }
        this.setImageAssetsFolder(typedArray.getString(R.styleable.LottieAnimationView_lottie_imageAssetsFolder));
        this.setProgress(typedArray.getFloat(R.styleable.LottieAnimationView_lottie_progress, 0.0f));
        this.enableMergePathsForKitKatAndAbove(typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove, false));
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_colorFilter)) {
            int n3 = typedArray.getResourceId(R.styleable.LottieAnimationView_lottie_colorFilter, -1);
            SimpleColorFilter simpleColorFilter = new SimpleColorFilter(AppCompatResources.getColorStateList((Context)this.getContext(), (int)n3).getDefaultColor());
            KeyPath keyPath = new KeyPath("**");
            LottieValueCallback<SimpleColorFilter> lottieValueCallback = new LottieValueCallback<SimpleColorFilter>(simpleColorFilter);
            this.addValueCallback(keyPath, (T)LottieProperty.COLOR_FILTER, lottieValueCallback);
        }
        if (typedArray.hasValue(R.styleable.LottieAnimationView_lottie_renderMode)) {
            int n4 = typedArray.getInt(R.styleable.LottieAnimationView_lottie_renderMode, RenderMode.AUTOMATIC.ordinal());
            if (n4 >= RenderMode.values().length) {
                n4 = RenderMode.AUTOMATIC.ordinal();
            }
            this.setRenderMode(RenderMode.values()[n4]);
        }
        this.setIgnoreDisabledSystemAnimations(typedArray.getBoolean(R.styleable.LottieAnimationView_lottie_ignoreDisabledSystemAnimations, false));
        typedArray.recycle();
        LottieDrawable lottieDrawable = this.lottieDrawable;
        float f = Utils.getAnimationScale(this.getContext()) FCMPL 0.0f;
        boolean bl4 = false;
        if (f != false) {
            bl4 = true;
        }
        lottieDrawable.setSystemAnimationsAreEnabled(bl4);
    }

    static /* synthetic */ void lambda$static$0(Throwable throwable) {
        if (Utils.isNetworkException(throwable)) {
            Logger.warning("Unable to load composition.", throwable);
            return;
        }
        throw new IllegalStateException("Unable to parse composition", throwable);
    }

    private void setCompositionTask(LottieTask<LottieComposition> lottieTask) {
        this.userActionsTaken.add((Object)UserActionTaken.SET_ANIMATION);
        this.clearComposition();
        this.cancelLoaderTask();
        this.compositionTask = lottieTask.addListener(this.loadedListener).addFailureListener(this.wrappedFailureListener);
    }

    private void setLottieDrawable() {
        boolean bl = this.isAnimating();
        this.setImageDrawable(null);
        this.setImageDrawable(this.lottieDrawable);
        if (bl) {
            this.lottieDrawable.resumeAnimation();
        }
    }

    public void addAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.lottieDrawable.addAnimatorListener(animatorListener);
    }

    public void addAnimatorPauseListener(Animator.AnimatorPauseListener animatorPauseListener) {
        this.lottieDrawable.addAnimatorPauseListener(animatorPauseListener);
    }

    public void addAnimatorUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.lottieDrawable.addAnimatorUpdateListener(animatorUpdateListener);
    }

    public boolean addLottieOnCompositionLoadedListener(LottieOnCompositionLoadedListener lottieOnCompositionLoadedListener) {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            lottieOnCompositionLoadedListener.onCompositionLoaded(lottieComposition);
        }
        return this.lottieOnCompositionLoadedListeners.add((Object)lottieOnCompositionLoadedListener);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, LottieValueCallback<T> lottieValueCallback) {
        this.lottieDrawable.addValueCallback(keyPath, t, lottieValueCallback);
    }

    public <T> void addValueCallback(KeyPath keyPath, T t, final SimpleLottieValueCallback<T> simpleLottieValueCallback) {
        this.lottieDrawable.addValueCallback(keyPath, t, new LottieValueCallback<T>(){

            @Override
            public T getValue(LottieFrameInfo<T> lottieFrameInfo) {
                return simpleLottieValueCallback.getValue(lottieFrameInfo);
            }
        });
    }

    public void cancelAnimation() {
        this.userActionsTaken.add((Object)UserActionTaken.PLAY_OPTION);
        this.lottieDrawable.cancelAnimation();
    }

    @Deprecated
    public void disableExtraScaleModeInFitXY() {
        this.lottieDrawable.disableExtraScaleModeInFitXY();
    }

    public void enableMergePathsForKitKatAndAbove(boolean bl) {
        this.lottieDrawable.enableMergePathsForKitKatAndAbove(bl);
    }

    public boolean getClipToCompositionBounds() {
        return this.lottieDrawable.getClipToCompositionBounds();
    }

    public LottieComposition getComposition() {
        return this.composition;
    }

    public long getDuration() {
        LottieComposition lottieComposition = this.composition;
        if (lottieComposition != null) {
            return (long)lottieComposition.getDuration();
        }
        return 0L;
    }

    public int getFrame() {
        return this.lottieDrawable.getFrame();
    }

    public String getImageAssetsFolder() {
        return this.lottieDrawable.getImageAssetsFolder();
    }

    public boolean getMaintainOriginalImageBounds() {
        return this.lottieDrawable.getMaintainOriginalImageBounds();
    }

    public float getMaxFrame() {
        return this.lottieDrawable.getMaxFrame();
    }

    public float getMinFrame() {
        return this.lottieDrawable.getMinFrame();
    }

    public PerformanceTracker getPerformanceTracker() {
        return this.lottieDrawable.getPerformanceTracker();
    }

    public float getProgress() {
        return this.lottieDrawable.getProgress();
    }

    public RenderMode getRenderMode() {
        return this.lottieDrawable.getRenderMode();
    }

    public int getRepeatCount() {
        return this.lottieDrawable.getRepeatCount();
    }

    public int getRepeatMode() {
        return this.lottieDrawable.getRepeatMode();
    }

    public float getSpeed() {
        return this.lottieDrawable.getSpeed();
    }

    public boolean hasMasks() {
        return this.lottieDrawable.hasMasks();
    }

    public boolean hasMatte() {
        return this.lottieDrawable.hasMatte();
    }

    public void invalidate() {
        super.invalidate();
        Drawable drawable2 = this.getDrawable();
        if (drawable2 instanceof LottieDrawable && ((LottieDrawable)drawable2).getRenderMode() == RenderMode.SOFTWARE) {
            this.lottieDrawable.invalidateSelf();
        }
    }

    public void invalidateDrawable(Drawable drawable2) {
        LottieDrawable lottieDrawable;
        Drawable drawable3 = this.getDrawable();
        if (drawable3 == (lottieDrawable = this.lottieDrawable)) {
            super.invalidateDrawable((Drawable)lottieDrawable);
            return;
        }
        super.invalidateDrawable(drawable2);
    }

    public boolean isAnimating() {
        return this.lottieDrawable.isAnimating();
    }

    public boolean isMergePathsEnabledForKitKatAndAbove() {
        return this.lottieDrawable.isMergePathsEnabledForKitKatAndAbove();
    }

    /* synthetic */ LottieResult lambda$fromAssets$2$com-airbnb-lottie-LottieAnimationView(String string2) throws Exception {
        if (this.cacheComposition) {
            return LottieCompositionFactory.fromAssetSync(this.getContext(), string2);
        }
        return LottieCompositionFactory.fromAssetSync(this.getContext(), string2, null);
    }

    /* synthetic */ LottieResult lambda$fromRawRes$1$com-airbnb-lottie-LottieAnimationView(int n) throws Exception {
        if (this.cacheComposition) {
            return LottieCompositionFactory.fromRawResSync(this.getContext(), n);
        }
        return LottieCompositionFactory.fromRawResSync(this.getContext(), n, null);
    }

    @Deprecated
    public void loop(boolean bl) {
        LottieDrawable lottieDrawable = this.lottieDrawable;
        int n = bl ? -1 : 0;
        lottieDrawable.setRepeatCount(n);
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!this.isInEditMode() && this.autoPlay) {
            this.lottieDrawable.playAnimation();
        }
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        int n;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState)parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.animationName = savedState.animationName;
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_ANIMATION) && !TextUtils.isEmpty((CharSequence)this.animationName)) {
            this.setAnimation(this.animationName);
        }
        this.animationResId = savedState.animationResId;
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_ANIMATION) && (n = this.animationResId) != 0) {
            this.setAnimation(n);
        }
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_PROGRESS)) {
            this.setProgress(savedState.progress);
        }
        if (!this.userActionsTaken.contains((Object)UserActionTaken.PLAY_OPTION) && savedState.isAnimating) {
            this.playAnimation();
        }
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_IMAGE_ASSETS)) {
            this.setImageAssetsFolder(savedState.imageAssetsFolder);
        }
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_REPEAT_MODE)) {
            this.setRepeatMode(savedState.repeatMode);
        }
        if (!this.userActionsTaken.contains((Object)UserActionTaken.SET_REPEAT_COUNT)) {
            this.setRepeatCount(savedState.repeatCount);
        }
    }

    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.animationName = this.animationName;
        savedState.animationResId = this.animationResId;
        savedState.progress = this.lottieDrawable.getProgress();
        savedState.isAnimating = this.lottieDrawable.isAnimatingOrWillAnimateOnVisible();
        savedState.imageAssetsFolder = this.lottieDrawable.getImageAssetsFolder();
        savedState.repeatMode = this.lottieDrawable.getRepeatMode();
        savedState.repeatCount = this.lottieDrawable.getRepeatCount();
        return savedState;
    }

    public void pauseAnimation() {
        this.autoPlay = false;
        this.lottieDrawable.pauseAnimation();
    }

    public void playAnimation() {
        this.userActionsTaken.add((Object)UserActionTaken.PLAY_OPTION);
        this.lottieDrawable.playAnimation();
    }

    public void removeAllAnimatorListeners() {
        this.lottieDrawable.removeAllAnimatorListeners();
    }

    public void removeAllLottieOnCompositionLoadedListener() {
        this.lottieOnCompositionLoadedListeners.clear();
    }

    public void removeAllUpdateListeners() {
        this.lottieDrawable.removeAllUpdateListeners();
    }

    public void removeAnimatorListener(Animator.AnimatorListener animatorListener) {
        this.lottieDrawable.removeAnimatorListener(animatorListener);
    }

    public void removeAnimatorPauseListener(Animator.AnimatorPauseListener animatorPauseListener) {
        this.lottieDrawable.removeAnimatorPauseListener(animatorPauseListener);
    }

    public boolean removeLottieOnCompositionLoadedListener(LottieOnCompositionLoadedListener lottieOnCompositionLoadedListener) {
        return this.lottieOnCompositionLoadedListeners.remove((Object)lottieOnCompositionLoadedListener);
    }

    public void removeUpdateListener(ValueAnimator.AnimatorUpdateListener animatorUpdateListener) {
        this.lottieDrawable.removeAnimatorUpdateListener(animatorUpdateListener);
    }

    public List<KeyPath> resolveKeyPath(KeyPath keyPath) {
        return this.lottieDrawable.resolveKeyPath(keyPath);
    }

    public void resumeAnimation() {
        this.userActionsTaken.add((Object)UserActionTaken.PLAY_OPTION);
        this.lottieDrawable.resumeAnimation();
    }

    public void reverseAnimationSpeed() {
        this.lottieDrawable.reverseAnimationSpeed();
    }

    public void setAnimation(int n) {
        this.animationResId = n;
        this.animationName = null;
        this.setCompositionTask(this.fromRawRes(n));
    }

    public void setAnimation(InputStream inputStream, String string2) {
        this.setCompositionTask(LottieCompositionFactory.fromJsonInputStream(inputStream, string2));
    }

    public void setAnimation(String string2) {
        this.animationName = string2;
        this.animationResId = 0;
        this.setCompositionTask(this.fromAssets(string2));
    }

    @Deprecated
    public void setAnimationFromJson(String string2) {
        this.setAnimationFromJson(string2, null);
    }

    public void setAnimationFromJson(String string2, String string3) {
        this.setAnimation((InputStream)new ByteArrayInputStream(string2.getBytes()), string3);
    }

    public void setAnimationFromUrl(String string2) {
        LottieTask<LottieComposition> lottieTask = this.cacheComposition ? LottieCompositionFactory.fromUrl(this.getContext(), string2) : LottieCompositionFactory.fromUrl(this.getContext(), string2, null);
        this.setCompositionTask(lottieTask);
    }

    public void setAnimationFromUrl(String string2, String string3) {
        this.setCompositionTask(LottieCompositionFactory.fromUrl(this.getContext(), string2, string3));
    }

    public void setApplyingOpacityToLayersEnabled(boolean bl) {
        this.lottieDrawable.setApplyingOpacityToLayersEnabled(bl);
    }

    public void setCacheComposition(boolean bl) {
        this.cacheComposition = bl;
    }

    public void setClipToCompositionBounds(boolean bl) {
        this.lottieDrawable.setClipToCompositionBounds(bl);
    }

    public void setComposition(LottieComposition lottieComposition) {
        if (L.DBG) {
            Log.v((String)TAG, (String)("Set Composition \n" + lottieComposition));
        }
        this.lottieDrawable.setCallback((Drawable.Callback)this);
        this.composition = lottieComposition;
        this.ignoreUnschedule = true;
        boolean bl = this.lottieDrawable.setComposition(lottieComposition);
        this.ignoreUnschedule = false;
        if (this.getDrawable() == this.lottieDrawable && !bl) {
            return;
        }
        if (!bl) {
            this.setLottieDrawable();
        }
        this.onVisibilityChanged((View)this, this.getVisibility());
        this.requestLayout();
        Iterator iterator = this.lottieOnCompositionLoadedListeners.iterator();
        while (iterator.hasNext()) {
            ((LottieOnCompositionLoadedListener)iterator.next()).onCompositionLoaded(lottieComposition);
        }
    }

    public void setFailureListener(LottieListener<Throwable> lottieListener) {
        this.failureListener = lottieListener;
    }

    public void setFallbackResource(int n) {
        this.fallbackResource = n;
    }

    public void setFontAssetDelegate(FontAssetDelegate fontAssetDelegate) {
        this.lottieDrawable.setFontAssetDelegate(fontAssetDelegate);
    }

    public void setFrame(int n) {
        this.lottieDrawable.setFrame(n);
    }

    public void setIgnoreDisabledSystemAnimations(boolean bl) {
        this.lottieDrawable.setIgnoreDisabledSystemAnimations(bl);
    }

    public void setImageAssetDelegate(ImageAssetDelegate imageAssetDelegate) {
        this.lottieDrawable.setImageAssetDelegate(imageAssetDelegate);
    }

    public void setImageAssetsFolder(String string2) {
        this.lottieDrawable.setImagesAssetsFolder(string2);
    }

    public void setImageBitmap(Bitmap bitmap) {
        this.cancelLoaderTask();
        super.setImageBitmap(bitmap);
    }

    public void setImageDrawable(Drawable drawable2) {
        this.cancelLoaderTask();
        super.setImageDrawable(drawable2);
    }

    public void setImageResource(int n) {
        this.cancelLoaderTask();
        super.setImageResource(n);
    }

    public void setMaintainOriginalImageBounds(boolean bl) {
        this.lottieDrawable.setMaintainOriginalImageBounds(bl);
    }

    public void setMaxFrame(int n) {
        this.lottieDrawable.setMaxFrame(n);
    }

    public void setMaxFrame(String string2) {
        this.lottieDrawable.setMaxFrame(string2);
    }

    public void setMaxProgress(float f) {
        this.lottieDrawable.setMaxProgress(f);
    }

    public void setMinAndMaxFrame(int n, int n2) {
        this.lottieDrawable.setMinAndMaxFrame(n, n2);
    }

    public void setMinAndMaxFrame(String string2) {
        this.lottieDrawable.setMinAndMaxFrame(string2);
    }

    public void setMinAndMaxFrame(String string2, String string3, boolean bl) {
        this.lottieDrawable.setMinAndMaxFrame(string2, string3, bl);
    }

    public void setMinAndMaxProgress(float f, float f2) {
        this.lottieDrawable.setMinAndMaxProgress(f, f2);
    }

    public void setMinFrame(int n) {
        this.lottieDrawable.setMinFrame(n);
    }

    public void setMinFrame(String string2) {
        this.lottieDrawable.setMinFrame(string2);
    }

    public void setMinProgress(float f) {
        this.lottieDrawable.setMinProgress(f);
    }

    public void setOutlineMasksAndMattes(boolean bl) {
        this.lottieDrawable.setOutlineMasksAndMattes(bl);
    }

    public void setPerformanceTrackingEnabled(boolean bl) {
        this.lottieDrawable.setPerformanceTrackingEnabled(bl);
    }

    public void setProgress(float f) {
        this.userActionsTaken.add((Object)UserActionTaken.SET_PROGRESS);
        this.lottieDrawable.setProgress(f);
    }

    public void setRenderMode(RenderMode renderMode) {
        this.lottieDrawable.setRenderMode(renderMode);
    }

    public void setRepeatCount(int n) {
        this.userActionsTaken.add((Object)UserActionTaken.SET_REPEAT_COUNT);
        this.lottieDrawable.setRepeatCount(n);
    }

    public void setRepeatMode(int n) {
        this.userActionsTaken.add((Object)UserActionTaken.SET_REPEAT_MODE);
        this.lottieDrawable.setRepeatMode(n);
    }

    public void setSafeMode(boolean bl) {
        this.lottieDrawable.setSafeMode(bl);
    }

    public void setSpeed(float f) {
        this.lottieDrawable.setSpeed(f);
    }

    public void setTextDelegate(TextDelegate textDelegate) {
        this.lottieDrawable.setTextDelegate(textDelegate);
    }

    public void unscheduleDrawable(Drawable drawable2) {
        LottieDrawable lottieDrawable;
        LottieDrawable lottieDrawable2;
        if (!this.ignoreUnschedule && drawable2 == (lottieDrawable = this.lottieDrawable) && lottieDrawable.isAnimating()) {
            this.pauseAnimation();
        } else if (!this.ignoreUnschedule && drawable2 instanceof LottieDrawable && (lottieDrawable2 = (LottieDrawable)drawable2).isAnimating()) {
            lottieDrawable2.pauseAnimation();
        }
        super.unscheduleDrawable(drawable2);
    }

    public Bitmap updateBitmap(String string2, Bitmap bitmap) {
        return this.lottieDrawable.updateBitmap(string2, bitmap);
    }

    private static class SavedState
    extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>(){

            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel);
            }

            public SavedState[] newArray(int n) {
                return new SavedState[n];
            }
        };
        String animationName;
        int animationResId;
        String imageAssetsFolder;
        boolean isAnimating;
        float progress;
        int repeatCount;
        int repeatMode;

        private SavedState(Parcel parcel) {
            super(parcel);
            this.animationName = parcel.readString();
            this.progress = parcel.readFloat();
            int n = parcel.readInt();
            int n2 = 1;
            if (n != n2) {
                n2 = 0;
            }
            this.isAnimating = n2;
            this.imageAssetsFolder = parcel.readString();
            this.repeatMode = parcel.readInt();
            this.repeatCount = parcel.readInt();
        }

        SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n) {
            super.writeToParcel(parcel, n);
            parcel.writeString(this.animationName);
            parcel.writeFloat(this.progress);
            parcel.writeInt((int)this.isAnimating);
            parcel.writeString(this.imageAssetsFolder);
            parcel.writeInt(this.repeatMode);
            parcel.writeInt(this.repeatCount);
        }

    }

    private static final class UserActionTaken
    extends Enum<UserActionTaken> {
        private static final /* synthetic */ UserActionTaken[] $VALUES;
        public static final /* enum */ UserActionTaken PLAY_OPTION;
        public static final /* enum */ UserActionTaken SET_ANIMATION;
        public static final /* enum */ UserActionTaken SET_IMAGE_ASSETS;
        public static final /* enum */ UserActionTaken SET_PROGRESS;
        public static final /* enum */ UserActionTaken SET_REPEAT_COUNT;
        public static final /* enum */ UserActionTaken SET_REPEAT_MODE;

        static {
            UserActionTaken userActionTaken;
            UserActionTaken userActionTaken2;
            UserActionTaken userActionTaken3;
            UserActionTaken userActionTaken4;
            UserActionTaken userActionTaken5;
            UserActionTaken userActionTaken6;
            SET_ANIMATION = userActionTaken2 = new UserActionTaken();
            SET_PROGRESS = userActionTaken6 = new UserActionTaken();
            SET_REPEAT_MODE = userActionTaken = new UserActionTaken();
            SET_REPEAT_COUNT = userActionTaken5 = new UserActionTaken();
            SET_IMAGE_ASSETS = userActionTaken4 = new UserActionTaken();
            PLAY_OPTION = userActionTaken3 = new UserActionTaken();
            $VALUES = new UserActionTaken[]{userActionTaken2, userActionTaken6, userActionTaken, userActionTaken5, userActionTaken4, userActionTaken3};
        }

        public static UserActionTaken valueOf(String string2) {
            return (UserActionTaken)Enum.valueOf(UserActionTaken.class, (String)string2);
        }

        public static UserActionTaken[] values() {
            return (UserActionTaken[])$VALUES.clone();
        }
    }

}

