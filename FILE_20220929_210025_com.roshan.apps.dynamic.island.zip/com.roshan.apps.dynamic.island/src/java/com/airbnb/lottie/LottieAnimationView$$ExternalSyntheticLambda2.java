/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieListener;

public final class LottieAnimationView$$ExternalSyntheticLambda2
implements LottieListener {
    public final void onResult(Object object) {
        LottieAnimationView.lambda$static$0((Throwable)object);
    }
}

