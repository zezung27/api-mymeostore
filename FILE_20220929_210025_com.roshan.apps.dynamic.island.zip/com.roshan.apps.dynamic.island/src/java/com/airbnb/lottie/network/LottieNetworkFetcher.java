/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 */
package com.airbnb.lottie.network;

import com.airbnb.lottie.network.LottieFetchResult;
import java.io.IOException;

public interface LottieNetworkFetcher {
    public LottieFetchResult fetchSync(String var1) throws IOException;
}

