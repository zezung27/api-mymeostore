/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.concurrent.Callable
 */
package com.airbnb.lottie;

import android.content.Context;
import com.airbnb.lottie.LottieCompositionFactory;
import java.lang.ref.WeakReference;
import java.util.concurrent.Callable;

public final class LottieCompositionFactory$$ExternalSyntheticLambda1
implements Callable {
    public final /* synthetic */ WeakReference f$0;
    public final /* synthetic */ Context f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ String f$3;

    public /* synthetic */ LottieCompositionFactory$$ExternalSyntheticLambda1(WeakReference weakReference, Context context, int n, String string2) {
        this.f$0 = weakReference;
        this.f$1 = context;
        this.f$2 = n;
        this.f$3 = string2;
    }

    public final Object call() {
        return LottieCompositionFactory.lambda$fromRawRes$2(this.f$0, this.f$1, this.f$2, this.f$3);
    }
}

