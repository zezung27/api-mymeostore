/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;

@Deprecated
public interface OnCompositionLoadedListener {
    public void onCompositionLoaded(LottieComposition var1);
}

