/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

public final class LottieDrawable$$ExternalSyntheticLambda6
implements LottieDrawable.LazyCompositionTask {
    public final /* synthetic */ LottieDrawable f$0;
    public final /* synthetic */ float f$1;
    public final /* synthetic */ float f$2;

    public /* synthetic */ LottieDrawable$$ExternalSyntheticLambda6(LottieDrawable lottieDrawable, float f, float f2) {
        this.f$0 = lottieDrawable;
        this.f$1 = f;
        this.f$2 = f2;
    }

    @Override
    public final void run(LottieComposition lottieComposition) {
        this.f$0.lambda$setMinAndMaxProgress$11$com-airbnb-lottie-LottieDrawable(this.f$1, this.f$2, lottieComposition);
    }
}

