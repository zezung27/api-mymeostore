/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.airbnb.lottie;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieListener;

public final class LottieAnimationView$$ExternalSyntheticLambda1
implements LottieListener {
    public final /* synthetic */ LottieAnimationView f$0;

    public /* synthetic */ LottieAnimationView$$ExternalSyntheticLambda1(LottieAnimationView lottieAnimationView) {
        this.f$0 = lottieAnimationView;
    }

    public final void onResult(Object object) {
        this.f$0.setComposition((LottieComposition)object);
    }
}

