/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Paint$Align
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Region$Op
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewParent
 *  androidx.core.content.ContextCompat
 *  java.io.PrintStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package com.boxedverticalseekbar;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import androidx.core.content.ContextCompat;
import com.lock.R;
import java.io.PrintStream;

public class BoxedVertical
extends View {
    private static final int MAX = 100;
    private static final int MIN = 0;
    private static final String TAG = "BoxedVertical";
    private int backgroundColor;
    private Rect dRect = new Rect();
    private boolean firstRun = true;
    private int mCornerRadius = 10;
    private Bitmap mDefaultImage;
    private int mDefaultValue;
    private boolean mEnabled = true;
    private boolean mImageEnabled = false;
    private int mMax = 100;
    private Bitmap mMaxImage;
    private int mMin = 0;
    private Bitmap mMinImage;
    private OnValuesChangeListener mOnValuesChangeListener;
    private int mPoints;
    private Paint mProgressPaint;
    private float mProgressSweep = 0.0f;
    private int mStep = 10;
    private Paint mTextPaint;
    private float mTextSize = 26.0f;
    private boolean mTouchDisabled = true;
    private int mtextBottomPadding = 20;
    private boolean mtextEnabled = true;
    private int scrHeight;
    private int scrWidth;

    public BoxedVertical(Context context) {
        super(context);
        this.init(context, null);
    }

    public BoxedVertical(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.init(context, attributeSet);
    }

    private double convertTouchEventPoint(float f) {
        int n = this.scrHeight;
        if (f > (float)(n * 2)) {
            return n * 2;
        }
        if (f < 0.0f) {
            f = 0.0f;
        }
        return f;
    }

    private void drawIcon(Bitmap bitmap, Canvas canvas) {
        Bitmap bitmap2 = this.getResizedBitmap(bitmap, canvas.getWidth() / 2, canvas.getWidth() / 2);
        canvas.drawBitmap(bitmap2, null, new RectF((float)(canvas.getWidth() / 2 - bitmap2.getWidth() / 2), (float)(canvas.getHeight() - bitmap2.getHeight()), (float)(canvas.getWidth() / 3 + bitmap2.getWidth()), (float)canvas.getHeight()), null);
    }

    private void drawText(Canvas canvas, Paint paint, String string2) {
        canvas.getClipBounds(this.dRect);
        int n = this.dRect.width();
        paint.setTextAlign(Paint.Align.LEFT);
        paint.getTextBounds(string2, 0, string2.length(), this.dRect);
        canvas.drawText(string2, (float)n / 2.0f - (float)this.dRect.width() / 2.0f - (float)this.dRect.left, (float)(canvas.getHeight() - this.mtextBottomPadding), paint);
    }

    private Bitmap getResizedBitmap(Bitmap bitmap, int n, int n2) {
        int n3 = bitmap.getWidth();
        int n4 = bitmap.getHeight();
        float f = (float)n2 / (float)n3;
        float f2 = (float)n / (float)n4;
        Matrix matrix = new Matrix();
        matrix.postScale(f, f2);
        return Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)n3, (int)n4, (Matrix)matrix, (boolean)false);
    }

    private void init(Context context, AttributeSet attributeSet) {
        int n;
        int n2;
        Paint paint;
        Paint paint2;
        System.out.println("INIT");
        float f = this.getResources().getDisplayMetrics().density;
        int n3 = ContextCompat.getColor((Context)context, (int)2131099767);
        this.backgroundColor = ContextCompat.getColor((Context)context, (int)2131099766);
        this.backgroundColor = ContextCompat.getColor((Context)context, (int)2131099766);
        int n4 = ContextCompat.getColor((Context)context, (int)2131099768);
        this.mTextSize = (int)(f * this.mTextSize);
        this.mDefaultValue = this.mMax / 2;
        if (attributeSet != null) {
            boolean bl;
            TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.BoxedVertical, 0, 0);
            this.mPoints = typedArray.getInteger(11, this.mPoints);
            this.mMax = typedArray.getInteger(8, this.mMax);
            this.mMin = typedArray.getInteger(2, this.mMin);
            this.mStep = typedArray.getInteger(13, this.mStep);
            this.mDefaultValue = typedArray.getInteger(1, this.mDefaultValue);
            this.mCornerRadius = typedArray.getInteger(7, this.mCornerRadius);
            this.mtextBottomPadding = typedArray.getInteger(14, this.mtextBottomPadding);
            this.mImageEnabled = bl = typedArray.getBoolean(6, this.mImageEnabled);
            if (bl) {
                this.mDefaultImage = ((BitmapDrawable)typedArray.getDrawable(4)).getBitmap();
                this.mMinImage = ((BitmapDrawable)typedArray.getDrawable(10)).getBitmap();
                this.mMaxImage = ((BitmapDrawable)typedArray.getDrawable(9)).getBitmap();
            }
            n3 = typedArray.getColor(12, n3);
            this.backgroundColor = typedArray.getColor(0, this.backgroundColor);
            this.mTextSize = (int)typedArray.getDimension(17, this.mTextSize);
            n4 = typedArray.getColor(15, n4);
            this.mEnabled = typedArray.getBoolean(5, this.mEnabled);
            this.mTouchDisabled = typedArray.getBoolean(18, this.mTouchDisabled);
            this.mtextEnabled = typedArray.getBoolean(16, this.mtextEnabled);
            this.mPoints = this.mDefaultValue;
            typedArray.recycle();
        }
        if ((n = this.mPoints) > (n2 = this.mMax)) {
            n = n2;
        }
        this.mPoints = n;
        int n5 = this.mMin;
        if (n < n5) {
            n = n5;
        }
        this.mPoints = n;
        this.mProgressPaint = paint2 = new Paint();
        paint2.setColor(n3);
        this.mProgressPaint.setAntiAlias(true);
        this.mProgressPaint.setStyle(Paint.Style.STROKE);
        this.mTextPaint = paint = new Paint();
        paint.setColor(n4);
        this.mTextPaint.setAntiAlias(true);
        this.mTextPaint.setStyle(Paint.Style.FILL);
        this.mTextPaint.setTextSize(this.mTextSize);
        this.scrHeight = context.getResources().getDisplayMetrics().heightPixels;
    }

    private void updateOnTouch(MotionEvent motionEvent) {
        this.setPressed(true);
        this.updateProgress((int)Math.round((double)this.convertTouchEventPoint(motionEvent.getY())));
    }

    private void updateProgress(int n) {
        OnValuesChangeListener onValuesChangeListener;
        int n2;
        this.mProgressSweep = n;
        int n3 = this.scrHeight;
        if (n > n3) {
            n = n3;
        }
        if (n < 0) {
            n = 0;
        }
        int n4 = this.mMax;
        int n5 = this.mMin;
        int n6 = n5 + n * (n4 - n5) / n3;
        this.mPoints = n2 = n4 + n5 - n6;
        if (n2 != n4 && n2 != n5) {
            int n7 = this.mStep;
            this.mPoints = n2 - n2 % n7 + n5 % n7;
        }
        if ((onValuesChangeListener = this.mOnValuesChangeListener) != null) {
            onValuesChangeListener.onPointsChanged(this, this.mPoints);
        }
        this.invalidate();
    }

    private void updateProgressByValue(int n) {
        this.mPoints = n;
        int n2 = this.mMax;
        if (n > n2) {
            n = n2;
        }
        this.mPoints = n;
        int n3 = this.mMin;
        if (n < n3) {
            n = n3;
        }
        this.mPoints = n;
        int n4 = n - n3;
        int n5 = this.scrHeight;
        float f = n4 * n5 / (n2 - n3);
        this.mProgressSweep = (float)n5 - f;
        OnValuesChangeListener onValuesChangeListener = this.mOnValuesChangeListener;
        if (onValuesChangeListener != null) {
            onValuesChangeListener.onPointsChanged(this, n);
        }
        this.invalidate();
    }

    public int getCornerRadius() {
        return this.mCornerRadius;
    }

    public int getDefaultValue() {
        return this.mDefaultValue;
    }

    public int getMax() {
        return this.mMax;
    }

    public int getStep() {
        return this.mStep;
    }

    public int getValue() {
        return this.mPoints;
    }

    public boolean isEnabled() {
        return this.mEnabled;
    }

    public boolean isImageEnabled() {
        return this.mImageEnabled;
    }

    protected void onDraw(Canvas canvas) {
        Bitmap bitmap;
        Bitmap bitmap2;
        Bitmap bitmap3;
        Paint paint = new Paint();
        paint.setAlpha(255);
        canvas.translate(0.0f, 0.0f);
        Path path = new Path();
        RectF rectF = new RectF(0.0f, 0.0f, (float)this.scrWidth, (float)this.scrHeight);
        int n = this.mCornerRadius;
        path.addRoundRect(rectF, (float)n, (float)n, Path.Direction.CCW);
        canvas.clipPath(path, Region.Op.INTERSECT);
        paint.setColor(this.backgroundColor);
        paint.setAntiAlias(true);
        canvas.drawRect(0.0f, 0.0f, (float)this.scrWidth, (float)this.scrHeight, paint);
        canvas.drawLine((float)(canvas.getWidth() / 2), (float)canvas.getHeight(), (float)(canvas.getWidth() / 2), this.mProgressSweep, this.mProgressPaint);
        if (this.mImageEnabled && (bitmap = this.mDefaultImage) != null && (bitmap3 = this.mMinImage) != null && (bitmap2 = this.mMaxImage) != null) {
            int n2 = this.mPoints;
            if (n2 == this.mMax) {
                this.drawIcon(bitmap2, canvas);
            } else if (n2 == this.mMin) {
                this.drawIcon(bitmap3, canvas);
            } else {
                this.drawIcon(bitmap, canvas);
            }
        } else if (this.mtextEnabled) {
            String string2 = String.valueOf((int)this.mPoints);
            this.drawText(canvas, this.mTextPaint, string2);
        }
        if (this.firstRun) {
            this.firstRun = false;
            this.setValue(this.mPoints);
        }
    }

    protected void onMeasure(int n, int n2) {
        this.scrWidth = BoxedVertical.getDefaultSize((int)this.getSuggestedMinimumWidth(), (int)n);
        this.scrHeight = BoxedVertical.getDefaultSize((int)this.getSuggestedMinimumHeight(), (int)n2);
        this.mProgressPaint.setStrokeWidth((float)this.scrWidth);
        super.onMeasure(n, n2);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.mEnabled) {
            this.getParent().requestDisallowInterceptTouchEvent(true);
            int n = motionEvent.getAction();
            if (n != 0) {
                if (n != 1) {
                    if (n != 2) {
                        if (n != 3) {
                            return true;
                        }
                        OnValuesChangeListener onValuesChangeListener = this.mOnValuesChangeListener;
                        if (onValuesChangeListener != null) {
                            onValuesChangeListener.onStopTrackingTouch(this);
                        }
                        this.setPressed(false);
                        this.getParent().requestDisallowInterceptTouchEvent(false);
                        return true;
                    }
                    this.updateOnTouch(motionEvent);
                    return true;
                }
                OnValuesChangeListener onValuesChangeListener = this.mOnValuesChangeListener;
                if (onValuesChangeListener != null) {
                    onValuesChangeListener.onStopTrackingTouch(this);
                }
                this.setPressed(false);
                this.getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
            OnValuesChangeListener onValuesChangeListener = this.mOnValuesChangeListener;
            if (onValuesChangeListener != null) {
                onValuesChangeListener.onStartTrackingTouch(this);
            }
            if (!this.mTouchDisabled) {
                this.updateOnTouch(motionEvent);
            }
            return true;
        }
        return false;
    }

    public void setCornerRadius(int n) {
        this.mCornerRadius = n;
        this.invalidate();
    }

    public void setDefaultValue(int n) {
        if (n <= this.mMax) {
            this.mDefaultValue = n;
            return;
        }
        throw new IllegalArgumentException("Default value should not be bigger than max value.");
    }

    public void setEnabled(boolean bl) {
        this.mEnabled = bl;
    }

    public void setImageEnabled(boolean bl) {
        this.mImageEnabled = bl;
    }

    public void setMax(int n) {
        if (n > this.mMin) {
            this.mMax = n;
            return;
        }
        throw new IllegalArgumentException("Max should not be less than zero");
    }

    public void setOnBoxedPointsChangeListener(OnValuesChangeListener onValuesChangeListener) {
        this.mOnValuesChangeListener = onValuesChangeListener;
    }

    public void setStep(int n) {
        this.mStep = n;
    }

    public void setValue(int n) {
        int n2;
        int n3 = this.mMax;
        if (n > n3) {
            n = n3;
        }
        if (n < (n2 = this.mMin)) {
            n = n2;
        }
        this.updateProgressByValue(n);
    }

    public static interface OnValuesChangeListener {
        public void onPointsChanged(BoxedVertical var1, int var2);

        public void onStartTrackingTouch(BoxedVertical var1);

        public void onStopTrackingTouch(BoxedVertical var1);
    }

}

