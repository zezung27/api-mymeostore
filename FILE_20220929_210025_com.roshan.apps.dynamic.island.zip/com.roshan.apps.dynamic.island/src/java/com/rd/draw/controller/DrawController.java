/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.view.MotionEvent
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 */
package com.rd.draw.controller;

import android.graphics.Canvas;
import android.view.MotionEvent;
import com.rd.animation.data.Value;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Indicator;
import com.rd.draw.drawer.Drawer;
import com.rd.utils.CoordinatesUtils;

public class DrawController {
    private Drawer drawer;
    private Indicator indicator;
    private ClickListener listener;
    private Value value;

    public DrawController(Indicator indicator) {
        this.indicator = indicator;
        this.drawer = new Drawer(indicator);
    }

    private void drawIndicator(Canvas canvas, int n, int n2, int n3) {
        boolean bl = this.indicator.isInteractiveAnimation();
        int n4 = this.indicator.getSelectedPosition();
        int n5 = this.indicator.getSelectingPosition();
        int n6 = this.indicator.getLastSelectedPosition();
        boolean bl2 = true;
        boolean bl3 = !bl && (n == n4 || n == n6) ? bl2 : false;
        if (!bl || n != n4 && n != n5) {
            bl2 = false;
        }
        boolean bl4 = bl3 | bl2;
        this.drawer.setup(n, n2, n3);
        if (this.value != null && bl4) {
            this.drawWithAnimation(canvas);
            return;
        }
        this.drawer.drawBasic(canvas, bl4);
    }

    private void drawWithAnimation(Canvas canvas) {
        AnimationType animationType = this.indicator.getAnimationType();
        switch (1.$SwitchMap$com$rd$animation$type$AnimationType[animationType.ordinal()]) {
            default: {
                return;
            }
            case 10: {
                this.drawer.drawScaleDown(canvas, this.value);
                return;
            }
            case 9: {
                this.drawer.drawSwap(canvas, this.value);
                return;
            }
            case 8: {
                this.drawer.drawDrop(canvas, this.value);
                return;
            }
            case 7: {
                this.drawer.drawThinWorm(canvas, this.value);
                return;
            }
            case 6: {
                this.drawer.drawFill(canvas, this.value);
                return;
            }
            case 5: {
                this.drawer.drawSlide(canvas, this.value);
                return;
            }
            case 4: {
                this.drawer.drawWorm(canvas, this.value);
                return;
            }
            case 3: {
                this.drawer.drawScale(canvas, this.value);
                return;
            }
            case 2: {
                this.drawer.drawColor(canvas, this.value);
                return;
            }
            case 1: 
        }
        this.drawer.drawBasic(canvas, true);
    }

    private void onIndicatorTouched(float f, float f2) {
        int n;
        if (this.listener != null && (n = CoordinatesUtils.getPosition(this.indicator, f, f2)) >= 0) {
            this.listener.onIndicatorClicked(n);
        }
    }

    public void draw(Canvas canvas) {
        int n = this.indicator.getCount();
        for (int i = 0; i < n; ++i) {
            this.drawIndicator(canvas, i, CoordinatesUtils.getXCoordinate(this.indicator, i), CoordinatesUtils.getYCoordinate(this.indicator, i));
        }
    }

    public void setClickListener(ClickListener clickListener) {
        this.listener = clickListener;
    }

    public void touch(MotionEvent motionEvent) {
        if (motionEvent == null) {
            return;
        }
        if (motionEvent.getAction() != 1) {
            return;
        }
        this.onIndicatorTouched(motionEvent.getX(), motionEvent.getY());
    }

    public void updateValue(Value value) {
        this.value = value;
    }

    public static interface ClickListener {
        public void onIndicatorClicked(int var1);
    }

}

