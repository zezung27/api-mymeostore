/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.Color
 *  android.util.AttributeSet
 *  java.lang.Object
 *  java.lang.String
 */
package com.rd.draw.controller;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.util.AttributeSet;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Indicator;
import com.rd.draw.data.Orientation;
import com.rd.draw.data.RtlMode;
import com.rd.pageindicatorview.R;
import com.rd.utils.DensityUtils;

public class AttributeController {
    private static final int DEFAULT_IDLE_DURATION = 3000;
    private Indicator indicator;

    public AttributeController(Indicator indicator) {
        this.indicator = indicator;
    }

    private AnimationType getAnimationType(int n) {
        switch (n) {
            default: {
                return AnimationType.NONE;
            }
            case 9: {
                return AnimationType.SCALE_DOWN;
            }
            case 8: {
                return AnimationType.SWAP;
            }
            case 7: {
                return AnimationType.DROP;
            }
            case 6: {
                return AnimationType.THIN_WORM;
            }
            case 5: {
                return AnimationType.FILL;
            }
            case 4: {
                return AnimationType.SLIDE;
            }
            case 3: {
                return AnimationType.WORM;
            }
            case 2: {
                return AnimationType.SCALE;
            }
            case 1: {
                return AnimationType.COLOR;
            }
            case 0: 
        }
        return AnimationType.NONE;
    }

    private RtlMode getRtlMode(int n) {
        if (n != 0) {
            if (n != 1) {
                if (n != 2) {
                    return RtlMode.Auto;
                }
                return RtlMode.Auto;
            }
            return RtlMode.Off;
        }
        return RtlMode.On;
    }

    private void initAnimationAttribute(TypedArray typedArray) {
        boolean bl = typedArray.getBoolean(R.styleable.PageIndicatorView_piv_interactiveAnimation, false);
        long l = typedArray.getInt(R.styleable.PageIndicatorView_piv_animationDuration, 350);
        if (l < 0L) {
            l = 0L;
        }
        AnimationType animationType = this.getAnimationType(typedArray.getInt(R.styleable.PageIndicatorView_piv_animationType, AnimationType.NONE.ordinal()));
        RtlMode rtlMode = this.getRtlMode(typedArray.getInt(R.styleable.PageIndicatorView_piv_rtl_mode, RtlMode.Off.ordinal()));
        boolean bl2 = typedArray.getBoolean(R.styleable.PageIndicatorView_piv_fadeOnIdle, false);
        long l2 = typedArray.getInt(R.styleable.PageIndicatorView_piv_idleDuration, 3000);
        this.indicator.setAnimationDuration(l);
        this.indicator.setInteractiveAnimation(bl);
        this.indicator.setAnimationType(animationType);
        this.indicator.setRtlMode(rtlMode);
        this.indicator.setFadeOnIdle(bl2);
        this.indicator.setIdleDuration(l2);
    }

    private void initColorAttribute(TypedArray typedArray) {
        int n = typedArray.getColor(R.styleable.PageIndicatorView_piv_unselectedColor, Color.parseColor((String)"#33ffffff"));
        int n2 = typedArray.getColor(R.styleable.PageIndicatorView_piv_selectedColor, Color.parseColor((String)"#ffffff"));
        this.indicator.setUnselectedColor(n);
        this.indicator.setSelectedColor(n2);
    }

    private void initCountAttribute(TypedArray typedArray) {
        int n;
        int n2;
        int n3 = typedArray.getResourceId(R.styleable.PageIndicatorView_piv_viewPager, -1);
        boolean bl = typedArray.getBoolean(R.styleable.PageIndicatorView_piv_autoVisibility, true);
        boolean bl2 = typedArray.getBoolean(R.styleable.PageIndicatorView_piv_dynamicCount, false);
        int n4 = typedArray.getInt(R.styleable.PageIndicatorView_piv_count, -1);
        if (n4 == -1) {
            n4 = 3;
        }
        if ((n2 = typedArray.getInt(R.styleable.PageIndicatorView_piv_select, 0)) < 0) {
            n = 0;
        } else if (n4 <= 0 || n2 <= (n = n4 - 1)) {
            n = n2;
        }
        this.indicator.setViewPagerId(n3);
        this.indicator.setAutoVisibility(bl);
        this.indicator.setDynamicCount(bl2);
        this.indicator.setCount(n4);
        this.indicator.setSelectedPosition(n);
        this.indicator.setSelectingPosition(n);
        this.indicator.setLastSelectedPosition(n);
    }

    private void initSizeAttribute(TypedArray typedArray) {
        float f;
        int n;
        Orientation orientation = typedArray.getInt(R.styleable.PageIndicatorView_piv_orientation, Orientation.HORIZONTAL.ordinal()) == 0 ? Orientation.HORIZONTAL : Orientation.VERTICAL;
        int n2 = (int)typedArray.getDimension(R.styleable.PageIndicatorView_piv_radius, (float)DensityUtils.dpToPx(6));
        if (n2 < 0) {
            n2 = 0;
        }
        if ((n = (int)typedArray.getDimension(R.styleable.PageIndicatorView_piv_padding, (float)DensityUtils.dpToPx(8))) < 0) {
            n = 0;
        }
        if ((f = typedArray.getFloat(R.styleable.PageIndicatorView_piv_scaleFactor, 0.7f)) < 0.3f) {
            f = 0.3f;
        } else if (f > 1.0f) {
            f = 1.0f;
        }
        int n3 = (int)typedArray.getDimension(R.styleable.PageIndicatorView_piv_strokeWidth, (float)DensityUtils.dpToPx(1));
        if (n3 > n2) {
            n3 = n2;
        }
        int n4 = this.indicator.getAnimationType() != AnimationType.FILL ? 0 : n3;
        this.indicator.setRadius(n2);
        this.indicator.setOrientation(orientation);
        this.indicator.setPadding(n);
        this.indicator.setScaleFactor(f);
        this.indicator.setStroke(n4);
    }

    public void init(Context context, AttributeSet attributeSet) {
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, R.styleable.PageIndicatorView, 0, 0);
        this.initCountAttribute(typedArray);
        this.initColorAttribute(typedArray);
        this.initAnimationAttribute(typedArray);
        this.initSizeAttribute(typedArray);
        typedArray.recycle();
    }
}

