/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.rd.draw.data;

public final class Orientation
extends Enum<Orientation> {
    private static final /* synthetic */ Orientation[] $VALUES;
    public static final /* enum */ Orientation HORIZONTAL;
    public static final /* enum */ Orientation VERTICAL;

    static {
        Orientation orientation;
        Orientation orientation2;
        HORIZONTAL = orientation2 = new Orientation();
        VERTICAL = orientation = new Orientation();
        $VALUES = new Orientation[]{orientation2, orientation};
    }

    public static Orientation valueOf(String string2) {
        return (Orientation)Enum.valueOf(Orientation.class, (String)string2);
    }

    public static Orientation[] values() {
        return (Orientation[])$VALUES.clone();
    }
}

