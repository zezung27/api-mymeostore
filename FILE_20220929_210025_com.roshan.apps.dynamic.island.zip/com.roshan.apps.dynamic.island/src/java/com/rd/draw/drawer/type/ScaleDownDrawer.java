/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Paint
 */
package com.rd.draw.drawer.type;

import android.graphics.Canvas;
import android.graphics.Paint;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.ScaleAnimationValue;
import com.rd.draw.data.Indicator;
import com.rd.draw.drawer.type.BaseDrawer;

public class ScaleDownDrawer
extends BaseDrawer {
    public ScaleDownDrawer(Paint paint, Indicator indicator) {
        super(paint, indicator);
    }

    public void draw(Canvas canvas, Value value, int n, int n2, int n3) {
        if (!(value instanceof ScaleAnimationValue)) {
            return;
        }
        ScaleAnimationValue scaleAnimationValue = (ScaleAnimationValue)value;
        float f = this.indicator.getRadius();
        int n4 = this.indicator.getSelectedColor();
        int n5 = this.indicator.getSelectedPosition();
        int n6 = this.indicator.getSelectingPosition();
        int n7 = this.indicator.getLastSelectedPosition();
        if (this.indicator.isInteractiveAnimation()) {
            if (n == n6) {
                f = scaleAnimationValue.getRadius();
                n4 = scaleAnimationValue.getColor();
            } else if (n == n5) {
                f = scaleAnimationValue.getRadiusReverse();
                n4 = scaleAnimationValue.getColorReverse();
            }
        } else if (n == n5) {
            f = scaleAnimationValue.getRadius();
            n4 = scaleAnimationValue.getColor();
        } else if (n == n7) {
            f = scaleAnimationValue.getRadiusReverse();
            n4 = scaleAnimationValue.getColorReverse();
        }
        this.paint.setColor(n4);
        canvas.drawCircle((float)n2, (float)n3, f, this.paint);
    }
}

