/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.AnimatorSet
 *  android.animation.PropertyValuesHolder
 *  android.animation.TimeInterpolator
 *  android.animation.ValueAnimator
 *  android.animation.ValueAnimator$AnimatorUpdateListener
 *  android.view.animation.AccelerateDecelerateInterpolator
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.rd.animation.type;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;
import com.rd.animation.controller.ValueController;
import com.rd.animation.data.Value;
import com.rd.animation.data.type.ThinWormAnimationValue;
import com.rd.animation.data.type.WormAnimationValue;
import com.rd.animation.type.BaseAnimation;
import com.rd.animation.type.ThinWormAnimation;
import com.rd.animation.type.WormAnimation;
import java.util.ArrayList;

public class ThinWormAnimation
extends WormAnimation {
    private ThinWormAnimationValue value = new ThinWormAnimationValue();

    public ThinWormAnimation(ValueController.UpdateListener updateListener) {
        super(updateListener);
    }

    static /* synthetic */ void access$000(ThinWormAnimation thinWormAnimation, ValueAnimator valueAnimator) {
        thinWormAnimation.onAnimateUpdated(valueAnimator);
    }

    private ValueAnimator createHeightAnimator(int n, int n2, long l) {
        ValueAnimator valueAnimator = ValueAnimator.ofInt((int[])new int[]{n, n2});
        valueAnimator.setInterpolator((TimeInterpolator)new AccelerateDecelerateInterpolator());
        valueAnimator.setDuration(l);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this){
            final /* synthetic */ ThinWormAnimation this$0;
            {
                this.this$0 = thinWormAnimation;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                ThinWormAnimation.access$000(this.this$0, valueAnimator);
            }
        });
        return valueAnimator;
    }

    private void onAnimateUpdated(ValueAnimator valueAnimator) {
        this.value.setHeight((Integer)valueAnimator.getAnimatedValue());
        if (this.listener != null) {
            this.listener.onValueUpdated(this.value);
        }
    }

    @Override
    public ThinWormAnimation duration(long l) {
        super.duration(l);
        return this;
    }

    @Override
    public ThinWormAnimation progress(float f) {
        if (this.animator != null) {
            long l = (long)(f * (float)this.animationDuration);
            int n = ((AnimatorSet)this.animator).getChildAnimations().size();
            for (int i = 0; i < n; ++i) {
                long l2;
                ValueAnimator valueAnimator = (ValueAnimator)((AnimatorSet)this.animator).getChildAnimations().get(i);
                long l3 = l - valueAnimator.getStartDelay();
                if (l3 > (l2 = valueAnimator.getDuration())) {
                    l3 = l2;
                } else if (l3 < 0L) {
                    l3 = 0L;
                }
                if (i == n - 1 && l3 <= 0L || valueAnimator.getValues() == null || valueAnimator.getValues().length <= 0) continue;
                valueAnimator.setCurrentPlayTime(l3);
            }
        }
        return this;
    }

    @Override
    public WormAnimation with(int n, int n2, int n3, boolean bl) {
        if (this.hasChanges(n, n2, n3, bl)) {
            this.animator = this.createAnimator();
            this.coordinateStart = n;
            this.coordinateEnd = n2;
            this.radius = n3;
            this.isRightSide = bl;
            int n4 = n3 * 2;
            this.rectLeftEdge = n - n3;
            this.rectRightEdge = n + n3;
            this.value.setRectStart(this.rectLeftEdge);
            this.value.setRectEnd(this.rectRightEdge);
            this.value.setHeight(n4);
            WormAnimation.RectValues rectValues = this.createRectValues(bl);
            long l = (long)(0.8 * (double)this.animationDuration);
            long l2 = (long)(0.2 * (double)this.animationDuration);
            long l3 = (long)(0.5 * (double)this.animationDuration);
            long l4 = (long)(0.5 * (double)this.animationDuration);
            ValueAnimator valueAnimator = this.createWormAnimator(rectValues.fromX, rectValues.toX, l, false, this.value);
            ValueAnimator valueAnimator2 = this.createWormAnimator(rectValues.reverseFromX, rectValues.reverseToX, l, true, this.value);
            valueAnimator2.setStartDelay(l2);
            ValueAnimator valueAnimator3 = this.createHeightAnimator(n4, n3, l3);
            ValueAnimator valueAnimator4 = this.createHeightAnimator(n3, n4, l3);
            valueAnimator4.setStartDelay(l4);
            ((AnimatorSet)this.animator).playTogether(new Animator[]{valueAnimator, valueAnimator2, valueAnimator3, valueAnimator4});
        }
        return this;
    }
}

